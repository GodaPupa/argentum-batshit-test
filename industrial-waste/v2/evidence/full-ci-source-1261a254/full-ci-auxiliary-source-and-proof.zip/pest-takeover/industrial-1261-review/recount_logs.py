"""Read-only independent recount; does not run any engine, tests or network requests."""
from pathlib import Path
import collections, hashlib, json, re, zipfile

ROOT = Path('/workspace/scratch/94f5141e9448')
OUT = ROOT / 'pest-takeover/industrial-1261-review'
SRC = ROOT / 'industrial/audit-1261'
sha = lambda b: hashlib.sha256(b).hexdigest()

def parse(raw):
    text = raw.decode('utf-8')
    rows=[]; tasks=[]; skipped_task_lines=[]; ok=[]; builds=[]; errors=[]
    for original in text.splitlines():
        line = re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ?', '', original)
        line = re.sub(r'\x1b\[[0-9;]*m', '', line)
        task = re.fullmatch(r'> Task (:[^ ]+:test)(?: (.*))?', line)
        if task: tasks.append({'task':task[1], 'suffix':task[2] or ''})
        if line.startswith('> Task ') and line.endswith(' SKIPPED'): skipped_task_lines.append(original)
        if not line.startswith('> Task '):
            match = re.fullmatch(r'(.+) > (.+) (PASSED|SKIPPED|FAILED)',line)
            if match: rows.append({'class':match[1], 'case':match[2], 'result':match[3]})
            elif re.search(r' (PASSED|SKIPPED|FAILED)$',line): raise AssertionError(('unparsed result suffix',line))
        if re.fullmatch(r'test_.* \.\.\. ok',line): ok.append(line)
        if line.startswith('BUILD SUCCESSFUL'): builds.append(line)
        if '##[error]' in line: errors.append(line)
    return {'bytes':len(raw),'sha256':sha(raw),'counts':dict(collections.Counter(x['result'] for x in rows)),
       'test_tasks':tasks,'skipped_case_records':[x for x in rows if x['result']=='SKIPPED'],
       'excluded_gradle_skipped_task_lines':skipped_task_lines,'build_success_lines':builds,
       'python_ok_records':ok,'error_annotations':errors,'records':rows,
       'head_mentions':{x:text.count(x) for x in ['1261a25494d93f588efbcd1c1e5798b212a058c9','9af38ac609a7adddb64bdab6ad9627a9378f4ef8']},
       'terminal_lines':text.splitlines()[-5:]}

archive = SRC/'full-ci-decoded-logs.zip'
z = zipfile.ZipFile(archive)
assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==9
ci={n:parse(z.read(n)) for n in z.namelist()}
metadata=json.loads((OUT/'live-metadata.json').read_text())
jobs=next(x['data'] for x in metadata if '/jobs?' in x['url'])
assert jobs['total_count']==len(jobs['jobs'])==10
assert {int(re.search(r'(\d+)\.log$',n)[1]) for n in ci}=={j['id'] for j in jobs['jobs'] if j['conclusion']=='success'}
assert [(j['name'],j['conclusion']) for j in jobs['jobs'] if j['conclusion']!='success']==[('coverage','skipped')]
total=collections.Counter()
allci=set()
for r in ci.values():
    total.update(r['counts']);allci.update((x['class'],x['case'],x['result']) for x in r['records'])
author=json.loads((SRC/'FULL_CI_LOG_AUDIT.json').read_text())
for a in author['logs']:
    r=ci[a['file']]
    assert a['sha256']==r['sha256'] and a['bytes']==r['bytes']
    for k,name in [('passed_lines','PASSED'),('skipped_lines','SKIPPED'),('failed_lines','FAILED')]: assert a[k]==r['counts'].get(name,0)
assert dict(total)=={'PASSED':16698,'SKIPPED':39}
tasks={(r['task'],r['suffix']) for v in ci.values() for r in v['test_tasks']}
assert sorted(x for x,s in tasks if s=='')==author['fresh_test_tasks']
assert sorted(x for x,s in tasks if s=='FROM-CACHE')==author['cached_test_tasks']
assert len(tasks)==19 and all(s in ('','FROM-CACHE') for _,s in tasks)
for v in ci.values(): del v['records']
aux={}
for label,name in [('G9','job-108520999836.log'),('G10','job-108520999739.log'),('R0','job-108520999587.log'),('guard','job-108520999584.log')]:
    v=parse((SRC/name).read_bytes());v['file']=str(SRC/name)
    v['case_records_also_present_in_current_CI']=all((x['class'],x['case'],x['result']) in allci for x in v['records']) if v['records'] else None
    aux[label]=v
assert aux['G9']['counts']=={'PASSED':9} and aux['G10']['counts']=={'PASSED':12}
assert len(aux['R0']['python_ok_records'])==14 and len(aux['guard']['python_ok_records'])==7
receipts={}
for n in ['r0-original.zip','guard-original.zip']:
    p=SRC/n;q=zipfile.ZipFile(p);assert q.testzip() is None
    assert len(q.namelist())==1
    receipts[n]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'members':{m:{'bytes':len(q.read(m)),'sha256':sha(q.read(m)),'content':json.loads(q.read(m))} for m in q.namelist()}}
assert receipts['guard-original.zip']['members']['live-guard-status.json']['content']['status']=='BLOCKED_BEFORE_INITIALIZATION'
report={'scope':'Complete decoded logs, not raw XML or unique XML case counts. Read-only independent artifact inspection; no test execution.',
   'ci_zip':{'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(ci),'CRC':'PASS'},
   'ci_logs':ci,'ci_totals':dict(total),'fresh_test_tasks':sorted(x for x,s in tasks if s==''),'cached_test_tasks':sorted(x for x,s in tasks if s=='FROM-CACHE'),
   'coverage_job':'skipped, not a testcase','auxiliary':aux,'receipts':receipts}
(OUT/'independent-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archive':report['ci_zip'],'counts':dict(total),'tasks':len(tasks),'fresh':len(report['fresh_test_tasks']),'cached':report['cached_test_tasks'],'auxiliary':{k:{'counts':v['counts'],'python_cases':len(v['python_ok_records']),'builds':len(v['build_success_lines']),'current_CI_overlap':v['case_records_also_present_in_current_CI']} for k,v in aux.items()}},indent=2))
