"""Inspect retained software qualification bytes only; no source imports or execution."""
import ast, hashlib, io, json, pathlib, re, stat, zipfile
OUT=pathlib.Path('sphinx-audit/industrial-observer-attempt01-review')
ORIGINAL=pathlib.Path('attachments/c498e47c-095f-4856-8a4f-db63eb415c14/industrial-observer-36291222116-original.zip')
AUTHOR=pathlib.Path('industrial/executor-handoff/observer-attempt-01')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
meta=json.loads((OUT/'independent-live-metadata.json').read_text())['records']
run=meta['run'];assert (run['id'],run['head_sha'],run['event'],run['run_attempt'],run['status'],run['conclusion'])==(36291222116,'2ced3a971197c1b8ad5d34306d964316c4bdff2b','push',1,'completed','success')
assert meta['jobs']['total_count']==len(meta['jobs']['jobs'])==1
assert meta['artifacts']['total_count']==len(meta['artifacts']['artifacts'])==1
artifact=meta['artifacts']['artifacts'][0];assert artifact['id']==10921314614
assert pin(ORIGINAL)=={'bytes':93132,'sha256':'0ceb157a4684a177f8a0a107586d7db0c2a0e1032a35e329e85a1c7f31caf69c'}
assert artifact['digest']=='sha256:'+pin(ORIGINAL)['sha256'] and artifact['size_in_bytes']==93132
assert meta['commit']['tree']['sha']==meta['tree']['sha']=='d8c6fd234a6f5e61c813ed49ae8e54a75be5d0b4' and not meta['tree']['truncated']
gitfiles={x['path']:x for x in meta['tree']['tree'] if x['type']=='blob'};assert len(gitfiles)==8
expected=json.loads(pathlib.Path('sphinx-audit/industrial-parent-observer-review/independent-control-static-bindings.json').read_text())['files']
with zipfile.ZipFile(ORIGINAL) as outer:
 assert outer.testzip() is None and set(outer.namelist())=={'observer-qualification-original.zip','observer-qualification-archive.json'}
 inner_bytes=outer.read('observer-qualification-original.zip');index=json.loads(outer.read('observer-qualification-archive.json'))
 assert len(inner_bytes)==index['zip_bytes']==176091 and sha(inner_bytes)==index['zip_sha256']=='25644c93e5e52dc5ab433dff29671415d108ddc9c4159b0ae0779d0f288b12a6'
 with zipfile.ZipFile(io.BytesIO(inner_bytes)) as z:
  names=z.namelist();assert len(names)==len(set(names))==340 and z.testzip() is None
  idx={x['path']:x for x in index['members']};assert len(idx)==340 and set(idx)==set(names)
  members=[]
  for name in names:
   b=z.read(name);r=idx[name];assert len(b)==r['bytes'] and sha(b)==r['sha256']
   assert len(b)<=4*1024*1024
   mode=z.getinfo(name).external_attr>>16
   if r['kind']=='symlink_target_bytes':assert stat.S_ISLNK(mode)
   members.append({'path':name,'bytes':len(b),'sha256':sha(b),'kind':r['kind']})
  assert sum(x['bytes'] for x in members)==index['uncompressed_bytes']==255541 and len(members)<=1500 and index['uncompressed_bytes']<=32*1024*1024
  read=lambda name:json.loads(z.read(name))
  before=read('source-before.json');after=read('source-after.json');assert before==after
  assert set(before['files'])==set(gitfiles)==set(expected)
  assert before['git']['head']==run['head_sha'] and before['git']['tree']==meta['tree']['sha'] and before['git']['tracked_status']==''
  pins=[]
  for name,row in before['files'].items():
   b=z.read('source-before/'+name);assert b==z.read('source-after/'+name)
   assert sha(b)==row['sha256']==expected[name]['sha256'];assert len(b)==row['bytes_captured']==row['bytes_on_disk']==expected[name]['bytes']
   assert blob(b)==row['git_blob_sha1']==gitfiles[name]['sha'] and gitfiles[name]['mode']=='100644'
   assert row['capture_complete'] and row['canonical'] and row['kind']=='regular'
   pins.append({'path':name,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
  for phase in ('source-before','source-after'):
   for i,name in enumerate(('.github/workflows/parent-jvm-observer-qualification.yml','CONTROL_MANIFEST.json','QUALIFICATION_PROPOSAL.md','SOURCE_MANIFEST.json','tools/observed_test_runtime.py','tools/parent_jvm_observer.py','tools/qualify_parent_jvm_observer.py','tools/test_parent_jvm_observer.py'),1):assert read(phase+'/capture-record-'+str(i)+'.json')=={'path':name,**before['files'][name]}
   for k,value in before['git'].items():assert read(phase+'/git-'+k+'.json')=={'observed':value}
  sm=read('source-before/SOURCE_MANIFEST.json');testtree=ast.parse(z.read('source-before/tools/test_parent_jvm_observer.py'))
  astnames=sorted(n.name for n in ast.walk(testtree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
  unittest=z.read('unit21.stderr').decode();names_seen=re.findall(r'^(test_\w+) \(__main__\.ParentJvmObserverTest\.test_\w+\) \.\.\. ok$',unittest,re.M)
  assert len(names_seen)==len(set(names_seen))==21 and sorted(names_seen)==astnames==sorted(sm['unit_fixture_identities'])
  assert re.search(r'\nRan 21 tests in [^\n]+\n\nOK\n\Z',unittest)
  assert z.read('unit21.stdout')==b''
  exits={name:read(name) for name in ('unit21-exit.json','actual-parent-probe-exit.json','fixtures/actual-parent-probe/compile-exit.json','fixtures/actual-parent-probe/launch-exit.json')}
  for name,x in exits.items():
   assert x['returncode']==0 and x['timeout'] is False
   if name.startswith('fixtures/'):assert x['direct_child_reaped'] and x['owned_session_termination_requested']
   else:assert x['owned_descendants_terminated_and_reaped']
  results={};negative=0
  for test in names_seen:
   root='fixtures/'+test+'/observation/'
   if test=='test_existing_attempt_is_never_overwritten':
    assert z.read(root+'prior-failure.json')==b'preserve these original bytes';assert root+'result.json' not in names;continue
   x=read(root+'result.json');assert x['admission'] is False and x['claims_created']==x['engine_initializations']==0
   assert root+'intent.json' in names and read(root+'intent.json')['observer_sha256']==before['files']['tools/parent_jvm_observer.py']['sha256']
   if test=='test_matching_two_snapshots_preserve_scope_and_observations':assert x['status']=='MATCHED_TWO_SNAPSHOTS_NOT_ADMISSION'
   else:assert x['status']=='FAILED_OBSERVATION';negative+=1
   if 'input_sha256' in x:assert x['input_sha256']==sha(z.read('fixtures/'+test+'/input.json'))
   results[test]=x
  assert negative==19
  fifo=read('fixtures/test_fifo_input_fails_without_blocking_and_retains_intent/fifo-fixture.json');assert stat.S_ISFIFO(fifo['mode'])
  assert results['test_fifo_input_fails_without_blocking_and_retains_intent']['error']['code']=='NONREGULAR_INPUT'
  mutation=z.read('fixtures/test_mutation_between_snapshots_fails_and_keeps_first_complete_marker/observation/observations.jsonl').decode();assert 'first_snapshot_complete' in mutation
  # Rebuild the actual probe's two launch snapshots from independently hashed raw members.
  root='fixtures/actual-parent-probe/';inp=read(root+'input.json');obs=read(root+'observation/result.json');probe=read(root+'result.json')
  journalbytes=z.read(root+'observation/observations.jsonl');journal=[json.loads(s) for s in journalbytes.splitlines()]
  assert [r['kind'] for r in journal]==['parent','classpath_entry','first_snapshot_complete','parent','classpath_entry']
  assert journal[0]==journal[3] and journal[1]==journal[4]
  argument=z.read(root+'gradle/worker-classpath-probe');assert sha(argument)==inp['argument_file_sha256']
  entry=journal[1]['identity'];assert [entry]==inp['ordered_classpath']
  cls=z.read(root+'repository/build/classes/ParentJvmObserverProbe.class');assert len(cls)==entry['members'][0]['bytes']==1136 and sha(cls)==entry['members'][0]['sha256']
  assert cls[:4]==b'\xca\xfe\xba\xbe' and int.from_bytes(cls[6:8],'big')==65
  snapshot={'parent':journal[0]['identity'],'java':journal[0]['java'],'argument_file_sha256':sha(argument),'ordered_classpath':[entry]}
  assert sha(enc(snapshot))==journal[2]['sha256']==obs['snapshot_sha256']
  launch=read(root+'launch-command.json')['argv'];assert sha(b'\0'.join(x.encode() for x in launch)+b'\0')==inp['cmdline_sha256']==journal[0]['identity']['cmdline_sha256']
  assert inp['roots']['repository']+'/build/classes'==argument.decode().splitlines()[1] and argument.decode().splitlines()[0]=='-cp'
  assert probe['status']=='PASS_READ_ONLY_ACTUAL_PARENT_PROBE' and obs['status']=='MATCHED_TWO_SNAPSHOTS_NOT_ADMISSION'
  assert sha(z.read(root+'repository/ParentJvmObserverProbe.java'))==probe['probe_source_sha256']
  assert sha(z.read(root+'observation/result.json'))==probe['observation_sha256']
  assert obs['input_sha256']==sha(z.read(root+'input.json')) and obs['journal_bytes']==len(journalbytes)==1671
  for x in (probe,obs):assert x['admission'] is False and x['claims_created']==x['engine_initializations']==0
  assert obs['bytes_read']<=inp['bounds']['max_total_bytes'] and obs['entries_visited']<=inp['bounds']['max_entries'] and obs['elapsed_seconds']<=inp['bounds']['max_seconds']
  env=read('environment.json');assert probe['java_sha256']==env['java_sha256']==journal[0]['java']['sha256']==inp['java_sha256']
  assert env['javac_sha256']==probe['javac_sha256'];assert sha(z.read('jdk-release.txt'))==env['jdk_release_sha256'];assert b'JAVA_VERSION="21.0.12.1"' in z.read('jdk-release.txt')
  overall=read('result.json');assert overall['status']=='PASS_BOUNDED_OBSERVATION_COMPONENT_ONLY' and overall['unit_cases']==21 and overall['actual_parent_probes']==1
  assert overall['unit_failures']==overall['unit_errors']==overall['unit_skips']==overall['official_allocations']==overall['engine_initializations']==0 and overall['admission'] is False
  assert sha(z.read(root+'result.json'))==overall['probe_result_sha256']
  author=json.loads((AUTHOR/'author-original-audit.json').read_text())
  retained=dict(author['retained_fixture_results']);assert retained.pop('test_existing_attempt_is_never_overwritten')=={'status':'ORIGINAL_BYTES_PRESERVED'}
  assert retained==results and author['actual_unit_cases']==names_seen
  assert author['actual_parent_observation']==obs and author['separate_actual_parent_probe']==probe
logjson=json.loads((AUTHOR/'decoded-job-log.json').read_text());log=logjson['structuredContent']['content']
assert "2ced3a971197c1b8ad5d34306d964316c4bdff2b" in log and 'Run python3 tools/qualify_parent_jvm_observer.py' in log and 'PASS_BOUNDED_OBSERVATION_COMPONENT_ONLY' in log
assert 'Ran 21 tests' not in log # unittest raw stderr is retained in the artifact, not fabricated in the wrapper log.
job=meta['jobs']['jobs'][0];step=next(x for x in job['steps'] if x['name']=='Run exactly21 software cases and one actual-parent probe');assert step['conclusion']=='success'
report={'schema':'industrial-observer-independent-original-byte-audit-v1','original':pin(ORIGINAL),'nested':{'bytes':len(inner_bytes),'sha256':sha(inner_bytes),'members':340,'uncompressed_bytes':255541},'member_index':members,'source_pins':pins,'source_before_after_equal':True,'run':{'id':run['id'],'head':run['head_sha'],'tree':meta['tree']['sha'],'attempt':1,'event':'push','job':job['id'],'step':step},'unit_names':names_seen,'negative_results':results,'negative_count':19,'preserved_prior_attempt_fixture':True,'exits':exits,'actual_probe':probe,'actual_observation':obs,'actual_snapshot_sha256_recomputed':sha(enc(snapshot)),'raw_class_sha256_recomputed':sha(cls),'JDK_release_sha256':env['jdk_release_sha256'],'tool_binary_hashes':'Reported/internal reconciliation only; executing Java/Javac/Python binary bytes are not independently available in the artifact.','decoded_log':{'bytes':len(log.encode()),'sha256':sha(log.encode()),'scope':'Complete connector-decoded log JSON; not original Actions log ZIP.'},'author_audit':pin(AUTHOR/'author-original-audit.json'),'admission':False,'reviewer_execution':'Only read/hash/AST/archive audit; no source import, tests, javac, JVM, observer or gameplay run.'}
f=OUT/'independent-original-byte-audit.json';f.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'report':pin(f),'unit_cases':len(names_seen),'negatives':negative,'actual_probes':1,'source_files':len(pins),'original':pin(ORIGINAL)},indent=2))
