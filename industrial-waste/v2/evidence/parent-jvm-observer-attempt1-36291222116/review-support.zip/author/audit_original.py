"""Read retained original bytes only. Does not import or execute observer/tests."""
import ast,hashlib,io,json,re,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
original=ROOT/'attachments/c498e47c-095f-4856-8a4f-db63eb415c14/industrial-observer-36291222116-original.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
raw=original.read_bytes(); outer=zipfile.ZipFile(io.BytesIO(raw))
assert len(outer.namelist())==len(set(outer.namelist()))==2 and outer.testzip() is None
assert len(raw)==93132 and sha(raw)=='0ceb157a4684a177f8a0a107586d7db0c2a0e1032a35e329e85a1c7f31caf69c'
innerraw=outer.read('observer-qualification-original.zip')
z=zipfile.ZipFile(io.BytesIO(innerraw))
names=z.namelist()
assert len(names)==len(set(names))==340 and z.testzip() is None
index=json.loads(outer.read('observer-qualification-archive.json'))
assert index['zip_bytes']==len(innerraw) and index['zip_sha256']==sha(innerraw)
assert set(names)=={x['path'] for x in index['members']}
for row in index['members']:
 b=z.read(row['path'])
 assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert sum(len(z.read(n)) for n in names)==index['uncompressed_bytes']==255541
j=lambda n:json.loads(z.read(n))
tree=json.loads((HERE/'live-tree.json').read_text())
blobs={x['path']:x for x in tree['tree'] if x['type']=='blob'}
before=j('source-before.json');after=j('source-after.json')
assert before==after and len(blobs)==len(before['files'])==8
assert before['git']['head']=='2ced3a971197c1b8ad5d34306d964316c4bdff2b'
assert before['git']['tree']==tree['sha']=='d8c6fd234a6f5e61c813ed49ae8e54a75be5d0b4'
assert before['git']['tracked_status']==''
for path,row in before['files'].items():
 b=z.read('source-before/'+path)
 assert b==z.read('source-after/'+path)
 assert row['canonical'] and row['capture_complete'] and row['kind']=='regular'
 assert len(b)==row['bytes_captured']==row['bytes_on_disk']==blobs[path]['size']
 assert sha(b)==row['sha256'] and blob(b)==row['git_blob_sha1']==blobs[path]['sha']
 assert blobs[path]['mode']=='100644' and row['mode']==33188
source=j('source-before/SOURCE_MANIFEST.json')
testast=ast.parse(z.read('source-before/tools/test_parent_jvm_observer.py'))
astnames=sorted(x.name for x in ast.walk(testast) if isinstance(x,ast.FunctionDef) and x.name.startswith('test_'))
log=z.read('unit21.stderr').decode()
actual=re.findall(r'^(test_\w+) \(__main__\.ParentJvmObserverTest\.\1\) \.\.\. ok$',log,re.M)
assert len(actual)==len(set(actual))==21
assert sorted(actual)==sorted(source['unit_fixture_identities'])==astnames
assert re.search(r'Ran 21 tests in \d+\.\d+s\n\nOK\s*\Z',log)
assert z.read('unit21.stdout')==b''
results={}
for name in actual:
 prefix='fixtures/'+name+'/observation/'
 if name=='test_existing_attempt_is_never_overwritten':
  assert z.read(prefix+'prior-failure.json')==b'preserve these original bytes'
  assert prefix+'result.json' not in names
  results[name]={'status':'ORIGINAL_BYTES_PRESERVED'}
 else:
  r=j(prefix+'result.json')
  assert r['admission'] is False and r['claims_created']==r['engine_initializations']==0
  assert prefix+'intent.json' in names
  results[name]=r
  if name=='test_matching_two_snapshots_preserve_scope_and_observations':
   assert r['status']=='MATCHED_TWO_SNAPSHOTS_NOT_ADMISSION'
  else:
   assert r['status']=='FAILED_OBSERVATION'
assert len([v for v in results.values() if v['status']=='FAILED_OBSERVATION'])==19
for n in ['unit21-exit.json','actual-parent-probe-exit.json','fixtures/actual-parent-probe/compile-exit.json','fixtures/actual-parent-probe/launch-exit.json']:
 r=j(n);assert r['returncode']==0 and not r['timeout']
for n in ['unit21-exit.json','actual-parent-probe-exit.json']:
 assert j(n)['owned_descendants_terminated_and_reaped']
p='fixtures/actual-parent-probe/'
probe=j(p+'result.json');observation=j(p+'observation/result.json');env=j('environment.json')
assert probe['status']=='PASS_READ_ONLY_ACTUAL_PARENT_PROBE'
assert probe['admission'] is False and probe['claims_created']==probe['engine_initializations']==0
assert probe['observation_sha256']==sha(z.read(p+'observation/result.json'))
assert probe['observer_sha256']==before['files']['tools/parent_jvm_observer.py']['sha256']
assert probe['probe_source_sha256']==sha(z.read(p+'repository/ParentJvmObserverProbe.java'))
assert probe['java_sha256']==env['java_sha256'] and probe['javac_sha256']==env['javac_sha256']
assert env['jdk_release_sha256']==sha(z.read('jdk-release.txt'))
obs=[json.loads(x) for x in z.read(p+'observation/observations.jsonl').decode().splitlines()]
assert [x['kind'] for x in obs]==['parent','classpath_entry','first_snapshot_complete','parent','classpath_entry']
assert obs[0]==obs[3] and obs[1]==obs[4]
expected=j(p+'input.json')
assert obs[0]['java']['sha256']==expected['java_sha256']==env['java_sha256']
assert obs[0]['identity']['cmdline_sha256']==expected['cmdline_sha256']
assert [obs[1]['identity']]==expected['ordered_classpath']
member=expected['ordered_classpath'][0]['members'][0]
assert member['sha256']==sha(z.read(p+'repository/build/classes/ParentJvmObserverProbe.class')) and member['bytes']==1136
assert expected['argument_file_sha256']==sha(z.read(p+'gradle/worker-classpath-probe'))
assert observation['status']=='MATCHED_TWO_SNAPSHOTS_NOT_ADMISSION'
assert observation['admission'] is False and observation['claims_created']==observation['engine_initializations']==0
assert observation['input_sha256']==sha(z.read(p+'input.json'))
assert observation['snapshot_sha256']==obs[2]['sha256']
snapshot={'parent':obs[0]['identity'],'java':obs[0]['java'],'argument_file_sha256':expected['argument_file_sha256'],'ordered_classpath':expected['ordered_classpath']}
encoded=(json.dumps(snapshot,sort_keys=True,separators=(',',':'))+'\n').encode()
assert sha(encoded)==observation['snapshot_sha256']
result=j('result.json')
assert result['status']=='PASS_BOUNDED_OBSERVATION_COMPONENT_ONLY'
assert result['control_commit']==before['git']['head'] and result['control_tree']==tree['sha']
assert result['run_id']=='36291222116' and result['run_attempt']==1
assert result['unit_cases']==21 and result['unit_errors']==result['unit_failures']==result['unit_skips']==0
assert result['actual_parent_probes']==1 and result['admission'] is False
assert result['engine_initializations']==result['official_allocations']==0
assert result['probe_result_sha256']==sha(z.read(p+'result.json'))
run=json.loads((HERE/'run.json').read_text())
artifact=json.loads((HERE/'artifacts.json').read_text())['artifacts']
assert run['conclusion']=='success' and run['run_attempt']==1 and run['head_sha']==before['git']['head']
assert len(artifact)==1 and artifact[0]['id']==10921314614
assert artifact[0]['size_in_bytes']==len(raw) and artifact[0]['digest']=='sha256:'+sha(raw)
commands={n:j(n) for n in names if n.endswith('-command.json')}
assert len(commands)==4
report={
 'schema':'parent-jvm-observer-original-author-audit-v1',
 'source':before['git'],'run_id':36291222116,'run_attempt':1,
 'original':{'path':str(original.relative_to(ROOT)),'bytes':len(raw),'sha256':sha(raw),'members':2,'crc':'PASS'},
 'nested_original':{'bytes':len(innerraw),'sha256':sha(innerraw),'members':340,'uncompressed_bytes':255541,'crc':'PASS','all_indexed_member_hashes_verified':True},
 'source_bindings':{'count':8,'full_bytes_before_after_equal':True,'live_git_blob_mode_size_match':True,'tracked_index_clean':True},
 'actual_unit_cases':actual,'unit_failures':0,'unit_errors':0,'unit_skips':0,
 'retained_fixture_results':results,'separate_actual_parent_probe':probe,
 'actual_parent_observation':observation,'commands':commands,'reported_tool_environment':env,
 'disposition':'AUTHOR_VERIFIED_BOUNDED_COMPONENT_RESULTS_PENDING_NONAUTHOR_ARTIFACT_REVIEW',
 'limits':['Read-only archive audit; did not import or run source, tests, Java or engine.',
 'Recorded Java/Javac/Python hashes were reconciled internally, not independently rehashed from runtime binaries.',
 'The class/probe/source bytes and ordered launch snapshots were rehashed from the actual archive. This does not prove loaded-class/JDK/native/image closure or in-flight immutability.',
 'No full runtime receiving acceptance, official executor wiring, source-bound permit, remote claim, R1 allocation or gameplay result.']
}
(HERE/'author-original-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','author_report_sha256':sha((HERE/'author-original-audit.json').read_bytes()),'unit_cases':len(actual),'rejections_retained':19,'actual_probes':1,'source_files':8,'members':340}))

