from pathlib import Path
import ast,hashlib,json,zipfile
r=Path('industrial/executor-handoff/observer-control')
with zipfile.ZipFile('industrial/executor-handoff/observer-control-held5542.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(r.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(r).as_posix())
p=r/'tools/qualify_parent_jvm_observer.py';s=p.read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='25fef68e62a77773a88e31ff6091dda50444de798a955ea6f410912691332343'
s=s.replace('MAX_MEMBERS = 1500\n','''MAX_MEMBERS = 1500
SOURCE_CAPTURE_LIMIT = 256 * 1024
CONTROL_FILES = (
    ".github/workflows/parent-jvm-observer-qualification.yml",
    "CONTROL_MANIFEST.json", "QUALIFICATION_PROPOSAL.md", "SOURCE_MANIFEST.json",
    "tools/observed_test_runtime.py", "tools/parent_jvm_observer.py",
    "tools/qualify_parent_jvm_observer.py", "tools/test_parent_jvm_observer.py",
)
''')
start=s.index('def inputs(manifest):\n');end=s.index('\ndef archive():\n',start)
s=s[:start]+'''def capture_inputs(label):
    """Retain bounded actual attempted bytes and errors before comparisons."""
    source = OUTPUT / label
    source.mkdir(exist_ok=False)
    observed = {"files": {}, "git": {}}
    for name in CONTROL_FILES:
        path = ROOT / name
        row = {}
        try:
            mode = path.lstat().st_mode
            row["mode"] = mode
            row["canonical"] = path.resolve(strict=True) == path
            if stat.S_ISLNK(mode):
                row.update(kind="symlink", link_target=os.readlink(path), capture_complete=False)
            elif not stat.S_ISREG(mode) or not row["canonical"]:
                row.update(kind="nonregular_or_noncanonical", capture_complete=False)
            else:
                row.update(kind="regular", bytes_on_disk=path.stat().st_size)
                descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
                with os.fdopen(descriptor, "rb") as stream:
                    require(stat.S_ISREG(os.fstat(stream.fileno()).st_mode), "Source became nonregular before capture")
                    data = stream.read(SOURCE_CAPTURE_LIMIT + 1)
                complete = len(data) <= SOURCE_CAPTURE_LIMIT and len(data) == row["bytes_on_disk"]
                retained = data[:SOURCE_CAPTURE_LIMIT]
                destination = source / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open("xb") as output:
                    output.write(retained)
                row.update(bytes_captured=len(retained), sha256=sha(retained), capture_complete=complete,
                           git_blob_sha1=hashlib.sha1(b"blob " + str(len(retained)).encode() + b"\\0" + retained).hexdigest() if complete else None)
        except Exception as error:
            row["error"] = {"type": type(error).__name__, "message": str(error)}
        observed["files"][name] = row
        save(source / ("capture-record-" + str(len(observed["files"])) + ".json"), {"path": name, **row})
    for name, args in {
        "head": ("rev-parse", "HEAD"), "tree": ("rev-parse", "HEAD^{tree}"),
        "ls_tree": ("ls-tree", "-r", "HEAD"),
        "tracked_status": ("status", "--porcelain=v1", "--untracked-files=no"),
    }.items():
        try:
            raw = git(*args)
            require(len(raw) <= MAX_LOG, "Git identity record exceeded output bound")
            observed["git"][name] = raw.decode().strip() if name in ("head", "tree") else raw.decode()
        except Exception as error:
            observed["git"][name] = {"error": {"type": type(error).__name__, "message": str(error)}}
        save(source / ("git-" + name + ".json"), {"observed": observed["git"][name]})
    save(OUTPUT / (label + ".json"), observed)
    return observed


def validate_inputs(observed, manifest):
    """Validate only after the actual attempted bytes/identities are durable."""
    require(all(isinstance(value, str) for value in observed["git"].values()), "Missing actual Git identity")
    require(observed["git"]["head"] == os.environ.get("GITHUB_SHA"), "Checkout commit mismatch")
    require(observed["git"]["tracked_status"] == "", "Tracked working-tree or index drift")
    committed = {}
    for line in observed["git"]["ls_tree"].splitlines():
        header, path = line.split("\\t", 1)
        mode, kind, blob = header.split()
        require(path not in committed, "Duplicate committed path")
        committed[path] = {"mode": mode, "kind": kind, "blob": blob}
    require(set(committed) == set(CONTROL_FILES), "Unexpected source tree membership")
    for path in CONTROL_FILES:
        row = observed["files"][path]
        require(row.get("capture_complete") and row.get("kind") == "regular" and row.get("canonical"), "Incomplete/nonregular source capture: " + path)
        require(committed[path]["kind"] == "blob" and committed[path]["mode"] == "100644" and not row["mode"] & 0o111,
                "Unexpected source mode: " + path)
        require(row["git_blob_sha1"] == committed[path]["blob"], "Actual bytes differ from committed blob: " + path)
    rows = manifest["files"]
    require(len(rows) == len(CONTROL_FILES) - 1 and {row["path"] for row in rows} == set(CONTROL_FILES) - {"CONTROL_MANIFEST.json"},
            "Control manifest source inventory differs")
    for row in rows:
        actual = observed["files"][row["path"]]
        require(actual["bytes_captured"] == row["bytes"] and actual["sha256"] == row["sha256"], "Declared source hash mismatch: " + row["path"])

''' +s[end:]
old='''    try:
        require(os.environ.get("GITHUB_EVENT_NAME") == "push" and os.environ.get("GITHUB_REF") == BRANCH,
'''
new='''    save(OUTPUT / "attempt-context.json", {key: os.environ.get(key) for key in
         ("GITHUB_SHA", "GITHUB_REF", "GITHUB_EVENT_NAME", "GITHUB_RUN_ID", "GITHUB_RUN_ATTEMPT")})
    try:
        before = capture_inputs("source-before")
        result.update(attempted_control_commit=before["git"].get("head"), attempted_control_tree=before["git"].get("tree"))
        require(os.environ.get("GITHUB_EVENT_NAME") == "push" and os.environ.get("GITHUB_REF") == BRANCH,
'''
assert old in s;s=s.replace(old,new,1)
old='''        manifest = json.loads((ROOT / "CONTROL_MANIFEST.json").read_text())
        require(manifest["schema"] == "parent-jvm-observer-isolated-control-v1", "Wrong control manifest")
        before = inputs(manifest)
        save(OUTPUT / "source-before.json", before)
        source = OUTPUT / "source"
        source.mkdir()
        for path in sorted(set(before) | {"CONTROL_MANIFEST.json"}):
            destination = source / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / path, destination)
'''
new='''        manifest = json.loads((OUTPUT / "source-before/CONTROL_MANIFEST.json").read_text())
        require(manifest["schema"] == "parent-jvm-observer-isolated-control-v1", "Wrong control manifest")
        validate_inputs(before, manifest)
'''
assert old in s;s=s.replace(old,new,1)
old='''        after = inputs(manifest)
        save(OUTPUT / "source-after.json", after)
        require(after == before, "Qualification source changed")
'''
new='''        after = capture_inputs("source-after")
        validate_inputs(after, manifest)
        require(after == before, "Qualification source or control manifest changed")
'''
assert old in s;s=s.replace(old,new,1)
ast.parse(s);p.write_text(s)
m=json.loads((r/'CONTROL_MANIFEST.json').read_text())
for row in m['files']:
 b=(r/row['path']).read_bytes();row['bytes']=len(b);row['sha256']=hashlib.sha256(b).hexdigest()
m['bounds']['each_attempted_source_capture_bytes']=256*1024
m['source_binding']='All8 actual attempted source records/captured bytes plus commit/tree/tracked-index status are retained before comparisons; all8 including control manifest must equal committed blobs/modes and before/after.'
(r/'CONTROL_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
for p in [r/'CONTROL_MANIFEST.json',r/'tools/qualify_parent_jvm_observer.py']:
 print(p,hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size)
for p in ['tools/parent_jvm_observer.py','tools/test_parent_jvm_observer.py','SOURCE_MANIFEST.json']:
 print('unchanged',p,hashlib.sha256((r/p).read_bytes()).hexdigest())
