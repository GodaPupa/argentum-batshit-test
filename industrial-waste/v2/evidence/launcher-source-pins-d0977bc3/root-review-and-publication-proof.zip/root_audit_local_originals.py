"""Read preserved Industrial local-test bytes; execute no project module or fixture."""
import ast,datetime as dt,hashlib,json,re,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
zpath=P/'local-validation-originals.zip'
index=json.loads((P/'local-validation-archive-index.json').read_text())
assert len(zpath.read_bytes())==index['bytes']==260788
assert sha(zpath.read_bytes())==index['sha256']=='d23ae278616ab4e1c4d6104eed3bf427e231b1748ab0bbebdfd4ffc0c5d06f90'
metadata=json.loads((P/'root-fresh-source-directory-metadata.json').read_text())
gitrows={row['path']:row for d in metadata['directories'] for row in d['entries']}
with zipfile.ZipFile(zpath) as z:
 names=z.namelist()
 assert len(names)==len(set(names))==47 and z.testzip() is None
 assert set(names)=={r['path'] for r in index['members']}
 members=[]
 for row in index['members']:
  b=z.read(row['path'])
  assert len(b)==row['bytes'] and sha(b)==row['sha256']
  assert b==(P/row['path']).read_bytes()
  members.append({'path':row['path'],'bytes':len(b),'sha256':sha(b)})
 receipt=json.loads(z.read('LOCAL_VALIDATION_RECEIPT.json'))
 candidate=json.loads(z.read('candidate-manifest.json'))
 expectedcandidate={row['path']:row['sha256'] for row in candidate['files']}
 test=ast.parse(z.read('candidate/industrial-waste/v2/test_r1_execute.py'))
 methods=sorted(c.name+'.'+m.name for c in test.body if isinstance(c,ast.ClassDef)
   for m in c.body if isinstance(m,ast.FunctionDef) and m.name.startswith('test_'))
 assert len(methods)==20
 phases={}
 for phase,count in [('focused',4),('regression',20)]:
  prefix='validation-'+phase+'-attempt1/'
  before=json.loads(z.read(prefix+'source-before.json'));after=json.loads(z.read(prefix+'source-after.json'))
  assert before==after and len(before)==(10 if phase=='focused' else 20)
  sources=[]
  for path,h in before.items():
   b=z.read('validation-context/'+path)
   assert len(b)==h['bytes'] and sha(b)==h['sha256']
   if path in expectedcandidate:
    assert sha(b)==expectedcandidate[path]
   else:
    assert blob(b)==gitrows[path]['sha'] and len(b)==gitrows[path]['size']
   sources.append({'path':path,'sha256':sha(b),'git_blob':blob(b),'candidate':path in expectedcandidate})
  intent=json.loads(z.read(prefix+'intent.json'));exitrec=json.loads(z.read(prefix+'exit.json'))
  assert exitrec['returncode']==0 and exitrec['timeout'] is False and exitrec['source_unchanged'] is True
  assert intent['command'][1:3]==['-I','-B']
  assert intent['command'][3:]==['industrial-waste/v2/test_r1_execute.py']+(['LauncherSourceBindingTests'] if phase=='focused' else[])+['-v']
  assert intent['environment_keys']==['GIT_CONFIG_GLOBAL','GIT_CONFIG_NOSYSTEM','LANG','LC_ALL','PATH']
  assert intent['credentials_in_child_environment'] is False and intent['official_environment_in_child'] is False
  assert sha(z.read('run_local_validation.py'))==intent['harness_sha256']
  assert sha(Path(intent['python_executable']).read_bytes())==intent['python_binary_sha256']
  started=dt.datetime.fromisoformat(intent['started_utc']);ended=dt.datetime.fromisoformat(exitrec['finished_utc'])
  assert 0<(ended-started).total_seconds()<intent['timeout_seconds']==120
  for name,h in exitrec['logs'].items():
   b=z.read(prefix+name);assert len(b)==h['bytes'] and sha(b)==h['sha256']
  assert z.read(prefix+'stdout.txt')==b''
  text=z.read(prefix+'stderr.txt').decode()
  rows=re.findall(r'^(\w+) \(__main__\.(\w+)\.(\w+)\) \.\.\. ok$',text,re.M)
  assert len(rows)==count and all(a==c for a,b,c in rows)
  observed=sorted(b+'.'+c for a,b,c in rows)
  assert len(set(observed))==count
  summary=re.search(r'\nRan (\d+) tests in ([0-9.]+)s\n\nOK\n$',text)
  assert summary and int(summary[1])==count
  assert not any(word in text for word in ['... FAIL','... ERROR','... skipped'])
  assert observed==sorted(receipt['actual_tests'][phase]['case_identities'])
  wanted=[x for x in methods if phase=='regression' or x.startswith('LauncherSourceBindingTests.')]
  assert observed==wanted
  phases[phase]={'case_names':observed,'count':count,'raw_report_seconds':float(summary[2]),'wall_seconds':(ended-started).total_seconds(),'exit':exitrec,'source_observations':sources,'python_binary_rehashed_again':True}
 assert set(phases['focused']['case_names'])<set(phases['regression']['case_names'])
 assert len([x for x in methods if x.startswith('ExecutionAdapterTests.')])==16
 for n in ['manual-independent-source-review.json','manual-independent-static-proof.json']:
  assert z.read(n)==(P/n).read_bytes()
proof={'schema':'root-industrial-launcher-local-original-byte-audit-v1','source_base':metadata['source'],'archive':{'bytes':260788,'sha256':index['sha256'],'members':members},'fresh_source_directories':metadata['directories'],'phases':phases,'distinct_methods':20,'case_executions':24,'overlap':4,'raw_failures_errors_skips':0,'source_files_currently_verified':20,'original_source_files_git_rebound':18,'test_source_AST_case_names':methods,'new_project_test_execution_by_reviewer':0}
out=P/'root-independent-local-byte-audit.json';out.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'proof':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'methods':20,'executions':24,'members':47,'git_rebound_originals':18}))

