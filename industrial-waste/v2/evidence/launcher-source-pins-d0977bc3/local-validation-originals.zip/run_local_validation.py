"""Execute each root-authorized offline software phase at most once, preserving raw logs."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CONTEXT = ROOT / 'validation-context'
phase = sys.argv[1]
assert phase in ('focused', 'regression')
out = ROOT / ('validation-' + phase + '-attempt1')
out.mkdir()  # Never overwrite or repeat an existing attempted phase.
sha = lambda b: hashlib.sha256(b).hexdigest()
def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')
def sources():
    return {str(p.relative_to(CONTEXT)): {'bytes': len(p.read_bytes()), 'sha256': sha(p.read_bytes())}
        for p in sorted(CONTEXT.rglob('*')) if p.is_file()}

before = sources()
write('source-before.json', before)
command = [sys.executable, '-I', '-B', 'industrial-waste/v2/test_r1_execute.py']
if phase == 'focused':
    command += ['LauncherSourceBindingTests']
command += ['-v']
env = {'PATH': os.environ['PATH'], 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
    'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1'}
write('intent.json', {'phase': phase, 'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'command': command, 'cwd': str(CONTEXT), 'timeout_seconds': 120,
    'stdout_stderr_per_file_limit': 4194304, 'environment_keys': sorted(env),
    'credentials_in_child_environment': False, 'official_environment_in_child': False,
    'python_executable': str(Path(sys.executable).resolve()), 'python_version': sys.version,
    'python_binary_sha256': sha(Path(sys.executable).resolve().read_bytes()),
    'harness_sha256': sha(Path(__file__).read_bytes()), 'engine_or_launcher_execution': False})
def limits():
    resource.setrlimit(resource.RLIMIT_FSIZE, (4194304, 4194304))
status = {'timeout': False}
try:
    with (out/'stdout.txt').open('xb') as stdout, (out/'stderr.txt').open('xb') as stderr:
        process = subprocess.Popen(command, cwd=CONTEXT, env=env, stdout=stdout, stderr=stderr,
            start_new_session=True, preexec_fn=limits)
        try:
            status['returncode'] = process.wait(timeout=120)
        except subprocess.TimeoutExpired:
            status['timeout'] = True
            os.killpg(process.pid, signal.SIGKILL)
            status['returncode'] = process.wait()
finally:
    after = sources()
    write('source-after.json', after)
    status['source_unchanged'] = before == after
    status['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    status['logs'] = {n: {'bytes': len((out/n).read_bytes()), 'sha256': sha((out/n).read_bytes())}
        for n in ('stdout.txt', 'stderr.txt') if (out/n).exists()}
    write('exit.json', status)
print(json.dumps(status))
raise SystemExit(0 if status.get('returncode') == 0 and not status['timeout'] and status['source_unchanged'] else 1)
