"""Independent byte audit of completed CI runtime evidence; never starts Java or a replay."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timedelta
import base64,gzip,hashlib,json,re,tarfile,zipfile
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;RAW=ROOT/'industrial/audit-1261'
ARCH=Path('/dev/shm/industrial-1261-runtime-36283941502/runtime-original.zip')
SRC='1261a25494d93f588efbcd1c1e5798b212a058c9';TREE='7e635c7ff700094d840bb64fdba7699f724cf594'
B='build/reports/industrial-waste-v2/runtime-composition/';W=B+'ai-worker/'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):return json.loads(p.read_text())
def gzread(p):return json.loads(gzip.decompress(p.read_bytes()))
def dt(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
meta=read(OUT/'priority-runtime-live-metadata.json')['36283941502'];run=meta['run'];job=meta['jobs']['jobs'][0];art=meta['artifacts']['artifacts'][0]
assert run['id']==36283941502 and run['head_sha']==SRC and run['run_attempt']==1 and run['event']=='push' and run['conclusion']=='success'
assert meta['jobs']['total_count']==1 and job['id']==108520988304 and job['conclusion']=='success'
assert art['id']==10920296265 and art['workflow_run']['head_sha']==SRC
original=pin(ARCH);assert original['bytes']==art['size_in_bytes']==99456585 and art['digest']=='sha256:'+original['sha256']
parts=read(RAW/'runtime-publication-parts.json');assert parts['original_bytes']==original['bytes'] and parts['original_sha256']==original['sha256']
offset=0
with ARCH.open('rb') as f:
 for i,p in enumerate(parts['parts']):
  assert p['index']==i and p['offset']==offset
  b=f.read(p['bytes']);assert len(b)==p['bytes'] and sha(b)==p['sha256'] and blob(b)==p['git_blob'];offset+=len(b)
 assert not f.read(1) and offset==original['bytes'] and len(parts['parts'])==12
treej=gzread(OUT/'current-complete-tree.json.gz');assert treej['sha']==TREE and not treej['truncated'];tree={x['path']:x for x in treej['entries']}
loc=read(OUT/'priority-source-locations.json');bodies={};cache={}
for p,row in loc['found'].items():
 if 'file' in row:b=(ROOT/row['file']).read_bytes()
 else:
  if row['json'] not in cache:cache[row['json']]=read(ROOT/row['json'])
  j=cache[row['json']];x=next(x for x in j if x.get('path')==p) if isinstance(j,list) else j[p];b=x['content'].encode()
 bodies[p]=b
for x in gzread(OUT/'priority-fresh-source-bodies.json.gz'):bodies[x['path']]=base64.b64decode(x['content']) if x['encoding']=='base64' else x['content'].encode()
def window(prefix):
 s=next(s for s in job['steps'] if s['name'].startswith(prefix));assert s['conclusion']=='success';return dt(s['started_at']),dt(s['completed_at'])+timedelta(seconds=1)
report={'schema':'sphinx-independent-industrial1261-runtime-original-audit-v1','source':SRC,'tree':TREE,'run':run['id'],'attempt':1,'job':job['id'],'artifact_id':art['id'],'original':original,'byte_parts':{'count':12,'all_offsets_sizes_sha256_gitblob_verified':True,'manifest':pin(RAW/'runtime-publication-parts.json'),'remote_blob_existence_independently_refetched':False}}
with zipfile.ZipFile(ARCH) as z:
 names=z.namelist();assert len(names)==len(set(names))==554 and z.testzip() is None
 def js(n):return json.loads(z.read(n))
 members=[]
 for n in names:
  with z.open(n) as f:h=hashlib.file_digest(f,'sha256').hexdigest()
  members.append({'path':n,'bytes':z.getinfo(n).file_size,'sha256':h})
 report['outer_members']=members
 prov=js(B+'provenance.json');assert prov['source_commit']==SRC and prov['source_tree']==TREE and prov['initial_checkout_status']==''
 assert prov['source_status']=='?? industrial-waste/v2/runtime-evidence/\n'
 assert not prov['execution_authorized'] and all(prov[k]==0 for k in ['official_allocations_initialized','official_actions_submitted','comparative_outcomes_exposed'])
 for p,h in prov['source_sha256'].items():assert sha(bodies[p])==h and blob(bodies[p])==tree[p]['sha'],p
 before=z.read(W+'compiled-inputs-before.json');after=z.read(W+'compiled-inputs-after.json');assert before==after
 inp=json.loads(before);assert len(inp)==21066
 for p,v in inp.items():assert tree[p]['sha']==v['git_blob'] and tree[p]['mode']==v['git_mode'],p
 report['source_binding']={'post_qualification_source_pins':len(prov['source_sha256']),'initial_status':'clean','final_status':prov['source_status'],'allowed_generated_registry_output':True,'compiled_input_entries':len(inp),'before_after_bytes_identical':True,'compiled_input_sha256':sha(before),'all_compiled_git_blobs_modes_match_fresh_current_tree':True}
 bank=js(W+'frozen-case-bank.json');assert z.read(W+'frozen-case-bank.json')==bodies['industrial-waste/v2/runtime-ai-case-bank.json']
 expected={(s['class'],n) for s in bank['cases'] for n in s['cases']};allowed={(s['class'],n) for s in bank['cases'] for n in s['allowed_skips']}
 raw_xml=[n for n in names if '/build/test-results/test/TEST-' in n and n.endswith('.xml')]
 counts={};suites=[];ai=[]
 for n in raw_xml:
  e=ET.fromstring(z.read(n));cases=e.findall('testcase');module=n.split('/build/test-results/test/')[0]
  module='ai' if module=='ai' else 'rules-engine' if module=='rules-engine' else 'lava-dart'
  prefix={'ai':'Qualify the same combined','rules-engine':'Qualify canonical payment','lava-dart':'Qualify received exact Lava'}[module]
  lo,hi=window(prefix);stamp=dt(e.attrib['timestamp']);assert lo<=stamp<=hi,(n,stamp,lo,hi)
  assert len(cases)==int(e.attrib['tests'])
  rows=[{'class':c.attrib['classname'],'name':c.attrib['name'],'failure':c.find('failure') is not None,'error':c.find('error') is not None,'skip':c.find('skipped') is not None} for c in cases]
  for attr,key in [('failures','failure'),('errors','error'),('skipped','skip')]:assert int(e.attrib.get(attr,0))==sum(r[key] for r in rows)
  assert not any(r['failure'] or r['error'] for r in rows)
  count=counts.setdefault(module,Counter());count['total']+=len(rows);count['skipped']+=sum(r['skip'] for r in rows);count['passed']+=sum(not r['skip'] for r in rows)
  if module=='ai':
   ai+=rows;copy=W+'junit/'+Path(n).name;assert z.read(copy)==z.read(n)
  suites.append({'path':n,'sha256':sha(z.read(n)),'timestamp':e.attrib['timestamp'],'cases':rows})
 assert counts=={'rules-engine':Counter(total=148,passed=148,skipped=0),'lava-dart':Counter(total=2,passed=2,skipped=0),'ai':Counter(total=144,passed=143,skipped=1)},counts
 assert len(ai)==len({(x['class'],x['name']) for x in ai})==bank['expected_total']==144
 assert {(x['class'],x['name']) for x in ai}==expected and {(x['class'],x['name']) for x in ai if x['skip']}==allowed
 assert len(allowed)==1 and next(iter(allowed))[0].endswith('IndustrialWasteV2R1OfficialExecutionTest')
 report['counts']={k:dict(v) for k,v in counts.items()};report['suites']=suites;report['deliberate_skip']=sorted(allowed)
 logs=[]
 for n,task,workers in [(B+'engine.log',':rules-engine:test',0),(B+'lava-dart.log',':mtg-sets:2000-2002:tests:test',0),(W+'qualification.log',':ai:test',1)]:
  s=z.read(n).decode();tasks=[(t,tail) for t,tail in re.findall(r'^> Task (\S+)(?: ([^\n]*))?$',s,re.M) if t.endswith(':test')]
  assert tasks and set(t for t,_ in tasks)=={task} and all(not v.strip() for _,v in tasks),tasks
  assert 'BUILD SUCCESSFUL' in s and 'BUILD FAILED' not in s
  assert s.count('started executing tests.')==s.count('finished executing tests.')==workers
  assert "'shlock' not found; running ./gradlew unlocked" in s
  logs.append({'path':n,'sha256':sha(z.read(n)),'tasks':tasks,'explicit_worker_pairs':workers,'worker_marker_limit':None if workers else 'No info worker markers; fresh actual task, named output and XML within live step window verified.'})
 py=z.read(B+'python-tests.txt').decode();pynames=re.findall(r'^(test\S.*) \.\.\. ok$',py,re.M)
 assert len(pynames)==len(set(pynames))==80 and 'Ran 80 tests' in py and re.search(r'^OK\s*$',py,re.M)
 report['python']={'cases':80,'identities':pynames,'sha256':sha(z.read(B+'python-tests.txt'))};report['logs']=logs
 worker=js(W+'receipt.json');assert worker['source_head']==SRC and worker['source_tree']==TREE and worker['status']=='PASS' and worker['command_exit_status']==0 and worker['official_games']==0 and worker['official_execution_authorized'] is False
 assert worker['bank_sha256']==sha(z.read(W+'frozen-case-bank.json')) and worker['compiled_inputs_unchanged'] is True
 for s in suites:
  if s['path'].startswith('ai/'):assert dt(worker['started_at_utc'])<=dt(s['timestamp'])<=dt(worker['command_finished_at_utc'])
 reg=js(W+'compiled-card-registry.json');assert sha(z.read(W+'compiled-card-registry.json'))==worker['compiled_registry']['sha256']
 assert len(reg['definitions'])==69 and len(reg['frozen_card_names'])==34 and len(reg['registered_token_names'])==35
 for d in reg['definitions']:assert sha(d['raw_definition_json'].encode())==d['raw_definition_sha256'] and json.loads(d['raw_definition_json'])['name']==d['name']
 obs=js(W+'runtime-classpath-observation/manifest.json');arc=js(W+'observed-ai-runtime/runtime-archive-receipt.json')
 assert obs['schema']=='industrial-post-run-runtime-classpath-observation-v1'
 assert dt(obs['observed_at_utc'])>=dt(worker['command_finished_at_utc'])
 assert obs['receipt_sha256']==arc['qualification_receipt_sha256']==sha(z.read(W+'receipt.json')) and arc['observation_sha256']==sha(z.read(W+'runtime-classpath-observation/manifest.json'))
 workers=obs['stages'][0]['matching_workers'];assert len(workers)==1 and workers[0]['classpath']==arc['ordered_classpath'] and len(arc['ordered_classpath'])==56
 assert workers[0]['argument_file_sha256']==worker['actual_worker']['argument_file_sha256']==arc['actual_worker_argument_file_sha256']
 assert arc['java_executable']['sha256']==worker['actual_worker']['java_sha256']==worker['java']['sha256']
 assert arc['source_head']==SRC and arc['engine_initializations']==arc['games']==arc['entropy_draws']==0
 flat=[]
 for i,c in enumerate(arc['ordered_classpath']):
  if c['type']=='file':flat.append({'path':f'classpath/{i:03d}/runtime','classpath_index':i,'sha256':c['sha256'],'bytes':c['bytes']})
  else:
   assert c['type']=='directory'
   flat.extend({'path':f"classpath/{i:03d}/{m['path']}",'classpath_index':i,'sha256':m['sha256'],'bytes':m['bytes']} for m in c['members'])
 assert flat==arc['archive']['members'] and len(flat)==2549
 tarpath=W+'observed-ai-runtime/'+arc['archive']['path'];assert z.getinfo(tarpath).file_size==arc['archive']['bytes']
 with z.open(tarpath) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==arc['archive']['sha256']
 want={x['path']:x for x in flat};seen=set();payload=0
 with z.open(tarpath) as stream,tarfile.open(fileobj=stream,mode='r|gz') as t:
  for m in t:
   assert m.isfile() and m.name in want and m.name not in seen
   e=want[m.name];assert m.size==e['bytes'];assert hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()==e['sha256'];seen.add(m.name);payload+=m.size
 assert seen==set(want)
 report['observed_runtime']={'scope':'Exact post-qualification classpath byte preservation only; not proof of in-flight stability or pre-consumption executing identity.','ordered_entries':56,'members':2549,'payload_bytes':payload,'archive_sha256':arc['archive']['sha256'],'registry_definitions':69,'registry_names':[x['name'] for x in reg['definitions']],'java_sha256_reported_by_capture':arc['java_executable']['sha256'],'worker_argument_sha256_reported_by_capture':arc['actual_worker_argument_file_sha256'],'java_executable_binary_independently_rehashed':False,'actual_worker_observations':1,'qualification_receipt_sha256':sha(z.read(W+'receipt.json'))}
 traces=[]
 for rp in [p for p in names if p.endswith('/replay.json')]:
  root=rp.rsplit('/',1)[0]+'/';replay=js(rp);actions=js(root+'actions.json');journal=[json.loads(l) for l in z.read(root+'transitions.jsonl').splitlines()];quiet=[json.loads(l) for l in z.read(root+'quiet-checkpoint-observations.jsonl').splitlines()]
  assert replay['status']=='EXACT_ACTION_EVENT_STATE_REPLAY' and replay['checkpointReplay']=='EXACT_EVERY_QUIET_CHECKPOINT_REPLAY'
  assert len(journal)==len(actions)*2 and replay['actions']==len(actions) and replay['quietCheckpointObservations']==len(quiet)
  for i,action in enumerate(actions):
   d,r=journal[2*i:2*i+2];assert d['type']=='ACTION_DECLARED' and r['type']=='ACTION_RETURNED' and d['index']==r['index']==i+1 and d['action']==action and r['error'] is None
  for q in quiet:assert q['stateSha256']==journal[q['acceptedActions']*2-1]['stateSha256']
  assert sha(z.read(root+'final-state.json'))==journal[-1]['stateSha256']
  attempt=js(root+'attempt-before-initialization.json');assert attempt['official'] is False and attempt['initialized'] is False
  first={}
  for q in quiet:first.setdefault(q['checkpoint']['ownTurn'],q['checkpoint'])
  assert list(first.values())==js(root+'checkpoints.json')
  traces.append({'root':root,'actions':len(actions),'quiet_observations':len(quiet),'replay_report':replay,'namespace':js(root+'input.json')['namespace'],'attempt':attempt,'raw_final_state_hash_verified':True,'state_event_action_reexecution_by_this_audit':False})
 assert sorted((x['actions'],x['quiet_observations']) for x in traces)==[(227,16),(242,16),(428,60)]
 report['excluded_successful_traces']=traces
 report['preserved_failure_fixture_paths']=[p for p in names if p.endswith('/failure.txt')]
 assert len(report['preserved_failure_fixture_paths'])==1
 complete=(RAW/'runtime-complete-decoded-job.log').read_text();assert 'git checkout --progress --force -B industrial-waste/v2-structural-redesign refs/remotes/origin/industrial-waste/v2-structural-redesign' in complete and re.search(r'git log -1 --format=%H\n[^\n]* '+SRC+r'\n',complete) and 'Cleaning up orphan processes' in complete
 report['complete_decoded_job_log']=pin(RAW/'runtime-complete-decoded-job.log')
report['limits']=['Read-only audit of actual completed source-bound CI qualification and original bytes. No local Java execution or semantic replay.', 'Observed classpath archive and reported Java/argument identities are post-run evidence, not a pre-prepare executing-runtime witness.', 'Deliberate official512 test skip is retained; zero official allocations from this qualification. No broad whole-source/gameplay admission.', 'Twelve publication parts match exact original byte ranges and local Git hashes; remote publication is a separate operation.']
(OUT/'independent-runtime-raw-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','zip_members':554,'counts':report['counts'],'python':80,'compiled_inputs':21066,'runtime_members':2549,'traces':[(x['actions'],x['quiet_observations']) for x in traces],'sha256':sha((OUT/'independent-runtime-raw-audit.json').read_bytes())}))
