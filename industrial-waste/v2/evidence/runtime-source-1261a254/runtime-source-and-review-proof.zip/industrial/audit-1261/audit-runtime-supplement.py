import json,zipfile,hashlib,tarfile,re,pathlib,datetime
P=pathlib.Path('industrial/audit-1261');sha=lambda b:hashlib.sha256(b).hexdigest()
z=zipfile.ZipFile('/dev/shm/industrial-1261-runtime-36283941502/runtime-original.zip');B='build/reports/industrial-waste-v2/runtime-composition/';W=B+'ai-worker/';read=lambda p:json.loads(z.read(p))
receipt=read(W+'receipt.json')
reg=read(W+'compiled-card-registry.json');assert len(reg['definitions'])==69 and len(reg['frozen_card_names'])==34 and len(reg['registered_token_names'])==35;assert sha(z.read(W+'compiled-card-registry.json'))==receipt['compiled_registry']['sha256']
for d in reg['definitions']:
 raw=d['raw_definition_json'];assert sha(raw.encode())==d['raw_definition_sha256'];assert json.loads(raw)['name']==d['name']
obs=read(W+'runtime-classpath-observation/manifest.json');arch=read(W+'observed-ai-runtime/runtime-archive-receipt.json');assert arch['qualification_receipt_sha256']==obs['receipt_sha256']==sha(z.read(W+'receipt.json'));assert arch['observation_sha256']==sha(z.read(W+'runtime-classpath-observation/manifest.json'))
workers=obs['stages'][0]['matching_workers'];assert len(workers)==1;assert workers[0]['classpath']==arch['ordered_classpath'];assert workers[0]['argument_file_sha256']==receipt['actual_worker']['argument_file_sha256']==arch['actual_worker_argument_file_sha256'];assert arch['java_executable']['sha256']==receipt['actual_worker']['java_sha256']==receipt['java']['sha256']
log=z.read(W+'qualification.log').decode();assert len(re.findall(r'Gradle Test Executor [0-9]+ started executing tests',log))==1;assert '> Task :ai:test\n' in log and 'BUILD SUCCESSFUL' in log
for p,task in [(B+'engine.log',':rules-engine:test'),(B+'lava-dart.log',':mtg-sets:2000-2002:tests:test')]:
 s=z.read(p).decode();assert '> Task '+task+'\n' in s and 'BUILD SUCCESSFUL' in s
py=z.read(B+'python-tests.txt').decode();names=re.findall(r'^(test\S.*) \.\.\. ok$',py,re.M);assert len(names)==80 and 'Ran 80 tests' in py
arc=arch['archive'];tarpath=W+'observed-ai-runtime/'+arc['path'];assert z.getinfo(tarpath).file_size==arc['bytes']
with z.open(tarpath) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==arc['sha256']
expected={m['path']:m for m in arc['members']};seen=set()
with z.open(tarpath) as f,tarfile.open(fileobj=f,mode='r|gz') as t:
 for m in t:
  if not m.isfile():continue
  assert m.name not in seen;seen.add(m.name);e=expected[m.name];assert m.size==e['bytes'];assert hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()==e['sha256']
assert seen==set(expected) and len(seen)==2549
tr=[]
for rp in [p for p in z.namelist() if p.endswith('/replay.json')]:
 root=rp.rsplit('/',1)[0]+'/';replay=read(rp);actions=read(root+'actions.json');journal=[json.loads(l) for l in z.read(root+'transitions.jsonl').splitlines()];quiet=[json.loads(l) for l in z.read(root+'quiet-checkpoint-observations.jsonl').splitlines()]
 assert len(journal)==len(actions)*2 and replay['actions']==len(actions) and replay['quietCheckpointObservations']==len(quiet)
 for i,action in enumerate(actions):
  d,r=journal[2*i:2*i+2];assert d['type']=='ACTION_DECLARED' and r['type']=='ACTION_RETURNED' and d['index']==r['index']==i+1 and d['action']==action and r['error'] is None
 for q in quiet:assert q['stateSha256']==journal[q['acceptedActions']*2-1]['stateSha256']
 assert sha(z.read(root+'final-state.json'))==journal[-1]['stateSha256'];assert read(root+'attempt-before-initialization.json')['official'] is False
 first={}
 for q in quiet:first.setdefault(q['checkpoint']['ownTurn'],q['checkpoint'])
 assert list(first.values())==read(root+'checkpoints.json')
 tr.append({'actions':len(actions),'quiet':len(quiet),'replay':replay['status'],'root':root})
assert sorted((x['actions'],x['quiet']) for x in tr)==[(227,16),(242,16),(428,60)]

flattened=[]
for i,entry in enumerate(arch['ordered_classpath']):
 if entry['type']=='file':flattened.append({'path':f'classpath/{i:03d}/runtime','classpath_index':i,'sha256':entry['sha256'],'bytes':entry['bytes']})
 else:
  assert entry['type']=='directory'
  for member in entry['members']:flattened.append({'path':f"classpath/{i:03d}/{member['path']}",'classpath_index':i,'sha256':member['sha256'],'bytes':member['bytes']})
assert flattened==arc['members']
result={'scope':'Source-author raw supplement, derived from preserved earlier independent checker. No local JVM replay or complete runtime/gameplay admission.','source':receipt['source_head'],'tree':receipt['source_tree'],'runtime_raw_audit_sha256':sha((P/'RUNTIME_RAW_AUDIT.json').read_bytes()),'registry_definitions':len(reg['definitions']),'registry_raw_hashes_and_names_verified':True,'python_cases':len(names),'actual_ai_workers':len(workers),'runtime_members':len(seen),'ordered_classpath_entries':len(arch['ordered_classpath']),'complete_ordered_classpath_flattening_matches_archived_members':True,'archive_sha256':arc['sha256'],'java_sha256':arch['java_executable']['sha256'],'worker_argument_sha256':arch['actual_worker_argument_file_sha256'],'traces':tr,'no_official':not receipt['official_execution_authorized'] and receipt['official_games']==0}
assert result['source']=='1261a25494d93f588efbcd1c1e5798b212a058c9' and result['tree']=='7e635c7ff700094d840bb64fdba7699f724cf594'
(P/'RUNTIME_SUPPLEMENT_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
