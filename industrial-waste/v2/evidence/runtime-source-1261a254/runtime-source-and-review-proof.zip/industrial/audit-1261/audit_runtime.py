import argparse, collections, hashlib, json, pathlib, tarfile, xml.etree.ElementTree as ET, zipfile

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('archive');ap.add_argument('out');args=ap.parse_args()
    p=pathlib.Path(args.archive)
    expected=json.loads((pathlib.Path(__file__).parent/'expected-git-files.json').read_text())
    report={'schema':'industrial-takeover-runtime-raw-audit-v1','source_commit':expected['source'],'source_tree':expected['tree'],
            'artifact':{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()},
            'scope':'Independent read of archived bytes; no local JVM execution or gameplay admission','failures':[]}
    with zipfile.ZipFile(p) as z:
        names=z.namelist(); assert len(names)==len(set(names));assert z.testzip() is None
        def find(suffix):
            hits=[n for n in names if n.endswith(suffix)];assert len(hits)==1,(suffix,hits);return hits[0]
        def read(suffix): return z.read(find(suffix))
        def js(suffix): return json.loads(read(suffix))
        prov=js('/provenance.json');assert prov['source_commit']==expected['source'] and prov['source_tree']==expected['tree']
        assert prov['initial_checkout_status']==''
        assert prov['official_allocations_initialized']==prov['official_actions_submitted']==prov['comparative_outcomes_exposed']==0
        before=js('ai-worker/compiled-inputs-before.json');after=js('ai-worker/compiled-inputs-after.json');assert before==after
        drift=[n for n,v in before.items() if expected['files'].get(n)!={'sha':v['git_blob'],'mode':v['git_mode']}];assert not drift,drift
        report['compiled_inputs']={'entries':len(before),'before_after_identical':True,'all_git_blob_mode_records_match_exact_source':True,
              'before_sha256':digest(read('ai-worker/compiled-inputs-before.json')),'after_sha256':digest(read('ai-worker/compiled-inputs-after.json'))}
        bank=js('ai-worker/frozen-case-bank.json');want={(r['class'],n) for r in bank['cases'] for n in r['cases']}
        allowed_skips={(r['class'],n) for r in bank['cases'] for n in r['allowed_skips']}
        suites=[];ai=[];counts=collections.defaultdict(collections.Counter)
        # The archived test-results tree is authoritative. Any copied AI bank is checked separately below.
        raw_xml=[n for n in names if '/build/test-results/test/TEST-' in n and n.endswith('.xml')]
        for n in raw_xml:
            raw=z.read(n);root=ET.fromstring(raw);cases=root.findall('testcase')
            assert int(root.get('tests'))==len(cases),(n,root.attrib)
            module=n.split('/build/test-results/test/')[0].split('/')[-1]
            actual=[]
            for c in cases:
                row={'name':c.get('name'),'class':c.get('classname',root.get('name')),
                     'failure':c.find('failure') is not None,'error':c.find('error') is not None,'skipped':c.find('skipped') is not None}
                actual.append(row);counts[module]['total']+=1
                counts[module]['failed']+=int(row['failure']);counts[module]['errors']+=int(row['error']);counts[module]['skipped']+=int(row['skipped'])
                counts[module]['passed']+=int(not any(row[k] for k in ('failure','error','skipped')))
                if module=='ai':ai.append(row)
            assert int(root.get('failures','0'))==sum(r['failure'] for r in actual)
            assert int(root.get('errors','0'))==sum(r['error'] for r in actual)
            assert int(root.get('skipped','0'))==sum(r['skipped'] for r in actual)
            suites.append({'path':n,'sha256':digest(raw),'timestamp':root.get('timestamp'),'cases':actual})
        actual={(r['class'],r['name']) for r in ai};assert len(ai)==len(actual)==bank['expected_total']
        assert actual==want,(actual-want,want-actual)
        assert {(r['class'],r['name']) for r in ai if r['skipped']}==allowed_skips
        assert not any(r['failure'] or r['error'] for r in ai)
        report['raw_counts']={k:dict(v) for k,v in counts.items()};report['suites']=suites
        worker=js('ai-worker/receipt.json');assert worker['status']=='PASS' and worker['command_exit_status']==0
        assert worker['source_head']==expected['source'] and worker['source_tree']==expected['tree']
        assert worker['bank_sha256']==digest(read('ai-worker/frozen-case-bank.json'))
        report['worker_receipt']=worker
        ar=js('observed-ai-runtime/runtime-archive-receipt.json');assert ar['status']=='ARCHIVED_OBSERVED_BYTES_REQUIRES_INDEPENDENT_REVIEW'
        report['runtime_archive_receipt']=ar
        artifact_path=find('observed-ai-runtime/'+ar['archive']['path'])
        with z.open(artifact_path) as f: archive_sha=hashlib.file_digest(f,'sha256').hexdigest()
        assert archive_sha==ar['archive']['sha256'] and z.getinfo(artifact_path).file_size==ar['archive']['bytes']
        members={r['path']:r for r in ar['archive']['members']};assert len(members)==len(ar['archive']['members'])
        seen=set()
        with z.open(artifact_path) as f, tarfile.open(fileobj=f,mode='r|gz') as tar:
            for entry in tar:
                assert entry.isfile() and entry.name in members and entry.name not in seen
                want_member=members[entry.name];stream=tar.extractfile(entry)
                assert entry.size==want_member['bytes'] and hashlib.file_digest(stream,'sha256').hexdigest()==want_member['sha256']
                seen.add(entry.name)
        assert seen==set(members)
        report['runtime_member_audit']={'verified':len(seen),'archive_sha256':archive_sha,'all_sizes_and_sha256_match':True}
        report['archive_members']=[{'name':x.filename,'bytes':x.file_size,'crc32':format(x.CRC,'08x')} for x in z.infolist()]
    report['status']='RAW_AUDIT_PASS_NOT_ADMISSION'
    pathlib.Path(args.out).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','artifact','compiled_inputs','raw_counts','runtime_member_audit')}))

if __name__=='__main__':main()
