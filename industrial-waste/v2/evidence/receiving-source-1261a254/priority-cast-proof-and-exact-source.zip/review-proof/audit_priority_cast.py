"""Independent raw355 audit. Reads originals and immutable source bytes; executes no engine."""
from pathlib import Path
import base64,gzip,hashlib,json,re,zipfile
from datetime import datetime
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent; RAW=ROOT/'industrial/audit-1261'
SRC='1261a25494d93f588efbcd1c1e5798b212a058c9'; TREE='7e635c7ff700094d840bb64fdba7699f724cf594'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):return json.loads(p.read_text())
def gzread(p):return json.loads(gzip.decompress(p.read_bytes()))
def pin(p):return {'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
treej=gzread(OUT/'current-complete-tree.json.gz');assert treej['sha']==TREE and not treej['truncated']
tree={x['path']:x for x in treej['entries']}
loc=read(OUT/'priority-source-locations.json');bodies={};jsoncache={}
for path,row in loc['found'].items():
 if 'file' in row:b=(ROOT/row['file']).read_bytes()
 else:
  if row['json'] not in jsoncache:jsoncache[row['json']]=read(ROOT/row['json'])
  j=jsoncache[row['json']];x=next(x for x in j if x.get('path')==path) if isinstance(j,list) else j[path];b=x['content'].encode()
 bodies[path]=b
fresh=gzread(OUT/'priority-fresh-source-bodies.json.gz');assert len(fresh)==175
for x in fresh:
 b=base64.b64decode(x['content']) if x['encoding']=='base64' else x['content'].encode();bodies[x['path']]=b
 assert blob(b)==x['sha']==tree[x['path']]['sha'],x['path']
assert len(bodies)==324
manifestcache=read(RAW/'priority-current-live-manifests.json')
for path,x in manifestcache.items():assert blob(x['content'].encode())==tree[path]['sha']
caseblob=read(RAW/'case-bank-live-source.json')['content'].encode();casepath='lab-coordinator/shared-capabilities/receiving-case-banks-v1.json'
assert blob(caseblob)==tree[casepath]['sha'];bank=json.loads(caseblob)
auth=gzread(OUT/'priority-preserved-authorities.json.gz');assert len(auth)==6
for x in auth:
 b=x['content'].encode();assert blob(b)==x['sha']
 if x['scope']=='current':assert blob(b)==tree[x['path']]['sha']
meta=read(OUT/'priority-runtime-live-metadata.json')['36283941456'];run=meta['run']
assert run['head_sha']==SRC and run['run_attempt']==1 and run['event']=='push' and run['conclusion']=='success'
assert meta['jobs']['total_count']==len(meta['jobs']['jobs'])==2
assert all(j['conclusion']=='success' for j in meta['jobs']['jobs'])
results=[];fullpins=[]
for file,name,oldfile,total in [('priority-original.zip','priority','10915152671.zip',220),('cast-original.zip','cast-observer','10915260528.zip',135)]:
 p=RAW/file;raw=p.read_bytes();artifact=next(a for a in meta['artifacts']['artifacts'] if a['digest']=='sha256:'+sha(raw))
 assert len(raw)==artifact['size_in_bytes'];assert artifact['workflow_run']['id']==run['id']
 with zipfile.ZipFile(p) as z,zipfile.ZipFile(ROOT/'industrial/audit-fc9bb'/oldfile) as old:
  assert z.testzip() is None and old.testzip() is None and len(z.namelist())==len(set(z.namelist()))
  members=[{'path':n,'bytes':len(z.read(n)),'sha256':sha(z.read(n))} for n in z.namelist()]
  man=json.loads(z.read('source-manifest.json'));before=json.loads(z.read('binding-attempt.json'));prov=json.loads(z.read('source-provenance.json'));actual=json.loads(z.read('actual-case-audit.json'))
  for obs in [before,prov]:
   assert obs['candidate_head']==obs['requested_head']==SRC and obs['tree']==TREE and obs['checkout_status']=='' and obs['official_execution_authorized'] is False
   assert obs['source_files_sha256']==man['source_files_sha256'] and obs['manifest_sha256']==sha(z.read('source-manifest.json'))
  mp='industrial-waste/v2/priority-receiving-'+name+'.json'
  assert z.read('source-manifest.json')==manifestcache[mp]['content'].encode()
  for path,h in man['source_files_sha256'].items():
   b=bodies[path];assert sha(b)==h and blob(b)==tree[path]['sha'],path
   if not results:fullpins.append({'path':path,'bytes':len(b),'sha256':h,'git_blob':blob(b),'body_origin':'fresh immutable fetch' if path in loc['missing'] else loc['found'][path]})
  assert len(man['source_files_sha256'])==324
  assert man['stages']==bank['banks'][name]
  assert actual['head']==SRC and actual['tree']==TREE and actual['actual_cases']==total and actual['errors']==[] and actual['official_games']==actual['outcomes_exposed']==0 and actual['official_execution_authorized'] is False
  assert actual['manifest_sha256']==sha(z.read('source-manifest.json')) and actual['case_bank_sha256']==sha(caseblob)
  rules=z.read('effective-rules.txt');assert len(rules)==man['rules']['byte_length'] and sha(rules)==man['rules']['sha256']
  for rule in man['preserved_authorities']:
   current=next(x for x in auth if x['scope']=='current' and x['path']==rule['path'])
   donor=next(x for x in auth if x['scope']=='donor' and x['path']==rule['donor_path'])
   assert current['content']==donor['content'] and sha(current['content'].encode())==rule['sha256']
  oldcases={}
  for n in old.namelist():
   if n.endswith('.xml'):
    e=ET.fromstring(old.read(n));oldcases[e.attrib['name']]={(c.attrib['classname'],c.attrib['name']) for c in e.findall('testcase')}
  commandnames=[n for n in z.namelist() if re.fullmatch('command-[0-9]+.json',n)]
  assert len(commandnames)==(27 if name=='priority' else 2)
  commands={n:json.loads(z.read(n)) for n in commandnames};commandproof=[]
  for n,c in commands.items():
   assert c['exit_status']==0 and c['started_epoch_ns']<c['finished_epoch_ns']
   assert c['command'][:2]==['just','test-class'] and '--rerun' in c['command'] and '--no-build-cache' in c['command']
   log=z.read(c['log']).decode();tasks=[(t,tail) for t,tail in re.findall(r'^> Task (\S+)(?: ([^\n]*))?$',log,re.M) if t.endswith(':test')]
   assert tasks and all(not tail.strip() for _,tail in tasks)
   assert log.count('started executing tests.')==log.count('finished executing tests.')==1 and 'BUILD SUCCESSFUL' in log and 'BUILD FAILED' not in log
   assert "'shlock' not found; running ./gradlew unlocked" in log
   commandproof.append({'file':n,**c,'log_sha256':sha(z.read(c['log'])),'fresh_test_task_lines':tasks,'fresh_worker_pairs':1})
  ids=[];stages=[]
  for st in man['stages']:
   xp='tests/'+st['stage']+'/TEST-'+st['class']+'.xml';b=z.read(xp);e=ET.fromstring(b);cases=e.findall('testcase');names=[(c.attrib['classname'],c.attrib['name']) for c in cases]
   assert e.attrib['name']==st['class'] and len(cases)==int(e.attrib['tests'])==st['expected_cases']
   assert all(int(e.attrib.get(k,0))==0 for k in ['failures','errors','skipped']) and all(c.find(k) is None for c in cases for k in ['failure','error','skipped'])
   assert set(names)==oldcases[st['class']] and len(names)==len(set(names));ids.extend(names)
   c=json.loads(z.read('tests/'+st['stage']+'/command.json'));assert c in commands.values() and z.read('tests/'+st['stage']+'/exit-status.txt').strip()==b'0'
   assert st['class'].split('.')[-1] in c['classes']
   timestamp=datetime.fromisoformat(e.attrib['timestamp'].replace('Z','+00:00')).timestamp()
   assert c['started_epoch_ns']/1e9<=timestamp<=c['finished_epoch_ns']/1e9
   assert st['test_source'] in bodies
   observed=next(x for x in actual['stages'] if x['stage']==st['stage']);assert observed['xml_sha256']==sha(b) and observed['case_names']==[n for _,n in names]
   stages.append({'stage':st['stage'],'class':st['class'],'cases':len(cases),'identities':names,'xml_sha256':sha(b),'timestamp':e.attrib['timestamp'],'command':c['log'],'source_sha256':sha(bodies[st['test_source']])})
  assert len(ids)==len(set(ids))==total
  results.append({'bank':name,'run':run['id'],'event':run['event'],'attempt':1,'artifact_id':artifact['id'],**pin(p),'members':members,'crc':'PASS','stages':stages,'commands':commandproof,'unique_cases':total,'failures':0,'errors':0,'skips':0,'source_pin_count':324,'prior_original':pin(ROOT/'industrial/audit-fc9bb'/oldfile),'source_map_timing':'Binding attempt and source-provenance records are pre-execution; no post-execution pin map is implied.'})
report={'schema':'sphinx-independent-industrial1261-priority-cast-raw-v1','source':SRC,'tree':TREE,'banks':results,'source_pins':fullpins,'source_body_counts':{'rehashed_retained':149,'fresh_immutable_fetch':175,'total_unique':324,'additional_preserved_authority_pairs':3},'engine_execution_by_review':False,'runtime_admitted':False,'official_execution_authorized':False,'proof_inputs':[pin(OUT/p) for p in ['priority-source-locations.json','priority-fresh-source-bodies.json.gz','current-complete-tree.json.gz','priority-runtime-live-metadata.json','priority-preserved-authorities.json.gz']]}
(OUT/'independent-priority-cast-raw-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':[r['unique_cases'] for r in results],'commands':[len(r['commands']) for r in results],'pins':len(fullpins),'sha256':sha((OUT/'independent-priority-cast-raw-audit.json').read_bytes())}))
