from pathlib import Path
import zipfile,json,hashlib,xml.etree.ElementTree as E,datetime,re
root=Path(__file__).parent
bank=json.loads((root.parent/'audit-51607/receiving-case-banks-v1.json').read_bytes());out=[]
for file,bankname,oldfile,expected in [('priority-original.zip','priority','industrial/audit-fc9bb/10915152671.zip',220),('cast-original.zip','cast-observer','industrial/audit-fc9bb/10915260528.zip',135)]:
 with zipfile.ZipFile(root/file) as z, zipfile.ZipFile(oldfile) as old:
  assert z.testzip() is None
  actual=json.loads(z.read('actual-case-audit.json'));manifest=json.loads(z.read('source-manifest.json'));prov=json.loads(z.read('source-provenance.json'));before=json.loads(z.read('binding-attempt.json'));oldactual=json.loads(old.read('actual-case-audit.json'))
  assert actual['head']==prov['candidate_head']==before['candidate_head']=='1261a25494d93f588efbcd1c1e5798b212a058c9'
  assert actual['tree']==prov['tree']==before['tree']=='7e635c7ff700094d840bb64fdba7699f724cf594'
  assert before['checkout_status']==prov['checkout_status']==''
  assert prov['source_files_sha256']==manifest['source_files_sha256']==before['source_files_sha256']
  assert prov['manifest_sha256']==actual['manifest_sha256']==hashlib.sha256(z.read('source-manifest.json')).hexdigest()
  assert actual['case_bank_sha256']==hashlib.sha256((root.parent/'audit-51607/receiving-case-banks-v1.json').read_bytes()).hexdigest()
  assert actual['actual_cases']==expected and not actual['errors']
  assert not actual['official_execution_authorized'] and actual['official_games']==actual['outcomes_exposed']==0
  want=bank['banks'][bankname];assert manifest['stages']==want
  oldnames={x['stage']:x['case_names'] for x in oldactual['stages']};stages=[]
  xmlpaths=[n for n in z.namelist() if n.endswith('.xml')];assert len(xmlpaths)==len(want)
  for stage in want:
   hits=[n for n in xmlpaths if n.startswith('tests/'+stage['stage']+'/')];assert len(hits)==1
   raw=z.read(hits[0]);x=E.fromstring(raw);cases=x.findall('testcase');names=[c.get('name') for c in cases]
   assert x.get('name')==stage['class']
   assert len(cases)==int(x.get('tests'))==stage['expected_cases']
   assert all(int(x.get(k,0))==0 for k in ['failures','errors','skipped'])
   assert all(all(c.find(k) is None for k in ['failure','error','skipped']) for c in cases)
   assert set(names)==set(oldnames[stage['stage']]) and len(names)==len(oldnames[stage['stage']])
   cmd=json.loads(z.read('tests/'+stage['stage']+'/command.json'))
   assert cmd['exit_status']==0 and z.read('tests/'+stage['stage']+'/exit-status.txt').strip()==b'0'
   assert '--rerun' in cmd['command'] and '--no-build-cache' in cmd['command']
   assert stage['class'].split('.')[-1] in cmd['classes']
   log=z.read(cmd['log']).decode();assert 'BUILD SUCCESSFUL' in log
   tasks=[l for l in log.splitlines() if re.search(r'> Task :'+stage['module'].replace('/',':')+r':test(?:\s|$)',l)]
   assert tasks and all(not any(s in l for s in ['FROM-CACHE','UP-TO-DATE','NO-SOURCE','SKIPPED']) for l in tasks)
   timestamp=datetime.datetime.fromisoformat(x.get('timestamp').replace('Z','+00:00')).timestamp()
   assert cmd['started_epoch_ns']/1e9-2<=timestamp<=cmd['finished_epoch_ns']/1e9+2
   report=next(r for r in actual['stages'] if r['stage']==stage['stage'])
   assert report['xml_sha256']==hashlib.sha256(raw).hexdigest() and report['case_names']==names
   stages.append({'stage':stage['stage'],'class':stage['class'],'cases':len(names),'xml_sha256':hashlib.sha256(raw).hexdigest(),'timestamp':x.get('timestamp'),'exact_prior_raw_case_identity_match':True,'command':cmd['log'],'fresh_test_tasks':tasks})
  commands=[n for n in z.namelist() if re.fullmatch(r'command-\d+\.json',n)]
  out.append({'artifact':file,'bytes':(root/file).stat().st_size,'sha256':hashlib.sha256((root/file).read_bytes()).hexdigest(),'source_commit':actual['head'],'source_tree':actual['tree'],'bank':bankname,'case_count':expected,'stages':stages,'command_count':len(commands),'source_pin_count':len(manifest['source_files_sha256']),'pin_scope':'All archived before/after/manifest pins equal; complete live-file rehash remains independent review scope.','all_raw_xml_cases_pass_no_skip':True,'official_games':0,'scope':'SOURCE_AUTHOR_RAW_COMPONENT_AUDIT_NOT_COMPLETE_R1_ADMISSION'})
(root/'AUTHOR_PRIORITY_CAST_RAW_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print([{k:v for k,v in row.items() if k!='stages'} for row in out])
