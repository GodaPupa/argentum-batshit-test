package com.wingedsheep.engine.handlers

import com.wingedsheep.engine.state.components.battlefield.chosenCreatureType
import com.wingedsheep.engine.state.components.battlefield.chosenColor
import com.wingedsheep.engine.state.components.battlefield.CastChoicesComponent
import com.wingedsheep.engine.state.components.battlefield.ChoiceValue
import com.wingedsheep.engine.handlers.effects.TargetResolutionUtils
import com.wingedsheep.engine.handlers.predicates.becameTappedOnlyOnceThisTurn
import com.wingedsheep.engine.handlers.predicates.hasDealtDamage
import com.wingedsheep.engine.handlers.predicates.receivedCounterThisTurn
import com.wingedsheep.engine.mechanics.layers.ProjectedState
import com.wingedsheep.engine.mechanics.layers.ProjectedValues
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.battlefield.AttachedToComponent
import com.wingedsheep.engine.state.components.battlefield.AttachmentsComponent
import com.wingedsheep.engine.state.components.battlefield.CrewSaddleContributorsComponent
import com.wingedsheep.engine.state.components.battlefield.EnteredThisTurnComponent
import com.wingedsheep.engine.state.components.battlefield.LastKnownPermanentComponent
import com.wingedsheep.engine.state.components.battlefield.DealtCombatDamageToPlayersThisTurnComponent
import com.wingedsheep.engine.state.components.battlefield.HasDealtCombatDamageToPlayerComponent
import com.wingedsheep.engine.state.components.battlefield.WasDealtDamageThisTurnComponent
import com.wingedsheep.engine.state.components.battlefield.TappedComponent
import com.wingedsheep.engine.state.components.battlefield.SaddledComponent
import com.wingedsheep.engine.state.components.battlefield.SolvedComponent
import com.wingedsheep.engine.state.components.battlefield.RenownedComponent
import com.wingedsheep.engine.state.components.combat.AttackedThisCombatComponent
import com.wingedsheep.engine.state.components.combat.AttackersDeclaredThisTurnComponent
import com.wingedsheep.engine.state.components.combat.AttackingComponent
import com.wingedsheep.engine.state.components.combat.BlockedThisCombatComponent
import com.wingedsheep.engine.state.components.combat.BlockedThisTurnComponent
import com.wingedsheep.engine.state.components.combat.BlockingComponent
import com.wingedsheep.engine.state.components.combat.PlayerAttackersThisTurnComponent
import com.wingedsheep.engine.state.components.combat.PlayerAttackersLastTurnComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.engine.state.components.identity.FaceDownComponent
import com.wingedsheep.engine.state.components.identity.RoomComponent
import com.wingedsheep.engine.state.components.identity.HasMorphAbilityComponent
import com.wingedsheep.engine.state.components.battlefield.CountersComponent
import com.wingedsheep.engine.state.components.identity.MorphDataComponent
import com.wingedsheep.engine.state.components.identity.PutIntoGraveyardThisTurnComponent
import com.wingedsheep.engine.state.components.identity.TokenComponent
import com.wingedsheep.sdk.core.CardType
import com.wingedsheep.sdk.core.Color
import com.wingedsheep.sdk.core.CounterType
import com.wingedsheep.engine.state.components.stack.ActivatedAbilityOnStackComponent
import com.wingedsheep.engine.state.components.stack.EntitySnapshot
import com.wingedsheep.engine.state.components.stack.SpellOnStackComponent
import com.wingedsheep.engine.state.components.stack.TriggeredAbilityOnStackComponent
import com.wingedsheep.sdk.core.Keyword
import com.wingedsheep.sdk.core.Subtype
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.predicates.CardPredicate
import com.wingedsheep.sdk.scripting.predicates.ControllerPredicate
import com.wingedsheep.sdk.scripting.predicates.evaluateWith
import com.wingedsheep.sdk.scripting.GameObjectFilter
import com.wingedsheep.sdk.scripting.predicates.StatePredicate
import com.wingedsheep.sdk.scripting.references.Player
import com.wingedsheep.sdk.scripting.targets.EffectTarget
import com.wingedsheep.sdk.scripting.values.DynamicAmount
import com.wingedsheep.sdk.scripting.values.EntityReference
import com.wingedsheep.engine.state.CastSpellRecord
import com.wingedsheep.engine.state.components.stack.ChosenTarget
import com.wingedsheep.engine.state.components.stack.TargetsComponent

/**
 * Evaluates the new unified predicates and filters against game state.
 *
 * This provides evaluation for:
 * - CardPredicate (type, color, subtype, mana value, P/T, keywords)
 * - StatePredicate (tapped, attacking, blocking)
 * - ControllerPredicate (youControl, opponentControls)
 * - GameObjectFilter (composed from the above predicates)
 */
class PredicateEvaluator {

    /**
     * Evaluate a GameObjectFilter against an entity using projected state.
     *
     * Always pass a [ProjectedState] — for battlefield entities this is required to see
     * continuous effects (type/color/control changes, granted keywords, P/T mods). For
     * entities in non-battlefield zones (hand, library, graveyard, stack), the projection
     * has no entry and the predicate matchers fall back to base [CardComponent] data, so
     * passing `state.projectedState` is always correct.
     *
     * Mid-projection callers (e.g. [com.wingedsheep.engine.mechanics.layers.EffectApplicator])
     * pass their intermediate projected state instead of the cached one.
     *
     * @param state Current game state
     * @param projected Projected (post-Rule 613) state — typically `state.projectedState`
     * @param entityId Entity to evaluate
     * @param filter The filter to match against
     * @param context Evaluation context (for controller resolution)
     * @return true if the entity matches all predicates in the filter
     */
    fun matches(
        state: GameState,
        projected: ProjectedState,
        entityId: EntityId,
        filter: GameObjectFilter,
        context: PredicateContext
    ): Boolean {
        val container = state.getEntity(entityId) ?: return false

        // Check controller predicate first (if specified)
        filter.controllerPredicate?.let { controllerPred ->
            if (!matchesControllerPredicate(state, projected, entityId, controllerPred, context)) {
                return false
            }
        }

        // Check all card predicates using projected state. The list is always a
        // conjunction; OR is expressed within a single CardPredicate.Or, not by a
        // filter-level flag.
        val cardMatches = filter.cardPredicates.all { predicate ->
            matchesCardPredicate(state, projected, entityId, predicate, context)
        }

        if (!cardMatches) return false

        // Check all state predicates. Most read base state, but the attachment/relative-power
        // branches need projection — thread the SAME [projected] we were handed (during layer
        // projection this is the empty-fallback ProjectedState, so we don't re-enter the lazy
        // GameState.projectedState mid-projection and recurse forever).
        val stateMatches = filter.statePredicates.all { predicate ->
            matchesStatePredicate(state, entityId, predicate, context, projected)
        }

        if (!stateMatches) return false

        // Recursive union (the `or` infix): match if any branch matches in full.
        if (filter.anyOf.isNotEmpty()) {
            return filter.anyOf.any { matches(state, projected, entityId, it, context) }
        }

        return true
    }

    /**
     * Evaluate [filter] against **frozen last-known information** instead of a live entity — the
     * arm of [matches] for an object the engine can no longer look up at all. Today that means a
     * *token*: CR 704.5d sweeps a token out of any non-battlefield zone as a state-based action and
     * the entity is deleted, so a Clue that sacrificed itself to pay for its own draw ability has no
     * `getEntity` row left while that ability sits on the stack (CR 113.7a — the ability exists
     * independently of its source, and the source's last known information is what answers
     * questions about it).
     *
     * **Partial by construction**, and deliberately so: what is answered here is card types,
     * sub/supertypes, colors, keywords, token-ness, controller and owner. A predicate outside that set (mana value,
     * P/T comparisons, "has a non-mana activated ability", …) reports
     * *unanswerable* rather than guessing — see [matchesSnapshotPredicate] — and an unanswerable
     * predicate makes the whole filter fail to match, which is the same answer the caller got before
     * any snapshot existed. State predicates (tapped, attacking, …) describe a battlefield presence
     * the object no longer has, so a filter carrying one never matches a snapshot.
     *
     * **Caller invariant: pass a snapshot captured with the state-aware
     * [com.wingedsheep.engine.state.components.stack.captureEntitySnapshots] overload** (the
     * `(ids, state)` one), and populate [EntitySnapshot.typeLine] and [EntitySnapshot.keywords] on
     * top of it. The unanswerable-reports-null discipline above cannot cover
     * [EntitySnapshot.wasToken] or [EntitySnapshot.keywords]: both default to a *legitimate* value
     * (`false` / empty) with no "was never captured" state, so a snapshot taken by the projection-
     * only overload answers `IsToken` false, `IsNontoken` true and every `HasKeyword` false with
     * full confidence rather than reporting unknown. There is one caller today
     * ([CardPredicate.AbilitySourceMatches] against
     * [com.wingedsheep.engine.state.components.stack.ActivatedAbilityOnStackComponent.lastKnownSourceSnapshot],
     * which does exactly that); a second one must too.
     */
    fun matchesSnapshot(
        state: GameState,
        snapshot: EntitySnapshot,
        filter: GameObjectFilter,
        context: PredicateContext,
        requireComplete: Boolean = false,
    ): Boolean {
        filter.controllerPredicate?.let { controllerPred ->
            if (requireComplete) {
                check(snapshot.controllerId != null && snapshot.ownerId != null) {
                    "Missing controller or owner for damage-source snapshot"
                }
                check(snapshotControllerPredicateSupported(controllerPred)) {
                    "Unsupported controller predicate for damage-source snapshot: $controllerPred"
                }
            }
            if (!matchesSnapshotController(state, snapshot, controllerPred, context)) return false
        }
        if (filter.statePredicates.isNotEmpty()) {
            check(!requireComplete) { "Unsupported state predicates for damage-source snapshot: ${filter.statePredicates}" }
            return false
        }
        val predicateResults = filter.cardPredicates.map { matchesSnapshotPredicate(snapshot, it) }
        if (false in predicateResults) return false
        if (null in predicateResults) {
            check(!requireComplete) { "Incomplete or unsupported damage-source snapshot predicates: ${filter.cardPredicates}" }
            return false
        }
        if (filter.anyOf.isNotEmpty()) {
            return filter.anyOf.any { matchesSnapshot(state, snapshot, it, context, requireComplete) }
        }
        return true
    }

    private fun snapshotControllerPredicateSupported(predicate: ControllerPredicate): Boolean = when (predicate) {
        is ControllerPredicate.And -> predicate.predicates.all(::snapshotControllerPredicateSupported)
        is ControllerPredicate.Or -> predicate.predicates.all(::snapshotControllerPredicateSupported)
        is ControllerPredicate.Not -> snapshotControllerPredicateSupported(predicate.predicate)
        ControllerPredicate.ControlledByYou, ControllerPredicate.ControlledByOpponent,
        ControllerPredicate.ControlledByAny, ControllerPredicate.ControlledByActivePlayer,
        ControllerPredicate.ControlledByTargetOpponent, ControllerPredicate.ControlledByTargetPlayer,
        ControllerPredicate.OwnedByYou, ControllerPredicate.OwnedByOpponent,
        ControllerPredicate.OwnedByTargetPlayer -> true
        else -> false
    }

    /**
     * Tri-state evaluation of one [CardPredicate] against frozen last-known information:
     * `true`/`false` when [EntitySnapshot] carries the characteristic, **null** when it doesn't.
     *
     * The null arm is what keeps [CardPredicate.Not] honest — negating "I don't know" would turn an
     * unsupported predicate into a match — and it propagates through `And`/`Or` the way an unknown
     * operand should: `And` is false if any operand is false, unknown if any is unknown; `Or` is
     * true if any operand is true, unknown if any is unknown.
     */
    private fun matchesSnapshotPredicate(snapshot: EntitySnapshot, predicate: CardPredicate): Boolean? {
        val typeLine = snapshot.typeLine
        return when (predicate) {
            CardPredicate.IsCreature -> typeLine?.isCreature
            CardPredicate.IsLand -> typeLine?.isLand
            CardPredicate.IsArtifact -> typeLine?.isArtifact
            CardPredicate.IsEnchantment -> typeLine?.isEnchantment
            CardPredicate.IsInstant -> typeLine?.isInstant
            CardPredicate.IsSorcery -> typeLine?.isSorcery
            CardPredicate.IsPlaneswalker -> typeLine?.cardTypes?.contains(CardType.PLANESWALKER)
            CardPredicate.IsPermanent -> typeLine?.isPermanent
            CardPredicate.IsLegendary -> typeLine?.isLegendary
            CardPredicate.IsNonlegendary -> typeLine?.isLegendary?.not()
            CardPredicate.IsToken -> snapshot.wasToken
            CardPredicate.IsNontoken -> !snapshot.wasToken
            is CardPredicate.HasColor -> snapshot.colors?.contains(predicate.color.name)
            is CardPredicate.NotColor -> snapshot.colors?.contains(predicate.color.name)?.not()
            CardPredicate.IsColorless -> snapshot.colors?.isEmpty()
            CardPredicate.IsColored -> snapshot.colors?.isNotEmpty()
            CardPredicate.IsMulticolored -> snapshot.colors?.let { it.size > 1 }
            CardPredicate.IsMonocolored -> snapshot.colors?.let { it.size == 1 }
            is CardPredicate.HasSubtype ->
                typeLine?.hasSubtype(predicate.subtype)
                    ?: snapshot.subtypes.any { it.equals(predicate.subtype.value, ignoreCase = true) }
            is CardPredicate.HasKeyword -> predicate.keyword.name in snapshot.keywords
            is CardPredicate.Not -> matchesSnapshotPredicate(snapshot, predicate.predicate)?.not()
            is CardPredicate.And -> {
                val results = predicate.predicates.map { matchesSnapshotPredicate(snapshot, it) }
                when {
                    results.any { it == false } -> false
                    results.any { it == null } -> null
                    else -> true
                }
            }
            is CardPredicate.Or -> {
                val results = predicate.predicates.map { matchesSnapshotPredicate(snapshot, it) }
                when {
                    results.any { it == true } -> true
                    results.any { it == null } -> null
                    else -> false
                }
            }
            else -> null
        }
    }

    /**
     * [ControllerPredicate] against a snapshot's frozen controller/owner. Missing historical
     * information remains a non-match rather than borrowing a returned object's controller.
     */
    private fun matchesSnapshotController(
        state: GameState,
        snapshot: EntitySnapshot,
        predicate: ControllerPredicate,
        context: PredicateContext
    ): Boolean {
        val controllerId = snapshot.controllerId
        return when (predicate) {
            is ControllerPredicate.And ->
                predicate.predicates.all { matchesSnapshotController(state, snapshot, it, context) }
            is ControllerPredicate.Or ->
                predicate.predicates.any { matchesSnapshotController(state, snapshot, it, context) }
            is ControllerPredicate.Not ->
                !matchesSnapshotController(state, snapshot, predicate.predicate, context)
            ControllerPredicate.ControlledByYou -> controllerId == context.controllerId
            ControllerPredicate.ControlledByOpponent -> controllerId?.let { it != context.controllerId } ?: false
            ControllerPredicate.ControlledByAny -> controllerId != null
            ControllerPredicate.ControlledByActivePlayer -> controllerId == state.activePlayerId
            ControllerPredicate.ControlledByTargetOpponent ->
                context.targetOpponentId?.let { controllerId == it } ?: false
            ControllerPredicate.ControlledByTargetPlayer ->
                context.targetPlayerId?.let { controllerId == it } ?: false
            ControllerPredicate.OwnedByYou -> snapshot.ownerId == context.controllerId
            ControllerPredicate.OwnedByOpponent -> snapshot.ownerId?.let { it != context.controllerId } ?: false
            ControllerPredicate.OwnedByTargetPlayer ->
                context.targetPlayerId?.let { snapshot.ownerId == it } ?: false
            else -> false
        }
    }

    /**
     * Whether an object with **no battlefield projection entry** (a spell on the stack, a card in
     * hand/library/graveyard/exile) effectively has [subtype]. Honors its printed subtypes,
     * Changeling (all creature types in all zones, Rule 702.73), and cross-zone "is the chosen
     * type" grants (Conspiracy / Leyline of Transformation — see
     * [ProjectedState.crossZoneGrantedSubtypes]). Battlefield permanents never reach this helper;
     * their subtypes come from the projected `subtypes` set.
     */
    private fun matchesBaseSubtype(
        state: GameState,
        projected: ProjectedState,
        entityId: EntityId,
        card: CardComponent,
        subtype: Subtype
    ): Boolean =
        card.typeLine.hasSubtype(subtype) ||
            (Keyword.CHANGELING in card.baseKeywords && subtype.value in Subtype.ALL_CREATURE_TYPES) ||
            projected.crossZoneGrantedSubtypes(state, entityId).any { it.equals(subtype.value, ignoreCase = true) }

    /**
     * The creature/other subtypes an object effectively has for "shares a type with" / chosen-type
     * comparisons. Battlefield permanents use their projected subtype set (empty if face down,
     * Rule 708.2); non-battlefield objects use their printed subtypes plus any cross-zone "is the
     * chosen type" grants ([ProjectedState.crossZoneGrantedSubtypes]). Changeling is intentionally
     * *not* folded in here (callers that honor Changeling check it separately), preserving the
     * pre-existing semantics of the share/chosen predicates.
     */
    private fun effectiveSubtypes(
        state: GameState,
        projected: ProjectedState,
        entityId: EntityId,
        card: CardComponent,
        projectedValues: ProjectedValues?
    ): Set<String> {
        if (projectedValues != null) {
            return if (projectedValues.isFaceDown) emptySet() else projectedValues.subtypes
        }
        return card.typeLine.subtypes.map { it.value }.toSet() +
            projected.crossZoneGrantedSubtypes(state, entityId)
    }

    /**
     * The entity's **card types** as uppercase [CardType] names, read from projected state with a
     * fall back to base card data.
     *
     * [ProjectedState.getTypes] mixes card types and supertypes into one string set (that is how
     * `Supertype.fromProjectedTypes` recovers the supertypes), so a caller that means "card type"
     * in the CR 205.2a sense has to sieve the set rather than compare it whole — otherwise a
     * legendary permanent would "share a card type" with any other legendary one. Pass
     * [projectedTypes] when the caller already has the projection entry in hand; pass null to look
     * it up (a reference outside the battlefield has no entry and falls through to its printed
     * type line).
     */
    private fun cardTypesOf(
        state: GameState,
        projected: ProjectedState,
        entityId: EntityId,
        projectedTypes: Set<String>?
    ): Set<String> {
        val raw = projectedTypes ?: projected.getTypes(entityId)
        val fromProjection = raw.mapNotNullTo(mutableSetOf()) { type ->
            CardType.entries.firstOrNull { it.name.equals(type, ignoreCase = true) }?.name
        }
        if (fromProjection.isNotEmpty()) return fromProjection
        return state.getEntity(entityId)?.get<CardComponent>()?.typeLine?.cardTypes
            ?.mapTo(mutableSetOf()) { it.name }
            ?: emptySet()
    }

    /**
     * Evaluate a CardPredicate against an entity using projected state.
     */
    fun matchesCardPredicate(
        state: GameState,
        projected: ProjectedState,
        entityId: EntityId,
        predicate: CardPredicate,
        context: PredicateContext? = null
    ): Boolean {
        val container = state.getEntity(entityId) ?: return false

        // Handle stack item type predicates before CardComponent check
        // since abilities on the stack don't have CardComponent
        if (predicate is CardPredicate.IsActivatedOrTriggeredAbility) {
            return container.has<ActivatedAbilityOnStackComponent>() ||
                container.has<TriggeredAbilityOnStackComponent>()
        }
        if (predicate is CardPredicate.IsTriggeredAbility) {
            return container.has<TriggeredAbilityOnStackComponent>()
        }
        if (predicate is CardPredicate.IsActivatedAbility) {
            return container.has<ActivatedAbilityOnStackComponent>()
        }
        // Composite predicates must recurse per-branch *before* the CardComponent null-check below,
        // so a heterogeneous Or/And/Not whose branches mix spell predicates (need a CardComponent)
        // with ability predicates (no CardComponent) evaluates each branch on its own terms. Without
        // this, `Or(IsInstant, IsSorcery, IsActivatedOrTriggeredAbility)` would short-circuit to
        // false for an ability on the stack (the whole composite bails at the missing CardComponent)
        // — breaking "copy/counter target spell or ability" (Return the Favor, Stifle).
        if (predicate is CardPredicate.Or) {
            return predicate.predicates.any { matchesCardPredicate(state, projected, entityId, it, context) }
        }
        if (predicate is CardPredicate.And) {
            return predicate.predicates.all { matchesCardPredicate(state, projected, entityId, it, context) }
        }
        if (predicate is CardPredicate.Not) {
            return !matchesCardPredicate(state, projected, entityId, predicate.predicate, context)
        }
        // Stack-relative targeting predicate: read the stack entity's TargetsComponent
        // and match each chosen target against the subfilter. Works for both spells and
        // activated/triggered abilities (none of which have CardComponent for the
        // permanent-target case, but TargetsComponent is independent of card data).
        if (predicate is CardPredicate.TargetsMatching) {
            val targets = container.get<TargetsComponent>()?.targets ?: return false
            if (targets.isEmpty()) return false
            val subContext = context ?: return false
            return targets.any { chosen ->
                val targetEntityId = when (chosen) {
                    is ChosenTarget.Permanent -> chosen.entityId
                    is ChosenTarget.Card -> chosen.cardId
                    is ChosenTarget.Spell -> chosen.spellEntityId
                    is ChosenTarget.Player -> return@any false
                }
                matches(state, projected, targetEntityId, predicate.subfilter, subContext)
            }
        }
        // Ability-source predicate ("copy target ability ... from a creature source"): an ability on
        // the stack is its own object with no characteristics of its own (CR 113.3b/c), so the match
        // is redirected onto the ability's source (CR 113.7) and evaluated there. Handled before the
        // CardComponent null-check for the same reason the ability predicates above are — the
        // ability entity has no CardComponent.
        //
        // Last known information: the source is routinely gone by the time the ability is on the
        // stack (a dies trigger's source is in the graveyard; a self-sacrifice ability's source is
        // already sacrificed). Two arms, in order:
        //  1. the source entity still exists — `matches` reads its projected characteristics while
        //     it is on the battlefield and falls back to its printed ones once it has left, which
        //     is equivalent resolution to what `SourceTypeTargeting.sourceCardTypes` does for
        //     Artifact Ward, and what CR 113.7a / CR 608.2b call for;
        //  2. the source entity is *gone* — a token swept by CR 704.5d — so fall back to the frozen
        //     `lastKnownSourceSnapshot` the activation captured before the self-sacrifice cost took
        //     it (a cracked Clue is still "an artifact source"). This is the same LKI value type the
        //     rest of the engine uses (`EntitySnapshot`), read through the `EntityView` accessors,
        //     not a parallel store.
        // A spell on the stack is deliberately not matched: it has no ability-on-stack component,
        // and the clause only ever speaks of abilities.
        if (predicate is CardPredicate.AbilitySourceMatches) {
            val activated = container.get<ActivatedAbilityOnStackComponent>()
            val sourceId = activated?.sourceId
                ?: container.get<TriggeredAbilityOnStackComponent>()?.sourceId
                ?: return false
            // A missing context is a non-match rather than a context-free evaluation of the
            // subfilter, deliberately and in step with the `TargetsMatching` branch above: the
            // subfilter may carry a controller predicate ("from a creature source you control")
            // that has no answer without one, and both live call sites (TargetFinder,
            // TargetEnumerationUtils) always supply a context.
            val subContext = context ?: return false
            if (state.getEntity(sourceId) != null) {
                return matches(state, projected, sourceId, predicate.subfilter, subContext)
            }
            val snapshot = activated?.lastKnownSourceSnapshot?.takeIf { it.entityId == sourceId }
                ?: return false
            return matchesSnapshot(state, snapshot, predicate.subfilter, subContext)
        }

        val card = container.get<CardComponent>() ?: return false
        val projectedValues = projected.getProjectedValues(entityId)

        // Use projected types/colors/keywords if available, otherwise fall back to base.
        // The projected `types` set includes supertypes (LEGENDARY, BASIC, SNOW, ...) baked in
        // by StateProjector — mirror that here so predicates like IsLegendary work for non-
        // battlefield entities (cards in hand/library/graveyard) which have no projection entry.
        val types = projectedValues?.types ?: (
            card.typeLine.cardTypes.map { it.name } + card.typeLine.supertypes.map { it.name }
        ).toSet()
        val colors = projectedValues?.colors ?: card.colors.map { it.name }.toSet()
        val keywords = projectedValues?.keywords ?: (card.baseKeywords.map { it.name } + card.baseFlags.map { it.name }).toSet()

        return when (predicate) {
            // Type predicates - use projected types
            CardPredicate.IsCreature -> "CREATURE" in types
            CardPredicate.IsLand -> "LAND" in types
            CardPredicate.IsArtifact -> "ARTIFACT" in types
            CardPredicate.IsEnchantment -> "ENCHANTMENT" in types
            CardPredicate.IsPlaneswalker -> "PLANESWALKER" in types
            CardPredicate.IsInstant -> "INSTANT" in types
            CardPredicate.IsSorcery -> "SORCERY" in types
            // Adventure-ness is a static characteristic of the whole card (not a projected type),
            // read straight off the CardComponent flag stamped at entity creation.
            CardPredicate.HasAdventure -> card.hasAdventure
            // Likewise for double-faced-ness (CR 712.1): a whole-card layout characteristic stamped
            // at entity creation, not a projected type, and true on either face.
            CardPredicate.IsDoubleFaced -> card.isDoubleFaced
            CardPredicate.HasNoAbilities -> card.oracleText.isBlank()
            CardPredicate.IsBasicLand -> "LAND" in types && card.typeLine.supertypes.any { it.name == "BASIC" }
            CardPredicate.IsPermanent -> types.any { it in setOf("CREATURE", "LAND", "ARTIFACT", "ENCHANTMENT", "PLANESWALKER") }
            CardPredicate.IsNonland -> "LAND" !in types
            CardPredicate.IsNoncreature -> "CREATURE" !in types
            CardPredicate.IsNonenchantment -> "ENCHANTMENT" !in types
            CardPredicate.IsNonartifact -> "ARTIFACT" !in types
            CardPredicate.IsToken -> container.has<TokenComponent>()
            CardPredicate.IsNontoken -> !container.has<TokenComponent>()
            CardPredicate.IsLegendary -> "LEGENDARY" in types
            CardPredicate.IsNonlegendary -> "LEGENDARY" !in types
            CardPredicate.HasNonManaActivatedAbility -> card.hasNonManaActivatedAbility
            CardPredicate.HasActivatedAbility -> card.hasActivatedAbility

            // Color predicates - use projected colors
            is CardPredicate.HasColor -> predicate.color.name in colors
            is CardPredicate.NotColor -> predicate.color.name !in colors
            CardPredicate.HasChosenColor -> context?.chosenColor?.let { it.name in colors } ?: false
            CardPredicate.IsColorless -> colors.isEmpty()
            CardPredicate.IsColored -> colors.isNotEmpty()
            CardPredicate.IsMulticolored -> colors.size > 1
            CardPredicate.IsMonocolored -> colors.size == 1

            // Subtype predicates - use projected subtypes when available (for text-changing effects)
            // Face-down creatures have no subtypes (Rule 708.2)
            is CardPredicate.HasSubtype -> {
                if (projectedValues?.isFaceDown == true) {
                    false
                } else {
                    projectedValues?.subtypes?.any { it.equals(predicate.subtype.value, ignoreCase = true) }
                        ?: matchesBaseSubtype(state, projected, entityId, card, predicate.subtype)
                }
            }
            is CardPredicate.NotSubtype -> {
                if (projectedValues?.isFaceDown == true) {
                    true  // Face-down has no subtypes
                } else {
                    val hasSubtype = projectedValues?.subtypes?.any { it.equals(predicate.subtype.value, ignoreCase = true) }
                        ?: matchesBaseSubtype(state, projected, entityId, card, predicate.subtype)
                    !hasSubtype
                }
            }
            is CardPredicate.HasAnyOfSubtypes -> {
                if (projectedValues?.isFaceDown == true) {
                    false
                } else {
                    predicate.subtypes.any { subtype ->
                        projectedValues?.subtypes?.any { it.equals(subtype.value, ignoreCase = true) }
                            ?: matchesBaseSubtype(state, projected, entityId, card, subtype)
                    }
                }
            }
            is CardPredicate.HasBasicLandType -> {
                if (projectedValues?.isFaceDown == true) {
                    false  // Face-down has no land types
                } else {
                    projectedValues?.subtypes?.any { it.equals(predicate.landType, ignoreCase = true) }
                        ?: card.typeLine.hasSubtype(com.wingedsheep.sdk.core.Subtype(predicate.landType))
                }
            }

            // Name predicates
            // A face-down permanent has no name (CR 708.2a), so it matches no name predicate —
            // the same masking the subtype/color/mana-value arms above apply. Load-bearing for the
            // batch combat-damage detector, which relies on this evaluator alone to keep a
            // face-down creature out of a name-filtered trigger.
            is CardPredicate.NameEquals ->
                projectedValues?.isFaceDown != true && card.name == predicate.name

            // CR 709 + Central Elevator ruling: a Room card may be found only if none of its
            // door names matches an *unlocked* door name of a Room the searcher controls. A Room
            // with no unlocked doors contributes neither of its names; a split Room card carries
            // both door names and is excluded if either matches. Fails open with no controller.
            is CardPredicate.NameNotSharedWithControlledRoom -> {
                val controllerId = context?.controllerId
                if (controllerId == null) {
                    true
                } else {
                    val controlledDoorNames = state.getBattlefield().flatMapTo(mutableSetOf<String>()) { id ->
                        val room = state.getEntity(id)?.get<RoomComponent>()
                        if (room == null || projected.getController(id) != controllerId) {
                            emptyList()
                        } else {
                            room.faces.filter { it.id in room.unlocked }.map { it.name }
                        }
                    }
                    card.name.split(" // ").map { it.trim() }.none { it in controlledDoorNames }
                }
            }
            is CardPredicate.NameNotSharedWithControlledToken -> {
                val controllerId = context?.controllerId
                if (controllerId == null) {
                    true
                } else {
                    val candidateName = projectedValues?.name ?: card.name
                    state.getBattlefield().none { id ->
                        val tokenName = projected.getName(id)
                            ?: state.getEntity(id)?.get<CardComponent>()?.name
                        projected.getController(id) == controllerId &&
                            state.getEntity(id)?.has<TokenComponent>() == true &&
                            tokenName == candidateName
                    }
                }
            }

            // "that doesn't have the same name as another permanent you control" (Yenna,
            // Redtooth Regent). Compares against every *other* permanent the controller has on
            // the battlefield — tokens and cards alike — so two same-named permanents disqualify
            // each other. Names on both sides come from the projection, honoring Layer 3
            // name-changing effects. Fails open with no controller in scope.
            is CardPredicate.NameNotSharedWithAnotherControlledPermanent -> {
                val controllerId = context?.controllerId
                if (controllerId == null) {
                    true
                } else {
                    val candidateName = projectedValues?.name ?: card.name
                    state.getBattlefield().none { id ->
                        id != entityId &&
                            projected.getController(id) == controllerId &&
                            (
                                projected.getName(id)
                                    ?: state.getEntity(id)?.get<CardComponent>()?.name
                                ) == candidateName
                    }
                }
            }

            // Keyword predicates - use projected keywords
            is CardPredicate.HasKeyword -> predicate.keyword.name in keywords
            is CardPredicate.NotKeyword -> predicate.keyword.name !in keywords

            // Mana value predicates - face-down has CMC 0 (Rule 708.2)
            is CardPredicate.ManaValueEquals -> {
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc == predicate.value
            }
            is CardPredicate.ManaValueAtMost -> {
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc <= predicate.max
            }
            is CardPredicate.ManaValueEqualsX -> {
                // Null xValue means X is unbound (legal-action enumeration runs before the player
                // chooses X). Match permissively so the ability is offered at all — failing closed
                // here means an "{X}: … target card with mana value X" ability is never enumerated,
                // because at X-unbound no card in the graveyard qualifies. Mirrors ManaValueAtMostX
                // and PowerEqualsX; the chosen X is enforced at activation-time validation and the
                // CR 608.2b resolution-time re-check. Likeness Looter, Rydia, Summoner of Mist.
                val xValue = context?.xValue
                if (xValue == null) true
                else {
                    val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                    cmc == xValue
                }
            }
            is CardPredicate.ManaValueAtMostX -> {
                // Null xValue means X is unbound (legal-action enumeration runs before the
                // player chooses X). Match permissively so the cast action is offered; the
                // chosen X is enforced at cast-time validation and resolution-time re-check.
                val xValue = context?.xValue
                if (xValue == null) true
                else {
                    val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                    cmc <= xValue
                }
            }
            is CardPredicate.ManaValueAtLeast -> {
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc >= predicate.min
            }
            is CardPredicate.ManaValueAtMostEntity -> {
                val refEntityId = resolveEntityReference(state, predicate.reference, context) ?: return false
                val refManaValue = state.getEntity(refEntityId)?.get<CardComponent>()?.manaValue ?: return false
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc <= refManaValue
            }
            is CardPredicate.ManaValueAtMostEntityManaSpent -> {
                val refEntityId = resolveEntityReference(state, predicate.reference, context) ?: return false
                val manaSpent = ManaSpentReader.totalSpent(state, refEntityId)
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc <= manaSpent
            }
            is CardPredicate.ManaValueAtMostColorsSpent -> {
                val refEntityId = resolveEntityReference(state, predicate.reference, context) ?: return false
                val colorsSpent = ManaSpentReader.distinctColorsSpent(state, refEntityId)
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc <= colorsSpent
            }
            is CardPredicate.ManaValueAtMostDynamic -> {
                val cap = evaluateDynamicCap(state, predicate.amount, context) ?: return false
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc <= cap
            }
            is CardPredicate.ManaValueEqualsDynamic -> {
                val want = evaluateDynamicCap(state, predicate.amount, context) ?: return false
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc == want
            }
            is CardPredicate.PowerEqualsDynamic -> {
                val want = evaluateDynamicCap(state, predicate.amount, context) ?: return false
                // No power at all (a noncreature spell) never matches — `null == want` is false.
                (projectedValues?.power ?: card.baseStats?.basePower) == want
            }
            is CardPredicate.ToughnessEqualsDynamic -> {
                val want = evaluateDynamicCap(state, predicate.amount, context) ?: return false
                (projectedValues?.toughness ?: card.baseStats?.baseToughness) == want
            }
            CardPredicate.ManaValueIsEven -> {
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc % 2 == 0
            }
            CardPredicate.ManaValueIsOdd -> {
                val cmc = if (projectedValues?.isFaceDown == true) 0 else card.manaValue
                cmc % 2 != 0
            }
            CardPredicate.HasXInManaCost -> {
                // Inspect the printed cost's {X} symbol, not the computed CMC. Face-down objects
                // (Rule 708.2 — no mana cost) never match.
                if (projectedValues?.isFaceDown == true) false else card.manaCost.hasX
            }
            is CardPredicate.ColoredManaSymbolsAtLeast -> {
                // Printed cost's colored pips (CR 107.4e/f via ManaCost.coloredSymbolCount) — not
                // the object's color, which layer 5 can change. Face-down: no mana cost (CR 708.2).
                if (projectedValues?.isFaceDown == true) false
                else card.manaCost.coloredSymbolCount(predicate.colors.toSet()) >= predicate.min
            }

            // Power/toughness predicates - use projected P/T
            is CardPredicate.PowerEquals -> {
                val power = projectedValues?.power ?: card.baseStats?.basePower
                power == predicate.value
            }
            is CardPredicate.PowerEqualsX -> {
                // Null xValue means X is unbound (legal-action enumeration runs before the
                // player chooses X). Match permissively so the ability is offered; the chosen
                // X is enforced at activation-time validation and resolution-time re-check —
                // mirrors ManaValueAtMostX. Once X is bound, require power to equal it exactly.
                val xValue = context?.xValue
                if (xValue == null) true
                else {
                    val power = projectedValues?.power ?: card.baseStats?.basePower
                    power == xValue
                }
            }
            is CardPredicate.PowerAtMost -> {
                val power = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                power <= predicate.max
            }
            is CardPredicate.PowerAtLeast -> {
                val power = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                power >= predicate.min
            }
            is CardPredicate.PowerAtLeastX -> {
                // Only meaningful at resolution, where X is bound (e.g. Expel the Interlopers'
                // non-targeted DestroyAll after the chosen number is stamped as X). A null xValue
                // is unexpected here; match nothing rather than everything so an unbound X can't
                // silently wipe the board — mirrors ToughnessAtMostX.
                val xValue = context?.xValue
                if (xValue == null) false
                else {
                    val power = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                    power >= xValue
                }
            }
            is CardPredicate.ToughnessEquals -> {
                val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness
                toughness == predicate.value
            }
            is CardPredicate.ToughnessAtMost -> {
                val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness ?: 0
                toughness <= predicate.max
            }
            is CardPredicate.ToughnessAtMostX -> {
                // Only meaningful at resolution, where X is bound (e.g. Zero Point Ballad's
                // non-targeted DestroyAll). A null xValue is unexpected here; match nothing
                // rather than everything so an unbound X can't silently wipe the board.
                val xValue = context?.xValue
                if (xValue == null) false
                else {
                    val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness ?: 0
                    toughness <= xValue
                }
            }
            is CardPredicate.ToughnessAtLeast -> {
                val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness ?: 0
                toughness >= predicate.min
            }
            is CardPredicate.PowerOrToughnessAtLeast -> {
                val power = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness ?: 0
                power >= predicate.min || toughness >= predicate.min
            }
            is CardPredicate.PowerOrToughnessAtMost -> {
                val power = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness ?: 0
                power <= predicate.max || toughness <= predicate.max
            }
            is CardPredicate.TotalPowerAndToughnessAtMost -> {
                val power = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness ?: 0
                (power + toughness) <= predicate.max
            }
            CardPredicate.ToughnessGreaterThanPower -> {
                val power = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                val toughness = projectedValues?.toughness ?: card.baseStats?.baseToughness ?: 0
                toughness > power
            }

            is CardPredicate.PowerGreaterThanEntity -> {
                val refEntityId = resolveEntityReference(state, predicate.reference, context) ?: return false
                val refContainer = state.getEntity(refEntityId) ?: return false
                // Prefer projected power for the reference (layer effects, +1/+1 counters, etc.);
                // fall back to its base printed power when projection has no entry (e.g., off-battlefield).
                val refPower = state.projectedState.getPower(refEntityId)
                    ?: refContainer.get<CardComponent>()?.baseStats?.basePower
                    ?: return false
                val candidatePower = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                candidatePower > refPower
            }

            is CardPredicate.PowerAtMostEntity -> {
                val refEntityId = resolveEntityReference(state, predicate.reference, context) ?: return false
                val refContainer = state.getEntity(refEntityId) ?: return false
                val refPower = state.projectedState.getPower(refEntityId)
                    ?: refContainer.get<CardComponent>()?.baseStats?.basePower
                    ?: return false
                val candidatePower = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                candidatePower <= refPower
            }

            is CardPredicate.PowerLessThanEntity -> {
                val refEntityId = resolveEntityReference(state, predicate.reference, context) ?: return false
                val refContainer = state.getEntity(refEntityId) ?: return false
                val refPower = state.projectedState.getPower(refEntityId)
                    ?: refContainer.get<CardComponent>()?.baseStats?.basePower
                    ?: return false
                val candidatePower = projectedValues?.power ?: card.baseStats?.basePower ?: 0
                candidatePower < refPower
            }

            CardPredicate.PowerGreaterThanBase -> {
                // Self-relative: current (projected) power vs the object's own printed base power.
                // A +1/+1 counter, an anthem, or any temporary pump raises projected power above
                // base and qualifies; a shrunk/unmodified creature does not. No projected power
                // (off-battlefield) or no fixed base (*/CDA power) → not greater.
                val basePower = card.baseStats?.basePower ?: return false
                val currentPower = projectedValues?.power ?: basePower
                currentPower > basePower
            }

            // Source-relative predicates
            CardPredicate.NotOfSourceChosenType -> {
                val sourceId = context?.sourceId ?: return true
                val chosenType = state.getEntity(sourceId)
                    ?.chosenCreatureType()
                    ?: return true
                val hasSubtype = projectedValues?.subtypes?.any { it.equals(chosenType, ignoreCase = true) }
                    ?: (card.typeLine.hasSubtype(Subtype(chosenType)) ||
                        projected.crossZoneGrantedSubtypes(state, entityId).any { it.equals(chosenType, ignoreCase = true) })
                !hasSubtype
            }

            CardPredicate.SharesCreatureTypeWithSource -> {
                val sourceId = context?.sourceId ?: return false
                // Source may be a spell on the stack (e.g., Amplify resolution-time reveal) —
                // projection only covers the battlefield, so fall back to base CardComponent.
                val sourceSubtypes = projected.getSubtypes(sourceId).ifEmpty {
                    state.getEntity(sourceId)?.get<CardComponent>()?.typeLine?.subtypes?.map { it.value }?.toSet()
                        ?: emptySet()
                }
                if (sourceSubtypes.isEmpty()) return false
                val entitySubtypes = effectiveSubtypes(state, projected, entityId, card, projectedValues)
                entitySubtypes.any { entitySubtype ->
                    sourceSubtypes.any { it.equals(entitySubtype, ignoreCase = true) }
                }
            }

            CardPredicate.SharesCreatureTypeWithTriggeringEntity -> {
                val triggeringId = context?.triggeringEntityId ?: return false
                // Try projected state first, fall back to base CardComponent (for dead creatures)
                val triggeringSubtypes = projected.getSubtypes(triggeringId).ifEmpty {
                    state.getEntity(triggeringId)?.get<CardComponent>()?.typeLine?.subtypes?.map { it.value }?.toSet()
                        ?: emptySet()
                }
                if (triggeringSubtypes.isEmpty()) return false
                val entitySubtypes = effectiveSubtypes(state, projected, entityId, card, projectedValues)
                entitySubtypes.any { entitySubtype ->
                    triggeringSubtypes.any { it.equals(entitySubtype, ignoreCase = true) }
                }
            }

            CardPredicate.HasChosenSubtype -> {
                val sourceId = context?.sourceId ?: return false
                val chosenType = state.getEntity(sourceId)
                    ?.chosenCreatureType()
                    ?: return false
                val entitySubtypes = effectiveSubtypes(state, projected, entityId, card, projectedValues)
                entitySubtypes.any { it.equals(chosenType, ignoreCase = true) } ||
                    // Changeling: has all creature types in all zones
                    (Keyword.CHANGELING in card.baseKeywords &&
                        chosenType in Subtype.ALL_CREATURE_TYPES)
            }

            is CardPredicate.SharesCreatureTypeWith -> {
                val referenceId = resolveEntityReference(state, predicate.entity, context) ?: return false
                val referenceSubtypes = projected.getSubtypes(referenceId).ifEmpty {
                    state.getEntity(referenceId)?.get<CardComponent>()?.typeLine?.subtypes?.map { it.value }?.toSet()
                        ?: emptySet()
                }
                if (referenceSubtypes.isEmpty()) return false
                val entitySubtypes = effectiveSubtypes(state, projected, entityId, card, projectedValues)
                entitySubtypes.any { entitySubtype ->
                    referenceSubtypes.any { it.equals(entitySubtype, ignoreCase = true) }
                }
            }

            is CardPredicate.SharesCardTypeWith -> {
                val referenceId = resolveEntityReference(state, predicate.entity, context) ?: return false
                val referenceTypes = cardTypesOf(state, projected, referenceId, null)
                if (referenceTypes.isEmpty()) return false
                val entityTypes = cardTypesOf(state, projected, entityId, projectedValues?.types)
                    .ifEmpty { card.typeLine.cardTypes.mapTo(mutableSetOf()) { it.name } }
                entityTypes.any { it in referenceTypes }
            }

            // "shares a card type with a card exiled with this creature" (Cemetery Illuminator).
            // The pile-wide sibling of SharesCardTypeWith: reads *every* card still in the source's
            // linked-exile pile, because the Illuminator keeps exiling on each enter and attack and
            // "a card exiled with this creature" means any of them. Printed type lines on both
            // sides — a card in exile and a card in a library have no battlefield projection whose
            // types a continuous effect could have changed (the same reading CostCalculator's
            // SharedCardTypesWithLinkedExile takes). Fails closed with no source in context.
            CardPredicate.SharesCardTypeWithLinkedExile -> {
                val sourceId = context?.sourceId ?: return false
                val exiledTypes = com.wingedsheep.engine.handlers.effects.linkedexile.LinkedExileLookup
                    .exiledCards(state, sourceId)
                    .mapNotNull { state.getEntity(it)?.get<CardComponent>()?.typeLine?.cardTypes }
                    .flatMapTo(mutableSetOf()) { types -> types.map { it.name } }
                if (exiledTypes.isEmpty()) return false
                val entityTypes = cardTypesOf(state, projected, entityId, projectedValues?.types)
                    .ifEmpty { card.typeLine.cardTypes.mapTo(mutableSetOf()) { it.name } }
                entityTypes.any { it in exiledTypes }
            }

            // "with the same name as a card exiled with this permanent" (Circu, Dimir Lobotomist).
            // The name axis of the branch above, and pile-wide for the same reason: Circu keeps
            // exiling on every blue and every black spell, so no single index names "a card exiled
            // with Circu". Printed names on both sides — a card in exile and a card in a hand or
            // library have no battlefield projection a Layer-3 rename could have touched. Fails
            // closed with no source in context.
            CardPredicate.SharesNameWithLinkedExile -> {
                val sourceId = context?.sourceId ?: return false
                val exiledNames = com.wingedsheep.engine.handlers.effects.linkedexile.LinkedExileLookup
                    .exiledCards(state, sourceId)
                    .mapNotNull { state.getEntity(it)?.get<CardComponent>()?.name?.takeIf { n -> n.isNotBlank() } }
                    .toSet()
                if (exiledNames.isEmpty()) return false
                val entityName = projected.getName(entityId)?.takeIf { it.isNotBlank() } ?: card.name
                entityName.isNotBlank() && entityName in exiledNames
            }

            is CardPredicate.SharesNameWith -> {
                val referenceId = resolveEntityReference(state, predicate.entity, context) ?: return false
                // Projected first so a renamed permanent (Layer 3, CR 613.1c) compares under its
                // new name; base card data second so a reference with no projection entry — an
                // Imprint pile's exiled card — still has a name to compare.
                val referenceName = projected.getName(referenceId)?.takeIf { it.isNotBlank() }
                    ?: state.getEntity(referenceId)?.get<CardComponent>()?.name
                    ?: return false
                if (referenceName.isBlank()) return false
                val entityName = projected.getName(entityId)?.takeIf { it.isNotBlank() } ?: card.name
                entityName.isNotBlank() && entityName == referenceName
            }

            is CardPredicate.SharesNameWithPermanentYouControl -> {
                val name = card.name
                if (name.isBlank()) return false
                val controllerId = context?.controllerId ?: return false
                state.getBattlefield().any { otherId ->
                    projected.getController(otherId) == controllerId &&
                        state.getEntity(otherId)?.get<CardComponent>()?.name == name &&
                        matches(state, projected, otherId, predicate.filter, context)
                }
            }

            is CardPredicate.SharesColorWith -> {
                val referenceId = resolveEntityReference(state, predicate.entity, context) ?: return false
                val referenceColors = projected.getColors(referenceId).ifEmpty {
                    state.getEntity(referenceId)?.get<CardComponent>()?.colors?.map { it.name }?.toSet()
                        ?: emptySet()
                }
                if (referenceColors.isEmpty()) return false
                colors.any { it in referenceColors }
            }

            is CardPredicate.SharesManaValueWith -> {
                val referenceId = resolveEntityReference(state, predicate.entity, context) ?: return false
                // Mana value is not a projected characteristic — no layer changes it — so both sides
                // read their card component directly. That is also what lets the reference be a card
                // outside the battlefield (an Imprint pile's exiled card).
                val referenceManaValue = state.getEntity(referenceId)?.get<CardComponent>()?.manaValue
                    ?: return false
                card.manaValue == referenceManaValue
            }

            is CardPredicate.SharesColorWithPermanentYouControl -> {
                if (colors.isEmpty()) return false
                val controllerId = context?.controllerId ?: return false
                state.getBattlefield().any { otherId ->
                    projected.getController(otherId) == controllerId &&
                        matches(state, projected, otherId, predicate.filter, context) &&
                        projected.getColors(otherId).any { it in colors }
                }
            }

            is CardPredicate.DoesNotShareCreatureTypeWithPermanentYouControl -> {
                val controllerId = context?.controllerId ?: return false
                val entitySubtypes = projectedValues?.subtypes ?: card.typeLine.subtypes.map { it.value }.toSet()
                // No shared type when no permanent you control shares any creature type with the candidate.
                state.getBattlefield().none { otherId ->
                    projected.getController(otherId) == controllerId &&
                        matches(state, projected, otherId, predicate.filter, context) &&
                        projected.getSubtypes(otherId).any { otherSubtype ->
                            entitySubtypes.any { it.equals(otherSubtype, ignoreCase = true) }
                        }
                }
            }

            is CardPredicate.DoesNotShareLandTypeWithPermanentYouControl -> {
                val controllerId = context?.controllerId ?: return false
                val entityLandTypes = (projectedValues?.subtypes ?: card.typeLine.subtypes.map { it.value }.toSet())
                    .filter { it in Subtype.ALL_BASIC_LAND_TYPES }
                // A candidate with no land types of its own shares none, so it matches trivially.
                if (entityLandTypes.isEmpty()) return true
                // No shared type when no permanent you control shares any land type with the candidate.
                state.getBattlefield().none { otherId ->
                    projected.getController(otherId) == controllerId &&
                        matches(state, projected, otherId, predicate.filter, context) &&
                        projected.getSubtypes(otherId).any { otherSubtype ->
                            entityLandTypes.any { it.equals(otherSubtype, ignoreCase = true) }
                        }
                }
            }

            CardPredicate.SharesChosenColorWithSource -> {
                val sourceId = context?.sourceId ?: return false
                val chosenColor = state.getEntity(sourceId)
                    ?.chosenColor()
                    ?: return false
                chosenColor.name in colors
            }

            CardPredicate.SharesColorWithRecipient -> {
                val recipientId = context?.recipientId ?: return false
                if (recipientId == entityId) return false
                val recipientColors = projected.getColors(recipientId).ifEmpty {
                    state.getEntity(recipientId)?.get<CardComponent>()?.colors?.map { it.name }?.toSet()
                        ?: emptySet()
                }
                if (recipientColors.isEmpty() || colors.isEmpty()) return false
                colors.any { it in recipientColors }
            }

            // Context-relative predicates (pipeline variable references)
            is CardPredicate.NameEqualsChosen -> {
                val chosenName = context?.chosenValues?.get(predicate.variableName) ?: return false
                // Nameless while face down (CR 708.2a) — see [CardPredicate.NameEquals] above.
                projectedValues?.isFaceDown != true && card.name.equals(chosenName, ignoreCase = true)
            }

            // Source-component name reference: the name durably chosen by the source permanent as it
            // entered (Petrified Hamlet). Read from the source's CastChoicesComponent[slot] — works
            // in static/projection contexts where there is no pipeline, as long as the predicate
            // context supplies the granting permanent as the source.
            is CardPredicate.NameEqualsChosenComponent -> {
                val sourceId = context?.sourceId ?: return false
                val chosenName = (state.getEntity(sourceId)
                    ?.get<CastChoicesComponent>()?.chosen?.get(predicate.slot)
                    as? ChoiceValue.TextChoice)?.text ?: return false
                card.name.equals(chosenName, ignoreCase = true)
            }

            // Source-component card-type reference: the card type durably chosen by the source
            // permanent as it entered (Arachne). Read from the source's CastChoicesComponent[slot];
            // works at cost-calculation / projection time as long as the predicate context supplies
            // the choosing permanent as the source. The card-type analogue of NameEqualsChosenComponent.
            is CardPredicate.CardTypeEqualsChosenComponent -> {
                val sourceId = context?.sourceId ?: return false
                val chosenType = (state.getEntity(sourceId)
                    ?.get<CastChoicesComponent>()?.chosen?.get(predicate.slot)
                    as? ChoiceValue.TextChoice)?.text ?: return false
                card.typeLine.cardTypes.any { it.displayName.equals(chosenType, ignoreCase = true) }
            }

            is CardPredicate.OriginallyPrintedInSet ->
                card.originalSetCode?.equals(predicate.setCode, ignoreCase = true) == true

            is CardPredicate.HasCardTypeFromVariable -> {
                val chosenType = context?.chosenValues?.get(predicate.variableName) ?: return false
                card.typeLine.cardTypes.any { it.displayName.equals(chosenType, ignoreCase = true) }
            }

            is CardPredicate.HasSubtypeFromVariable -> {
                val chosenType = context?.chosenValues?.get(predicate.variableName) ?: return false
                val entitySubtypes = projectedValues?.subtypes ?: card.typeLine.subtypes.map { it.value }.toSet()
                entitySubtypes.any { it.equals(chosenType, ignoreCase = true) } ||
                    // Changeling: has all creature types in all zones
                    (Keyword.CHANGELING in card.baseKeywords &&
                        chosenType in Subtype.ALL_CREATURE_TYPES)
            }

            is CardPredicate.HasSubtypeInStoredList -> {
                val storedTypes = context?.storedStringLists?.get(predicate.listName) ?: return false
                val entitySubtypes = projectedValues?.subtypes ?: card.typeLine.subtypes.map { it.value }.toSet()
                entitySubtypes.any { subtype ->
                    storedTypes.any { it.equals(subtype, ignoreCase = true) }
                }
            }

            is CardPredicate.HasSubtypeInEachStoredGroup -> {
                val groups = context?.storedSubtypeGroups?.get(predicate.groupName) ?: return false
                if (groups.isEmpty()) return false
                val entitySubtypes = projectedValues?.subtypes ?: card.typeLine.subtypes.map { it.value }.toSet()
                if (entitySubtypes.isEmpty()) return false
                groups.all { group ->
                    entitySubtypes.any { entitySubtype ->
                        group.any { it.equals(entitySubtype, ignoreCase = true) }
                    }
                }
            }

            // Composite predicates
            is CardPredicate.And -> {
                predicate.predicates.all { matchesCardPredicate(state, projected, entityId, it, context) }
            }
            is CardPredicate.Or -> {
                predicate.predicates.any { matchesCardPredicate(state, projected, entityId, it, context) }
            }
            is CardPredicate.Not -> {
                !matchesCardPredicate(state, projected, entityId, predicate.predicate, context)
            }

            // Handled before CardComponent check above — unreachable here
            CardPredicate.IsActivatedOrTriggeredAbility -> false
            CardPredicate.IsTriggeredAbility -> false
            CardPredicate.IsActivatedAbility -> false
            is CardPredicate.TargetsMatching -> false
            is CardPredicate.AbilitySourceMatches -> false
        }
    }

    /**
     * Evaluate a ControllerPredicate using projected state (for controller-changing effects).
     */
    private fun matchesControllerPredicate(
        state: GameState,
        projected: ProjectedState,
        entityId: EntityId,
        predicate: ControllerPredicate,
        context: PredicateContext
    ): Boolean {
        val container = state.getEntity(entityId) ?: return false

        // OwnedByYou/OwnedByOpponent check the card's owner, not controller.
        // These predicates are used for cards in graveyards/exile which don't have ControllerComponent —
        // so handle them before the controller lookup below.
        return when (predicate) {
            is ControllerPredicate.And -> predicate.predicates.all {
                matchesControllerPredicate(state, projected, entityId, it, context)
            }
            is ControllerPredicate.Or -> predicate.predicates.any {
                matchesControllerPredicate(state, projected, entityId, it, context)
            }
            is ControllerPredicate.Not ->
                !matchesControllerPredicate(state, projected, entityId, predicate.predicate, context)
            ControllerPredicate.OwnedByYou -> {
                val card = container.get<CardComponent>()
                card?.ownerId == context.controllerId
            }
            ControllerPredicate.OwnedByOpponent -> {
                val card = container.get<CardComponent>()
                card?.ownerId != null && card.ownerId != context.controllerId
            }
            ControllerPredicate.OwnedByTargetPlayer -> {
                val card = container.get<CardComponent>()
                val targetPlayer = context.targetPlayerId
                card?.ownerId != null && targetPlayer != null && card.ownerId == targetPlayer
            }
            ControllerPredicate.OwnedByTriggeringPlayer -> {
                val card = container.get<CardComponent>()
                // Mirror TargetResolutionUtils' Player.TriggeringPlayer resolution: for a damage
                // trigger the damaged player rides on triggeringEntityId (triggeringPlayerId is only
                // set by triggers that name a distinct player), so fall back to it. A non-player
                // triggeringEntityId (e.g. a creature) can never equal a card's owner, so it's safe.
                val triggeringPlayer = context.triggeringPlayerId ?: context.triggeringEntityId
                card?.ownerId != null && triggeringPlayer != null && card.ownerId == triggeringPlayer
            }
            else -> {
                // Use projected controller if available; otherwise fall back to the base
                // ControllerComponent or, for stack objects (spells and abilities), the
                // controllerId stored on their stack components.
                val controllerId = projected.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                    ?: container.get<SpellOnStackComponent>()?.casterId
                    ?: container.get<TriggeredAbilityOnStackComponent>()?.controllerId
                    ?: container.get<ActivatedAbilityOnStackComponent>()?.controllerId
                    ?: return false
                when (predicate) {
                    ControllerPredicate.ControlledByYou -> controllerId == context.controllerId
                    ControllerPredicate.ControlledByOpponent -> controllerId != context.controllerId
                    ControllerPredicate.ControlledByAny -> true
                    ControllerPredicate.ControlledByActivePlayer -> controllerId == state.activePlayerId
                    ControllerPredicate.ControlledByTargetOpponent -> {
                        context.targetOpponentId?.let { controllerId == it } ?: false
                    }
                    ControllerPredicate.ControlledByTargetPlayer -> {
                        context.targetPlayerId?.let { controllerId == it } ?: false
                    }
                    ControllerPredicate.ControlledByTriggeringPlayer -> {
                        // Mirror OwnedByTriggeringPlayer's resolution: the damaged player rides on
                        // triggeringEntityId for a damage trigger (triggeringPlayerId is only set by
                        // triggers that name a distinct player), so fall back to it. A non-player
                        // triggeringEntityId (e.g. a creature) can never equal a controller playerId.
                        val triggeringPlayer = context.triggeringPlayerId ?: context.triggeringEntityId
                        triggeringPlayer != null && controllerId == triggeringPlayer
                    }
                    is ControllerPredicate.ControlledByReferencedPlayer -> {
                        val referenced = context.resolvePlayerTarget(predicate.target)
                            ?: resolveReferencedPlayerFromState(state, projected, predicate.target, context)
                        referenced?.let { controllerId == it } ?: false
                    }
                    // Already handled above
                    ControllerPredicate.OwnedByYou, ControllerPredicate.OwnedByOpponent,
                    ControllerPredicate.OwnedByTriggeringPlayer,
                    is ControllerPredicate.And, is ControllerPredicate.Or, is ControllerPredicate.Not -> true
                }
            }
        }
    }

    /**
     * Resolve an [EffectTarget] player reference that needs [GameState] (so it can't be
     * answered by [PredicateContext.resolvePlayerTarget] alone): the controller of the entity that
     * caused the trigger (e.g. Tectonic Instability: "tap all lands its controller controls"), the
     * controller of the first chosen target, and the defending player of an attacking source.
     */
    private fun resolveReferencedPlayerFromState(
        state: GameState,
        projected: ProjectedState,
        target: EffectTarget,
        context: PredicateContext,
    ): EntityId? = when (target) {
        EffectTarget.ControllerOfTriggeringEntity -> {
            val triggeringId = context.triggeringEntityId ?: return null
            projected.getController(triggeringId)
                ?: state.getEntity(triggeringId)?.get<ControllerComponent>()?.playerId
                ?: state.getEntity(triggeringId)
                    ?.get<LastKnownPermanentComponent>()?.snapshot?.controllerId
        }
        // The controller of the spell/ability's first chosen target — lets a filter scope to
        // "creatures with the same controller as the target" (Fear, Fire, Foes!). A target the
        // effect itself has already moved off the battlefield reads its last-known controller
        // (CR 608.2h).
        EffectTarget.TargetController -> {
            val targetId = when (val first = context.targets.firstOrNull()) {
                is ChosenTarget.Permanent -> first.entityId
                is ChosenTarget.Card -> first.cardId
                else -> null
            } ?: return null
            projected.getController(targetId)
                ?: state.getEntity(targetId)?.get<ControllerComponent>()?.playerId
                ?: state.getEntity(targetId)
                    ?.get<LastKnownPermanentComponent>()?.snapshot?.controllerId
        }
        // "target creature defending player controls" (Necrite) — the filter is evaluated while the
        // trigger is choosing targets, so the defending player has to be resolvable *here* and not
        // only at resolution. Without it every candidate fails the controller predicate, the
        // trigger finds no legal targets, and it is removed from the stack without ever asking its
        // "you may" question. Reads combat off the source, with the same removed-from-combat
        // fallback the resolution-time path uses (CR 802.2a).
        is EffectTarget.PlayerRef -> when (target.player) {
            Player.DefendingPlayer -> TargetResolutionUtils
                .defendingPlayerOfAttacker(state, context.sourceId)
            // "…deals combat damage to a player, [that player] …" (Balefire Dragon). A self-bound
            // damage trigger carries the damaged player on `triggeringEntityId` and sets no
            // distinct `triggeringPlayerId` (see DamageTriggerDetector), which is exactly the
            // fallback TargetResolutionUtils.resolvePlayerTarget and the sibling
            // ControlledByTriggeringPlayer / OwnedByTriggeringPlayer predicates already apply.
            // PredicateContext can't do it alone — it has no state to tell a player id from a
            // creature's — so the turn-order guard lives here.
            Player.TriggeringPlayer ->
                context.triggeringEntityId?.takeIf { it in state.turnOrder }
            // "creatures enchanted player controls" (Radiant Restraints) — the controller scope a
            // Curse needs, and the only one that reads the *source's* attachment rather than the
            // ability's controller. Same resolution as StatePredicate.IsAttackingEnchantedPlayer:
            // the `in state.turnOrder` guard is what keeps a permanent host out, so an Aura on a
            // creature can never make this match anything.
            Player.EnchantedPlayer -> context.sourceId
                ?.let { state.getEntity(it) }
                ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                ?.targetId
                ?.takeIf { it in state.turnOrder }
            else -> null
        }
        else -> null
    }

    /**
     * Resolve an EntityReference to an EntityId using the predicate context.
     */
    /**
     * Resolve a [DynamicAmount] cap for [CardPredicate.ManaValueAtMostDynamic]. The amount is
     * evaluated through [DynamicAmountEvaluator] against a minimal [EffectContext] reconstructed
     * from the predicate context's controller/source/X. Returns null when there is no controller
     * to resolve player-scoped amounts against (e.g. legal-action enumeration with no context), so
     * the predicate fails closed rather than treating the cap as 0 and silently matching only
     * mana-value-0 cards.
     *
     * [PredicateContext.lastKnownSourceSnapshot] is carried onto the reconstructed context so a
     * source-relative amount keeps reading last-known information after the source has left the
     * battlefield (CR 608.2h / 113.7a). [DynamicAmountEvaluator] already owns that rule for every
     * [com.wingedsheep.engine.handlers.effects.LkiPolicy.LIVE_THEN_LKI] reference; without the
     * snapshot threaded through, its LKI branch found nothing here and fell through to base
     * characteristics — a pending "copy your next spell" rider capped on its dead source's power
     * read the printed value instead of the pumped one.
     */
    private fun evaluateDynamicCap(
        state: GameState,
        amount: DynamicAmount,
        context: PredicateContext?,
    ): Int? {
        val controllerId = context?.controllerId ?: return null
        val effectContext = EffectContext(
            sourceId = context.sourceId,
            objectReferences = context.objectReferences,
            sourceBattlefieldTimestamp = context.sourceBattlefieldTimestamp,
            controllerId = controllerId,
            xValue = context.xValue,
            lastKnownSourceSnapshot = context.lastKnownSourceSnapshot,
        )
        return DynamicAmountEvaluator().evaluate(state, amount, effectContext)
    }

    private fun resolveEntityReference(
        state: GameState,
        ref: EntityReference,
        context: PredicateContext?
    ): EntityId? {
        return when (ref) {
            is EntityReference.Source -> context?.sourceId
            // The card exiled with the source (Imprint). Resolvable here because the pile hangs off
            // the source entity, which every predicate context that names a source already knows —
            // no pipeline threading needed, unlike the cost-storage references below.
            is EntityReference.LinkedExiledCard ->
                com.wingedsheep.engine.handlers.effects.linkedexile.LinkedExileLookup
                    .exiledCard(state, context?.sourceId, ref.index)
            is EntityReference.Triggering -> context?.triggeringEntityId
            // The spell/ability's cast-time targets are threaded into [PredicateContext.targets]
            // by `fromEffectContext`, so a resolution-time group filter can be relative to a
            // chosen target — "each other creature that shares a color with it" (Radiance).
            // Empty during target *enumeration* (nothing chosen yet), where this yields null.
            is EntityReference.Target -> when (val chosen = context?.targets?.getOrNull(ref.index)) {
                is ChosenTarget.Permanent -> chosen.entityId
                is ChosenTarget.Card -> chosen.cardId
                is ChosenTarget.Spell -> chosen.spellEntityId
                is ChosenTarget.Player -> chosen.playerId
                null -> null
            }
            is EntityReference.Sacrificed -> null
            is EntityReference.TappedAsCost -> null
            is EntityReference.AffectedEntity -> context?.affectedEntityId
            is EntityReference.IterationEntity -> null // Only available during ForEachInGroup iteration
            // Pipeline-stored entities (cost-chosen, amassed Army) are threaded into PredicateContext
            // via [storedCollections] so a target/affected-entity filter can compare against them
            // ("power <= the amassed Army's power"). Mirrors TargetResolutionUtils.resolveEntityReference.
            is EntityReference.FromCostStorage ->
                context?.storedCollections?.get(ref.collectionName)?.getOrNull(ref.index)
            is EntityReference.AmassedArmy ->
                context?.storedCollections?.get(EntityReference.AmassedArmy.STORAGE_KEY)?.firstOrNull()
            is EntityReference.EnchantedCreature -> null // Attachment lookup needs state, not threaded here
            is EntityReference.RingBearer -> null // Ring-bearer lookup needs state, not threaded here
        }
    }

    /**
     * Evaluate a StatePredicate against an entity.
     */
    fun matchesStatePredicate(
        state: GameState,
        entityId: EntityId,
        predicate: StatePredicate,
        context: PredicateContext? = null,
        /**
         * Projection to consult for the branches that need continuous effects (attachment host
         * type/control, relative power). Defaults to the canonical lazy [GameState.projectedState]
         * for external callers (trigger matching, targeting). During layer projection the caller
         * passes the empty-fallback [ProjectedState] instead, so an `Exists`/attachment predicate
         * evaluated *while* the projection is being built does not re-enter the lazy delegate on the
         * same thread and recurse until the stack overflows (two Auras/Equipment whose conditional
         * statics reference each other, e.g. Bride's Gown ↔ Groom's Finery).
         */
        projected: ProjectedState = state.projectedState
    ): Boolean {
        val container = state.getEntity(entityId) ?: return false

        return when (predicate) {
            // Zone. Deliberately a *live* read with no last-known fallback — this predicate exists
            // to cancel the fallbacks the combat predicates below carry.
            StatePredicate.IsOnBattlefield -> entityId in state.getBattlefield()

            // Tap state
            StatePredicate.IsTapped -> container.has<TappedComponent>()
            StatePredicate.IsUntapped -> !container.has<TappedComponent>()

            // Combat state.
            //
            // On the battlefield this is the live "declared as attacker this combat" check. Once
            // the permanent has left, the live component is gone (the exit's combat cleanup tears
            // down the attack), so we fall back to the frozen last-known snapshot (CR 608.2h) —
            // that is exactly what "draw a card if it was attacking" (Garna, Bloodfist of Keld)
            // needs from a dies trigger that resolves after the death. The fallback can only fire
            // for an entity outside the battlefield, so live battlefield reads are unchanged.
            StatePredicate.IsAttacking ->
                container.get<AttackingComponent>() != null ||
                    container.get<LastKnownPermanentComponent>()?.snapshot?.wasAttacking == true
            // CR 506.5. A live read with no last-known fallback: "attacking alone" is a fact about
            // the current attacking set, and the snapshot records only that *this* creature was
            // attacking, never how many others were.
            StatePredicate.IsAttackingAlone ->
                container.has<AttackingComponent>() &&
                    state.getBattlefield().none {
                        it != entityId && state.getEntity(it)?.has<AttackingComponent>() == true
                    }
            // "Attacking one of your opponents": the defender has to be an opponent *player* of
            // the asking ability's controller — `getOpponents` only ever yields players, so an
            // attacker pointed at a planeswalker or battle never matches. No last-known fallback:
            // the frozen snapshot records only *that* the permanent was attacking, not whom.
            StatePredicate.IsAttackingAnOpponent -> {
                val you = context?.controllerId
                val defenderId = container.get<AttackingComponent>()?.defenderId
                you != null && defenderId != null && defenderId in state.getOpponents(you)
            }
            // "Attacking you and/or planeswalkers you control": the defender is either the asking
            // ability's controller themself, or a planeswalker that player controls. Battles are
            // excluded — a battle's protector is a player, not its controller, so `defendingPlayerOf`
            // would wrongly fold "attacking a battle you protect" into this. Same no-last-known
            // policy as IsAttackingAnOpponent.
            StatePredicate.IsAttackingYouOrYourPlaneswalkers -> {
                val you = context?.controllerId
                val defenderId = container.get<AttackingComponent>()?.defenderId
                you != null && defenderId != null && (
                    defenderId == you ||
                        (
                            state.getEntity(defenderId)
                                ?.get<com.wingedsheep.engine.state.components.identity.ControllerComponent>()
                                ?.playerId == you &&
                                projected.isPlaneswalker(defenderId)
                            )
                    )
            }
            // "Attacking enchanted player": the defender has to be the player the *source* Aura is
            // attached to (Curse of Hospitality). Scoped by attachment rather than by controller,
            // so unlike the two predicates above it reads `context.sourceId`: a planeswalker or battle the
            // enchanted player controls never matches (only a player id survives `in state.turnOrder`).
            // No last-known fallback, for
            // IsAttackingAnOpponent's reason.
            StatePredicate.IsAttackingEnchantedPlayer -> {
                val enchanted = context?.sourceId
                    ?.let { state.getEntity(it) }
                    ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                    ?.targetId
                    ?.takeIf { it in state.turnOrder }
                val defenderId = container.get<AttackingComponent>()?.defenderId
                enchanted != null && defenderId == enchanted
            }
            StatePredicate.IsBlocking -> container.has<BlockingComponent>()
            StatePredicate.IsBlocked -> {
                // Check if this attacking creature has any blockers assigned
                val attackingComp = container.get<AttackingComponent>()
                attackingComp != null && state.getBattlefield().any { blockerId ->
                    state.getEntity(blockerId)?.get<BlockingComponent>()?.blockedAttackerIds?.contains(entityId) == true
                }
            }
            StatePredicate.IsUnblocked -> {
                val attackingComp = container.get<AttackingComponent>()
                attackingComp != null && state.getBattlefield().none { blockerId ->
                    state.getEntity(blockerId)?.get<BlockingComponent>()?.blockedAttackerIds?.contains(entityId) == true
                }
            }

            // Same combat band as the effect's source (CR 702.22). Resolves against
            // context.sourceId: matches the source creature itself, or a creature sharing the
            // source's non-null band id. Yields false when there's no source context or the
            // source isn't attacking, so it's inert outside combat / damage-prevention contexts.
            StatePredicate.InSameBandAsSource -> {
                val sourceId = context?.sourceId
                val sourceAttacking = sourceId?.let { state.getEntity(it)?.get<AttackingComponent>() }
                when {
                    sourceAttacking == null -> false
                    entityId == sourceId -> true
                    sourceAttacking.bandId == null -> false
                    else -> container.get<AttackingComponent>()?.bandId == sourceAttacking.bandId
                }
            }

            // Creature blocking the effect's source (CR 509). Source-relative: the candidate is a
            // blocker whose blocked-attacker set contains context.sourceId. Inert with no source.
            StatePredicate.IsBlockingSource -> {
                val sourceId = context?.sourceId
                sourceId != null &&
                    container.get<BlockingComponent>()?.blockedAttackerIds?.contains(sourceId) == true
            }

            // Creature blocking the effect's source OR blocked by it (CR 509), read live from
            // combat state in both directions: either the candidate blocks the source, or the
            // source blocks the candidate. Source-relative; inert with no source.
            StatePredicate.IsCombatPairedWithSource -> {
                val sourceId = context?.sourceId
                sourceId != null && (
                    container.get<BlockingComponent>()?.blockedAttackerIds?.contains(sourceId) == true ||
                        state.getEntity(sourceId)?.get<BlockingComponent>()
                            ?.blockedAttackerIds?.contains(entityId) == true
                    )
            }

            // "…creatures you control blocking *that creature*" (Tidal Flats) — the same check as
            // IsBlockingSource but against the ForEach loop's current entity, which is what "that
            // creature" refers to inside the loop.
            StatePredicate.IsBlockingIterationEntity -> {
                val iterated = context?.iterationEntityId
                iterated != null &&
                    container.get<BlockingComponent>()?.blockedAttackerIds?.contains(iterated) == true
            }

            // Token created by the effect's source permanent (CR 111). Source-relative: the
            // candidate's stamped CreatedByComponent.creatorId equals context.sourceId. Inert with
            // no source context or for tokens with no recorded creator.
            StatePredicate.CreatedBySource -> {
                val sourceId = context?.sourceId
                sourceId != null &&
                    container.get<com.wingedsheep.engine.state.components.identity.CreatedByComponent>()
                        ?.creatorId == sourceId
            }

            // Goblin Artisans: the candidate object isn't the target of an ability on the stack whose
            // source is another battlefield permanent sharing the effect source's name.
            StatePredicate.NotTargetedByAbilityFromSameNamedSource -> {
                val sourceId = context?.sourceId
                val sourceName = sourceId?.let { state.getEntity(it)?.get<CardComponent>()?.name }
                if (sourceId == null || sourceName == null) {
                    true
                } else {
                    val battlefield = state.getBattlefield()
                    val targetedByOtherSameNamed = state.stack.any { stackId ->
                        val stackContainer = state.getEntity(stackId) ?: return@any false
                        // Only abilities (not spells) count — "an ability from another creature named …".
                        val abilitySourceId = stackContainer.get<ActivatedAbilityOnStackComponent>()?.sourceId
                            ?: stackContainer.get<TriggeredAbilityOnStackComponent>()?.sourceId
                            ?: return@any false
                        if (abilitySourceId == sourceId) return@any false // not "another" source
                        if (abilitySourceId !in battlefield) return@any false
                        val otherName = state.getEntity(abilitySourceId)?.get<CardComponent>()?.name
                        if (otherName != sourceName) return@any false
                        // Does this ability target the candidate object?
                        val targets = stackContainer.get<TargetsComponent>()?.targets ?: emptyList()
                        targets.any { t ->
                            when (t) {
                                is ChosenTarget.Spell -> t.spellEntityId == entityId
                                is ChosenTarget.Permanent -> t.entityId == entityId
                                is ChosenTarget.Card -> t.cardId == entityId
                                else -> false
                            }
                        }
                    }
                    !targetedByOtherSameNamed
                }
            }

            // Crewed/saddled the effect's source permanent this turn (CR 702.122 / 702.171).
            // Source-relative: reads the source's CrewSaddleContributorsComponent and checks
            // membership. Inert with no source context.
            StatePredicate.CrewedOrSaddledSourceThisTurn -> {
                val sourceId = context?.sourceId
                val contributors = sourceId
                    ?.let { state.getEntity(it)?.get<CrewSaddleContributorsComponent>() }
                contributors != null && entityId in contributors.creatureIds
            }
            StatePredicate.CrewedOrSaddledBySourceThisTurn -> {
                // Mirror of CrewedOrSaddledSourceThisTurn: the candidate (entityId) is the Vehicle,
                // the source is the crewer. Read the candidate's contributors and ask whether the
                // source is among them.
                val sourceId = context?.sourceId
                val contributors = state.getEntity(entityId)?.get<CrewSaddleContributorsComponent>()
                sourceId != null && contributors != null && sourceId in contributors.creatureIds
            }

            // Summoning sickness / ETB
            StatePredicate.EnteredThisTurn -> {
                container.has<EnteredThisTurnComponent>()
            }

            // Counter history — "one or more counters were put on it this turn", optionally scoped
            // to a kind and to placements by the permanent's own controller. Reads the per-turn
            // marker rather than the live counters, so it survives their removal. Also the engine
            // side of Conditions.SourceReceivedCounterThisTurn (SourceMatches over this predicate).
            is StatePredicate.ReceivedCounterThisTurn ->
                receivedCounterThisTurn(container, predicate)

            // Tap history — "it's the first time it has become tapped this turn", read live off the
            // tap counter so CR 603.4's resolution-time re-check can differ from the trigger-time one.
            StatePredicate.BecameTappedOnlyOnceThisTurn ->
                becameTappedOnlyOnceThisTurn(container, state.turnNumber)

            // Damage state
            StatePredicate.WasDealtDamageThisTurn -> {
                container.has<WasDealtDamageThisTurnComponent>()
            }
            // Damage history, active voice. One marker, two windows — presence for the lifetime
            // reading, its turn stamp against the current turn for "…this turn".
            is StatePredicate.HasDealtDamage ->
                hasDealtDamage(container, state.turnNumber, predicate)
            StatePredicate.HasDealtCombatDamageToPlayer -> {
                container.has<HasDealtCombatDamageToPlayerComponent>()
            }

            // Dealt combat damage this turn to the player who controls the effect's source.
            // Source-relative: resolves context.sourceId's controller and checks the candidate's
            // per-turn recipient marker. "...a creature that dealt combat damage to you this turn"
            // (Witch-king of Angmar). Inert with no source context.
            StatePredicate.DealtCombatDamageToSourceControllerThisTurn -> {
                val sourceId = context?.sourceId
                val sourceController = sourceId
                    ?.let { state.getEntity(it)?.get<ControllerComponent>()?.playerId }
                sourceController != null &&
                    container.get<DealtCombatDamageToPlayersThisTurnComponent>()
                        ?.playerIds?.contains(sourceController) == true
            }

            // Mirror of the above: the *source* is the damage dealer and the candidate is any
            // permanent. Reads the source's per-turn recipient marker and asks whether the
            // candidate's current controller is among them ("destroy each nonland permanent whose
            // controller was dealt combat damage by this creature this turn" — Steel Hellkite).
            // Controller is read from the projected state so control-changing effects count.
            StatePredicate.ControllerDealtCombatDamageBySourceThisTurn -> {
                val sourceId = context?.sourceId
                val damagedPlayers = sourceId
                    ?.let { state.getEntity(it)?.get<DealtCombatDamageToPlayersThisTurnComponent>() }
                    ?.playerIds ?: emptySet()
                val candidateController = state.projectedState.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                candidateController != null && candidateController in damagedPlayers
            }

            // Whether this creature has been declared as an attacker this turn — derived
            // from the controller's PlayerAttackersThisTurnComponent, the same set that
            // backs raid / "you attacked with N creatures this turn" tribal triggers.
            //
            // Controller comes from projection first: after an Act of Treason the base
            // ControllerComponent names the player who no longer controls it, and the attacker set
            // lives on the player who declared. AffectsFilterResolver reads it the same way.
            StatePredicate.AttackedThisTurn -> {
                val controllerId = projected.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                    ?: return false
                val attackerSet = state.getEntity(controllerId)
                    ?.get<PlayerAttackersThisTurnComponent>()
                    ?.attackerIds ?: emptySet()
                entityId in attackerSet
            }

            // "Creatures that couldn't attack" (Season of the Witch). The clause spares a creature
            // that had no say in staying home, so it asks a cut-down version of the declare-attackers
            // checks. Two of the three come from CR 508.1a — who may be declared, and by whom:
            //  - only the active player declares attackers, so a creature its controller couldn't
            //    have attacked *with* — anything an opponent controls on this turn — is spared.
            //    Asked through `isActiveTurnFor`, so a shared team turn (CR 805.10b) counts both
            //    teammates' creatures as able to attack;
            //  - summoning sickness (entered this turn without haste);
            // and the third from CR 508.1c, the attack *restrictions*: defender (CR 702.3b) or a
            // projected "can't attack" (Pacifism). All of them read from projection where they can,
            // so granted/removed keywords count.
            //
            // The controller clause asks whose turn it is, which answers "was this player the one
            // declaring?" but not "did a declaration happen at all". AttackersDeclaredThisTurn is
            // the second half: an effect that skips the combat phase (False Peace, Fatespinner)
            // means nobody reached a Declare Attackers Step, so no creature stayed home by choice.
            //
            // Not the full declare-attackers legality check — that needs a chosen defending player
            // and a card registry, neither of which predicate evaluation has — so a creature kept
            // home only by a "can't attack unless …" restriction is still destroyed, as is one that
            // came under its controller's control this turn without entering the battlefield (the
            // sickness half reads EnteredThisTurn, not the sickness marker itself).
            StatePredicate.CouldNotHaveAttackedThisTurn -> {
                val controllerId = projected.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                controllerId == null ||
                    !state.isActiveTurnFor(controllerId) ||
                    state.getEntity(controllerId)
                        ?.has<AttackersDeclaredThisTurnComponent>() != true ||
                    projected.hasKeyword(entityId, Keyword.DEFENDER) ||
                    projected.cantAttack(entityId) ||
                    (
                        container.has<EnteredThisTurnComponent>() &&
                            !projected.hasKeyword(entityId, Keyword.HASTE)
                        )
            }

            // The same read one turn back: PlayerAttackersLastTurnComponent is the this-turn set as
            // it stood at the end of the controller's own most recent turn. Controller read as
            // above, so the two attack-history predicates agree with each other and with projection.
            StatePredicate.AttackedLastTurn -> {
                val controllerId = projected.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                    ?: return false
                val attackerSet = state.getEntity(controllerId)
                    ?.get<PlayerAttackersLastTurnComponent>()
                    ?.attackerIds ?: emptySet()
                entityId in attackerSet
            }

            // Whether this creature was declared as an attacker / blocker this combat — backed by the
            // per-entity AttackedThisCombatComponent / BlockedThisCombatComponent markers, stamped at
            // declaration time and cleared only when the combat phase ends (so they survive deaths and
            // removal-from-combat that clear the live AttackingComponent/BlockingComponent).
            StatePredicate.AttackedThisCombat -> {
                container.has<AttackedThisCombatComponent>()
            }

            StatePredicate.BlockedThisTurn -> {
                container.has<BlockedThisTurnComponent>()
            }

            StatePredicate.BlockedThisCombat -> {
                container.has<BlockedThisCombatComponent>()
            }

            // "Put there this turn" filter for graveyard-zone targets (Abyssal Harvester — FDN).
            // Reads the marker ZoneTransitionService stamps on every graveyard arrival,
            // regardless of the zone it came from. The marker is stripped when the card leaves
            // the graveyard (so it can't outlive the arrival it describes) AND at the start of
            // every turn by BeginningPhaseManager (so the "this turn" window matches MTG's
            // per-turn semantics, not the engine's per-round turn counter).
            StatePredicate.PutIntoGraveyardThisTurn -> {
                container.has<PutIntoGraveyardThisTurnComponent>()
            }

            // The zone-restricted sibling: same marker, but the arrival must have been from
            // the battlefield (Samwise the Stouthearted, Lobelia Sackville-Baggins — LTR).
            StatePredicate.PutIntoGraveyardFromBattlefieldThisTurn -> {
                container.get<PutIntoGraveyardThisTurnComponent>()?.fromBattlefield == true
            }

            // "Blocked or was blocked by a legendary creature this turn" (You Cannot Pass! — LTR).
            // Reads the marker stamped at block declaration; survives the legendary partner leaving.
            StatePredicate.BlockedOrWasBlockedByLegendaryThisTurn -> {
                container.has<com.wingedsheep.engine.state.components.combat.BlockedOrWasBlockedByLegendaryThisTurnComponent>()
            }

            // Face-down state
            StatePredicate.IsFaceDown -> container.has<FaceDownComponent>()
            StatePredicate.IsFaceUp -> !container.has<FaceDownComponent>()

            // Morph ability — check both the runtime turn-up data (face-down permanents) and the
            // card definition tag (cards in hand/library/graveyard). Manifested, cloaked and
            // disguised permanents carry turn-up data too, so the runtime check asks whether one
            // of the procedures actually came from morph.
            StatePredicate.HasMorphAbility ->
                container.has<HasMorphAbilityComponent>() ||
                container.get<MorphDataComponent>()?.hasMorphProcedure == true

            // Disguise ability (CR 702.168) — the printed keyword only, read off the card in any
            // zone. No MorphDataComponent fallback: the turn-up data exists only while the
            // permanent is face down, and "creatures with disguise" asks about face-up ones.
            StatePredicate.HasDisguiseAbility ->
                container.has<com.wingedsheep.engine.state.components.identity.HasDisguiseAbilityComponent>()

            // Ring-bearer designation (CR 701.54e): only while it has the component AND is controlled
            // by the player who designated it.
            StatePredicate.IsRingBearer -> {
                val bearer = container.get<com.wingedsheep.engine.state.components.identity.RingBearerComponent>()
                bearer != null && projected.getController(entityId) == bearer.ownerId
            }

            // Soulbond pairing (CR 702.95b) — via the shared read, which re-checks the link rather
            // than trusting the component, so a half that has already left the battlefield counts as
            // unpaired immediately instead of at the next SBA pass (CR 702.95e).
            StatePredicate.IsPaired ->
                com.wingedsheep.engine.mechanics.SoulbondPairing.isPaired(state, entityId)

            // Counter state
            is StatePredicate.HasCounter -> {
                val countersComponent = container.get<CountersComponent>()
                if (countersComponent == null) return false
                val counterType = when (predicate.counterType) {
                    "+1/+1" -> CounterType.PLUS_ONE_PLUS_ONE
                    "-1/-1" -> CounterType.MINUS_ONE_MINUS_ONE
                    else -> try {
                        CounterType.valueOf(predicate.counterType.uppercase().replace(' ', '_'))
                    } catch (_: IllegalArgumentException) {
                        return false
                    }
                }
                countersComponent.getCount(counterType) > 0
            }
            StatePredicate.HasAnyCounter -> {
                val countersComponent = container.get<CountersComponent>()
                countersComponent != null && countersComponent.counters.values.any { it > 0 }
            }

            // Equipment state
            StatePredicate.IsEquipped -> {
                val attachments = container.get<AttachmentsComponent>()
                if (attachments == null || attachments.attachedIds.isEmpty()) return false
                attachments.attachedIds.any { attachId ->
                    val attachContainer = state.getEntity(attachId)
                    val card = attachContainer?.get<CardComponent>()
                    card?.typeLine?.isEquipment == true
                }
            }

            // Aura state — "enchanted". Mirrors IsEquipped over the Aura subtype instead of
            // Equipment, so a permanent carrying only Equipment (or only counters) is not enchanted.
            StatePredicate.IsEnchanted -> {
                val attachments = container.get<AttachmentsComponent>()
                if (attachments == null || attachments.attachedIds.isEmpty()) return false
                attachments.attachedIds.any { attachId ->
                    state.getEntity(attachId)?.get<CardComponent>()?.typeLine?.isAura == true
                }
            }

            // Aura state scoped by who controls the Aura — "enchanted by Auras you control"
            // (Archon of the Wild Rose). "You" is this evaluation's controller.
            is StatePredicate.IsEnchantedByAura -> {
                val attachments = container.get<AttachmentsComponent>()
                if (attachments == null || attachments.attachedIds.isEmpty()) return false
                // Fail closed with no context: "Auras you control" has no meaning without a "you",
                // and matching every Aura would silently widen the filter.
                val you = context?.controllerId ?: return false
                attachments.attachedIds.any { attachId ->
                    val aura = state.getEntity(attachId) ?: return@any false
                    if (aura.get<CardComponent>()?.typeLine?.isAura != true) return@any false
                    val auraController = aura.get<ControllerComponent>()?.playerId ?: return@any false
                    predicate.auraController.evaluateWith { leaf ->
                        when (leaf) {
                            ControllerPredicate.ControlledByYou -> auraController == you
                            ControllerPredicate.ControlledByOpponent -> auraController != you
                            ControllerPredicate.ControlledByAny -> true
                            ControllerPredicate.ControlledByActivePlayer ->
                                auraController == state.activePlayerId
                            else -> null
                        }
                    }
                }
            }

            StatePredicate.IsModified -> com.wingedsheep.engine.handlers.predicates.isModified(state, entityId)

            // Attached-to-type — entity has an AttachedToComponent and the referenced
            // permanent currently has the requested CardType (Pyramids: "Aura attached
            // to a land"). Reads the attached-to permanent's projected types so that a
            // permanent animated into a different type via continuous effects (e.g. a
            // land turned into a creature) is matched correctly.
            is StatePredicate.AttachedToCardType -> {
                val attached = container.get<AttachedToComponent>() ?: return false
                projected.hasType(attached.targetId, predicate.cardType.name)
            }

            // General attachment match — entity is attached to a host that matches the nested
            // filter, evaluated against projected battlefield state so the host's control ("a
            // creature you control"), card type, keywords, P/T all compose (Stolen Uniform's
            // "attached to a creature you control"). The "you" of any controller predicate is the
            // controllerId carried in this evaluation context.
            is StatePredicate.AttachedTo -> {
                val attached = container.get<AttachedToComponent>() ?: return false
                // A controller predicate in the nested filter needs a "you"; without an evaluation
                // context fall back to the host's actual controller so the match can still run.
                // Use base ControllerComponent under the empty-fallback projection (where
                // getController is null) so mid-projection evaluation still resolves a "you".
                val ctx = context ?: PredicateContext(
                    controllerId = projected.getController(attached.targetId)
                        ?: state.getEntity(attached.targetId)?.get<ControllerComponent>()?.playerId
                        ?: return false
                )
                matches(state, projected, attached.targetId, predicate.filter, ctx)
            }

            // "whose controller controls an Island" (Seasinger). The nested filter is scanned
            // over the candidate's controller's battlefield, and its "you" is rebound to that
            // controller — not to the ability's controller — because the clause describes the
            // creature's own side of the table.
            is StatePredicate.ControllerControls -> {
                val ownerId = projected.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                    ?: return false
                val ctx = PredicateContext(
                    controllerId = ownerId,
                    sourceId = context?.sourceId,
                    sourceBattlefieldTimestamp = context?.sourceBattlefieldTimestamp,
                    objectReferences = context?.objectReferences ?: ObjectReferenceEnvironment(),
                )
                state.getBattlefield().any { candidate ->
                    matches(state, projected, candidate, predicate.filter, ctx)
                }
            }

            // Source-relative — the candidate IS the effect's source permanent itself
            // (GameObjectFilter counterpart of GroupFilter's Scope.Self). Backs the granted
            // PreventActivatedAbilities form (Braided Net), where the activation-legality
            // check supplies the grant's holder as the source. False with no source context.
            StatePredicate.IsSource -> context != null && context.sourceId == entityId &&
                context.objectReferences.isCurrent(context.objectReferences.source, state) &&
                (context.objectReferences.captured || context.sourceBattlefieldTimestamp == null || state.getEntity(entityId)
                    ?.get<com.wingedsheep.engine.state.components.battlefield.BattlefieldEntryTimestampComponent>()
                    ?.timestamp == context.sourceBattlefieldTimestamp)
            StatePredicate.IsGrantingPermanent -> context?.granterId != null && context.granterId == entityId

            // Source-relative — the candidate is the permanent the effect's source is attached
            // to (its enchanted/equipped creature). Read the source's AttachedToComponent and
            // compare its targetId to the candidate. False with no source or an unattached source.
            // Negated via StatePredicate.Not for "other than enchanted creature" edicts
            // (Sporogenic Infection).
            StatePredicate.IsAttachedToBySource -> {
                val sourceId = context?.sourceId ?: return false
                val attachedTo = state.getEntity(sourceId)?.get<AttachedToComponent>()?.targetId
                attachedTo == entityId
            }

            // Mirror of IsAttachedToBySource: the candidate is an Aura/Equipment attached TO the
            // source (static on the host, e.g. Cloud's "an Equipment attached to it").
            StatePredicate.IsAttachedToSource -> {
                val sourceId = context?.sourceId ?: return false
                val attachedTo = state.getEntity(entityId)?.get<AttachedToComponent>()?.targetId
                attachedTo == sourceId
            }

            // Source-relative: the candidate card was exiled by the effect's source permanent, i.e.
            // its id is recorded in the source's LinkedExileComponent. Backs "target card exiled
            // with ~" reanimation (The Darkness Crystal). Inert with no source context.
            StatePredicate.ExiledWithSource -> {
                val sourceId = context?.sourceId ?: return false
                state.getEntity(sourceId)
                    ?.get<com.wingedsheep.engine.state.components.battlefield.LinkedExileComponent>()
                    ?.exiledIds?.contains(entityId) == true
            }

            // Saddled marker — set by BecomeSaddledExecutor when a Saddle ability resolves
            // (CR 702.171b). Cleared at end-of-turn cleanup or when the permanent leaves play.
            StatePredicate.IsSaddled -> container.has<SaddledComponent>()
            // Solved marker — set by BecomeSolvedExecutor when a Case's "To solve" trigger
            // resolves (CR 719.3b). Sticky until the permanent leaves the battlefield.
            StatePredicate.IsSolved -> container.has<SolvedComponent>()
            // Renowned marker — set by BecomeRenownedExecutor when a renown trigger resolves
            // (CR 702.112b). Sticky until the permanent leaves the battlefield.
            StatePredicate.IsRenowned -> container.has<RenownedComponent>()

            // Suspected designation (CR 701.60a) — a Layer-ability floating effect, so the answer
            // lives in the projection rather than on a component. Unlike saddled it never expires.
            StatePredicate.IsSuspected -> projected.isSuspected(entityId)

            // Zone-specific marker — set by WarpExileExecutor when a warped
            // permanent is exiled at end of turn (CR 702.185b).
            StatePredicate.IsWarpExiled ->
                container.has<com.wingedsheep.engine.state.components.identity.WarpExiledComponent>()

            // Battlefield marker — set when a warped spell resolves (CR 702.185).
            StatePredicate.WasCastForWarp ->
                container.has<com.wingedsheep.engine.state.components.battlefield.WarpedComponent>()

            // Cast-origin zone of a spell on the stack — reads the engine-stamped
            // SpellOnStackComponent.castFromZone (Wash Away's "wasn't cast from its owner's hand").
            is StatePredicate.WasCastFromZone ->
                container.get<SpellOnStackComponent>()?.castFromZone == predicate.zone

            // Relative power
            StatePredicate.HasGreatestPower -> {
                val entityController = projected.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                    ?: return false
                val entityPower = projected.getPower(entityId) ?: return false
                val maxPower = state.getBattlefield()
                    .filter { id ->
                        val ctrl = projected.getController(id)
                            ?: state.getEntity(id)?.get<ControllerComponent>()?.playerId
                        ctrl == entityController && projected.isCreature(id)
                    }
                    .maxOfOrNull { projected.getPower(it) ?: Int.MIN_VALUE }
                    ?: return false
                entityPower >= maxPower
            }

            // Global least power: the minimum power among *all* creatures on the battlefield,
            // regardless of controller. Ties leave every minimum-power creature matching, so a
            // downstream "choose one" selection breaks them (Drop of Honey).
            StatePredicate.HasLeastPowerAmongAllCreatures -> {
                if (!projected.isCreature(entityId)) return false
                val entityPower = projected.getPower(entityId) ?: return false
                val minPower = state.getBattlefield()
                    .filter { projected.isCreature(it) }
                    .minOfOrNull { projected.getPower(it) ?: Int.MAX_VALUE }
                    ?: return false
                entityPower <= minPower
            }

            // Global greatest mana value among every creature on the battlefield. Mana value is
            // a printed characteristic (no projection entry), so it is read off CardComponent; a
            // face-down creature has no mana cost and counts as 0, mirroring the least-mana-value
            // reading below. Ties leave every maximum-mana-value creature matching.
            StatePredicate.HasGreatestManaValueAmongAllCreatures -> {
                if (!projected.isCreature(entityId)) return false
                val entityManaValue = if (projected.getProjectedValues(entityId)?.isFaceDown == true) 0
                else container.get<CardComponent>()?.manaValue ?: return false
                val maxManaValue = state.getBattlefield()
                    .asSequence()
                    .filter { projected.isCreature(it) }
                    .mapNotNull { candidateId ->
                        val candidate = state.getEntity(candidateId) ?: return@mapNotNull null
                        if (projected.getProjectedValues(candidateId)?.isFaceDown == true) 0
                        else candidate.get<CardComponent>()?.manaValue
                    }
                    .maxOrNull()
                    ?: return false
                entityManaValue >= maxManaValue
            }

            is StatePredicate.HasLeastManaValueAmong -> {
                val predicateContext = context ?: return false
                val entityManaValue = if (projected.getProjectedValues(entityId)?.isFaceDown == true) {
                    0
                } else {
                    container.get<CardComponent>()?.manaValue ?: return false
                }
                val minManaValue = state.getBattlefield()
                    .asSequence()
                    .filter { matches(state, projected, it, predicate.candidates, predicateContext) }
                    .mapNotNull { candidateId ->
                        val candidate = state.getEntity(candidateId) ?: return@mapNotNull null
                        if (projected.getProjectedValues(candidateId)?.isFaceDown == true) 0
                        else candidate.get<CardComponent>()?.manaValue
                    }
                    .minOrNull()
                    ?: return false
                entityManaValue == minManaValue
            }

            StatePredicate.HasLeastPower -> {
                val entityController = projected.getController(entityId)
                    ?: container.get<ControllerComponent>()?.playerId
                    ?: return false
                val entityPower = projected.getPower(entityId) ?: return false
                val minPower = state.getBattlefield()
                    .filter { id ->
                        val ctrl = projected.getController(id)
                            ?: state.getEntity(id)?.get<ControllerComponent>()?.playerId
                        ctrl == entityController && projected.isCreature(id)
                    }
                    .minOfOrNull { projected.getPower(it) ?: Int.MAX_VALUE }
                    ?: return false
                entityPower <= minPower
            }

            // Rooms: has at least one locked door (CR 709.5c). The unlock-a-door targeting
            // restriction — a fully-unlocked Room (or any non-Room) has no door to unlock.
            StatePredicate.HasLockedDoor ->
                container.get<RoomComponent>()?.lockedFaces?.isNotEmpty() == true

            // Composite / logical combinators
            is StatePredicate.Or -> predicate.predicates.any { matchesStatePredicate(state, entityId, it, context, projected) }
            is StatePredicate.And -> predicate.predicates.all { matchesStatePredicate(state, entityId, it, context, projected) }
            is StatePredicate.Not -> !matchesStatePredicate(state, entityId, predicate.predicate, context, projected)
        }
    }

    // =========================================================================
    // CastSpellRecord matching (for retroactive spell-type queries)
    // =========================================================================

    /**
     * Evaluate a GameObjectFilter against a CastSpellRecord (a snapshot of a spell's
     * characteristics at cast time). Used for "did you cast a historic spell this turn?" etc.
     *
     * Only card predicates are evaluated — state and controller predicates are skipped
     * since they're not meaningful for historical cast records.
     *
     * Face-down spells have no characteristics per CR 708.2, so only filters with
     * no card predicates (i.e. GameObjectFilter.Any) match them.
     */
    fun matchesFilter(
        record: CastSpellRecord,
        filter: GameObjectFilter,
        context: PredicateContext? = null
    ): Boolean {
        if (filter.cardPredicates.isEmpty() && filter.anyOf.isEmpty()) return true
        if (record.isFaceDown) return false

        // Conjunction over card predicates; OR lives inside a CardPredicate.Or.
        if (!filter.cardPredicates.all { matchesRecordPredicate(record, it, context) }) return false
        // Recursive union (`or` infix): only the card predicates of each branch are
        // meaningful for a cast record; state/controller branches are skipped as above.
        if (filter.anyOf.isNotEmpty()) return filter.anyOf.any { matchesFilter(record, it, context) }
        return true
    }

    private fun matchesRecordPredicate(
        record: CastSpellRecord,
        predicate: CardPredicate,
        context: PredicateContext? = null
    ): Boolean {
        val typeLine = record.typeLine
        return when (predicate) {
            // Type predicates
            CardPredicate.IsCreature -> typeLine.isCreature
            CardPredicate.IsLand -> typeLine.isLand
            CardPredicate.IsArtifact -> typeLine.isArtifact
            CardPredicate.IsEnchantment -> typeLine.isEnchantment
            CardPredicate.IsPlaneswalker -> com.wingedsheep.sdk.core.CardType.PLANESWALKER in typeLine.cardTypes
            CardPredicate.IsInstant -> typeLine.isInstant
            CardPredicate.IsSorcery -> typeLine.isSorcery
            // A cast-spell record stores only the resolved characteristics, not the card's layout,
            // so adventure-ness can't be recovered here. No in-scope card queries it against cast
            // history; fall through to the safe default.
            CardPredicate.HasAdventure -> false
            // Same limitation as HasAdventure above — the record keeps no layout, and no in-scope
            // card asks about double-faced-ness against cast history.
            CardPredicate.IsDoubleFaced -> false
            CardPredicate.HasNoAbilities -> false
            CardPredicate.IsBasicLand -> typeLine.isBasicLand
            CardPredicate.IsPermanent -> typeLine.isPermanent
            CardPredicate.IsNonland -> !typeLine.isLand
            CardPredicate.IsNoncreature -> !typeLine.isCreature
            CardPredicate.IsNonenchantment -> !typeLine.isEnchantment
            CardPredicate.IsNonartifact -> !typeLine.isArtifact
            CardPredicate.IsToken -> false // cast spells are never tokens
            CardPredicate.IsNontoken -> true
            CardPredicate.IsLegendary -> typeLine.isLegendary
            CardPredicate.IsNonlegendary -> !typeLine.isLegendary

            // Color predicates
            is CardPredicate.HasColor -> predicate.color in record.colors
            is CardPredicate.NotColor -> predicate.color !in record.colors
            CardPredicate.IsColorless -> record.colors.isEmpty()
            CardPredicate.IsColored -> record.colors.isNotEmpty()
            CardPredicate.IsMulticolored -> record.colors.size > 1
            CardPredicate.IsMonocolored -> record.colors.size == 1

            // Subtype predicates
            is CardPredicate.HasSubtype -> typeLine.hasSubtype(predicate.subtype)
            is CardPredicate.NotSubtype -> !typeLine.hasSubtype(predicate.subtype)
            is CardPredicate.HasAnyOfSubtypes -> predicate.subtypes.any { typeLine.hasSubtype(it) }
            is CardPredicate.HasBasicLandType -> typeLine.hasSubtype(Subtype(predicate.landType))

            // Mana value predicates
            is CardPredicate.ManaValueEquals -> record.manaValue == predicate.value
            is CardPredicate.ManaValueAtMost -> record.manaValue <= predicate.max
            // ManaValueAtMostX / ManaValueEqualsX are resolution-time chosen-number predicates;
            // without context they cannot match record-level cast history.
            CardPredicate.ManaValueAtMostX -> false
            CardPredicate.ManaValueEqualsX -> false
            is CardPredicate.ManaValueAtLeast -> record.manaValue >= predicate.min
            // Entity-relative — no entity context for cast records
            is CardPredicate.ManaValueAtMostEntity -> false
            is CardPredicate.ManaValueAtMostEntityManaSpent -> false
            is CardPredicate.ManaValueAtMostColorsSpent -> false
            is CardPredicate.ManaValueAtMostDynamic -> false
            is CardPredicate.ManaValueEqualsDynamic -> false
            is CardPredicate.PowerEqualsDynamic -> false
            is CardPredicate.ToughnessEqualsDynamic -> false
            CardPredicate.ManaValueIsEven -> record.manaValue % 2 == 0
            CardPredicate.ManaValueIsOdd -> record.manaValue % 2 != 0
            // A cast-spell record stores the resolved mana value, not the printed cost, so we
            // cannot recover whether {X} was in the printed cost — nor its colored pips.
            CardPredicate.HasXInManaCost -> false
            is CardPredicate.ColoredManaSymbolsAtLeast -> false

            // Power/toughness — not meaningful for cast records
            is CardPredicate.PowerEquals, is CardPredicate.PowerAtMost, is CardPredicate.PowerAtLeast,
            CardPredicate.PowerEqualsX, CardPredicate.PowerAtLeastX,
            is CardPredicate.ToughnessEquals, is CardPredicate.ToughnessAtMost, is CardPredicate.ToughnessAtLeast,
            CardPredicate.ToughnessAtMostX,
            is CardPredicate.PowerOrToughnessAtLeast,
            is CardPredicate.PowerOrToughnessAtMost,
            is CardPredicate.TotalPowerAndToughnessAtMost,
            is CardPredicate.PowerGreaterThanEntity,
            is CardPredicate.PowerAtMostEntity,
            is CardPredicate.PowerLessThanEntity,
            CardPredicate.PowerGreaterThanBase,
            CardPredicate.ToughnessGreaterThanPower -> false

            // Name predicates — matched against the record's card name; a record without a
            // name (predating name tracking) is unknown and never equals a given name.
            is CardPredicate.NameEquals -> record.name == predicate.name
            // A name captured into the pipeline earlier in this same resolution — the searched-out
            // card of Grim Reminder's "each opponent who cast a spell this turn with the same name
            // as that card". Matched case-insensitively, exactly as the entity-matching path does.
            // Without a context (a static/projection evaluation, which has no pipeline) there is no
            // captured name and nothing can match.
            is CardPredicate.NameEqualsChosen -> {
                val chosenName = context?.chosenValues?.get(predicate.variableName)
                chosenName != null && record.name.equals(chosenName, ignoreCase = true)
            }
            CardPredicate.NameNotSharedWithControlledRoom -> false
            CardPredicate.NameNotSharedWithControlledToken -> false
            CardPredicate.NameNotSharedWithAnotherControlledPermanent -> false
            is CardPredicate.OriginallyPrintedInSet -> false

            // Keyword predicates — not stored in record
            is CardPredicate.HasKeyword, is CardPredicate.NotKeyword -> false

            // Source-relative and context predicates — not applicable
            CardPredicate.NotOfSourceChosenType, CardPredicate.SharesCreatureTypeWithSource,
            CardPredicate.SharesCreatureTypeWithTriggeringEntity, CardPredicate.HasChosenSubtype,
            CardPredicate.HasChosenColor, CardPredicate.SharesChosenColorWithSource,
            CardPredicate.SharesColorWithRecipient,
            is CardPredicate.SharesCreatureTypeWith,
            is CardPredicate.SharesCardTypeWith,
            CardPredicate.SharesCardTypeWithLinkedExile,
            CardPredicate.SharesNameWithLinkedExile,
            is CardPredicate.SharesColorWith,
            is CardPredicate.SharesManaValueWith,
            is CardPredicate.SharesNameWith,
            is CardPredicate.SharesColorWithPermanentYouControl,
            is CardPredicate.SharesNameWithPermanentYouControl,
            is CardPredicate.DoesNotShareCreatureTypeWithPermanentYouControl,
            is CardPredicate.DoesNotShareLandTypeWithPermanentYouControl -> false
            is CardPredicate.HasCardTypeFromVariable,
            is CardPredicate.HasSubtypeFromVariable, is CardPredicate.HasSubtypeInStoredList,
            is CardPredicate.HasSubtypeInEachStoredGroup -> false
            // Source-component name/card-type references are permanent-static predicates, not
            // meaningful for a cast-spell record.
            is CardPredicate.NameEqualsChosenComponent -> false
            is CardPredicate.CardTypeEqualsChosenComponent -> false

            // Stack ability check — cast spells are not abilities
            CardPredicate.IsActivatedOrTriggeredAbility -> false
            CardPredicate.IsTriggeredAbility -> false
            CardPredicate.IsActivatedAbility -> false

            // A cast-spell record has no battlefield permanent to inspect for activated abilities.
            CardPredicate.HasNonManaActivatedAbility -> false
            CardPredicate.HasActivatedAbility -> false

            // Stack-relative targeting predicate — historical cast records have no
            // chosen-target snapshot, so this always returns false here.
            is CardPredicate.TargetsMatching -> false

            // Ability-source predicate — a cast-spell record is not an ability and has no source
            // object to inspect.
            is CardPredicate.AbilitySourceMatches -> false

            // Composite predicates
            is CardPredicate.And -> predicate.predicates.all { matchesRecordPredicate(record, it) }
            is CardPredicate.Or -> predicate.predicates.any { matchesRecordPredicate(record, it) }
            is CardPredicate.Not -> !matchesRecordPredicate(record, predicate.predicate)
        }
    }
}

/**
 * Context for predicate evaluation, providing player references.
 */
data class PredicateContext(
    val controllerId: EntityId,
    val targetOpponentId: EntityId? = null,
    val targetPlayerId: EntityId? = null,
    val sourceId: EntityId? = null,
    /** Original source visit for resolution-time source/exclusion predicates. */
    val sourceBattlefieldTimestamp: Long? = null,
    val objectReferences: ObjectReferenceEnvironment = ObjectReferenceEnvironment(),
    /** Owner of the entity being evaluated (for graveyard targeting) */
    val ownerId: EntityId? = null,
    /**
     * The permanent whose static ability granted the resolving ability (the Equipment/Aura bearing
     * a `GrantActivatedAbility`/`GrantTriggeredAbility`). Lets a target filter resolve
     * [StatePredicate.IsGrantingPermanent] — e.g. "an artifact other than [this granting Equipment]"
     * (Dire Blunderbuss). Null for ungranted abilities.
     */
    val granterId: EntityId? = null,
    /** The entity that caused the trigger to fire (for SharesCreatureTypeWithTriggeringEntity) */
    val triggeringEntityId: EntityId? = null,
    /**
     * The player associated with the trigger (the damaged player for damage triggers, the player
     * whose event fired otherwise). Lets a target filter resolve
     * [EffectTarget.PlayerRef] of [Player.TriggeringPlayer] — e.g. "target creature **that player**
     * controls" on Fear of Burning Alive's "deals noncombat damage to an opponent" trigger.
     */
    val triggeringPlayerId: EntityId? = null,
    /**
     * The entity an enclosing `ForEachInGroup` is currently iterating over. Lets a filter inside
     * such a loop talk about *that* creature — Tidal Flats' "creatures you control blocking that
     * creature" — where a source-relative predicate would read the enchantment instead.
     */
    val iterationEntityId: EntityId? = null,
    /**
     * The entity a continuous effect is being applied to during projection (e.g. the creature an
     * Aura is enchanting). Lets filters resolve [EntityReference.AffectedEntity] — needed by
     * `AggregateBattlefield(filter = ...sharingCreatureTypeWith(AffectedEntity))` for Alpha Status.
     * Only set during projection-time evaluation; null otherwise.
     */
    val affectedEntityId: EntityId? = null,
    /** Named values chosen by the player during pipeline execution (e.g., creature type, color). */
    val chosenValues: Map<String, String> = emptyMap(),
    /** Named string lists stored by pipeline effects (e.g., chosen creature types). */
    val storedStringLists: Map<String, List<String>> = emptyMap(),
    /**
     * Named lists of subtype sets stored by pipeline effects — one `Set<String>` per
     * source entity. Populated by `GatherSubtypesEffect`. Used by
     * [CardPredicate.HasSubtypeInEachStoredGroup] to implement "shares a subtype with
     * each of" semantics.
     */
    val storedSubtypeGroups: Map<String, List<Set<String>>> = emptyMap(),
    /**
     * Named lists of entity ids stored by pipeline effects — e.g. the amassed Army under
     * [EntityReference.AmassedArmy.STORAGE_KEY], or a cost-chosen entity under its `storeAs` key.
     * Lets a target/affected-entity filter resolve [EntityReference.AmassedArmy] /
     * [EntityReference.FromCostStorage] and compare against the stored entity's projected
     * characteristics ("power <= the amassed Army's power" — Grishnákh, Brash Instigator).
     * Threaded from `EffectContext.pipeline.storedCollections`; empty when no pipeline state exists.
     */
    val storedCollections: Map<String, List<EntityId>> = emptyMap(),
    /** Ordered targets chosen for the effect; used to resolve explicit EffectTarget references. */
    val targets: List<ChosenTarget> = emptyList(),
    /** Named targets bound via the DSL, mapped by name. */
    val namedTargets: Map<String, ChosenTarget> = emptyMap(),
    /**
     * The X chosen for the source spell/ability (cast-time selection or snapshot from
     * SpellOnStackComponent at resolution). Used by [CardPredicate.ManaValueAtMostX] to
     * filter targets by "mana value X or less".
     */
    val xValue: Int? = null,
    /**
     * The color chosen during the current effect's resolution (e.g. via `ChooseColorThen`).
     * Read by [CardPredicate.HasChosenColor] so filters can match "permanents of that color".
     */
    val chosenColor: Color? = null,
    /**
     * The recipient of the in-flight damage, when evaluating a damage replacement's source
     * filter. Read by [CardPredicate.SharesColorWithRecipient] so a source filter can be
     * relative to what's being damaged (Well-Laid Plans).
     */
    val recipientId: EntityId? = null,
    /**
     * Last-known information for [sourceId] when the source has left the battlefield, threaded into
     * the [EffectContext] that [PredicateEvaluator.evaluateDynamicCap] reconstructs so a
     * source-relative [DynamicAmount] cap resolves against the characteristics the source last had
     * (CR 608.2h / 113.7a) instead of falling through to its base characteristics.
     *
     * Null while the source is still on the battlefield — the evaluator's LKI branch only engages
     * for an entity that is not in `state.getBattlefield()`, so a live source keeps reading
     * projected state and a stale snapshot could not shadow it either way.
     */
    val lastKnownSourceSnapshot: EntitySnapshot? = null
) {
    /**
     * Resolve an [EffectTarget] reference to a concrete player [EntityId].
     *
     * Supports [EffectTarget.BoundVariable] (maps by target name), [EffectTarget.ContextTarget]
     * (maps by position in [targets]), and [EffectTarget.Controller]. Returns `null` when the
     * reference doesn't resolve to a player — filters that depend on a player target will then
     * match nothing, which is the safe default.
     */
    fun resolvePlayerTarget(target: EffectTarget): EntityId? {
        val chosen: ChosenTarget? = when (target) {
            is EffectTarget.BoundVariable -> namedTargets[target.name]
            is EffectTarget.ContextTarget -> targets.getOrNull(target.index)
            EffectTarget.Controller -> return controllerId
            is EffectTarget.PlayerRef -> return when (target.player) {
                Player.You -> controllerId
                Player.TriggeringPlayer -> triggeringPlayerId
                Player.TargetPlayer, Player.TargetOpponent -> targetPlayerId
                else -> null
            }
            else -> null
        }
        return (chosen as? ChosenTarget.Player)?.playerId
    }

    companion object {
        /**
         * Create from EffectContext for compatibility.
         */
        fun fromEffectContext(context: EffectContext): PredicateContext {
            // "Target opponent" / "target player" predicates read the concretely chosen
            // player target — never a turn-order-derived opponent.
            val chosenPlayerTarget = context.targets.firstNotNullOfOrNull { target ->
                (target as? ChosenTarget.Player)?.playerId
            }
            return PredicateContext(
                controllerId = context.controllerId,
                targetOpponentId = chosenPlayerTarget,
                targetPlayerId = chosenPlayerTarget,
                sourceId = context.sourceId,
                sourceBattlefieldTimestamp = context.sourceBattlefieldTimestamp,
            objectReferences = context.objectReferences,
                granterId = context.granterId,
                triggeringEntityId = context.triggeringEntityId,
                triggeringPlayerId = context.triggeringPlayerId,
                affectedEntityId = context.affectedEntityId,
                chosenValues = context.pipeline.chosenValues,
                storedStringLists = context.pipeline.storedStringLists,
                storedSubtypeGroups = context.pipeline.storedSubtypeGroups,
                storedCollections = context.pipeline.storedCollections,
                targets = context.targets,
                namedTargets = context.pipeline.namedTargets,
                xValue = context.xValue,
                chosenColor = context.chosenColor,
                iterationEntityId = context.pipeline.iterationTarget
            )
        }
    }
}
