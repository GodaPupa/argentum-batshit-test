package com.wingedsheep.engine.handlers.continuations

import com.wingedsheep.engine.core.*
import com.wingedsheep.engine.handlers.DynamicAmountEvaluator
import com.wingedsheep.engine.handlers.EffectContext
import com.wingedsheep.engine.handlers.PipelineState
import com.wingedsheep.engine.handlers.effects.EntersWithReplacements
import com.wingedsheep.engine.handlers.effects.copy.CopyExceptionApplier
import com.wingedsheep.engine.handlers.effects.life.LifePaymentService
import com.wingedsheep.engine.mechanics.modal.ChosenModeMemory
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.stack.SpellOnStackComponent
import com.wingedsheep.engine.state.components.battlefield.ChoiceValue
import com.wingedsheep.engine.state.components.battlefield.withCastChoice
import com.wingedsheep.engine.legalactions.utils.TargetEnumerationUtils
import com.wingedsheep.sdk.core.Zone
import com.wingedsheep.sdk.scripting.ChoiceSlot
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.effects.CompositeEffect
import com.wingedsheep.sdk.scripting.effects.Mode
import com.wingedsheep.sdk.scripting.events.CounterTypeFilter
import com.wingedsheep.sdk.scripting.values.DynamicAmount

class ModalAndCloneContinuationResumer(
    private val services: com.wingedsheep.engine.core.EngineServices
) : ContinuationResumerModule {

    private val dynamicAmountEvaluator = DynamicAmountEvaluator()

    override fun resumers(): List<ContinuationResumer<*>> = listOf(
        resumer(ModalContinuation::class, ::resumeModal),
        resumer(ModalTargetContinuation::class, ::resumeModalTarget),
        resumer(CloneEntersContinuation::class, ::resumeCloneEnters),
        resumer(CloneEntersOnBattlefieldContinuation::class, ::resumeCloneEntersOnBattlefield),
        resumer(EntersWithChoiceSpellContinuation::class, ::resumeEntersWithChoiceSpell),
        resumer(EntersWithChoiceOnBattlefieldContinuation::class, ::resumeEntersWithChoiceOnBattlefield),
        resumer(PayLifeOrEnterTappedLandContinuation::class, ::resumePayLifeOrEnterTappedLand),
        resumer(PayLifeOrEnterTappedSpellContinuation::class, ::resumePayLifeOrEnterTappedSpell),
        resumer(RevealCountersContinuation::class, ::resumeRevealCounters),
        resumer(ExileCountersContinuation::class, ::resumeExileCounters),
        resumer(DevourEntersContinuation::class, ::resumeDevourEnters),
        resumer(DevourMintedTokenContinuation::class, ::resumeDevourMintedToken),
        resumer(CastWithCreatureTypeContinuation::class, ::resumeCastWithCreatureType),
        resumer(BudgetModalContinuation::class, ::resumeBudgetModal),
        resumer(CreateTokenCopyOfChosenContinuation::class, ::resumeCreateTokenCopyOfChosen),
        resumer(CreateTokenCopyAuraHostContinuation::class, ::resumeCreateTokenCopyAuraHost),
        resumer(ChooseActionContinuation::class, ::resumeChooseAction)
    )

    fun resumeModal(
        state: GameState,
        continuation: ModalContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is OptionChosenResponse) {
            return ExecutionResult.error(state, "Expected option response for modal spell")
        }

        val availableIndices = continuation.availableIndices ?: continuation.modes.indices.toList()
        val optionIndex = response.optionIndex
        // "Choose up to N" — a synthetic decline option is appended after the
        // mode options when minChooseCount is satisfied. Picking it short-circuits
        // execution with no chosen modes.
        val canDecline = continuation.selectedModeIndices.size >= continuation.minChooseCount &&
            continuation.selectedModeIndices.size < continuation.chooseCount
        val declineIndex = if (canDecline) availableIndices.size else -1
        val maxIndex = if (canDecline) availableIndices.size else availableIndices.size - 1
        if (optionIndex < 0 || optionIndex > maxIndex) {
            return ExecutionResult.error(state, "Invalid mode option index: $optionIndex")
        }
        if (optionIndex == declineIndex) {
            return resolveChosenModes(state, continuation, continuation.selectedModeIndices, checkForMore)
        }
        val originalModeIndex = availableIndices[optionIndex]
        val newSelectedIndices = continuation.selectedModeIndices + originalModeIndex
        // With allowRepeat the same mode stays on the menu for every remaining pick; without it
        // each mode is offered once (the "choose two different modes" default).
        val newAvailableIndices =
            if (continuation.allowRepeat) availableIndices
            else availableIndices.toMutableList().also { it.removeAt(optionIndex) }

        // "Choose one that hasn't been chosen" (Gandalf the Grey): record the chosen mode
        // on the source so later triggers exclude it. Persists for the source's lifetime.
        // Turn-scoped sibling (Breeches, Eager Pillager): record on a component cleared at end
        // of turn instead, so the exclusion resets next turn.
        val stateAfterRecord = ChosenModeMemory.record(
            state, continuation.sourceId, originalModeIndex,
            ever = continuation.recordChosenModesOnSource,
            thisTurn = continuation.recordChosenModesThisTurn
        )

        // More modes still need to be picked — present the next ChooseOptionDecision.
        if (newSelectedIndices.size < continuation.chooseCount && newAvailableIndices.isNotEmpty()) {
            val sourceName = continuation.sourceName ?: "modal spell"
            val prompt = "Choose a mode for $sourceName (${newSelectedIndices.size + 1} of ${continuation.chooseCount})"
            val nextCanDecline = newSelectedIndices.size >= continuation.minChooseCount
            val baseOptions = newAvailableIndices.map { continuation.modes[it].description }
            val decisionOptions = if (nextCanDecline) {
                baseOptions + com.wingedsheep.engine.handlers.effects.composite.ModalEffectExecutor.DECLINE_MODE_LABEL
            } else baseOptions
            val question = { decisionId: String -> ChooseOptionDecision(
                id = decisionId,
                playerId = continuation.controllerId,
                prompt = prompt,
                context = DecisionContext(
                    sourceId = continuation.sourceId,
                    sourceName = continuation.sourceName,
                    phase = DecisionPhase.RESOLUTION
                ),
                options = decisionOptions
            ) }
            val nextContinuation = continuation.copy(
                selectedModeIndices = newSelectedIndices,
                availableIndices = newAvailableIndices
            )
            return stateAfterRecord.suspendForDecision(
                question = question,
                answer = nextContinuation,
                events = emptyList(),
            )
        }

        return resolveChosenModes(stateAfterRecord, continuation, newSelectedIndices, checkForMore)
    }

    /**
     * Execute the modes selected so far, in pick order. Used both when the player
     * has met `chooseCount` and when they decline a "choose up to N" pick.
     */
    private fun resolveChosenModes(
        state: GameState,
        continuation: ModalContinuation,
        selectedModeIndices: List<Int>,
        checkForMore: CheckForMore
    ): ExecutionResult {
        val chosenModes = selectedModeIndices.map { continuation.modes[it] }
        // For single-mode flow, preserve revert-to-mode-selection by passing the full modes list
        // when there's only one chosen mode and it needs targets. For multi-mode, don't allow cancel.
        val allowCancelBackToModes = continuation.chooseCount == 1 && chosenModes.size == 1
        return processChosenModeQueue(
            services = services,
            state = state,
            queue = chosenModes,
            controllerId = continuation.controllerId,
            sourceId = continuation.sourceId,
            sourceName = continuation.sourceName,
            xValue = continuation.xValue,
            triggeringEntityId = continuation.triggeringEntityId,
            allowCancelBackToModesList = if (allowCancelBackToModes) continuation.modes else null,
            outerTargets = continuation.outerTargets,
            outerNamedTargets = continuation.outerNamedTargets,
            pipeline = continuation.pipeline,
            objectReferences = continuation.objectReferences,
            accumulatedEvents = emptyList(),
            checkForMore = checkForMore
        )
    }

    /**
     * Resume after player selected targets for a modal spell mode.
     * Execute the chosen mode's effect with the selected targets.
     */
    fun resumeModalTarget(
        state: GameState,
        continuation: ModalTargetContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        // Handle cancel: go back to mode selection (single-mode flow only)
        if (response is CancelDecisionResponse && continuation.modes != null) {
            return revertToModeSelection(state, continuation)
        }

        if (response !is TargetsResponse) {
            return ExecutionResult.error(state, "Expected targets response for modal spell")
        }

        // Convert selected targets to ChosenTargets, sorted by requirement index
        // so buildNamedTargets maps them correctly to each requirement
        val chosenTargets = response.selectedTargets.entries
            .sortedBy { it.key }
            .flatMap { (_, targetIds) ->
                targetIds.map { targetId ->
                    entityIdToChosenTarget(state, targetId)
                }
            }

        val context = EffectContext(
            sourceId = continuation.sourceId,
            objectReferences = continuation.objectReferences,
            controllerId = continuation.controllerId,
            xValue = continuation.xValue,
            targets = chosenTargets,
            pipeline = continuation.pipeline.copy(namedTargets = continuation.pipeline.namedTargets + EffectContext.buildNamedTargets(continuation.targetRequirements, chosenTargets)),
            triggeringEntityId = continuation.triggeringEntityId
        )

        // Execute this mode's effect with the picked targets. The helper pre-pushes a
        // tail frame carrying any remaining chosen modes so that if this effect itself
        // pauses (e.g. a targeted Scry's reorder decision), the rest of the queue
        // (choose-N modal) still resumes afterward instead of being dropped.
        return executeChosenModeWithTail(
            services = services,
            state = state,
            effect = continuation.effect,
            context = context,
            tail = continuation.remainingChosenModes,
            controllerId = continuation.controllerId,
            sourceId = continuation.sourceId,
            sourceName = continuation.sourceName,
            xValue = continuation.xValue,
            triggeringEntityId = continuation.triggeringEntityId,
            outerTargets = continuation.outerTargets,
            outerNamedTargets = continuation.outerNamedTargets,
            accumulatedEvents = emptyList(),
            checkForMore = checkForMore
        )
    }

    /**
     * Apply an `EntersAsCopy` copy onto [entityId] in place (CR 707.2): overwrite its
     * [CardComponent] with [targetCardComponent]'s copiable characteristics (re-homed to [newOwnerId]),
     * add any [additionalSubtypes] / [additionalKeywords] and name / P-T overrides (via
     * [CopyExceptionApplier], the same arithmetic every other copy path runs), and snapshot a
     * [com.wingedsheep.engine.state.components.identity.CopyOfComponent] so the permanent reverts to
     * its printed identity when it leaves the battlefield (CR 400.7 / 707.2).
     *
     * Shared by both copy-enters paths — the spell resolution ([resumeCloneEnters], where the entity
     * is still a spell on the stack) and the already-on-battlefield direct entry
     * ([resumeCloneEntersOnBattlefield], a land played / token). Returns the updated state; callers
     * read the copied [CardComponent] back off it.
     */
    private fun applyCopyToEntity(
        state: GameState,
        entityId: EntityId,
        originalCardComponent: CardComponent,
        targetCardComponent: CardComponent,
        newOwnerId: EntityId?,
        additionalSubtypes: List<String>,
        additionalKeywords: List<com.wingedsheep.sdk.core.Keyword>,
        nameOverride: String?,
        powerOverride: Int?,
        toughnessOverride: Int?,
    ): GameState {
        // The riders are the same "except …" clause every other copy path carries (CR 707.9b), so
        // they go through the one engine-side implementation rather than a fourth hand-rolled copy.
        val exceptions = com.wingedsheep.sdk.scripting.effects.CopyExceptions(
            nameOverride = nameOverride,
            addedKeywords = additionalKeywords.toSet(),
            addedSubtypes = additionalSubtypes.map { com.wingedsheep.sdk.core.Subtype(it) }.toSet(),
            powerOverride = powerOverride,
            toughnessOverride = toughnessOverride,
        )
        val copiedCardComponent = CopyExceptionApplier.apply(
            targetCardComponent.copy(
                ownerId = newOwnerId,
                // Which physical card this object is printed on doesn't change when it copies
                // something: layout isn't a copiable value (CR 707.2). CR 712.9's example is exactly
                // this — "a Clone enters as a copy of Wildblood Pack … because the Clone is itself
                // not a double-faced card, it can't transform" — and its converse, a Kruin Outlaw
                // copying Elite Vanguard that transforms anyway. So keep the copier's own flag.
                isDoubleFaced = originalCardComponent.isDoubleFaced,
            ),
            exceptions,
        )
        return state.updateEntity(entityId) { c ->
            c.with(copiedCardComponent)
                .with(com.wingedsheep.engine.state.components.identity.CopyOfComponent(
                    originalCardDefinitionId = originalCardComponent.cardDefinitionId,
                    copiedCardDefinitionId = targetCardComponent.cardDefinitionId,
                    originalCardComponent = originalCardComponent
                ))
        }
    }

    /**
     * Apply an `EntersAsCopy.additionalCounters` rider — "except it enters with N additional +1/+1
     * counters on it" (Altered Ego, Spark Double). Only ever called when a copy was actually made:
     * the rider is part of the copy effect, so declining the copy declines the counters (printed
     * ruling). Routes through [EntersWithReplacements.placeEntryCounters] so Hardened Scales-style
     * counter-placement modifiers and the "counter placed this turn" tracker behave exactly as they
     * do for a printed "enters with counters".
     *
     * @param xValue the value chosen for X while casting, for a [DynamicAmount.XValue] amount; null
     *   on the non-spell entry path (a land/token copy has no cast X).
     */
    private fun applyCopyEntryCounters(
        state: GameState,
        entityId: EntityId,
        controllerId: EntityId,
        amount: DynamicAmount,
        xValue: Int?,
    ): Pair<GameState, List<GameEvent>> {
        val context = EffectContext(sourceId = entityId, controllerId = controllerId, xValue = xValue)
        val count = dynamicAmountEvaluator.evaluate(state, amount, context)
        val entityName = state.getEntity(entityId)?.get<CardComponent>()?.name ?: ""
        return EntersWithReplacements.placeEntryCounters(
            state, entityId, CounterTypeFilter.PlusOnePlusOne, count, controllerId, entityName
        )
    }

    /**
     * Resume after player selects a creature to copy for Clone-style effects.
     */
    fun resumeCloneEnters(
        state: GameState,
        continuation: CloneEntersContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for clone")
        }

        val spellId = continuation.spellId
        val controllerId = continuation.controllerId
        val ownerId = continuation.ownerId
        val events = mutableListOf<GameEvent>()

        val spellContainer = state.getEntity(spellId)
            ?: return ExecutionResult.error(state, "Clone spell entity not found: $spellId")

        val originalCardComponent = spellContainer.get<CardComponent>()
            ?: return ExecutionResult.error(state, "Clone spell has no CardComponent")

        val spellComponent = spellContainer.get<SpellOnStackComponent>()
            ?: return ExecutionResult.error(state, "Clone spell has no SpellOnStackComponent")

        var newState = state

        // If a creature was selected, copy its CardComponent
        val selectedCreatureId = response.selectedCards.firstOrNull()
        val copiedCardDef: com.wingedsheep.sdk.model.CardDefinition?
        var copyApplied = false

        if (selectedCreatureId != null) {
            val targetContainer = newState.getEntity(selectedCreatureId)
            val targetCardComponent = targetContainer?.get<CardComponent>()

            if (targetCardComponent != null) {
                copyApplied = true
                // Copy the target's copiable characteristics onto the spell (keeping Clone's own
                // ownerId), plus any Mockingbird/Superior-Spider-Man overrides — shared with the
                // land-copy path via applyCopyToEntity.
                newState = applyCopyToEntity(
                    state = newState,
                    entityId = spellId,
                    originalCardComponent = originalCardComponent,
                    targetCardComponent = targetCardComponent,
                    newOwnerId = ownerId,
                    additionalSubtypes = continuation.additionalSubtypes,
                    additionalKeywords = continuation.additionalKeywords,
                    nameOverride = continuation.nameOverride,
                    powerOverride = continuation.powerOverride,
                    toughnessOverride = continuation.toughnessOverride,
                )

                // "except it enters with X additional +1/+1 counters on it" (Altered Ego) — part of
                // the copy effect, so it only applies when a copy was actually made. Stamped before
                // the permanent enters so it is genuinely *entering* with them: state-based actions
                // never see the 0/0, and enters-with-counters triggers read the final total.
                val extraCounters = continuation.additionalCounters
                if (extraCounters != null) {
                    val (afterCounters, counterEvents) = applyCopyEntryCounters(
                        newState, spellId, controllerId, extraCounters, spellComponent.xValue
                    )
                    newState = afterCounters
                    events.addAll(counterEvents)
                }

                // Look up the card definition for the copied creature
                copiedCardDef = services.cardRegistry.getCard(targetCardComponent.cardDefinitionId)
            } else {
                // Target creature no longer exists - enter as itself
                copiedCardDef = services.cardRegistry.getCard(originalCardComponent.cardDefinitionId)
            }
        } else {
            // Player declined to copy - enter as itself (0/0 Clone)
            copiedCardDef = services.cardRegistry.getCard(originalCardComponent.cardDefinitionId)
        }

        // Get the (possibly updated) card component for event names
        val finalCardComponent = newState.getEntity(spellId)?.get<CardComponent>() ?: originalCardComponent

        // Track whether a copy was made (original name differs from final name)
        val copyOfOriginalName = if (selectedCreatureId != null && finalCardComponent.name != originalCardComponent.name) {
            originalCardComponent.name
        } else null

        // Complete the permanent entry using the shared helper
        val (enterState, enterEvents) = services.stackResolver.enterPermanentOnBattlefield(
            newState, spellId, spellComponent, finalCardComponent, copiedCardDef
        )
        newState = enterState
        events.addAll(enterEvents.map { event ->
            if (event is ZoneChangeEvent && event.entityId == spellId && event.toZone == Zone.BATTLEFIELD)
                event.copy(copyOfOriginalName = copyOfOriginalName) else event
        })

        events.add(ResolvedEvent(spellId, finalCardComponent.name))

        // "When you do, exile that card." (Superior Spider-Man) — exile the copied
        // graveyard card after the copy has been applied and the permanent has entered.
        if (continuation.exileCopiedCard && copyApplied && selectedCreatureId != null) {
            val exileResult = com.wingedsheep.engine.handlers.effects.ZoneTransitionService
                .moveToZone(newState, selectedCreatureId, Zone.EXILE)
            newState = exileResult.state
            events.addAll(exileResult.events)
        }

        return checkForMore(newState, events)
    }

    /**
     * Resume after a player chooses (or declines) a card/permanent to copy for an
     * [com.wingedsheep.sdk.scripting.EntersAsCopy] replacement on a permanent that has already been
     * placed on the battlefield **directly** (a land played — Echoing Deeps / Vesuva / Thespian's
     * Stage — or a token). Unlike [resumeCloneEnters], the entity is already a battlefield permanent,
     * so we copy onto it in place, tap it if [CloneEntersOnBattlefieldContinuation.tappedIfCopied]
     * and a copy was made, then fire the entry's ETB triggers off a synthesized [ZoneChangeEvent].
     */
    fun resumeCloneEntersOnBattlefield(
        state: GameState,
        continuation: CloneEntersOnBattlefieldContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for clone-enters-on-battlefield")
        }

        val entityId = continuation.entityId
        val entityContainer = state.getEntity(entityId)
            ?: return ExecutionResult.error(state, "Clone-enters entity not found: $entityId")
        val originalCardComponent = entityContainer.get<CardComponent>()
            ?: return ExecutionResult.error(state, "Clone-enters entity has no CardComponent")

        var newState = state
        var copyApplied = false
        val outEvents = mutableListOf<GameEvent>()
        val selectedId = response.selectedCards.firstOrNull()

        if (selectedId != null) {
            val targetCardComponent = newState.getEntity(selectedId)?.get<CardComponent>()
            if (targetCardComponent != null) {
                copyApplied = true
                // Copy the chosen object's copiable characteristics (CR 707.2) onto this permanent,
                // keeping its own owner — shared with the spell-resolution path via applyCopyToEntity.
                newState = applyCopyToEntity(
                    state = newState,
                    entityId = entityId,
                    originalCardComponent = originalCardComponent,
                    targetCardComponent = targetCardComponent,
                    newOwnerId = originalCardComponent.ownerId,
                    additionalSubtypes = continuation.additionalSubtypes,
                    additionalKeywords = continuation.additionalKeywords,
                    nameOverride = continuation.nameOverride,
                    powerOverride = continuation.powerOverride,
                    toughnessOverride = continuation.toughnessOverride,
                )
            }
        }

        // "enter tapped as a copy" — only tap when a copy was actually made.
        if (copyApplied && continuation.tappedIfCopied) {
            newState = newState.updateEntity(entityId) { c ->
                c.with(com.wingedsheep.engine.state.components.battlefield.TappedComponent)
            }
        }

        // "except it enters with N additional +1/+1 counters on it" — likewise only when a copy
        // was actually made.
        val bfExtraCounters = continuation.additionalCounters
        if (copyApplied && bfExtraCounters != null) {
            val (afterCounters, counterEvents) = applyCopyEntryCounters(
                newState, entityId, continuation.controllerId, bfExtraCounters, xValue = null
            )
            newState = afterCounters
            outEvents.addAll(counterEvents)
        }

        // "When you do, exile that card." (graveyard copies) — exile the copied card afterward.
        if (copyApplied && continuation.exileCopiedCard && selectedId != null) {
            val exileResult = com.wingedsheep.engine.handlers.effects.ZoneTransitionService
                .moveToZone(newState, selectedId, Zone.EXILE)
            newState = exileResult.state
            outEvents.addAll(exileResult.events)
        }

        val finalCardComponent = newState.getEntity(entityId)?.get<CardComponent>() ?: originalCardComponent
        val copyOfOriginalName = if (copyApplied && finalCardComponent.name != originalCardComponent.name) {
            originalCardComponent.name
        } else null

        // Emit the entry event now that the final (copied) identity is in place — this is the
        // single ZoneChangeEvent the client sees for this land play (PlayLandHandler deliberately
        // does not carry one), so it carries the copied name and `copyOfOriginalName`. It also
        // drives ETB triggers (landfall / "when ~ enters"), mirroring resumeCloneEnters.
        val zoneChangeEvent = ZoneChangeEvent(
            entityId,
            finalCardComponent.name,
            continuation.fromZone,
            Zone.BATTLEFIELD,
            continuation.controllerId,
            copyOfOriginalName = copyOfOriginalName,
            oldObject = continuation.entryOldObject, newObject = continuation.entryNewObject,
        )
        val triggers = services.triggerDetector.detectTriggers(newState, listOf(zoneChangeEvent))
        if (triggers.isNotEmpty()) {
            val triggerResult = services.triggerProcessor.processTriggers(newState, triggers)
            if (triggerResult.isPaused) {
                return ExecutionResult.propagatePause(
                    triggerResult.state,
                    outEvents + zoneChangeEvent + triggerResult.events
                )
            }
            return checkForMore(triggerResult.newState, outEvents + zoneChangeEvent + triggerResult.events)
        }

        return checkForMore(newState, outEvents + zoneChangeEvent)
    }

    /**
     * Resume after player makes an "as enters" choice for a spell being resolved.
     * Dispatches on choiceType to store the right component, then checks for chained
     * choices before completing the permanent entry.
     */
    fun resumeEntersWithChoiceSpell(
        state: GameState,
        continuation: EntersWithChoiceSpellContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        val spellId = continuation.spellId
        val controllerId = continuation.controllerId
        val ownerId = continuation.ownerId

        // Store the chosen value based on choice type — into the unified cast-choices bag.
        var newState = when (continuation.choiceType) {
            com.wingedsheep.sdk.scripting.ChoiceType.COLOR -> {
                if (response !is ColorChosenResponse) {
                    return ExecutionResult.error(state, "Expected color choice response")
                }
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.COLOR, ChoiceValue.ColorChoice(response.color))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.CREATURE_TYPE -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for creature type choice")
                }
                val chosenType = continuation.creatureTypes.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid creature type index: ${response.optionIndex}")
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.CREATURE_TYPE, ChoiceValue.TextChoice(chosenType))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.CREATURE_ON_BATTLEFIELD -> {
                if (response !is CardsSelectedResponse) {
                    return ExecutionResult.error(state, "Expected cards selected response for creature choice")
                }
                val chosenCreatureId = response.selectedCards.firstOrNull()
                    ?: return ExecutionResult.error(state, "No creature selected")
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.CREATURE, ChoiceValue.EntityChoice(chosenCreatureId))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.MODE -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for mode choice")
                }
                val modeId = continuation.modeOptionIds.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid mode option index: ${response.optionIndex}")
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.MODE, ChoiceValue.TextChoice(modeId))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.BASIC_LAND_TYPE -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for land type choice")
                }
                val chosenType = continuation.landTypes.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid land type index: ${response.optionIndex}")
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.LAND_TYPE, ChoiceValue.TextChoice(chosenType))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.OPPONENT -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for opponent choice")
                }
                val chosenOpponent = continuation.opponentIds.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid opponent index: ${response.optionIndex}")
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.OPPONENT, ChoiceValue.EntityChoice(chosenOpponent))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.CARD_NAME -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for card name choice")
                }
                val chosenName = continuation.cardNames.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid card name index: ${response.optionIndex}")
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.CARD_NAME, ChoiceValue.TextChoice(chosenName))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.NUMBER -> {
                if (response !is NumberChosenResponse) {
                    return ExecutionResult.error(state, "Expected number chosen response for number choice")
                }
                state.updateEntity(spellId) { c ->
                    c.withCastChoice(ChoiceSlot.CHOSEN_NUMBER, ChoiceValue.NumberChoice(response.number))
                }
            }
        }

        // Granted-Riot synthesis: apply the chosen +1/+1-counter / haste branch now — a granted
        // permanent has no printed EntersWithCounters/haste static — before it enters the battlefield.
        val syntheticRiotEvents = mutableListOf<GameEvent>()
        if (continuation.syntheticRiot && response is OptionChosenResponse) {
            val modeId = continuation.modeOptionIds.getOrNull(response.optionIndex)
            if (modeId != null) {
                val nm = newState.getEntity(spellId)?.get<CardComponent>()?.name ?: "Unknown"
                val (rs, re) = com.wingedsheep.engine.handlers.effects.EntersWithReplacements
                    .applyGrantedRiotBranch(newState, spellId, controllerId, modeId, nm)
                newState = rs
                syntheticRiotEvents.addAll(re)
            }
            // CR 702.136b — each granted riot instance is a separate choice; re-pause for the next
            // one (a permanent granted riot by two lords chooses counter/haste twice).
            if (continuation.syntheticRiotRemaining > 0) {
                val cc = newState.getEntity(spellId)?.get<CardComponent>()
                if (cc != null) {
                    val repause = services.stackResolver.pauseForEntersWithChoice(
                        newState, spellId, controllerId, ownerId, cc,
                        com.wingedsheep.engine.mechanics.RiotSynthesis.RIOT_CHOICE,
                        syntheticRiot = true,
                        syntheticRiotRemaining = continuation.syntheticRiotRemaining - 1
                    )
                    if (repause != null && repause.isPaused) {
                        return ExecutionResult.propagatePause(
                            repause.state, syntheticRiotEvents + repause.events
                        )
                    }
                }
            }
        }

        // Check if the card has remaining choices to chain to
        val spellContainer = newState.getEntity(spellId)
            ?: return ExecutionResult.error(state, "Spell entity not found: $spellId")
        val cardComponent = spellContainer.get<CardComponent>()
            ?: return ExecutionResult.error(state, "Spell has no CardComponent")
        val cardDef = services.cardRegistry.getCard(cardComponent.cardDefinitionId)

        val nextChoice = cardDef?.script?.replacementEffects
            ?.filterIsInstance<com.wingedsheep.sdk.scripting.EntersWithChoice>()
            ?.sortedBy { it.choiceType.ordinal }
            ?.firstOrNull { it.choiceType.ordinal > continuation.choiceType.ordinal }

        if (nextChoice != null) {
            val result = services.stackResolver.pauseForEntersWithChoice(
                newState, spellId, controllerId, ownerId, cardComponent, nextChoice
            )
            if (result != null) return result
        }

        // No more choices — complete the permanent entry
        val spellComponent = spellContainer.get<SpellOnStackComponent>()
            ?: return ExecutionResult.error(state, "Spell has no SpellOnStackComponent")

        val (enterState, enterEvents) = services.stackResolver.enterPermanentOnBattlefield(
            newState, spellId, spellComponent, cardComponent, cardDef
        )
        newState = enterState

        val events = mutableListOf<GameEvent>()
        events.addAll(syntheticRiotEvents)
        events.addAll(enterEvents)

        // The generic "as this permanent enters, …" replacement ([OnEnterRunEffect]) — the same
        // call `StackResolver.resolvePermanentSpell` makes just after `enterPermanentOnBattlefield`.
        // It lives at both call sites because `enterPermanentOnBattlefield` returns a
        // `(GameState, events)` pair and this replacement may *pause*, which that signature can't
        // express. Without it here, a card carrying an `EntersWithChoice` **and** an
        // `OnEnterRunEffect` silently loses the second one: the choice pauses before the permanent
        // enters, and this resume path is where entry is completed (Grifter's Blade — "choose a
        // creature you control it could be attached to. If you do, it enters attached to that
        // creature", which is the CREATURE_ON_BATTLEFIELD choice plus an attach).
        val onEnterResult = com.wingedsheep.engine.handlers.effects.PermanentEntryReplacements
            .runOnEnterRunEffect(
                newState, spellId, controllerId, services.cardRegistry,
                { s, e, ctx -> services.effectExecutorRegistry.execute(s, e, ctx) },
                xValue = spellComponent.xValue,
            )
        if (onEnterResult != null) {
            // A pause carries the entry events with it so the ETB triggers are deferred to the
            // resume path rather than lost — exactly as the spell path documents.
            if (onEnterResult.isPaused) {
                return ExecutionResult.propagatePause(
                    onEnterResult.state, events + onEnterResult.events
                )
            }
            newState = onEnterResult.state
            events.addAll(onEnterResult.events)
        }

        events.add(ResolvedEvent(spellId, cardComponent.name))

        return checkForMore(newState, events)
    }

    /**
     * Resume after player makes an "as enters" choice for a land played directly to the battlefield.
     * The land is already on the battlefield — just store the chosen value and check for chained choices.
     */
    fun resumeEntersWithChoiceOnBattlefield(
        state: GameState,
        continuation: EntersWithChoiceOnBattlefieldContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        val entityId = continuation.entityId
        // Store the chosen value based on choice type — into the unified cast-choices bag.
        var newState = when (continuation.choiceType) {
            com.wingedsheep.sdk.scripting.ChoiceType.COLOR -> {
                if (response !is ColorChosenResponse) {
                    return ExecutionResult.error(state, "Expected color choice response")
                }
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.COLOR, ChoiceValue.ColorChoice(response.color))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.CREATURE_TYPE -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for creature type choice")
                }
                val chosenType = continuation.creatureTypes.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid creature type index: ${response.optionIndex}")
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.CREATURE_TYPE, ChoiceValue.TextChoice(chosenType))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.CREATURE_ON_BATTLEFIELD -> {
                if (response !is CardsSelectedResponse) {
                    return ExecutionResult.error(state, "Expected cards selected response for creature choice")
                }
                val chosenCreatureId = response.selectedCards.firstOrNull()
                    ?: return ExecutionResult.error(state, "No creature selected")
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.CREATURE, ChoiceValue.EntityChoice(chosenCreatureId))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.MODE -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for mode choice")
                }
                val modeId = continuation.modeOptionIds.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid mode option index: ${response.optionIndex}")
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.MODE, ChoiceValue.TextChoice(modeId))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.BASIC_LAND_TYPE -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for land type choice")
                }
                val chosenType = continuation.landTypes.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid land type index: ${response.optionIndex}")
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.LAND_TYPE, ChoiceValue.TextChoice(chosenType))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.OPPONENT -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for opponent choice")
                }
                val chosenOpponent = continuation.opponentIds.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid opponent index: ${response.optionIndex}")
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.OPPONENT, ChoiceValue.EntityChoice(chosenOpponent))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.CARD_NAME -> {
                if (response !is OptionChosenResponse) {
                    return ExecutionResult.error(state, "Expected option chosen response for card name choice")
                }
                val chosenName = continuation.cardNames.getOrNull(response.optionIndex)
                    ?: return ExecutionResult.error(state, "Invalid card name index: ${response.optionIndex}")
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.CARD_NAME, ChoiceValue.TextChoice(chosenName))
                }
            }
            com.wingedsheep.sdk.scripting.ChoiceType.NUMBER -> {
                if (response !is NumberChosenResponse) {
                    return ExecutionResult.error(state, "Expected number chosen response for number choice")
                }
                state.updateEntity(entityId) { c ->
                    c.withCastChoice(ChoiceSlot.CHOSEN_NUMBER, ChoiceValue.NumberChoice(response.number))
                }
            }
        }

        // Granted-Riot synthesis: apply the chosen +1/+1-counter / haste branch to the (already
        // on-battlefield) permanent — it has no printed EntersWithCounters/haste static — before ETB
        // triggers fire.
        val syntheticRiotEvents = mutableListOf<GameEvent>()
        if (continuation.syntheticRiot && response is OptionChosenResponse) {
            val modeId = continuation.modeOptionIds.getOrNull(response.optionIndex)
            if (modeId != null) {
                val nm = newState.getEntity(entityId)?.get<CardComponent>()?.name ?: "Unknown"
                val (rs, re) = com.wingedsheep.engine.handlers.effects.EntersWithReplacements
                    .applyGrantedRiotBranch(newState, entityId, continuation.controllerId, modeId, nm)
                newState = rs
                syntheticRiotEvents.addAll(re)
            }
            // CR 702.136b — each granted riot instance is a separate choice; re-pause for the next
            // one, carrying the events already applied so they aren't lost across the pause.
            if (continuation.syntheticRiotRemaining > 0) {
                val cc = newState.getEntity(entityId)?.get<CardComponent>()
                if (cc != null) {
                    val repause = com.wingedsheep.engine.handlers.effects.PermanentEntryReplacements
                        .pauseForEntersWithChoice(
                            newState, entityId, continuation.controllerId, cc,
                            com.wingedsheep.engine.mechanics.RiotSynthesis.RIOT_CHOICE,
                            continuation.fromZone,
                            carryEvents = syntheticRiotEvents,
                            syntheticRiot = true,
                            syntheticRiotRemaining = continuation.syntheticRiotRemaining - 1,
                            entryOldObject = continuation.entryOldObject, entryNewObject = continuation.entryNewObject,
                        )
                    if (repause != null) return repause
                }
            }
        }

        // Check if the permanent has remaining choices to chain to (e.g. color + creature type).
        val entityContainer = newState.getEntity(entityId)
        val cardComponent = entityContainer?.get<CardComponent>()
        val cardDef = cardComponent?.let { services.cardRegistry.getCard(it.cardDefinitionId) }

        val nextChoice = cardDef?.script?.replacementEffects
            ?.filterIsInstance<com.wingedsheep.sdk.scripting.EntersWithChoice>()
            ?.sortedBy { it.choiceType.ordinal }
            ?.firstOrNull { it.choiceType.ordinal > continuation.choiceType.ordinal }

        if (nextChoice != null) {
            val result = com.wingedsheep.engine.handlers.effects.PermanentEntryReplacements.pauseForEntersWithChoice(
                newState, entityId, continuation.controllerId, cardComponent, nextChoice, continuation.fromZone,
                entryOldObject = continuation.entryOldObject, entryNewObject = continuation.entryNewObject,
            )
            if (result != null) return result
            // null means the chained choice couldn't be presented — fall through to fire triggers.
        }

        // Final choice resolved — fire any triggers from the permanent entering (e.g. landfall,
        // "when ~ enters"). The permanent already moved to the battlefield when it was placed; we
        // synthesize the matching ZoneChangeEvent here so triggers can react now that the chosen
        // value is recorded.
        val zoneChangeEvent = ZoneChangeEvent(
            entityId,
            cardComponent?.name ?: "Unknown",
            continuation.fromZone,
            Zone.BATTLEFIELD,
            continuation.controllerId,
            oldObject = continuation.entryOldObject, newObject = continuation.entryNewObject,
        )
        val triggerEvents = listOf(zoneChangeEvent)
        val triggers = services.triggerDetector.detectTriggers(newState, triggerEvents)
        // Detection used the actual entry-time observers above. Publish this exact occurrence
        // once; the next detector must still see every distinct event from an automatic tail.
        val entryEvents = syntheticRiotEvents + zoneChangeEvent.copy(entryTriggersAlreadyProcessed = true)
        if (triggers.isNotEmpty()) {
            val triggerResult = services.triggerProcessor.processTriggers(newState, triggers)
            if (triggerResult.isPaused) {
                return ExecutionResult.propagatePause(
                    triggerResult.state,
                    entryEvents + triggerResult.events
                )
            }
            return checkForMore(triggerResult.newState, entryEvents + triggerResult.events)
        }

        return checkForMore(newState, entryEvents)
    }

    /**
     * Resume after player answers yes/no to "pay life or enter tapped" for a land played directly.
     *
     * The land is already on the battlefield. If yes -> pay life, land stays untapped.
     * If no -> land gets tapped. Then detect and process triggers from the land entering.
     */
    fun resumePayLifeOrEnterTappedLand(
        state: GameState,
        continuation: PayLifeOrEnterTappedLandContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for pay life or enter tapped")
        }

        var newState = state
        val events = mutableListOf<GameEvent>()

        if (response.choice) {
            // Player chose to pay life
            val (afterPayment, paymentEvents) = LifePaymentService
                .pay(newState, continuation.controllerId, continuation.lifeCost)
                ?: return ExecutionResult.error(state, "Player has no life total")
            newState = afterPayment
            events.addAll(paymentEvents)
        } else {
            // Player chose not to pay — land enters tapped
            newState = newState.updateEntity(continuation.landId) { c ->
                c.with(com.wingedsheep.engine.state.components.battlefield.TappedComponent)
            }
        }

        // Detect and process any triggers from the land entering (e.g., landfall)
        val landContainer = newState.getEntity(continuation.landId)
        val cardComponent = landContainer?.get<CardComponent>()
        val zoneChangeEvent = ZoneChangeEvent(
            continuation.landId,
            cardComponent?.name ?: "Unknown",
            continuation.fromZone,
            Zone.BATTLEFIELD,
            continuation.controllerId,
            oldObject = continuation.entryOldObject, newObject = continuation.entryNewObject,
        )
        val triggerEvents = listOf(zoneChangeEvent)
        val triggers = services.triggerDetector.detectTriggers(newState, triggerEvents)
        if (triggers.isNotEmpty()) {
            val triggerResult = services.triggerProcessor.processTriggers(newState, triggers)

            if (triggerResult.isPaused) {
                return ExecutionResult.propagatePause(
                    triggerResult.state,
                    events + triggerResult.events
                )
            }

            return ExecutionResult.success(
                triggerResult.newState,
                events + triggerResult.events
            )
        }

        return checkForMore(newState, events)
    }

    /**
     * Resume after player answers yes/no to "pay life or enter tapped" for a spell resolving.
     *
     * If yes -> pay life, permanent enters untapped. If no -> permanent enters tapped.
     * Then completes the permanent entry to the battlefield.
     */
    fun resumePayLifeOrEnterTappedSpell(
        state: GameState,
        continuation: PayLifeOrEnterTappedSpellContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for pay life or enter tapped")
        }

        var newState = state
        val events = mutableListOf<GameEvent>()

        if (response.choice) {
            // Player chose to pay life
            val (afterPayment, paymentEvents) = LifePaymentService
                .pay(newState, continuation.controllerId, continuation.lifeCost)
                ?: return ExecutionResult.error(state, "Player has no life total")
            newState = afterPayment
            events.addAll(paymentEvents)
        }

        // Complete the permanent entry
        val spellContainer = newState.getEntity(continuation.spellId)
            ?: return ExecutionResult.error(state, "Spell entity not found: ${continuation.spellId}")

        val cardComponent = spellContainer.get<CardComponent>()
        val spellComponent = spellContainer.get<SpellOnStackComponent>()
            ?: return ExecutionResult.error(state, "Spell has no SpellOnStackComponent")

        val cardDef = cardComponent?.let { services.cardRegistry.getCard(it.cardDefinitionId) }
        val (enterState, enterEvents) = services.stackResolver.enterPermanentOnBattlefield(
            newState, continuation.spellId, spellComponent, cardComponent, cardDef
        )
        newState = enterState
        events.addAll(enterEvents)

        // If player declined to pay life, tap the permanent
        if (!response.choice) {
            newState = newState.updateEntity(continuation.spellId) { c ->
                c.with(com.wingedsheep.engine.state.components.battlefield.TappedComponent)
            }
        }

        events.add(ResolvedEvent(continuation.spellId, cardComponent?.name ?: "Unknown"))

        return checkForMore(newState, events)
    }

    /**
     * Resume casting a spell after the player chose a creature type during casting.
     *
     * Completes the casting by putting the spell on the stack with the chosen type,
     * then detects and processes triggers (same as CastSpellHandler does).
     */
    fun resumeCastWithCreatureType(
        state: GameState,
        continuation: CastWithCreatureTypeContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is OptionChosenResponse) {
            return ExecutionResult.error(state, "Expected option choice response for creature type selection")
        }

        val chosenType = continuation.creatureTypes.getOrNull(response.optionIndex)
            ?: return ExecutionResult.error(state, "Invalid creature type index: ${response.optionIndex}")

        // Complete casting: put spell on stack with the chosen creature type
        val castResult = services.stackResolver.castSpell(
            state,
            continuation.cardId,
            continuation.casterId,
            continuation.targets,
            continuation.xValue,
            continuation.sacrificedPermanents,
            targetRequirements = continuation.targetRequirements,
            chosenCreatureType = chosenType
        )

        if (!castResult.isSuccess) {
            return castResult
        }

        var allEvents = castResult.events

        // Detect and process triggers from casting (same as CastSpellHandler does)
        val triggers = continuation.pendingCostTriggers + services.triggerDetector.detectTriggers(castResult.newState, allEvents)
        if (!castResult.state.stackResolutionPendingPriority) {
            return com.wingedsheep.engine.mechanics.CastPriorityProcessor(
                services.sbaChecker, services.triggerDetector, services.triggerProcessor
            ).start(castResult.state, continuation.casterId, allEvents, triggers)
        }
        if (triggers.isNotEmpty()) {
            val triggerResult = services.triggerProcessor.processTriggers(castResult.newState, triggers)

            if (triggerResult.isPaused) {
                return ExecutionResult.propagatePause(
                    triggerResult.state.withPriority(continuation.casterId),
                    allEvents + triggerResult.events
                )
            }

            allEvents = allEvents + triggerResult.events
            return ExecutionResult.success(
                triggerResult.newState.withPriority(continuation.casterId),
                allEvents
            )
        }

        return ExecutionResult.success(
            castResult.newState.withPriority(continuation.casterId),
            allEvents
        )
    }

    /**
     * Resume after player reveals cards for enters-with-reveal-counters.
     *
     * Adds counters based on how many cards were revealed, then completes
     * the permanent entry to the battlefield.
     */
    fun resumeRevealCounters(
        state: GameState,
        continuation: RevealCountersContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for reveal counters")
        }

        val spellId = continuation.spellId
        val controllerId = continuation.controllerId
        val ownerId = continuation.ownerId
        val revealedCards = response.selectedCards

        var newState = state

        // Add counters based on revealed cards
        val revealEvents = mutableListOf<GameEvent>()
        if (revealedCards.isNotEmpty()) {
            val resolvedCounterType = resolveCounterTypeFromString(continuation.counterType)
            if (resolvedCounterType != null) {
                val counterCount = revealedCards.size * continuation.countersPerReveal
                val current = newState.getEntity(spellId)
                    ?.get<com.wingedsheep.engine.state.components.battlefield.CountersComponent>()
                    ?: com.wingedsheep.engine.state.components.battlefield.CountersComponent()
                newState = newState.updateEntity(spellId) { c ->
                    c.with(current.withAdded(resolvedCounterType, counterCount))
                }
            }

            // Emit reveal event so opponent can see the revealed cards
            val cardNames = revealedCards.mapNotNull { cardId ->
                newState.getEntity(cardId)?.get<CardComponent>()?.name
            }
            val imageUris = revealedCards.mapNotNull { cardId ->
                newState.getEntity(cardId)?.get<CardComponent>()?.imageUri
            }
            val spellName = newState.getEntity(spellId)?.get<CardComponent>()?.name
            revealEvents.add(
                CardsRevealedEvent(
                    revealingPlayerId = controllerId,
                    cardIds = revealedCards,
                    cardNames = cardNames,
                    imageUris = imageUris,
                    source = spellName
                )
            )
        }

        // Complete the permanent entry
        val spellContainer = newState.getEntity(spellId)
            ?: return ExecutionResult.error(state, "Spell entity not found: $spellId")

        val cardComponent = spellContainer.get<CardComponent>()
            ?: return ExecutionResult.error(state, "Spell has no CardComponent")

        val spellComponent = spellContainer.get<SpellOnStackComponent>()
            ?: return ExecutionResult.error(state, "Spell has no SpellOnStackComponent")

        val cardDef = services.cardRegistry.getCard(cardComponent.cardDefinitionId)
        val (enterState4, enterEvents4) = services.stackResolver.enterPermanentOnBattlefield(
            newState, spellId, spellComponent, cardComponent, cardDef
        )
        newState = enterState4

        val events = mutableListOf<GameEvent>()
        events.addAll(enterEvents4)
        events.addAll(revealEvents)
        events.add(ResolvedEvent(spellId, cardComponent.name))

        return checkForMore(newState, events)
    }

    fun resumeExileCounters(
        state: GameState,
        continuation: ExileCountersContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for exile counters")
        }

        var newState = state
        val events = mutableListOf<GameEvent>()
        val actuallyExiled = mutableListOf<com.wingedsheep.sdk.model.EntityId>()
        for (cardId in response.selectedCards) {
            val transition = com.wingedsheep.engine.handlers.effects.ZoneTransitionService.moveToZone(
                newState, cardId, Zone.EXILE
            )
            newState = transition.state
            events.addAll(transition.events)
            if (newState.getZone(com.wingedsheep.engine.state.ZoneKey(
                    newState.getEntity(cardId)?.get<CardComponent>()?.ownerId ?: continuation.controllerId,
                    Zone.EXILE
                )).contains(cardId)
            ) actuallyExiled.add(cardId)
        }

        if (actuallyExiled.isNotEmpty()) {
            val linked = newState.getEntity(continuation.spellId)
                ?.get<com.wingedsheep.engine.state.components.battlefield.LinkedExileComponent>()
                ?.exiledIds.orEmpty()
            newState = newState.updateEntity(continuation.spellId) { container ->
                container.with(com.wingedsheep.engine.state.components.battlefield.LinkedExileComponent(linked + actuallyExiled))
            }
            val counterCount = actuallyExiled.size * continuation.countersPerCard
            val counterFilter = when (continuation.counterType) {
                "+1/+1" -> CounterTypeFilter.PlusOnePlusOne
                "-1/-1" -> CounterTypeFilter.MinusOneMinusOne
                else -> CounterTypeFilter.Named(continuation.counterType)
            }
            val (counterState, counterEvents) = EntersWithReplacements.placeEntryCounters(
                newState,
                continuation.spellId,
                counterFilter,
                counterCount,
                continuation.controllerId,
                newState.getEntity(continuation.spellId)?.get<CardComponent>()?.name ?: "",
            )
            newState = counterState
            events.addAll(counterEvents)
        }

        val spellContainer = newState.getEntity(continuation.spellId)
            ?: return ExecutionResult.error(state, "Spell entity not found: ${continuation.spellId}")
        val cardComponent = spellContainer.get<CardComponent>()
            ?: return ExecutionResult.error(state, "Spell has no CardComponent")
        val spellComponent = spellContainer.get<SpellOnStackComponent>()
            ?: return ExecutionResult.error(state, "Spell has no SpellOnStackComponent")
        val cardDef = services.cardRegistry.getCard(cardComponent.cardDefinitionId)
        val (enteredState, enterEvents) = services.stackResolver.enterPermanentOnBattlefield(
            newState, continuation.spellId, spellComponent, cardComponent, cardDef
        )
        events.addAll(enterEvents)
        events.add(ResolvedEvent(continuation.spellId, cardComponent.name))
        return checkForMore(enteredState, events)
    }

    /**
     * Resume after the player selects permanents to sacrifice for Devour.
     *
     * Sacrifices the chosen permanents (Rule 701.21 — owner of each goes to graveyard),
     * places `multiplier × count` counters of the saved counter type on the entering
     * spell entity, then completes the permanent entry to the battlefield.
     */
    fun resumeDevourEnters(
        state: GameState,
        continuation: DevourEntersContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for devour")
        }

        val spellId = continuation.spellId
        val controllerId = continuation.controllerId
        val ownerId = continuation.ownerId
        val sacrificed = response.selectedCards

        var newState = state
        val events = mutableListOf<GameEvent>()

        // Sacrifice the chosen permanents.
        val (afterSacrifice, sacrificeEvents) = sacrificeForDevour(newState, controllerId, sacrificed)
        newState = afterSacrifice
        events.addAll(sacrificeEvents)

        // Place counters on the still-resolving spell entity.
        val counterCount = sacrificed.size * continuation.multiplier
        if (counterCount > 0) {
            val resolvedCounterType = resolveCounterTypeFromString(continuation.counterType)
                ?: com.wingedsheep.sdk.core.CounterType.PLUS_ONE_PLUS_ONE
            val current = newState.getEntity(spellId)
                ?.get<com.wingedsheep.engine.state.components.battlefield.CountersComponent>()
                ?: com.wingedsheep.engine.state.components.battlefield.CountersComponent()
            newState = newState.updateEntity(spellId) { c ->
                c.with(current.withAdded(resolvedCounterType, counterCount))
            }
            // Devour counters go on the object *as it enters* the battlefield, so CR 122.6a makes
            // the entering permanent's controller the placer regardless of whose effect it was.
            // The spell entity has no projected controller yet, so the flag is passed directly.
            val (afterMark, firstThisTurn) = com.wingedsheep.engine.handlers.effects.DamageUtils
                .recordCounterPlacement(
                    newState,
                    spellId,
                    com.wingedsheep.engine.handlers.effects.permanent.counters.counterTypeToString(resolvedCounterType),
                    byController = true,
                )
            newState = afterMark
            val spellName = newState.getEntity(spellId)?.get<CardComponent>()?.name ?: ""
            events.add(
                com.wingedsheep.engine.core.CountersAddedEvent(
                    spellId, continuation.counterType, counterCount, spellName, firstThisTurn,
                    placedBy = controllerId
                )
            )
        }

        // Complete the permanent entry.
        val spellContainer = newState.getEntity(spellId)
            ?: return ExecutionResult.error(state, "Spell entity not found: $spellId")
        val cardComponent = spellContainer.get<CardComponent>()
            ?: return ExecutionResult.error(state, "Spell has no CardComponent")
        val spellComponent = spellContainer.get<SpellOnStackComponent>()
            ?: return ExecutionResult.error(state, "Spell has no SpellOnStackComponent")
        val cardDef = services.cardRegistry.getCard(cardComponent.cardDefinitionId)

        val (afterEnter, enterEvents) = services.stackResolver.enterPermanentOnBattlefield(
            newState, spellId, spellComponent, cardComponent, cardDef
        )
        newState = afterEnter
        events.addAll(enterEvents)
        events.add(ResolvedEvent(spellId, cardComponent.name))

        return checkForMore(newState, events)
    }

    /**
     * Sacrifice the permanents a player chose for a Devour as-enters replacement (CR 702.82,
     * CR 701.21 — each goes to its owner's graveyard), emitting the sacrifice event and every
     * zone-change event the moves produce.
     *
     * Shared by both devour entry paths — a permanent cast as a spell ([resumeDevourEnters]) and a
     * token minted from a bare definition ([resumeDevourMintedToken]) — so the two cannot drift
     * apart on what a devour sacrifice emits.
     */
    private fun sacrificeForDevour(
        state: GameState,
        controllerId: EntityId,
        sacrificed: List<EntityId>,
    ): Pair<GameState, List<GameEvent>> {
        if (sacrificed.isEmpty()) return state to emptyList()
        val events = mutableListOf<GameEvent>()
        val names = sacrificed.map { id ->
            state.getEntity(id)?.get<CardComponent>()?.name ?: "Unknown"
        }
        events.add(
            com.wingedsheep.engine.core.PermanentsSacrificedEvent(controllerId, sacrificed, names)
        )
        var newState = com.wingedsheep.engine.handlers.effects.ZoneTransitionService
            .trackPermanentSacrifice(state, sacrificed, controllerId)
        for (permanentId in sacrificed) {
            val result = com.wingedsheep.engine.handlers.effects.ZoneTransitionService
                .moveToZone(newState, permanentId, com.wingedsheep.sdk.core.Zone.GRAVEYARD)
            newState = result.state
            events.addAll(result.events)
        }
        return newState to events
    }

    /**
     * Resume after the player selects permanents to sacrifice for Devour on a token minted from a
     * bare card definition — the Momir Basic avatar's random-creature token.
     *
     * The token does not exist yet: devour is an as-enters replacement (CR 614), and a devour
     * creature is usually a 0/0, so the decision was raised *before* the mint rather than after.
     * Sacrifices the picks, then re-enters
     * [com.wingedsheep.engine.handlers.effects.token.TokenFromDefinition.mint] with the earned
     * counter count so the token enters already carrying it — and its ETB triggers, fired by the
     * caller off the mint's zone-change event, see the final power.
     */
    fun resumeDevourMintedToken(
        state: GameState,
        continuation: DevourMintedTokenContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for devour")
        }
        val cardDef = services.cardRegistry.getCard(continuation.cardDefinitionId)
            ?: return ExecutionResult.error(
                state, "Card definition not found: ${continuation.cardDefinitionId}"
            )

        val (afterSacrifice, sacrificeEvents) = sacrificeForDevour(
            state, continuation.controllerId, response.selectedCards
        )

        val minted = com.wingedsheep.engine.handlers.effects.token.TokenFromDefinition.mint(
            state = afterSacrifice,
            cardDef = cardDef,
            controllerId = continuation.controllerId,
            cardRegistry = services.cardRegistry,
            staticAbilityHandler = com.wingedsheep.engine.mechanics.layers.StaticAbilityHandler(
                services.cardRegistry
            ),
            devourCounters = response.selectedCards.size * continuation.multiplier,
        ).toExecutionResult()

        // The mint can pause again (a devour creature that also has an as-enters choice); carry the
        // sacrifice events across that pause so they are not lost.
        if (minted.isPaused) {
            return ExecutionResult.propagatePause(
                minted.state,
                sacrificeEvents + minted.events
            )
        }
        return checkForMore(minted.state, sacrificeEvents + minted.events)
    }

    private fun resolveCounterTypeFromString(counterType: String): com.wingedsheep.sdk.core.CounterType? {
        // Map string constants (from Counters object) to enum values
        val byDescription = com.wingedsheep.sdk.core.CounterType.entries.associateBy { entry ->
            entry.name.lowercase().replace('_', ' ')
        }
        return when (counterType) {
            "+1/+1" -> com.wingedsheep.sdk.core.CounterType.PLUS_ONE_PLUS_ONE
            "-1/-1" -> com.wingedsheep.sdk.core.CounterType.MINUS_ONE_MINUS_ONE
            else -> byDescription[counterType.lowercase()] ?: run {
                System.err.println("WARNING: Unknown counter type '$counterType' in EntersWithRevealCounters, skipping counter placement")
                null
            }
        }
    }

    /**
     * Resume after player chose budget modal modes (Season cycle pawprints).
     * Receives a BudgetModalResponse with all selected mode indices at once.
     * Validates the total cost fits the budget, then executes in printed order.
     */
    fun resumeBudgetModal(
        state: GameState,
        continuation: BudgetModalContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is BudgetModalResponse) {
            return ExecutionResult.error(state, "Expected budget modal response")
        }

        val selectedIndices = response.selectedModeIndices

        // Validate all indices are in range
        for (idx in selectedIndices) {
            if (idx < 0 || idx >= continuation.modes.size) {
                return ExecutionResult.error(state, "Invalid mode index: $idx")
            }
        }

        // Validate total cost doesn't exceed budget
        val totalCost = selectedIndices.sumOf { continuation.modes[it].cost }
        if (totalCost > continuation.remainingBudget) {
            return ExecutionResult.error(state, "Total cost $totalCost exceeds budget ${continuation.remainingBudget}")
        }

        // No modes chosen → no-op
        if (selectedIndices.isEmpty()) {
            return checkForMore(state, emptyList())
        }

        // Sort by mode index for printed-order execution
        val sortedIndices = selectedIndices.sorted()

        val effects = sortedIndices.map { continuation.modes[it].effect }

        val context = EffectContext(
            sourceId = continuation.sourceId,
            objectReferences = continuation.objectReferences,
            controllerId = continuation.controllerId,
        )

        val result = services.effectExecutorRegistry.execute(state, CompositeEffect(effects), context).toExecutionResult()
        if (result.isPaused) return result
        return checkForMore(result.state, result.events.toList())
    }

    /**
     * Resume after player chose a permanent to create a token copy of.
     */
    fun resumeCreateTokenCopyOfChosen(
        state: GameState,
        continuation: CreateTokenCopyOfChosenContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected cards selected response for token copy")
        }

        if (response.selectedCards.isEmpty()) {
            return checkForMore(state, emptyList())
        }

        val chosenId = response.selectedCards.first()
        val staticAbilityHandler = com.wingedsheep.engine.mechanics.layers.StaticAbilityHandler(services.cardRegistry)
        val result = com.wingedsheep.engine.handlers.effects.token.CreateTokenCopyOfChosenPermanentExecutor.createTokenCopy(
            state, chosenId, continuation.controllerId,
            staticAbilityHandler, services.cardRegistry
        ).toExecutionResult()
        if (result.isPaused) return result
        return checkForMore(result.state, result.events.toList())
    }

    /**
     * Resume after the controller chose what an Aura token copy enchants (CR 303.4h).
     *
     * Creates exactly one token, already attached to the chosen host, then asks again for the
     * next one when the effect owes more than one Aura copy. An empty pick (or a host that left
     * the battlefield while the decision was outstanding) means no legal attachment, so that
     * token isn't created — CR 303.4g.
     */
    fun resumeCreateTokenCopyAuraHost(
        state: GameState,
        continuation: CreateTokenCopyAuraHostContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is TargetsResponse) {
            return ExecutionResult.error(state, "Expected targets response for Aura token host selection")
        }

        val hostId = response.selectedTargets[0]?.firstOrNull()
        if (hostId == null || hostId !in state.getBattlefield()) {
            return checkForMore(state, emptyList())
        }

        val executor = com.wingedsheep.engine.handlers.effects.token.CreateTokenCopyOfTargetExecutor(
            staticAbilityHandler = com.wingedsheep.engine.mechanics.layers.StaticAbilityHandler(services.cardRegistry),
            cardRegistry = services.cardRegistry,
        )
        val created = executor.createTokens(
            state = state,
            effect = continuation.effect,
            context = continuation.context,
            controllerId = continuation.controllerId,
            count = 1,
            auraHostId = hostId,
        )

        val remaining = continuation.remaining - 1
        if (remaining <= 0) {
            return checkForMore(created.state, created.events.toList())
        }

        // The token copy can open a question of its own — a printed "choose ... as this enters"
        // (CR 614.12) or granted riot. Only one suspension may be installed at a time, so the next
        // host prompt cannot be stacked on top of it; asking anyway trips the guard in
        // `suspendForDecision`. Report it rather than throwing out of the action processor.
        // Chaining the remaining prompts underneath that choice needs a continuation of its own.
        if (created.isPaused) {
            return ExecutionResult.error(
                created.state,
                "Cannot ask for the next Aura token host while the previous copy owes an as-enters choice"
            )
        }

        // More Aura copies owed — each gets its own host choice.
        val next = com.wingedsheep.engine.handlers.effects.token.AuraTokenHostChooser.pause(
            state = created.state,
            effect = continuation.effect,
            context = continuation.context,
            auraDefinitionId = continuation.auraDefinitionId,
            auraName = continuation.auraName,
            controllerId = continuation.controllerId,
            remaining = remaining,
            cardRegistry = services.cardRegistry,
        )
        val events = created.events.toList() + next.events.toList()
        if (next.pendingDecision == null) return checkForMore(next.state, events)
        return ExecutionResult.propagatePause(next.state, events)
    }

    /**
     * Revert from target selection back to mode selection for a modal spell.
     */
    private fun revertToModeSelection(
        state: GameState,
        continuation: ModalTargetContinuation
    ): ExecutionResult {
        val modes = continuation.modes!!
        val sourceName = continuation.sourceName ?: "modal spell"

        val modeDescriptions = modes.map { it.description }

        val question = { decisionId: String -> ChooseOptionDecision(
            id = decisionId,
            playerId = continuation.controllerId,
            prompt = "Choose a mode for $sourceName",
            context = DecisionContext(
                sourceId = continuation.sourceId,
                sourceName = sourceName,
                phase = DecisionPhase.RESOLUTION
            ),
            options = modeDescriptions
        ) }

        val modalContinuation = ModalContinuation(
            controllerId = continuation.controllerId,
            sourceId = continuation.sourceId,
            objectReferences = continuation.objectReferences,
            sourceName = continuation.sourceName,
            modes = modes,
            xValue = continuation.xValue,
            triggeringEntityId = continuation.triggeringEntityId,
            outerTargets = continuation.outerTargets,
            outerNamedTargets = continuation.outerNamedTargets,
            pipeline = continuation.pipeline
        )

        return state.suspendForDecision(
            question = question,
            answer = modalContinuation,
            events = emptyList(),
        )
    }

    // =========================================================================
    // ChooseAction
    // =========================================================================

    private fun resumeChooseAction(
        state: GameState,
        continuation: ChooseActionContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is OptionChosenResponse) {
            return ExecutionResult.error(state, "Expected option response for ChooseActionEffect")
        }

        val choiceIndex = response.optionIndex
        if (choiceIndex < 0 || choiceIndex >= continuation.choices.size) {
            return ExecutionResult.error(state, "Invalid choice index: $choiceIndex")
        }

        val chosenEffect = continuation.choices[choiceIndex].effect

        // Build context preserving original targets so ContextTarget references still work
        val context = EffectContext(
            sourceId = continuation.sourceId,
            objectReferences = continuation.objectReferences,
            controllerId = continuation.controllerId,
            targets = continuation.targets,
            triggeringEntityId = continuation.triggeringEntityId,
            pipeline = PipelineState(namedTargets = continuation.namedTargets)
        )

        val result = services.effectExecutorRegistry.execute(state, chosenEffect, context).toExecutionResult()

        return if (result.isPaused) {
            result
        } else {
            checkForMore(result.state, result.events.toList())
        }
    }

}

/**
 * Sequentially resolve a queue of chosen modal-ability modes (resolution-time modal
 * triggered / activated abilities — rule 603.3c).
 *
 * - Modes that need no targets execute immediately; their events accumulate.
 * - A mode requiring targets auto-selects a lone player target, silently fizzles when
 *   all its targets have become illegal (Rule 608.2b), or pauses with a
 *   [ChooseTargetsDecision] otherwise; the remaining modes ride along on the
 *   [ModalTargetContinuation].
 * - **Every** mode is executed through [executeChosenModeWithTail], which pushes a
 *   [ModalChosenModeTailContinuation] beneath the mode's effect first, so a *nested*
 *   pause inside a mode (a targeted Scry's reorder prompt, a ChooseAction, …) resumes
 *   the rest of the queue afterward instead of dropping it.
 *
 * Top-level so both the resumer and the [CoreAutoResumerModule] auto-resumer for
 * [ModalChosenModeTailContinuation] can drive it — the resolution-time twin of
 * [com.wingedsheep.engine.handlers.effects.composite.processPreTargetedEffectQueue].
 */
internal fun processChosenModeQueue(
    services: EngineServices,
    state: GameState,
    queue: List<Mode>,
    controllerId: EntityId,
    sourceId: EntityId?,
    sourceName: String?,
    xValue: Int?,
    triggeringEntityId: EntityId?,
    allowCancelBackToModesList: List<Mode>?,
    outerTargets: List<com.wingedsheep.engine.state.components.stack.ChosenTarget>,
    outerNamedTargets: Map<String, com.wingedsheep.engine.state.components.stack.ChosenTarget>,
    accumulatedEvents: List<GameEvent>,
    checkForMore: CheckForMore,
    pipeline: PipelineState = PipelineState.EMPTY,
    objectReferences: com.wingedsheep.engine.handlers.ObjectReferenceEnvironment = com.wingedsheep.engine.handlers.ObjectReferenceEnvironment()
): ExecutionResult {
    if (queue.isEmpty()) return checkForMore(state, accumulatedEvents)

    val head = queue.first()
    val tail = queue.drop(1)
    val displayName = sourceName ?: "modal spell"

    if (head.targetRequirements.isEmpty()) {
        // No targets — execute directly, inheriting outer-scope targets so
        // EffectTarget.ContextTarget references in the inner effect resolve to the
        // targets chosen by the enclosing spell/ability.
        val context = EffectContext(
            sourceId = sourceId,
            objectReferences = objectReferences,
            controllerId = controllerId,
            xValue = xValue,
            targets = outerTargets,
            pipeline = pipeline.copy(namedTargets = pipeline.namedTargets + outerNamedTargets),
            triggeringEntityId = triggeringEntityId
        )
        return executeChosenModeWithTail(
            services, state, head.effect, context, tail,
            controllerId, sourceId, sourceName, xValue, triggeringEntityId,
            outerTargets, outerNamedTargets, accumulatedEvents, checkForMore
        )
    }

    // Targets required — find legal targets, auto-select / skip / pause as needed.
    val legalTargetsMap = mutableMapOf<Int, List<EntityId>>()
    val requirementInfos = head.targetRequirements.mapIndexed { index, req ->
        val legalTargets = services.targetFinder.findLegalTargets(
            state = state,
            requirement = req,
            controllerId = controllerId,
            sourceId = sourceId
        )
        legalTargetsMap[index] = legalTargets
        TargetRequirementInfo(
            index = index,
            description = req.description,
            minTargets = req.effectiveMinCount,
            maxTargets = req.count
        )
    }

    val allSatisfied = requirementInfos.all { info ->
        (legalTargetsMap[info.index]?.isNotEmpty() == true) || info.minTargets == 0
    }
    if (!allSatisfied) {
        // Fizzle just this mode; continue with the rest.
        return processChosenModeQueue(
            services, state, tail, controllerId, sourceId, sourceName, xValue,
            triggeringEntityId, allowCancelBackToModesList, outerTargets, outerNamedTargets,
            accumulatedEvents, checkForMore, pipeline, objectReferences
        )
    }

    // Auto-select a single mandatory player target.
    if (head.targetRequirements.size == 1) {
        val req = head.targetRequirements[0]
        val targets = legalTargetsMap[0] ?: emptyList()
        if (TargetEnumerationUtils.shouldAutoSelectPlayerTarget(req, targets)) {
            val chosenTargets = listOf(entityIdToChosenTarget(state, targets[0]))
            val context = EffectContext(
                sourceId = sourceId,
                objectReferences = objectReferences,
                controllerId = controllerId,
                xValue = xValue,
                targets = chosenTargets,
                pipeline = pipeline.copy(namedTargets = pipeline.namedTargets + EffectContext.buildNamedTargets(head.targetRequirements, chosenTargets)),
                triggeringEntityId = triggeringEntityId
            )
            return executeChosenModeWithTail(
                services, state, head.effect, context, tail,
                controllerId, sourceId, sourceName, xValue, triggeringEntityId,
                outerTargets, outerNamedTargets, accumulatedEvents, checkForMore
            )
        }
    }

    // Pause for target selection. Always surface the mode description so the player
    // knows which mode of a Choose-N modal ability they are targeting for. The tail
    // rides on the ModalTargetContinuation; resumeModalTarget re-enters via
    // executeChosenModeWithTail so a nested pause inside this mode still survives.
    val prompt = "Choose targets for $displayName — ${head.description}"
    val question = { decisionId: String -> ChooseTargetsDecision(
        id = decisionId,
        playerId = controllerId,
        prompt = prompt,
        context = DecisionContext(
            sourceId = sourceId,
            sourceName = sourceName,
            phase = DecisionPhase.RESOLUTION
        ),
        targetRequirements = requirementInfos,
        legalTargets = legalTargetsMap,
        canCancel = allowCancelBackToModesList != null && tail.isEmpty()
    ) }

    val modalTargetContinuation = ModalTargetContinuation(
        controllerId = controllerId,
        sourceId = sourceId,
        sourceName = sourceName,
        effect = head.effect,
        xValue = xValue,
        targetRequirements = head.targetRequirements,
        modes = if (tail.isEmpty()) allowCancelBackToModesList else null,
        triggeringEntityId = triggeringEntityId,
        remainingChosenModes = tail,
        outerTargets = outerTargets,
        outerNamedTargets = outerNamedTargets,
        pipeline = pipeline,
        objectReferences = objectReferences
    )

    return state.suspendForDecision(question, modalTargetContinuation, accumulatedEvents)
}

/**
 * Execute one chosen mode's effect, keeping the rest of the choose-N queue alive across
 * a nested pause.
 *
 * Before running [effect], a [ModalChosenModeTailContinuation] carrying [tail] is pushed
 * so that if the effect pauses for its own decision, that decision's continuation lands
 * ON TOP and the tail frame sits beneath — the [CoreAutoResumerModule] auto-resumer then
 * drains [tail] once the inner chain finishes. On synchronous success the pre-pushed
 * frame is popped and the tail drains immediately. Mirrors
 * [com.wingedsheep.engine.handlers.effects.composite.processPreTargetedEffectQueue]'s
 * pre-push-tail discipline.
 */
private fun executeChosenModeWithTail(
    services: EngineServices,
    state: GameState,
    effect: com.wingedsheep.sdk.scripting.effects.Effect,
    context: EffectContext,
    tail: List<Mode>,
    controllerId: EntityId,
    sourceId: EntityId?,
    sourceName: String?,
    xValue: Int?,
    triggeringEntityId: EntityId?,
    outerTargets: List<com.wingedsheep.engine.state.components.stack.ChosenTarget>,
    outerNamedTargets: Map<String, com.wingedsheep.engine.state.components.stack.ChosenTarget>,
    accumulatedEvents: List<GameEvent>,
    checkForMore: CheckForMore
): ExecutionResult {
    val stateForExecution = if (tail.isNotEmpty()) {
        state.pushContinuation(
            ModalChosenModeTailContinuation(
                controllerId = controllerId,
                sourceId = sourceId,
                sourceName = sourceName,
                xValue = xValue,
                triggeringEntityId = triggeringEntityId,
                remainingChosenModes = tail,
                outerTargets = outerTargets,
                outerNamedTargets = outerNamedTargets,
                pipeline = context.pipeline,
                objectReferences = context.objectReferences
            )
        )
    } else state

    val result = services.effectExecutorRegistry.execute(stateForExecution, effect, context).toExecutionResult()
    val events = accumulatedEvents + result.events

    if (result.isPaused) {
        return ExecutionResult.propagatePause(result.state, events)
    }
    if (result.error != null) {
        return result.copy(events = events)
    }

    // Success — pop the pre-pushed tail frame and drain the rest synchronously.
    val nextState = if (tail.isNotEmpty()) result.state.popContinuation().second else result.state
    return processChosenModeQueue(
        services, nextState, tail, controllerId, sourceId, sourceName, xValue,
        triggeringEntityId, allowCancelBackToModesList = null,
        outerTargets, outerNamedTargets, events, checkForMore,
        context.pipeline, context.objectReferences.authorize(result.events)
    )
}
