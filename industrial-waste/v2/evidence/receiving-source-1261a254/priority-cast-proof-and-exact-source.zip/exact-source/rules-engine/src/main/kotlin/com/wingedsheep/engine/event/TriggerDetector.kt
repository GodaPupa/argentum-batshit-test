package com.wingedsheep.engine.event

import com.wingedsheep.engine.core.ClassLevelChangedEvent
import com.wingedsheep.engine.core.CountersAddedEvent
import com.wingedsheep.engine.core.AttackersDeclaredEvent
import com.wingedsheep.engine.core.CardCycledEvent
import com.wingedsheep.engine.core.CardExiledWithMadnessEvent
import com.wingedsheep.engine.core.CardPlottedEvent
import com.wingedsheep.engine.core.CardsDiscardedEvent
import com.wingedsheep.engine.core.CardsDrawnEvent
import com.wingedsheep.engine.core.StepChangedEvent
import com.wingedsheep.engine.core.TappedEvent
import com.wingedsheep.engine.core.UntappedEvent
import com.wingedsheep.engine.core.ControlChangedEvent
import com.wingedsheep.engine.core.DoorUnlockedEvent
import com.wingedsheep.engine.core.DamageDealtEvent
import com.wingedsheep.engine.core.InitiativeTakenEvent
import com.wingedsheep.engine.core.UndercityRoomEnteredEvent
import com.wingedsheep.engine.core.PermanentsSacrificedEvent
import com.wingedsheep.engine.core.ReflexiveAbilityTriggeredEvent
import com.wingedsheep.engine.core.SpellCastEvent
import com.wingedsheep.engine.core.ZoneChangeEvent
import com.wingedsheep.engine.core.GameEvent as EngineGameEvent
import com.wingedsheep.engine.handlers.ConditionEvaluator
import com.wingedsheep.engine.handlers.EffectContext
import com.wingedsheep.engine.handlers.PredicateContext
import com.wingedsheep.engine.handlers.PredicateEvaluator
import com.wingedsheep.engine.registry.CardRegistry
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.nameVisibleToAll
import com.wingedsheep.engine.state.components.battlefield.AttachedToComponent
import com.wingedsheep.engine.state.components.battlefield.ClassLevelComponent
import com.wingedsheep.engine.state.components.battlefield.CountersComponent
import com.wingedsheep.engine.state.components.battlefield.SagaComponent
import com.wingedsheep.engine.state.components.battlefield.TriggeredAbilityFiredEverComponent
import com.wingedsheep.engine.state.components.battlefield.TriggeredAbilityFiredThisTurnComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.identity.EmblemSourceComponent
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.engine.state.components.identity.FaceDownComponent
import com.wingedsheep.engine.state.components.identity.PlayWithFixedAlternativeManaCostComponent
import com.wingedsheep.engine.state.components.identity.MadnessExiledComponent
import com.wingedsheep.sdk.scripting.GameObjectFilter
import com.wingedsheep.sdk.scripting.SuppressEntersTriggers
import com.wingedsheep.engine.state.components.identity.RoomComponent
import com.wingedsheep.engine.state.components.identity.RoomFaceId
import com.wingedsheep.engine.state.components.identity.RoomFaceStatics
import com.wingedsheep.engine.state.components.identity.TokenComponent
import com.wingedsheep.engine.state.components.identity.OwnerComponent
import com.wingedsheep.engine.state.components.player.PlayerInitiativeComponent
import com.wingedsheep.engine.mechanics.layers.ProjectedState
import com.wingedsheep.engine.state.ComponentContainer
import com.wingedsheep.sdk.core.CounterType
import com.wingedsheep.sdk.core.ManaCost
import com.wingedsheep.sdk.core.Step
import com.wingedsheep.sdk.core.Zone
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.predicates.ControllerPredicate
import com.wingedsheep.sdk.scripting.*
import com.wingedsheep.sdk.scripting.predicates.evaluateWith
import com.wingedsheep.sdk.scripting.events.DamageType
import com.wingedsheep.sdk.scripting.events.RecipientFilter
import com.wingedsheep.sdk.scripting.references.Player
import com.wingedsheep.sdk.dsl.decayed

/**
 * Detects triggered abilities that should fire based on game events.
 *
 * Triggers are returned in APNAP (Active Player, Non-Active Player) order for
 * proper stack placement.
 *
 * Delegates to focused sub-detectors for specific trigger categories:
 * - [DeathAndLeaveTriggerDetector] — dies/leaves-battlefield triggers
 * - [DamageTriggerDetector] — damage source/received triggers
 * - [AttachmentTriggerDetector] — aura/equipment triggers
 */
class TriggerDetector(
    private val cardRegistry: CardRegistry,
    private val abilityRegistry: AbilityRegistry = AbilityRegistry(),
    private val conditionEvaluator: ConditionEvaluator = ConditionEvaluator(),
    private val predicateEvaluator: PredicateEvaluator = PredicateEvaluator()
) {

    private val matcher = TriggerMatcher(predicateEvaluator, conditionEvaluator)
    private val abilityResolver = TriggerAbilityResolver(cardRegistry, abilityRegistry)
    private val deathAndLeaveDetector = DeathAndLeaveTriggerDetector(abilityResolver, matcher)
    private val damageDetector = DamageTriggerDetector(abilityResolver, matcher)
    private val attachmentDetector = AttachmentTriggerDetector(abilityResolver, matcher)

    /**
     * Build a trigger index for the current game state.
     *
     * Pre-scans all battlefield permanents once, categorizing each entity by the
     * engine event types its triggers respond to. This replaces O(N) battlefield
     * scans per event with O(1) lookups into pre-built buckets.
     *
     * Also pre-computes:
     * - Aura entities indexed by their attachment targets
     * - Grant providers, ward grants, ward suppressors and attachments-by-target, via
     *   [BattlefieldStaticsIndex] — one walk that every per-entity ability resolution reads
     * - Damage observer trigger lists for specialized detection methods
     */
    private fun buildTriggerIndex(state: GameState): TriggerIndex {
        val projected = state.projectedState

        // Phase 1: One walk for every battlefield-wide fact the per-entity ability resolution below
        // needs — the grant providers it already collected, plus the ward grants, ward suppressors
        // and attachments-by-target that each of the N calls used to re-scan for individually
        // (see BattlefieldStaticsIndex).
        val statics = BattlefieldStaticsIndex.build(state, cardRegistry)
        val grantProviders = statics.triggerGrantProviders

        // Phase 2: Index each battlefield entity by trigger categories
        val categoryMap = HashMap<TriggerCategory, MutableList<TriggerIndex.IndexedEntity>>()
        val auraMap = HashMap<EntityId, MutableList<TriggerIndex.IndexedEntity>>()
        val damageToYou = mutableListOf<TriggerIndex.IndexedEntity>()
        val subtypeDmg = mutableListOf<TriggerIndex.IndexedEntity>()
        val damageObs = mutableListOf<TriggerIndex.IndexedEntity>()
        val deathTrackers = mutableListOf<TriggerIndex.IndexedEntity>()

        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val cardComponent = container.get<CardComponent>() ?: continue
            val controllerId = projected.getController(entityId) ?: continue

            // CR 708.2: a face-down permanent has none of the printed card's abilities, so it
            // contributes no triggers of its own — except ward, which disguise and cloak list
            // among the face-down characteristics (CR 702.168a / 701.58a) and which a static
            // ability elsewhere can grant to any creature, face down or not.
            val abilities = if (container.has<FaceDownComponent>()) {
                abilityResolver.getWardTriggeredAbilities(
                    entityId, cardComponent.cardDefinitionId, state, statics
                )
            } else {
                abilityResolver.getTriggeredAbilitiesWithProviders(
                    entityId, cardComponent.cardDefinitionId, state, grantProviders, statics
                )
            }
            if (abilities.isEmpty() && container.get<AttachedToComponent>() == null) continue

            val entry = TriggerIndex.IndexedEntity(entityId, cardComponent, controllerId, abilities)

            // Categorize by event types this entity's triggers respond to
            val entityCategories = mutableSetOf<TriggerCategory>()
            for (ability in abilities) {
                if (Zone.BATTLEFIELD in ability.activeZones) {
                    entityCategories.addAll(TriggerIndex.triggerToCategories(ability.trigger, ability.binding))

                    // Index damage observer triggers
                    val trigger = ability.trigger
                    if (trigger is EventPattern.DealsDamageEvent && ability.binding == TriggerBinding.ANY) {
                        // Every "… deals damage to you" observer goes to the damage-to-you index,
                        // with or without a sourceFilter — `RecipientFilter.You` is unmatchable in
                        // the general observer path (TriggerMatcher.matchesDealsDamageTrigger
                        // returns false for it), so a source-filtered one routed anywhere else
                        // would silently never fire (Farsight Mask).
                        if (trigger.recipient == RecipientFilter.You) {
                            damageToYou.add(entry)
                        } else if (trigger.damageType == DamageType.Combat &&
                            trigger.recipient == RecipientFilter.AnyPlayer &&
                            trigger.sourceFilter != null &&
                            trigger.sourceFilter is GameObjectFilter &&
                            (trigger.sourceFilter as GameObjectFilter).cardPredicates.any {
                                it is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasSubtype
                            }
                        ) {
                            subtypeDmg.add(entry)
                        } else {
                            // General damage observer (e.g., Kazarov, Gossip's Talent level 3)
                            damageObs.add(entry)
                        }
                    }

                    // Index creature-dealt-damage-dies triggers
                    if (trigger is EventPattern.CreatureDealtDamageBySourceDiesEvent) {
                        deathTrackers.add(entry)
                    }
                }
            }
            for (cat in entityCategories) {
                categoryMap.getOrPut(cat) { mutableListOf() }.add(entry)
            }

            // Index auras by attachment target
            val attachedTo = container.get<AttachedToComponent>()?.targetId
            if (attachedTo != null) {
                auraMap.getOrPut(attachedTo) { mutableListOf() }.add(entry)
            }
        }

        // Phase 3: Index cards in the non-battlefield zones whose abilities function from that zone,
        // but only for the batch / observer categories that are consumed exclusively by the dedicated
        // detectors (see TriggerIndex.NON_BATTLEFIELD_BATCH_CATEGORIES). These shapes are skipped
        // by the per-event zone passes (TriggerMatcher returns false for them), so they
        // would otherwise never fire from outside the battlefield. Enables graveyard-active
        // recursion triggers like Killian's Confidence, and the batch-shaped eminence abilities.
        for (zone in NON_BATTLEFIELD_ACTIVE_ZONES) {
            for (playerId in state.turnOrder) {
                for (entityId in state.getZone(playerId, zone)) {
                    val container = state.getEntity(entityId) ?: continue
                    val cardComponent = container.get<CardComponent>() ?: continue
                    val abilities =
                        abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, statics)
                    if (abilities.isEmpty()) continue
                    // The controller of a card outside the battlefield is its owner.
                    val ownerId = cardComponent.ownerId
                        ?: container.get<OwnerComponent>()?.playerId
                        ?: playerId
                    val entry = TriggerIndex.IndexedEntity(entityId, cardComponent, ownerId, abilities)
                    val entityCategories = mutableSetOf<TriggerCategory>()
                    for (ability in abilities) {
                        if (zone !in ability.activeZones) continue
                        for (cat in TriggerIndex.triggerToCategories(ability.trigger, ability.binding)) {
                            if (cat in TriggerIndex.NON_BATTLEFIELD_BATCH_CATEGORIES) entityCategories.add(cat)
                        }
                    }
                    for (cat in entityCategories) {
                        categoryMap.getOrPut(cat) { mutableListOf() }.add(entry)
                    }
                }
            }
        }

        return TriggerIndex(
            byCategory = categoryMap,
            aurasByTarget = auraMap,
            grantProviders = grantProviders,
            statics = statics,
            damageToYouObservers = damageToYou,
            subtypeDamageObservers = subtypeDmg,
            damageObservers = damageObs,
            creatureDamageDeathTrackers = deathTrackers,
        )
    }

    /**
     * Detect all triggers that should fire based on the given events.
     *
     * @param state The current game state
     * @param events The events that occurred
     * @return List of pending triggers in APNAP order
     */
    fun detectTriggers(
        state: GameState,
        events: List<EngineGameEvent>
    ): List<PendingTrigger> = detectUnprocessedTriggers(
        state,
        events.filterNot {
            it is ZoneChangeEvent && it.toZone == Zone.BATTLEFIELD && it.entryTriggersAlreadyProcessed
        },
        contextEvents = events,
    )

    /** Suppress processed causes without erasing their historical object-reference context. */
    private fun detectUnprocessedTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        contextEvents: List<EngineGameEvent>,
    ): List<PendingTrigger> {
        val index = buildTriggerIndex(state)
        val triggers = mutableListOf<PendingTrigger>()

        for ((eventIndex, event) in contextEvents.withIndex()) {
            if (event is ZoneChangeEvent && event.toZone == Zone.BATTLEFIELD &&
                event.entryTriggersAlreadyProcessed) continue
            // DrawEvent firing counts are derived from CardsDrawnThisTurnComponent, which `state`
            // holds at its POST-batch value. When one execution emits several CardsDrawnEvents for
            // the same player, each event needs to know how many of those draws happened after it
            // so the matcher can reconstruct the count as of that event (exceptFirstInDrawStep
            // exemption boundary).
            val samePlayerDrawsLaterInBatch = if (event is CardsDrawnEvent) {
                contextEvents.subList(eventIndex + 1, contextEvents.size)
                    .filterIsInstance<CardsDrawnEvent>()
                    .filter { it.playerId == event.playerId }
                    .sumOf { it.count }
            } else 0
            val detected = detectTriggersForEvent(state, event, index, samePlayerDrawsLaterInBatch)
            triggers.addAll(detected.map { pending ->
                val selfZoneEvent = event is ZoneChangeEvent && event.entityId == pending.sourceId
                val attachedDeparture = selfZoneEvent && pending.ability.binding == TriggerBinding.ATTACHED &&
                    pending.triggerContext.triggeringEntityId != pending.sourceId
                val triggeringZoneEvent = if (event is ZoneChangeEvent && pending.triggerContext.triggeringEntityId == event.entityId) event
                    else if (attachedDeparture) contextEvents.take(eventIndex).filterIsInstance<ZoneChangeEvent>().lastOrNull {
                        it.entityId == pending.triggerContext.triggeringEntityId && it.fromZone == Zone.BATTLEFIELD
                    } else null
                val eventContext = triggeringZoneEvent?.let(TriggerContext::fromEvent) ?: pending.triggerContext
                val sourceEventContext = (event as? ZoneChangeEvent)?.takeIf { selfZoneEvent }?.let(TriggerContext::fromEvent)
                val sourceAtEvent = contextEvents.subList(eventIndex + 1, contextEvents.size)
                    .filterIsInstance<ZoneChangeEvent>().firstOrNull { it.entityId == pending.sourceId }?.oldObject
                    ?: state.objectRef(pending.sourceId)
                pending.copy(triggerContext = eventContext, objectReferences = com.wingedsheep.engine.handlers.ObjectReferenceEnvironment(
                    captured = true,
                    origin = if (selfZoneEvent) sourceEventContext?.triggeringOrigin else sourceAtEvent,
                    // CR 400.7f allows the Aura's immediate graveyard object, including the unattached SBA.
                    source = if (attachedDeparture && (event as ZoneChangeEvent).toZone != Zone.GRAVEYARD)
                        sourceEventContext?.triggeringOrigin
                    else if (selfZoneEvent) sourceEventContext?.triggeringObject else sourceAtEvent,
                    triggering = if (triggeringZoneEvent != null) eventContext.triggeringObject
                    else eventContext.triggeringObject ?: pending.triggerContext.triggeringEntityId?.let { id ->
                        contextEvents.subList(eventIndex + 1, contextEvents.size).filterIsInstance<ZoneChangeEvent>()
                            .firstOrNull { it.entityId == id }?.oldObject ?: state.objectRef(id)
                    },
                ))
            })
        }

        // Rule 603.10: "Look back in time" for simultaneous deaths.
        // When multiple creatures die at the same time (e.g., from Infest),
        // each creature's death triggers should still see the others dying.
        // The main loop in detectTriggersForEvent only checks battlefield creatures,
        // so dead creatures miss each other's death events. Fix that here.
        deathAndLeaveDetector.detectSimultaneousDeathTriggers(state, index.statics, events, triggers)

        // Detect "whenever one or more cards are put into your graveyard from your library"
        // batching triggers (e.g., Sidisi, Brood Tyrant). Groups library→graveyard zone changes
        // and fires the trigger at most once per controller.
        detectLibraryToGraveyardBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more [filtered] cards are put into your graveyard from anywhere"
        // batching triggers (e.g., Moonshadow). Groups all to-graveyard zone changes by owner
        // and fires the trigger at most once per controller.
        detectAnyToGraveyardBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more cards leave your graveyard" batching triggers
        // (e.g., Attuned Hunter, Kishla Skimmer). Groups from-graveyard zone changes by the
        // owner of that graveyard and fires the trigger at most once per controller. The
        // "during your turn" restriction is a triggerRestriction (Conditions.IsYourTurn) on the card.
        detectCardsLeftGraveyardBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more cards are put into exile from graveyards and/or the
        // battlefield" batching triggers (Ketramose, the New Dawn). Unlike the graveyard batches
        // this is not scoped to one player's zones, so it fires once per qualifying source.
        detectCardsPutIntoExileBatchTriggers(state, events, triggers, index)

        // Detect "whenever you sacrifice one or more [permanents]" batching triggers
        // (e.g., Camellia, the Seedmiser). Groups sacrifice events per controller
        // and fires the trigger at most once per controller.
        detectSacrificeBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more [filtered] permanents become tapped" batching triggers
        // (e.g., Deeproot Pilgrimage). Fires the trigger at most once per source regardless of how
        // many matching permanents were tapped simultaneously; the per-event path skips batch taps.
        detectTapBatchTriggers(state, events, triggers, index)

        // Detect "whenever you untap one or more permanents …" batching triggers (e.g. The
        // Millennium Calendar). The untap step untaps all your permanents in one batch; this fires
        // the trigger once for that batch and exposes the untapped permanents so a "that many"
        // payoff can count them. The per-event path skips batch untaps.
        detectUntapBatchTriggers(state, events, triggers, index)

        // Detect "whenever you put one or more counters on one or more [permanents]" batching
        // triggers (CountersPlacedEvent(batch = true), e.g. Invisible Woman, Sue Storm). One effect
        // that puts counters on several permanents emits one CountersAddedEvent per recipient; this
        // fires the trigger once for that batch, not once per recipient. The per-event path skips
        // batch counter placements.
        detectCountersPlacedBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more [creatures] you control deal combat damage to a player"
        // batching triggers (e.g., Kastral, the Windcrested). Groups combat damage events
        // and fires the trigger at most once per observer.
        detectCombatDamageBatchTriggers(state, events, triggers, state.projectedState, index)

        // The initiative's inherent rules are not printed abilities on a permanent. They are
        // synthesized from initiative-taking and combat-damage events, while room entry is its own
        // stack trigger so opponents retain the normal response window.
        detectInitiativeTriggers(state, events, triggers)
        detectUndercityRoomTriggers(events, triggers)

        // Detect recipient-side "whenever one or more [creatures] are dealt [excess] damage"
        // batching triggers (DealsDamageEvent(batch = true), e.g. Magmatic Galleon). Fires the
        // trigger at most once per observer regardless of how many recipients were damaged
        // simultaneously; the per-event observer path skips batch triggers.
        damageDetector.detectDamageObserverBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more creatures you control leave the battlefield without dying"
        // batching triggers (e.g., Dour Port-Mage). Groups zone changes from battlefield to
        // non-graveyard zones and fires the trigger at most once per observer.
        detectLeaveBattlefieldWithoutDyingBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more [other] creatures you control die" batching triggers
        // (e.g., Vengeful Townsfolk). Groups battlefield→graveyard zone changes by each dying
        // creature's last-known controller and fires the trigger at most once per controller —
        // so a board wipe that kills several of a player's creatures fires the trigger once,
        // not once per creature (the over-counting a per-creature death trigger would suffer).
        detectCreaturesDiedBatchTriggers(state, events, triggers, index)

        // Detect "whenever one or more [filtered] permanents you control enter the battlefield"
        // batching triggers (e.g., Builder's Talent). Groups zone changes to battlefield
        // and fires the trigger at most once per observer.
        detectPermanentsEnteredBatchTriggers(state, events, triggers, index)

        // A `ReflexiveTriggerEffect`'s action half completed — turn it into a real CR 603.12
        // reflexive triggered ability instead of resolving it inline. Unconditional: the event
        // itself IS the trigger condition, so this bypasses TriggerIndex/TriggerSpec matching
        // entirely and constructs one PendingTrigger per event directly.
        detectReflexiveTriggers(events, triggers)

        // Detect "When you unlock this door" triggers (CR 709.5h, DSK Rooms).
        // Face-aware: only the unlocked face's "When you unlock this door" abilities fire.
        detectDoorUnlockedTriggers(state, events, triggers)

        // Detect "When this Class becomes level N" triggers.
        // Class level-up events fire ETB triggers from the newly gained class level.
        detectClassLevelUpTriggers(state, events, triggers)

        // Detect Saga chapter triggers from lore counter additions
        detectSagaChapterTriggers(state, events, triggers)

        // Duplicate triggers for "additional time" static abilities (e.g., Naban, Panharmonicon,
        // Gandalf the White). When a permanent matching the filter enters or leaves the
        // battlefield (per the static's directions), triggered abilities on the controller's
        // permanents that fired from that event trigger an additional time per copy.
        duplicateETBOrLTBTriggers(state, events, triggers)

        // Duplicate triggers caused by a creature being declared as an attacker (Windcrag Siege's
        // Mardu mode). The attack-cause analogue of duplicateETBTriggers.
        duplicateAttackTriggers(state, events, triggers)

        // Duplicate death/leave-the-battlefield triggers caused by a creature dying (Teysa Karlov;
        // The Masamune's granted ability). The death-cause analogue of duplicateAttackTriggers.
        duplicateDeathTriggers(state, events, triggers)

        // Duplicate triggers for "all triggers from a filtered source trigger again" static
        // abilities (e.g., Twinflame Travelers). For each pending trigger whose source matches
        // a doubler's filter, add a copy.
        duplicateSourceTriggers(state, triggers)

        // Detect event-based delayed triggers (e.g. Long River Lurker's
        // "whenever that creature deals combat damage this turn, you may exile it").
        detectEventBasedDelayedTriggers(state, events, triggers)

        // Detect evoke sacrifice triggers: when a permanent enters with EvokedComponent,
        // create a "sacrifice self" delayed trigger (CR 702.74)
        detectEvokeSacrificeTriggers(state, events, triggers)

        // Detect the Decayed counter's attack trigger (CR 702.147a): when a creature with a
        // decayed counter is declared as an attacker, it must be sacrificed at end of combat.
        detectDecayedCounterAttackTriggers(state, events, triggers)

        // Torpor Orb family (SuppressEntersTriggers): remove every pending trigger that a
        // matching permanent entering the battlefield caused (CR 603.6 enters-the-battlefield
        // triggers). Runs after all ETB detection paths so it covers the per-permanent, "one or
        // more permanents entered" batch, and duplicated (Panharmonicon) copies uniformly.
        suppressEntersTriggers(state, events, triggers)

        // Filter out once-per-turn triggers that have already fired this turn, and dedupe
        // simultaneous fires (see [capOncePerTurnTriggers]).
        val filteredTriggers = capOncePerTurnTriggers(state, triggers)

        // Rule 603.4: Filter out triggers with unmet intervening-if conditions
        return matcher.sortByApnapOrder(
            state,
            matcher.filterByTriggerCondition(state, assignGranterIds(state, filteredTriggers, contextEvents))
        )
    }

    /**
     * Stamp each granted triggered ability with the permanent that granted it (an Equipment/Aura
     * granting a trigger to the attached creature), so the resolving effect can reference its
     * granter (CR 201.5a) via [com.wingedsheep.engine.handlers.EffectContext.granterId] — e.g. Dire
     * Blunderbuss's "sacrifice an artifact other than Dire Blunderbuss". Applied uniformly to every
     * event-based path (per-event scan plus the batch/duplicate detectors that append directly to
     * the trigger list) and to [detectPhaseStepTriggers], so a granted upkeep/step trigger is
     * covered too — not just the attack-trigger case.
     *
     * When several identical granters are attached to the same creature (two copies of the same
     * Equipment), each fires its own trigger with an identical `abilityId`; a per-`(source, ability)`
     * cursor hands the granting attachments out in index order so the N triggers map 1:1 onto the N
     * granters instead of all collapsing onto the first. Triggers beyond the granter count (e.g. a
     * Panharmonicon-doubled copy) clamp to the last granter, keeping the doubled copy pointed at the
     * same Equipment. Cheap: [TriggerAbilityResolver.resolveGranterIds] is O(1) for the un-attached
     * majority.
     */
    private fun assignGranterIds(
        state: GameState,
        triggers: List<PendingTrigger>,
        events: List<EngineGameEvent> = emptyList(),
    ): List<PendingTrigger> {
        val cursor = HashMap<Pair<EntityId, com.wingedsheep.sdk.scripting.AbilityId>, Int>()
        return triggers.map { unstamped ->
            var trigger = unstamped.copy(sourceBattlefieldTimestamp = unstamped.sourceBattlefieldTimestamp
                ?: unstamped.triggerContext.triggeringBattlefieldTimestamp
                    ?.takeIf { unstamped.triggerContext.triggeringEntityId == unstamped.sourceId }
                ?: state.getEntity(unstamped.sourceId)
                    ?.get<com.wingedsheep.engine.state.components.battlefield.BattlefieldEntryTimestampComponent>()?.timestamp)
            if (!trigger.objectReferences.captured) {
                val triggerContext = trigger.triggerContext
                val selfEvent = triggerContext.triggeringEntityId == trigger.sourceId
                val departure = events.filterIsInstance<ZoneChangeEvent>().firstOrNull {
                    it.entityId == trigger.sourceId && it.fromZone == Zone.BATTLEFIELD &&
                        (trigger.sourceBattlefieldTimestamp == null ||
                            it.lastKnown?.battlefieldEntryTimestamp == trigger.sourceBattlefieldTimestamp)
                }
                val origin = if (selfEvent && triggerContext.triggeringOrigin != null) triggerContext.triggeringOrigin
                    else departure?.oldObject ?: state.objectRef(trigger.sourceId)
                val actionable = if (selfEvent && triggerContext.triggeringObject != null) triggerContext.triggeringObject else origin
                trigger = trigger.copy(objectReferences = com.wingedsheep.engine.handlers.ObjectReferenceEnvironment(
                    captured = true, origin = origin, source = actionable,
                    triggering = triggerContext.triggeringObject ?: triggerContext.triggeringEntityId?.let { id ->
                        events.filterIsInstance<ZoneChangeEvent>().lastOrNull { it.entityId == id }?.newObject
                            ?: state.objectRef(id)
                    },
                ))
            }
            val granters = abilityResolver.resolveGranterIds(state, trigger.sourceId, trigger.ability.id)
            if (granters.isEmpty()) return@map trigger
            val key = trigger.sourceId to trigger.ability.id
            val i = cursor.getOrDefault(key, 0)
            cursor[key] = i + 1
            trigger.copy(granterId = granters.getOrElse(i) { granters.last() })
        }
    }

    /**
     * Filter [triggers] for "this ability triggers only once each turn" (`oncePerTurn`) abilities.
     *
     * Two cuts, in order:
     *  1. Drop any oncePerTurn trigger whose source has already fired that ability id this turn
     *     (tracked by [TriggeredAbilityFiredThisTurnComponent], stamped when the trigger is put on
     *     the stack — `TriggerProcessor.processSingleTrigger` — not when it resolves).
     *  2. Within this single detection pass, keep only the *first* trigger per
     *     `(sourceId, abilityId)` for oncePerTurn abilities. The fired-this-turn tracker is only
     *     written once a detected trigger reaches the processor, so a single multi-subject event
     *     (e.g. a player discarding two cards, which fires a per-card "whenever a player discards"
     *     trigger twice) would otherwise queue two instances from one pass before either is
     *     processed and stamps the tracker. This
     *     dedupe enforces the "only once each turn" cap for batch-style triggers — e.g. Hostile
     *     Investigator investigating once even when several cards are discarded at once.
     *
     * Non-oncePerTurn triggers are never deduped (two lord bonuses, two prowess fires, etc. must
     * all survive).
     */
    private fun capOncePerTurnTriggers(
        state: GameState,
        triggers: List<PendingTrigger>
    ): List<PendingTrigger> {
        val seenCapped = HashSet<Pair<EntityId, com.wingedsheep.sdk.scripting.AbilityId>>()
        return triggers.filter { trigger ->
            val ability = trigger.ability
            // Same capping logic for "once each turn" (per-turn tracker) and "triggers only once"
            // (lifetime tracker): drop if already fired, then collapse simultaneous fires.
            if (!ability.oncePerTurn && !ability.triggersOnce) return@filter true
            val entity = state.getEntity(trigger.sourceId)
            if (ability.oncePerTurn) {
                val tracker = entity?.get<TriggeredAbilityFiredThisTurnComponent>()
                if (tracker != null && tracker.hasFired(ability.id)) return@filter false
            }
            if (ability.triggersOnce) {
                val everTracker = entity?.get<TriggeredAbilityFiredEverComponent>()
                if (everTracker != null && everTracker.hasFired(ability.id)) return@filter false
            }
            // Collapse simultaneous fires of the same ability from the same source.
            seenCapped.add(trigger.sourceId to ability.id)
        }
    }

    /**
     * Initiative inherent triggers: taking the initiative ventures, and combat damage to the holder
     * transfers the initiative to each qualifying damage-source controller.
     */
    private fun detectInitiativeTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        for (event in events.filterIsInstance<InitiativeTakenEvent>()) {
            triggers.add(
                InitiativeTriggers.venture(
                    event.playerId,
                    "Whenever you take the initiative, venture into Undercity"
                )
            )
        }

        val holder = state.turnOrder.firstOrNull { playerId ->
            state.getEntity(playerId)?.has<PlayerInitiativeComponent>() == true
        } ?: return

        val takers = linkedSetOf<EntityId>()
        for (event in events.filterIsInstance<DamageDealtEvent>()) {
            if (!event.isCombatDamage || event.targetId != holder || event.sourceId == null) continue
            val source = state.getEntity(event.sourceId) ?: continue
            val card = source.get<CardComponent>() ?: continue
            if (!card.typeLine.isCreature) continue
            val controller = source.get<ControllerComponent>()?.playerId
                ?: source.get<OwnerComponent>()?.playerId
                ?: card.ownerId
                ?: continue
            if (controller != holder &&
                state.getEntity(controller)?.has<com.wingedsheep.engine.state.components.player.PlayerLostComponent>() != true
            ) {
                takers.add(controller)
            }
        }
        for (playerId in takers) {
            triggers.add(InitiativeTriggers.take(playerId))
        }
    }

    /** Turn a room-entry signal into that room's triggered ability on the stack. */
    private fun detectUndercityRoomTriggers(
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        for (event in events.filterIsInstance<UndercityRoomEnteredEvent>()) {
            triggers.add(InitiativeTriggers.room(event.playerId, event.room))
        }
    }

    /**
     * Detect delayed triggers that should fire at the given step.
     * Returns the pending triggers and the IDs of consumed delayed triggers.
     */
    fun detectDelayedTriggers(state: GameState, step: Step): Pair<List<PendingTrigger>, Set<String>> {
        val matching = state.delayedTriggers.filter { delayed ->
            delayed.trigger == null &&
                delayed.fireAtStep == step &&
                // "your next end step" is the team's in a shared team turn (CR 805.4) — the
                // non-representative head is never `activePlayerId`, so equality would strand
                // every one of their step-keyed delayed triggers.
                (delayed.fireOnPlayerId == null || state.isActiveTurnFor(delayed.fireOnPlayerId)) &&
                (delayed.notBeforeTurn == null || state.turnNumber >= delayed.notBeforeTurn)
        }
        if (matching.isEmpty()) return emptyList<PendingTrigger>() to emptySet()

        val triggers = matching.map { delayed ->
            PendingTrigger(
                ability = TriggeredAbility.create(
                    trigger = EventPattern.StepEvent(Step.END, Player.Each),
                    binding = TriggerBinding.ANY,
                    effect = delayed.effect,
                    targetRequirement = delayed.targetRequirement,
                    additionalTargetRequirements = delayed.additionalTargetRequirements
                ),
                sourceId = delayed.sourceId,
                objectReferences = delayed.objectReferences.copy(captured = true),
                sourceName = delayed.sourceName,
                controllerId = delayed.controllerId,
                triggerContext = TriggerContext(
                    step = step,
                    triggeringEntityId = delayed.fireOnPlayerId,
                    triggeringPlayerId = delayed.fireOnPlayerId
                )
            )
        }
        val consumedIds = matching.filterNot { it.repeatAtEachMatchingStep }.map { it.id }.toSet()
        return matcher.sortByApnapOrder(state, triggers) to consumedIds
    }

    /**
     * Detect triggers for phase/step changes.
     * Uses trigger index to only check entities with step-based triggers.
     */
    fun detectPhaseStepTriggers(
        state: GameState,
        step: Step,
        activePlayerId: EntityId
    ): List<PendingTrigger> {
        val index = buildTriggerIndex(state)
        val triggers = mutableListOf<PendingTrigger>()
        val projected = state.projectedState

        // Check battlefield entities with StepEvent triggers
        for (entry in index.getEntitiesForCategory(TriggerCategory.STEP)) {
            for (ability in entry.abilities) {
                if (Zone.BATTLEFIELD !in ability.activeZones) continue
                if (matcher.matchesStepTrigger(ability.trigger, step, entry.controllerId, state, entry.entityId)) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = entry.entityId,
                            sourceName = entry.cardComponent.name,
                            controllerId = entry.controllerId,
                            triggerContext = TriggerContext(step = step, triggeringEntityId = activePlayerId)
                        )
                    )
                }
            }
        }

        // Check ATTACHED step triggers on auras (e.g., Custody Battle, Lingering Death)
        // For ATTACHED + StepEvent(Player.You), "you" = the attached creature's controller
        for ((targetId, attachments) in index.aurasByTarget) {
            val enchantedController = projected.getController(targetId) ?: continue
            for (entry in attachments) {
                for (ability in entry.abilities) {
                    if (ability.binding != TriggerBinding.ATTACHED) continue
                    if (Zone.BATTLEFIELD !in ability.activeZones) continue
                    val trigger = ability.trigger as? EventPattern.StepEvent ?: continue
                    if (step != trigger.step) continue
                    if (matcher.matchesPlayerForStep(trigger.player, enchantedController, state)) {
                        triggers.add(
                            PendingTrigger(
                                ability = ability,
                                sourceId = entry.entityId,
                                sourceName = entry.cardComponent.name,
                                controllerId = enchantedController,
                                triggerContext = TriggerContext(step = step, triggeringEntityId = activePlayerId)
                            )
                        )
                    }
                }
            }
        }

        // Check the non-battlefield zones a card's abilities can function from for step-based
        // triggers (CR 113.6b). Graveyard: Gigapede's upkeep return. Exile: suspend's countdown,
        // paradigm's main-phase offer. Command zone: an *eminence* ability worded as a step trigger
        // (Arahbo, Roar of the World's beginning-of-combat pump).
        //
        // Cards in all three are owned rather than controlled, so the owner is the controller of
        // any ability they produce.
        for (zone in NON_BATTLEFIELD_ACTIVE_ZONES) {
            for (playerId in state.turnOrder) {
                for (entityId in state.getZone(playerId, zone)) {
                    val container = state.getEntity(entityId) ?: continue
                    val cardComponent = container.get<CardComponent>() ?: continue

                    val abilities = abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, index.statics)

                    for (ability in abilities) {
                        if (zone !in ability.activeZones) continue
                        val ownerId = cardComponent.ownerId
                            ?: container.get<OwnerComponent>()?.playerId
                            ?: continue
                        if (matcher.matchesStepTrigger(ability.trigger, step, ownerId, state, entityId)) {
                            triggers.add(
                                PendingTrigger(
                                    ability = ability,
                                    sourceId = entityId,
                                    sourceName = cardComponent.name,
                                    controllerId = ownerId,
                                    triggerContext = TriggerContext(step = step, triggeringEntityId = activePlayerId)
                                )
                            )
                        }
                    }
                }
            }
        }

        // Check global granted triggered abilities for step-based triggers
        // (e.g., Dimensional Breach creates a permanent global upkeep trigger)
        for (global in state.globalGrantedTriggeredAbilities) {
            val ability = global.ability
            if (matcher.matchesStepTrigger(ability.trigger, step, global.controllerId, state, global.sourceId)) {
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = global.sourceId,
                        sourceName = global.sourceName,
                        controllerId = global.controllerId,
                        triggerContext = TriggerContext(step = step, triggeringEntityId = activePlayerId)
                    )
                )
            }
        }

        // The player who has the initiative ventures into Undercity at the beginning of their upkeep.
        if (step == Step.UPKEEP &&
            state.getEntity(activePlayerId)?.has<PlayerInitiativeComponent>() == true
        ) {
            triggers.add(
                InitiativeTriggers.venture(
                    activePlayerId,
                    "At the beginning of your upkeep, venture into Undercity"
                )
            )
        }

        // Duplicate triggers for "all triggers from a filtered source trigger again" static
        // abilities (e.g., Twinflame Travelers) — also applies to phase/step triggers.
        duplicateSourceTriggers(state, triggers)

        // Filter out once-per-turn triggers that have already fired this turn, and dedupe
        // simultaneous fires (see [capOncePerTurnTriggers]).
        val filteredTriggers = capOncePerTurnTriggers(state, triggers)

        // Rule 603.4: Filter out triggers with unmet intervening-if conditions
        return matcher.sortByApnapOrder(
            state,
            matcher.filterByTriggerCondition(state, assignGranterIds(state, filteredTriggers))
        )
    }

    /**
     * Detect event-based delayed triggered abilities scoped to a watched entity.
     *
     * Unlike step-based delayed triggers, event-based ones are NOT consumed on fire —
     * they may fire multiple times before expiry (e.g., double strike combat damage).
     * They are removed only by their [DelayedTriggerExpiry] (e.g., end of turn cleanup).
     */
    /**
     * When a permanent enters the battlefield with EvokedComponent, create a "sacrifice self"
     * trigger that goes on the stack as a separate triggered ability (CR 702.74).
     * The ETB triggers and the sacrifice trigger are siblings on the stack — the player
     * can respond between them.
     */
    private fun detectEvokeSacrificeTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        val etbEvents = events.filterIsInstance<ZoneChangeEvent>().filter { it.toZone == Zone.BATTLEFIELD }
        for (event in etbEvents) {
            val entity = state.getEntity(event.entityId) ?: continue
            if (!entity.has<com.wingedsheep.engine.state.components.battlefield.EvokedComponent>()) continue
            val cardComponent = entity.get<CardComponent>() ?: continue
            val controllerId = entity.get<ControllerComponent>()?.playerId ?: event.ownerId

            // Create a sacrifice-self trigger
            val sacrificeAbility = TriggeredAbility.create(
                trigger = com.wingedsheep.sdk.scripting.EventPattern.ZoneChangeEvent(to = Zone.BATTLEFIELD),
                binding = TriggerBinding.SELF,
                effect = com.wingedsheep.sdk.dsl.Effects.SacrificeTarget(
                    com.wingedsheep.sdk.scripting.targets.EffectTarget.Self
                ),
                // The name is interpolated into the text, so the mask has to be applied here —
                // masking AbilityTriggeredEvent.sourceName downstream would leave it in the
                // description. Evoke can't apply to a face-down cast today; Decayed below can.
                descriptionOverride =
                    "Evoke — Sacrifice ${nameVisibleToAll(state, event.entityId, cardComponent.name)}"
            )
            triggers.add(
                PendingTrigger(
                    ability = sacrificeAbility,
                    sourceId = event.entityId,
                    sourceName = cardComponent.name,
                    controllerId = controllerId,
                    triggerContext = TriggerContext(triggeringEntityId = event.entityId)
                )
            )
        }
    }

    /**
     * CR 702.147a — Decayed's triggered half, driven by a decayed counter rather than a printed
     * ability. When a creature with one or more decayed counters is declared as an attacker, fire
     * an attack-triggered ability that schedules a "sacrifice it at end of combat" delayed trigger
     * (via [CreateDelayedTriggerEffect], step [Step.END_COMBAT]) — the exact composition the
     * printed `card { decayed() }` helper uses. The "can't block" static half is handled in
     * projection ([StateProjector]).
     */
    private fun detectDecayedCounterAttackTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        val declaredAttackers = events.filterIsInstance<AttackersDeclaredEvent>()
            .flatMap { it.attackers }
            .distinct()
        for (attackerId in declaredAttackers) {
            val entity = state.getEntity(attackerId) ?: continue
            val counters = entity.get<CountersComponent>() ?: continue
            if (counters.getCount(com.wingedsheep.sdk.core.CounterType.DECAYED) <= 0) continue
            val cardComponent = entity.get<CardComponent>() ?: continue
            val controllerId = entity.get<com.wingedsheep.engine.state.components.identity.ControllerComponent>()
                ?.playerId ?: continue

            val sacrificeAtEndOfCombat = TriggeredAbility.create(
                trigger = com.wingedsheep.sdk.scripting.EventPattern.AttackEvent(),
                binding = TriggerBinding.SELF,
                effect = com.wingedsheep.sdk.scripting.effects.CreateDelayedTriggerEffect(
                    step = Step.END_COMBAT,
                    effect = com.wingedsheep.sdk.dsl.Effects.SacrificeTarget(
                        com.wingedsheep.sdk.scripting.targets.EffectTarget.Self
                    )
                ),
                descriptionOverride = "Decayed — When " +
                    "${nameVisibleToAll(state, attackerId, cardComponent.name)} attacks, " +
                    "sacrifice it at end of combat."
            )
            triggers.add(
                PendingTrigger(
                    ability = sacrificeAtEndOfCombat,
                    sourceId = attackerId,
                    sourceName = cardComponent.name,
                    controllerId = controllerId,
                    triggerContext = TriggerContext(triggeringEntityId = attackerId)
                )
            )
        }
    }

    /**
     * Torpor Orb family ([com.wingedsheep.sdk.scripting.SuppressEntersTriggers]): strip every
     * pending trigger that a *matching permanent entering the battlefield* caused.
     *
     * Per Torpor Orb's Gatherer rulings this suppresses both the entering permanent's own
     * enters-the-battlefield triggers and any other permanent's "whenever a [...] enters" trigger
     * whose triggering object is that permanent — the gate is whether the entering object matches a
     * [SuppressEntersTriggers.filter] in projected state (continuous effects apply), not what the
     * watching trigger's text names. Replacement effects (enters with counters/tapped) and
     * "as it enters" choices are untouched because they never become [PendingTrigger]s.
     *
     * Operates as a final filter over the already-detected batch, so it covers the per-permanent
     * ETB path ([detectTriggersForEvent]), the "one or more permanents entered" batch path
     * ([detectPermanentsEnteredBatchTriggers]), and the Panharmonicon-style duplicates uniformly.
     */
    private fun suppressEntersTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        if (triggers.isEmpty()) return

        // Which permanents entered the battlefield in this batch.
        val enteredIds = events.asSequence()
            .filterIsInstance<ZoneChangeEvent>()
            .filter { it.toZone == Zone.BATTLEFIELD }
            .map { it.entityId }
            .toSet()
        if (enteredIds.isEmpty()) return

        // Active suppressors (filter + the granting permanent's projected controller, which is the
        // reference player for the filter's controller predicate so `youControl()` scopes correctly).
        val projected = state.projectedState
        data class Suppressor(val filter: GameObjectFilter, val controllerId: EntityId)
        val suppressors = mutableListOf<Suppressor>()
        for (permanentId in state.getBattlefield()) {
            val container = state.getEntity(permanentId) ?: continue
            if (container.has<FaceDownComponent>()) continue
            val cardDef = container.get<CardComponent>()
                ?.let { cardRegistry.getCard(it.cardDefinitionId) } ?: continue
            for (ability in cardDef.script.staticAbilities) {
                if (ability is SuppressEntersTriggers) {
                    val controller = projected.getController(permanentId)
                        ?: container.get<ControllerComponent>()?.playerId ?: continue
                    suppressors.add(Suppressor(ability.filter, controller))
                }
            }
        }
        if (suppressors.isEmpty()) return

        // An entered permanent whose entry is suppressed by at least one active suppressor.
        val suppressionCache = HashMap<EntityId, Boolean>()
        fun isSuppressed(entityId: EntityId): Boolean {
            if (entityId !in enteredIds) return false
            return suppressionCache.getOrPut(entityId) {
                suppressors.any { s ->
                    predicateEvaluator.matches(
                        state, projected, entityId, s.filter,
                        PredicateContext(controllerId = s.controllerId)
                    )
                }
            }
        }

        // Whether an ability's trigger is an enters-the-battlefield shape (the only triggers an
        // entry causes); leaves/attack/etc. triggers are never suppressed even if their context
        // entity happens to have entered this batch.
        fun isEntersTrigger(trigger: com.wingedsheep.sdk.scripting.EventPattern): Boolean = when (trigger) {
            is com.wingedsheep.sdk.scripting.EventPattern.ZoneChangeEvent -> trigger.to == Zone.BATTLEFIELD
            is com.wingedsheep.sdk.scripting.EventPattern.PermanentsEnteredEvent -> true
            else -> false
        }

        val iterator = triggers.listIterator()
        while (iterator.hasNext()) {
            val trigger = iterator.next()
            if (!isEntersTrigger(trigger.ability.trigger)) continue
            val ctx = trigger.triggerContext
            val captured = ctx.capturedEntityIds
            if (captured != null) {
                // Batch trigger: strip the suppressed entries; drop the whole trigger if none
                // of the permanents that caused it survive.
                val survivors = captured.filterNot { isSuppressed(it) }
                when {
                    survivors.isEmpty() -> iterator.remove()
                    survivors.size != captured.size ->
                        iterator.set(trigger.copy(triggerContext = ctx.copy(capturedEntityIds = survivors)))
                }
            } else {
                val triggeringId = ctx.triggeringEntityId ?: trigger.sourceId
                if (isSuppressed(triggeringId)) iterator.remove()
            }
        }
    }

    private fun detectEventBasedDelayedTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        val eventBased = state.delayedTriggers.filter { it.trigger != null }
        if (eventBased.isEmpty()) return

        // A one-shot delayed trigger ([DelayedTriggeredAbility.fireOnce]) must fire at most
        // once even if several events in this batch match it — track which ids have already
        // produced a pending trigger this pass.
        val firedOnceIds = mutableSetOf<String>()
        for ((eventIndex, event) in events.withIndex()) {
            for (delayed in eventBased) {
                fun referencesFor(id: EntityId?): com.wingedsheep.engine.handlers.ObjectReferenceEnvironment {
                    val triggering = if (event is ZoneChangeEvent && event.entityId == id)
                        TriggerContext.fromEvent(event).triggeringObject
                    else id?.let { entity -> events.drop(eventIndex + 1).filterIsInstance<ZoneChangeEvent>()
                        .firstOrNull { it.entityId == entity }?.oldObject ?: state.objectRef(entity) }
                    return delayed.objectReferences.copy(captured = true, triggering = triggering)
                }
                if (delayed.fireOnce && delayed.id in firedOnceIds) continue
                val spec = delayed.trigger ?: continue
                if (!matchesEventForWatchedEntity(spec, event, delayed.watchedEntityId, delayed.watchedRecipientId, delayed.id, delayed.sourceId, delayed.controllerId, state)) continue

                // A filter-scoped attack delayed trigger ("this turn, whenever a creature you control
                // attacks alone, do X to it" — The Last Ronin III) must fan out one trigger per
                // declared attacker so EffectTarget.TriggeringEntity resolves to each attacker.
                // AttackersDeclaredEvent carries no single triggering entity (fromEvent returns none),
                // so mirror the non-delayed per-attacker path (Rule 603.2c).
                val specEvent = spec.event
                if (specEvent is com.wingedsheep.sdk.scripting.EventPattern.AttackEvent &&
                    event is AttackersDeclaredEvent && delayed.watchedEntityId == null
                ) {
                    val attackFilter = specEvent.filter
                    for (attackerId in event.attackers) {
                        if (attackFilter != null && !predicateEvaluator.matches(
                                state, state.projectedState, attackerId, attackFilter,
                                PredicateContext(controllerId = delayed.controllerId, sourceId = delayed.sourceId)
                            )
                        ) continue
                        if (delayed.fireOnce && delayed.id in firedOnceIds) continue
                        if (delayed.fireOnce) firedOnceIds.add(delayed.id)
                        triggers.add(
                            PendingTrigger(
                                ability = TriggeredAbility.create(
                                    trigger = spec.event,
                                    binding = spec.binding,
                                    effect = delayed.effect,
                                    targetRequirement = delayed.targetRequirement,
                                    additionalTargetRequirements = delayed.additionalTargetRequirements
                                ),
                                sourceId = delayed.sourceId,
                objectReferences = referencesFor(attackerId),
                                sourceName = delayed.sourceName,
                                controllerId = delayed.controllerId,
                                triggerContext = TriggerContext.fromEvent(event).copy(triggeringEntityId = attackerId),
                                consumesDelayedTriggerId = if (delayed.fireOnce) delayed.id else null
                            )
                        )
                    }
                    continue
                }

                // "…whenever this creature blocks or becomes blocked by a creature this combat, that
                // creature gains first strike" (Goblin Flotilla). Like the battlefield-resident
                // form, this fans out one trigger per combat partner so `TriggeringEntity` names
                // the *partner* — the creature the rider actually acts on — rather than the watched
                // creature itself.
                if (specEvent is com.wingedsheep.sdk.scripting.EventPattern.BlocksOrBecomesBlockedByEvent &&
                    event is com.wingedsheep.engine.core.BlockersDeclaredEvent &&
                    delayed.watchedEntityId != null
                ) {
                    val watched = delayed.watchedEntityId
                    val partners = mutableListOf<EntityId>()
                    event.blockers[watched]?.let { partners.addAll(it) }
                    for ((blockerId, attackerIds) in event.blockers) {
                        if (attackerIds.contains(watched)) partners.add(blockerId)
                    }
                    for (partnerId in partners.distinct()) {
                        val partnerFilter = specEvent.partnerFilter
                        if (partnerFilter != null && !predicateEvaluator.matches(
                                state, state.projectedState, partnerId, partnerFilter,
                                PredicateContext(controllerId = delayed.controllerId, sourceId = delayed.sourceId)
                            )
                        ) continue
                        if (delayed.fireOnce && delayed.id in firedOnceIds) continue
                        if (delayed.fireOnce) firedOnceIds.add(delayed.id)
                        triggers.add(
                            PendingTrigger(
                                ability = TriggeredAbility.create(
                                    trigger = spec.event,
                                    binding = spec.binding,
                                    effect = delayed.effect,
                                    targetRequirement = delayed.targetRequirement,
                                    additionalTargetRequirements = delayed.additionalTargetRequirements
                                ),
                                sourceId = delayed.sourceId,
                objectReferences = referencesFor(partnerId),
                                sourceName = delayed.sourceName,
                                controllerId = delayed.controllerId,
                                triggerContext = TriggerContext(triggeringEntityId = partnerId),
                                consumesDelayedTriggerId = if (delayed.fireOnce) delayed.id else null
                            )
                        )
                    }
                    continue
                }

                if (delayed.fireOnce) firedOnceIds.add(delayed.id)
                triggers.add(
                    PendingTrigger(
                        ability = TriggeredAbility.create(
                            trigger = spec.event,
                            binding = spec.binding,
                            effect = delayed.effect,
                            targetRequirement = delayed.targetRequirement,
                            additionalTargetRequirements = delayed.additionalTargetRequirements
                        ),
                        sourceId = delayed.sourceId,
                objectReferences = referencesFor(delayed.watchedEntityId ?: TriggerContext.fromEvent(event).triggeringEntityId),
                        sourceName = delayed.sourceName,
                        controllerId = delayed.controllerId,
                        triggerContext = TriggerContext.fromEvent(event).copy(
                            triggeringEntityId = delayed.watchedEntityId
                                ?: TriggerContext.fromEvent(event).triggeringEntityId
                        ),
                        consumesDelayedTriggerId = if (delayed.fireOnce) delayed.id else null
                    )
                )
            }
        }
    }

    /**
     * Match an event against a delayed-trigger TriggerSpec.
     *
     * Two scoping modes:
     *  - **Entity-scoped** (`watchedEntityId != null`): the trigger watches one concrete entity —
     *    DealsDamageEvent (scoped on damage source) and ZoneChangeEvent ("when *that* creature dies
     *    this turn"). The spec's GameObjectFilter is not applied; the watched entity is the scope.
     *  - **Filter-scoped** (`watchedEntityId == null`): the trigger watches a *group* described by
     *    the spec's GameObjectFilter + TriggerBinding — the attack-declaration events ("when you next
     *    attack this turn") and ZoneChangeEvent ("whenever a creature you control enters this turn").
     *    These delegate to the shared [TriggerMatcher] so they behave identically to battlefield
     *    triggers, honoring the filter (including its controller predicate) and binding.
     */
    private fun matchesEventForWatchedEntity(
        spec: com.wingedsheep.sdk.scripting.TriggerSpec,
        event: EngineGameEvent,
        watchedEntityId: EntityId?,
        watchedRecipientId: EntityId?,
        delayedId: String,
        sourceId: EntityId,
        controllerId: EntityId,
        state: GameState
    ): Boolean {
        val specEvent = spec.event
        return when (specEvent) {
            // Attack-declaration triggers are player-/filter-scoped, not entity-scoped, so they
            // reuse the canonical matcher rather than the watched-entity narrowing above.
            // Powers "when you next attack this turn, …" (YouAttackEvent) and the general
            // "when a [filtered] creature next attacks" (AttackEvent).
            is com.wingedsheep.sdk.scripting.EventPattern.YouAttackEvent,
            is com.wingedsheep.sdk.scripting.EventPattern.AttackEvent ->
                matcher.matchesTrigger(specEvent, spec.binding, event, sourceId, controllerId, state)
            // Spell-cast delayed triggers ("whenever you cast a [filtered] spell this turn, …",
            // Rediscover the Way chapter III) are filter-scoped: delegate to the canonical
            // spell-cast matcher so the spell filter and casting-player predicate are honored.
            is com.wingedsheep.sdk.scripting.EventPattern.SpellCastEvent ->
                matcher.matchesTrigger(specEvent, spec.binding, event, sourceId, controllerId, state)
            // Ability-activation delayed triggers ("when you next activate an exhaust ability that
            // isn't a mana ability this turn, …", Pit Automaton) are player-scoped, not
            // entity-scoped: there is no watched permanent, so delegate to the canonical matcher so
            // the player scope and the exhaust / mana-ability clauses behave identically to a
            // battlefield-resident "whenever you activate …" trigger.
            is com.wingedsheep.sdk.scripting.EventPattern.AbilityActivatedEvent ->
                matcher.matchesTrigger(specEvent, spec.binding, event, sourceId, controllerId, state)
            is com.wingedsheep.sdk.scripting.EventPattern.DealsDamageEvent -> {
                if (event !is com.wingedsheep.engine.core.DamageDealtEvent) return false
                if (watchedEntityId != null && event.sourceId != watchedEntityId) return false
                // Recipient-scoped ("…to *that player* this turn"): the damaged entity must be
                // the baked recipient. The spec's recipient filter still applies on top.
                if (watchedRecipientId != null && event.targetId != watchedRecipientId) return false
                matcher.matchesDealsDamageTrigger(specEvent, event, state, controllerId)
            }
            // "When damage is prevented this way": fires only for this delayed trigger's own
            // shield, matched by the linkId echoed back on the DamagePreventedEvent.
            is com.wingedsheep.sdk.scripting.EventPattern.DamagePreventedEvent -> {
                event is com.wingedsheep.engine.core.DamagePreventedEvent && event.linkId == delayedId
            }
            // "When you play a card this way": fires only for the may-play permission that this
            // delayed trigger is linked to, matched by the linkId echoed on the event.
            is com.wingedsheep.sdk.scripting.EventPattern.CardPlayedFromPermissionEvent -> {
                event is com.wingedsheep.engine.core.CardPlayedFromPermissionEvent && event.linkId == delayedId
            }
            is com.wingedsheep.sdk.scripting.EventPattern.ZoneChangeEvent -> {
                if (event !is ZoneChangeEvent) return false
                if (watchedEntityId != null) {
                    // Entity-scoped: "when *that* creature dies/leaves this turn". The watched
                    // entity already narrows the trigger, so we only check the zone transition —
                    // the spec's GameObjectFilter does not apply.
                    if (event.entityId != watchedEntityId) return false
                    if (specEvent.from != null && event.fromZone != specEvent.from) return false
                    if (specEvent.to != null && event.toZone != specEvent.to) return false
                    if (specEvent.excludeTo != null && event.toZone == specEvent.excludeTo) return false
                    true
                } else {
                    // Filter-scoped: "whenever a creature you control enters this turn". There is no
                    // single watched entity, so the spec's GameObjectFilter and TriggerBinding are
                    // what scope the trigger. Delegate to the canonical zone-change matcher so it
                    // behaves identically to a battlefield-resident "whenever a [filtered] permanent
                    // enters/leaves" trigger (Thunder of Unity chapters II/III).
                    matcher.matchesZoneChangeTrigger(specEvent, spec.binding, event, sourceId, controllerId, state)
                }
            }
            // Entity-scoped control-change delayed trigger ("when you lose control of *that*
            // permanent this turn", Stolen Uniform). The watched entity is the permanent; the
            // [com.wingedsheep.sdk.scripting.ControlChangeDirection] selects which side of the
            // change relative to this trigger's controller:
            //  - LOST: fires when the *old* controller was this trigger's controller.
            //  - GAINED: fires when the *new* controller is this trigger's controller.
            is com.wingedsheep.sdk.scripting.EventPattern.ControlChangeEvent -> {
                if (event !is com.wingedsheep.engine.core.ControlChangedEvent) return false
                if (event.oldControllerId == event.newControllerId) return false
                if (watchedEntityId != null && event.permanentId != watchedEntityId) return false
                when (specEvent.direction) {
                    com.wingedsheep.sdk.scripting.ControlChangeDirection.LOST ->
                        event.oldControllerId == controllerId
                    com.wingedsheep.sdk.scripting.ControlChangeDirection.GAINED ->
                        event.newControllerId == controllerId
                }
            }
            // Goblin Flotilla's "this combat" rider. Entity-scoped: the watched creature must be
            // in combat with somebody; which partners it fired for is decided by the fan-out above.
            is com.wingedsheep.sdk.scripting.EventPattern.BlocksOrBecomesBlockedByEvent -> {
                if (event !is com.wingedsheep.engine.core.BlockersDeclaredEvent) return false
                val watched = watchedEntityId ?: return false
                event.blockers.containsKey(watched) || event.blockers.values.any { it.contains(watched) }
            }
            // "This turn, when target creature you control attacks and isn't blocked, …" — the
            // Fallen Empires Delif's artifacts. Entity-scoped: the watched creature is the one
            // whose unblocked attack the delayed trigger is waiting for, so the CR 509.3g test
            // runs against it rather than against the artifact that created the trigger.
            is com.wingedsheep.sdk.scripting.EventPattern.BecomesUnblockedEvent -> {
                if (event !is com.wingedsheep.engine.core.BlockersDeclaredEvent) return false
                val watched = watchedEntityId ?: return false
                val isAttacking = state.getEntity(watched)
                    ?.get<com.wingedsheep.engine.state.components.combat.AttackingComponent>() != null
                isAttacking && event.blockers.values.none { it.contains(watched) }
            }
            else -> false
        }
    }

    private fun detectTriggersForEvent(
        state: GameState,
        event: EngineGameEvent,
        index: TriggerIndex,
        samePlayerDrawsLaterInBatch: Int = 0
    ): List<PendingTrigger> {
        val triggers = mutableListOf<PendingTrigger>()
        val projected = state.projectedState

        // Check only battlefield permanents with triggers relevant to this event type
        for (entry in index.getEntitiesForEvent(event)) {
            val entityId = entry.entityId
            val cardComponent = entry.cardComponent
            val controllerId = entry.controllerId

            for (ability in entry.abilities) {
                if (Zone.BATTLEFIELD !in ability.activeZones) continue
                if (isGraveyardToHandSelfTrigger(ability, event, entityId)) continue
                if (matcher.matchesTrigger(ability.trigger, ability.binding, event, entityId, controllerId, state)) {
                    // For "whenever a creature attacks" (AttackEvent with ANY binding),
                    // create one trigger per attacking creature (Rule 603.2c)
                    if (ability.trigger is EventPattern.AttackEvent && ability.binding == TriggerBinding.ANY &&
                        event is AttackersDeclaredEvent) {
                        val attackFilter = (ability.trigger as EventPattern.AttackEvent).filter
                        for (attackerId in event.attackers) {
                            if (attackFilter != null) {
                                // Filtered trigger: match creature against filter (includes controller predicate)
                                if (predicateEvaluator.matches(
                                        state, projected, attackerId, attackFilter,
                                        PredicateContext(controllerId = controllerId, sourceId = entityId)
                                    )) {
                                    triggers.add(
                                        PendingTrigger(
                                            ability = ability,
                                            sourceId = entityId,
                                            sourceName = cardComponent.name,
                                            controllerId = controllerId,
                                            triggerContext = TriggerContext(triggeringEntityId = attackerId)
                                        )
                                    )
                                }
                            } else {
                                // Unfiltered trigger: any creature attacking
                                triggers.add(
                                    PendingTrigger(
                                        ability = ability,
                                        sourceId = entityId,
                                        sourceName = cardComponent.name,
                                        controllerId = controllerId,
                                        triggerContext = TriggerContext(triggeringEntityId = attackerId)
                                    )
                                )
                            }
                        }
                    }
                    // For "whenever a creature you control becomes blocked" (BecomesBlockedEvent with ANY binding),
                    // create one trigger per blocked creature controlled by the ability's controller.
                    // If a filter is set (e.g., "whenever a Beast becomes blocked"), match any blocked
                    // creature matching the filter regardless of controller.
                    else if (ability.trigger is EventPattern.BecomesBlockedEvent && ability.binding == TriggerBinding.ANY &&
                        event is com.wingedsheep.engine.core.BlockersDeclaredEvent) {
                        val trigger = ability.trigger as EventPattern.BecomesBlockedEvent
                        val creatureFilter = trigger.filter
                        val blockedAttackers = event.blockers.values.flatten().distinct()
                        for (attackerId in blockedAttackers) {
                            if (creatureFilter != null) {
                                // Filtered trigger: match any creature matching the filter (any controller)
                                if (predicateEvaluator.matches(state, projected, attackerId, creatureFilter, PredicateContext(controllerId = controllerId, sourceId = entityId))) {
                                    triggers.add(
                                        PendingTrigger(
                                            ability = ability,
                                            sourceId = entityId,
                                            sourceName = cardComponent.name,
                                            controllerId = controllerId,
                                            triggerContext = TriggerContext(triggeringEntityId = attackerId)
                                        )
                                    )
                                }
                            } else {
                                // Unfiltered trigger: only creatures controlled by the ability's controller
                                val attackerController = projected.getController(attackerId)
                                if (attackerController == controllerId) {
                                    triggers.add(
                                        PendingTrigger(
                                            ability = ability,
                                            sourceId = entityId,
                                            sourceName = cardComponent.name,
                                            controllerId = controllerId,
                                            triggerContext = TriggerContext(triggeringEntityId = attackerId)
                                        )
                                    )
                                }
                            }
                        }
                    }
                    // For "whenever a creature [you control] blocks" (BlockEvent with ANY binding),
                    // create one trigger per matching blocker.
                    else if (ability.trigger is EventPattern.BlockEvent && ability.binding == TriggerBinding.ANY &&
                        event is com.wingedsheep.engine.core.BlockersDeclaredEvent) {
                        val blockFilter = (ability.trigger as EventPattern.BlockEvent).filter
                        for (blockerId in event.blockers.keys) {
                            if (blockFilter != null) {
                                if (predicateEvaluator.matches(
                                        state, projected, blockerId, blockFilter,
                                        PredicateContext(controllerId = controllerId, sourceId = entityId)
                                    )) {
                                    triggers.add(
                                        PendingTrigger(
                                            ability = ability,
                                            sourceId = entityId,
                                            sourceName = cardComponent.name,
                                            controllerId = controllerId,
                                            triggerContext = TriggerContext(triggeringEntityId = blockerId)
                                        )
                                    )
                                }
                            } else {
                                triggers.add(
                                    PendingTrigger(
                                        ability = ability,
                                        sourceId = entityId,
                                        sourceName = cardComponent.name,
                                        controllerId = controllerId,
                                        triggerContext = TriggerContext(triggeringEntityId = blockerId)
                                    )
                                )
                            }
                        }
                    }
                    // For "whenever this creature blocks a [filter]" (BlockEvent with SELF binding +
                    // attackerFilter), create one trigger per blocked attacker matching the filter.
                    // triggeringEntityId = the blocked attacker. Skystinger pattern.
                    else if (ability.trigger is EventPattern.BlockEvent && ability.binding == TriggerBinding.SELF &&
                        (ability.trigger as EventPattern.BlockEvent).attackerFilter != null &&
                        event is com.wingedsheep.engine.core.BlockersDeclaredEvent) {
                        val attackerFilter = (ability.trigger as EventPattern.BlockEvent).attackerFilter!!
                        val blockedAttackerIds = event.blockers[entityId] ?: emptyList()
                        for (attackerId in blockedAttackerIds) {
                            if (predicateEvaluator.matches(
                                    state, projected, attackerId, attackerFilter,
                                    PredicateContext(controllerId = controllerId, sourceId = entityId)
                                )) {
                                triggers.add(
                                    PendingTrigger(
                                        ability = ability,
                                        sourceId = entityId,
                                        sourceName = cardComponent.name,
                                        controllerId = controllerId,
                                        triggerContext = TriggerContext(triggeringEntityId = attackerId)
                                    )
                                )
                            }
                        }
                    }
                    // "Whenever this creature becomes blocked[ by ...]" (BecomesBlockedEvent, SELF).
                    // Two shapes that differ in firing count:
                    //   - Unfiltered ("becomes blocked"): becoming blocked is a single event no
                    //     matter how many creatures block, so fire exactly ONCE with the source as
                    //     the triggering entity. This keeps blocker-count payoffs correct (Rampage:
                    //     +N/+N for each creature blocking it beyond the first) and avoids prompting
                    //     "may" abilities once per blocker (Gustcloak).
                    //   - Filtered ("becomes blocked by a creature matching [filter]"): fire once per
                    //     matching blocker, with triggeringEntityId = the blocker, so effects targeting
                    //     the triggering entity resolve to that blocker (Flanking gives each -1/-1).
                    else if (ability.trigger is EventPattern.BecomesBlockedEvent && ability.binding == TriggerBinding.SELF &&
                        event is com.wingedsheep.engine.core.BlockersDeclaredEvent) {
                        val blockerFilter = (ability.trigger as EventPattern.BecomesBlockedEvent).filter
                        if (blockerFilter == null) {
                            val isBlocked = event.blockers.values.any { it.contains(entityId) }
                            if (isBlocked) {
                                triggers.add(
                                    PendingTrigger(
                                        ability = ability,
                                        sourceId = entityId,
                                        sourceName = cardComponent.name,
                                        controllerId = controllerId,
                                        triggerContext = TriggerContext(triggeringEntityId = entityId)
                                    )
                                )
                            }
                        } else {
                            for ((blockerId, attackerIds) in event.blockers) {
                                if (!attackerIds.contains(entityId)) continue
                                if (!predicateEvaluator.matches(
                                        state, projected, blockerId, blockerFilter,
                                        PredicateContext(controllerId = controllerId, sourceId = entityId)
                                    )
                                ) continue
                                triggers.add(
                                    PendingTrigger(
                                        ability = ability,
                                        sourceId = entityId,
                                        sourceName = cardComponent.name,
                                        controllerId = controllerId,
                                        triggerContext = TriggerContext(triggeringEntityId = blockerId)
                                    )
                                )
                            }
                        }
                    }
                    // For "blocks or becomes blocked by [filter]" (BlocksOrBecomesBlockedByEvent),
                    // check both blocking and being-blocked relationships and create one trigger per
                    // matching partner. Supports SELF binding (the creature itself) and ATTACHED
                    // binding (an Equipment/Aura whose equipped/enchanted creature is in combat —
                    // Barrow-Blade); for ATTACHED the combat relationships are read against the
                    // attached creature, but the trigger's source stays the equipment.
                    else if (ability.trigger is EventPattern.BlocksOrBecomesBlockedByEvent &&
                        (ability.binding == TriggerBinding.SELF || ability.binding == TriggerBinding.ATTACHED) &&
                        event is com.wingedsheep.engine.core.BlockersDeclaredEvent) {
                        val trigger = ability.trigger as EventPattern.BlocksOrBecomesBlockedByEvent
                        val combatCreatureId: EntityId? = if (ability.binding == TriggerBinding.ATTACHED) {
                            state.getEntity(entityId)
                                ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                                ?.targetId
                        } else entityId
                        val partners = mutableListOf<EntityId>()

                        if (combatCreatureId != null) {
                            // Case 1: combat creature is a blocker — partners are the attackers it blocks
                            val blockedAttackerIds = event.blockers[combatCreatureId]
                            if (blockedAttackerIds != null) {
                                partners.addAll(blockedAttackerIds)
                            }

                            // Case 2: combat creature is an attacker — partners are blockers blocking it
                            for ((blockerId, attackerIds) in event.blockers) {
                                if (attackerIds.contains(combatCreatureId)) {
                                    partners.add(blockerId)
                                }
                            }
                        }

                        val matchingPartners = partners.distinct().filter { partnerId ->
                            val partnerFilter = trigger.partnerFilter
                            partnerFilter == null || predicateEvaluator.matches(
                                state, projected, partnerId, partnerFilter,
                                PredicateContext(controllerId = controllerId, sourceId = entityId)
                            )
                        }
                        // "…blocks or becomes blocked *by* [filter]" is once per matching partner
                        // (Corrosive Ooze). The partner-less wording "…blocks or becomes blocked"
                        // is a single trigger however many creatures it is paired with (Spitting
                        // Slug), so collapse to the first matching partner — it still binds an "it".
                        val firingPartners =
                            if (trigger.oncePerCombat) matchingPartners.take(1) else matchingPartners
                        for (partnerId in firingPartners) {
                            triggers.add(
                                PendingTrigger(
                                    ability = ability,
                                    sourceId = entityId,
                                    sourceName = cardComponent.name,
                                    controllerId = controllerId,
                                    triggerContext = TriggerContext(triggeringEntityId = partnerId)
                                )
                            )
                        }
                    }
                    // "Whenever enchanted/equipped creature attacks and isn't blocked"
                    // (Farrel's Mantle). BecomesUnblockedEvent piggybacks on BlockersDeclaredEvent
                    // and its condition is a *negative* over the whole block map — "no blocker
                    // lists this attacker" — which the per-entity AttachmentTriggerDetector path
                    // cannot express, so ATTACHED is resolved here alongside the sibling
                    // BlocksOrBecomesBlockedBy case. The combat relationships are read against the
                    // enchanted creature; the trigger's source stays the Aura/Equipment, and the
                    // triggering entity is the attacker so "it"/"its controller" bind to it.
                    else if (ability.trigger is EventPattern.BecomesUnblockedEvent &&
                        ability.binding == TriggerBinding.ATTACHED &&
                        event is com.wingedsheep.engine.core.BlockersDeclaredEvent) {
                        val attachedCreatureId = state.getEntity(entityId)
                            ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                            ?.targetId
                        val isAttacking = attachedCreatureId != null && state.getEntity(attachedCreatureId)
                            ?.get<com.wingedsheep.engine.state.components.combat.AttackingComponent>() != null
                        val isUnblocked = attachedCreatureId != null &&
                            event.blockers.values.none { it.contains(attachedCreatureId) }
                        if (isAttacking && isUnblocked) {
                            triggers.add(
                                PendingTrigger(
                                    ability = ability,
                                    sourceId = entityId,
                                    sourceName = cardComponent.name,
                                    controllerId = controllerId,
                                    triggerContext = TriggerContext(triggeringEntityId = attachedCreatureId)
                                )
                            )
                        }
                    }
                    // For "whenever [a player] draws a card" (DrawEvent), drawing N cards via a
                    // single effect creates N separate trigger firings — one per card drawn
                    // (CR 121.2 + 603.2). The engine emits a single aggregate CardsDrawnEvent, so
                    // expand it here. `exceptFirstInDrawStep` (Orcish Bowmasters) subtracts the one
                    // card exempted by CR 504.1 — the matcher computes the final firing count.
                    else if (ability.trigger is EventPattern.DrawEvent && event is CardsDrawnEvent) {
                        val firings = matcher.drawTriggerFiringCount(
                            ability.trigger as EventPattern.DrawEvent, event, controllerId, state,
                            samePlayerDrawsLaterInBatch
                        )
                        repeat(firings) {
                            triggers.add(
                                PendingTrigger(
                                    ability = ability,
                                    sourceId = entityId,
                                    sourceName = cardComponent.name,
                                    controllerId = controllerId,
                                    triggerContext = TriggerContext.fromEvent(event)
                                )
                            )
                        }
                    }
                    // Same shape for "whenever an opponent discards a card" — discarding N cards
                    // through one effect creates N separate trigger firings, one per matching card,
                    // and each firing binds *its* card as the triggering entity so "exile it from
                    // their graveyard" (Tinybones, Bauble Burglar) acts on the right card (CR 400.7e
                    // — the trigger can find the object the discarded card became in the graveyard).
                    // Batch wording ("whenever you discard one or more cards", CR 603.2c) collapses
                    // the whole event to a single firing — CardsDiscardedEvent is already one event
                    // per discard action, so the cap is exactly the printed once-per-event — and has
                    // no single "it" to bind.
                    else if (ability.trigger is EventPattern.DiscardEvent &&
                        event is CardsDiscardedEvent) {
                        val discardTrigger = ability.trigger as EventPattern.DiscardEvent
                        val matchingCards = matcher.matchingDiscardedCards(
                            discardTrigger,
                            event,
                            entityId,
                            controllerId,
                            state
                        )
                        val boundCards: List<EntityId?> = if (discardTrigger.batch) {
                            if (matchingCards.isEmpty()) emptyList() else listOf(null)
                        } else {
                            matchingCards
                        }
                        for (discardedCardId in boundCards) {
                            triggers.add(
                                PendingTrigger(
                                    ability = ability,
                                    sourceId = entityId,
                                    sourceName = cardComponent.name,
                                    controllerId = controllerId,
                                    triggerContext = TriggerContext.fromEvent(event)
                                        .copy(triggeringEntityId = discardedCardId)
                                )
                            )
                        }
                    } else {
                        // For abilities like Death Match where the triggered ability should be
                        // controlled by the triggering entity's controller, not the source's controller
                        val effectiveControllerId = if (ability.controlledByTriggeringEntityController) {
                            val triggeringEntityId = TriggerContext.fromEvent(event).triggeringEntityId
                            if (triggeringEntityId != null) {
                                projected.getController(triggeringEntityId) ?: controllerId
                            } else {
                                controllerId
                            }
                        } else {
                            controllerId
                        }

                        // Lock in the attached creature's power for Aura/Equipment abilities that
                        // read "enchanted/equipped creature ... its power" (e.g. Pain for All). The
                        // creature — and the aura — may leave before the ability resolves (removed in
                        // response to the aura's ETB trigger), in which case the resolver falls back to
                        // this last-known value (CR 608.2h).
                        val enchantedPower = state.getEntity(entityId)
                            ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                            ?.targetId
                            ?.let { projected.getPower(it) }

                        // "Whenever you cast a spell that targets one or more [filter], **those**
                        // …" — capture the matching targets now, at trigger time. The triggered
                        // ability exists on the stack independently of the spell that caused it
                        // (CR 113.7a), and the spell sits *under* it, so an opponent can counter or
                        // retarget it in response: a payoff that re-read the spell's live
                        // TargetsComponent at resolution would silently act on nothing, or on the
                        // wrong creature. Seeded into the resolving ability's pipeline as
                        // TRIGGER_CAPTURED_COLLECTION, the same channel batch ETB triggers use.
                        val capturedTargets = (event as? SpellCastEvent)?.let {
                            matcher.capturedCastTargets(ability.trigger, it, state, entityId, controllerId)
                        }

                        triggers.add(
                            PendingTrigger(
                                ability = ability,
                                sourceId = entityId,
                                sourceName = cardComponent.name,
                                controllerId = effectiveControllerId,
                                triggerContext = TriggerContext.fromEvent(event).let { ctx ->
                                    ctx.copy(
                                        enchantedCreatureLastKnownPower = enchantedPower,
                                        // Never clobber a capture the event itself carries
                                        // (manifest dread's graveyard cards).
                                        capturedEntityIds = capturedTargets ?: ctx.capturedEntityIds,
                                        // "Whenever a source deals damage to this creature" binds
                                        // the damage *source*, so "that source's controller …"
                                        // (Belltower Sphinx) resolves. DamageTriggerDetector owns
                                        // the same rule for the case where the creature died to
                                        // that damage; both paths must agree.
                                        triggeringEntityId =
                                            if (event is DamageDealtEvent &&
                                                DamageTriggerDetector.bindsDamageSource(ability)
                                            ) event.sourceId else ctx.triggeringEntityId
                                    )
                                }
                            )
                        )
                    }
                }
            }
        }

        // Check the non-battlefield zones a card's abilities can function from for non-step triggers
        // (CR 113.6b). Graveyard: Dragon Shadow's "when a creature with MV 6+ enters, return this
        // from graveyard". Command zone: an *eminence* cast trigger — Edgar Markov's "whenever you
        // cast another Vampire spell" has to fire while Edgar sits in the command zone, which no
        // battlefield scan reaches.
        //
        // Exile is deliberately absent: every exile-active shape today (suspend, madness, paradigm)
        // already has its own dedicated detection path, and a general exile pass here would fire
        // those a second time.
        for (zone in NON_BATTLEFIELD_EVENT_TRIGGER_ZONES) {
            for (playerId in state.turnOrder) {
                for (entityId in state.getZone(playerId, zone)) {
                    val container = state.getEntity(entityId) ?: continue
                    val cardComponent = container.get<CardComponent>() ?: continue

                    val abilities = abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, index.statics)

                    for (ability in abilities) {
                        if (zone !in ability.activeZones) continue
                        // Explicit battlefield-exit triggers use the dedicated look-back detectors.
                        // "From anywhere" triggers instead see the card in its destination zone,
                        // including abilities restored when it leaves the battlefield.
                        if (event is ZoneChangeEvent && event.fromZone == Zone.BATTLEFIELD &&
                            event.entityId == entityId &&
                            (ability.trigger as? EventPattern.ZoneChangeEvent)?.from == Zone.BATTLEFIELD
                        ) continue
                        if (isGraveyardToHandSelfTrigger(ability, event, entityId)) continue
                        val ownerId = cardComponent.ownerId
                            ?: container.get<OwnerComponent>()?.playerId
                            ?: continue
                        if (matcher.matchesTrigger(ability.trigger, ability.binding, event, entityId, ownerId, state)) {
                            // Same trigger-time capture as the battlefield scan above, so a
                            // "…targets one or more X, those X …" ability active from the
                            // graveyard or command zone reads the same snapshot.
                            val capturedTargets = (event as? SpellCastEvent)?.let {
                                matcher.capturedCastTargets(ability.trigger, it, state, entityId, ownerId)
                            }
                            triggers.add(
                                PendingTrigger(
                                    ability = ability,
                                    sourceId = entityId,
                                    sourceName = cardComponent.name,
                                    controllerId = ownerId,
                                    triggerContext = TriggerContext.fromEvent(event).let { ctx ->
                                        if (capturedTargets == null) ctx
                                        else ctx.copy(capturedEntityIds = capturedTargets)
                                    }
                                )
                            )
                        }
                    }
                }
            }
        }

        // Check global granted triggered abilities (e.g., False Cure)
        detectGlobalGrantedTriggers(state, event, triggers)

        // The inherent speed trigger every player with speed has (CR 702.179d)
        detectInherentSpeedTriggers(state, event, triggers)

        // Handle death triggers (source might not be on battlefield anymore)
        if (event is ZoneChangeEvent && event.toZone == Zone.GRAVEYARD &&
            event.fromZone == Zone.BATTLEFIELD) {
            deathAndLeaveDetector.detectDeathTriggers(state, index.statics, event, triggers)
            // Handle "whenever a creature dealt damage by this creature this turn dies" triggers
            deathAndLeaveDetector.detectCreatureDealtDamageBySourceDiesTriggers(state, event, triggers, projected, index)
            // Handle ATTACHED zone-change triggers on auras that went to graveyard with their creature
            // (detected on the AURA's zone change event using lastKnownAttachedTo)
            deathAndLeaveDetector.detectDeadAuraAttachmentTriggers(state, index.statics, event, triggers)
            // Handle persist (CR 702.79) — nontoken creature with persist dies with no -1/-1 counter
            deathAndLeaveDetector.detectPersistTriggers(state, event, triggers)
            // Handle undying (CR 702.93) — permanent with undying dies with no +1/+1 counter
            deathAndLeaveDetector.detectUndyingTriggers(state, event, triggers)
            // Handle Enduring (Duskmourn Glimmer cycle) — nontoken creature with Enduring dies and
            // returns as an enchantment.
            deathAndLeaveDetector.detectEnduringTriggers(state, event, triggers)
        }

        // Handle leaves-the-battlefield triggers (source is no longer on battlefield)
        if (event is ZoneChangeEvent && event.fromZone == Zone.BATTLEFIELD) {
            deathAndLeaveDetector.detectLeavesBattlefieldTriggers(state, index.statics, event, triggers)
        }

        // A card returning to hand is absent from the graveyard's resident-source pass.
        if (event is ZoneChangeEvent && event.fromZone == Zone.GRAVEYARD && event.toZone == Zone.HAND) {
            detectGraveyardToHandTriggers(state, index.statics, event, triggers)
        }

        // Handle cycling triggers on the cycled card itself (e.g., Renewed Faith)
        if (event is CardCycledEvent) {
            detectCyclingCardTriggers(state, index.statics, event, triggers)
        }

        // Handle "when you discard this card" triggers on the discarded card itself, which now
        // sits in the graveyard (or in exile, if it also had madness) rather than in hand —
        // e.g. Edgar's Awakening. Mirrors the cycling pass above.
        if (event is CardsDiscardedEvent) {
            detectSelfDiscardTriggers(state, index.statics, event, triggers)
        }

        // Handle "when this card becomes plotted" triggers on the plotted card itself, which
        // now sits face up in exile rather than on the battlefield (e.g., Aloe Alchemist).
        if (event is CardPlottedEvent) {
            detectPlottedCardTriggers(state, index.statics, event, triggers)
        }

        // Handle the madness cast offer (CR 702.35a) on a card just discarded into exile.
        if (event is CardExiledWithMadnessEvent) {
            detectMadnessCastTriggers(state, event, triggers)
        }

        // Handle damage-received triggers for creatures no longer on the battlefield
        // (e.g., Broodhatch Nantuko dies from combat damage but trigger still fires)
        if (event is DamageDealtEvent && event.targetId !in state.getBattlefield()) {
            damageDetector.detectDamageReceivedTriggers(state, index.statics, event, triggers)
        }

        // Handle damage-source triggers
        if (event is DamageDealtEvent && event.sourceId != null) {
            damageDetector.detectDamageSourceTriggers(state, index.statics, event, triggers, projected)
        }

        // Handle "whenever a creature/spell deals damage to this" triggers (e.g., Tephraderm)
        if (event is DamageDealtEvent && event.sourceId != null) {
            damageDetector.detectDamagedBySourceTriggers(state, index.statics, event, triggers)
        }

        // Handle "whenever a creature deals damage to you" triggers (e.g., Aurification)
        if (event is DamageDealtEvent && event.sourceId != null && event.targetId in state.turnOrder) {
            damageDetector.detectDamageToControllerTriggers(state, event, triggers, projected, index)
        }

        // Handle general damage observer triggers (e.g., Kazarov: "whenever a creature an opponent controls is dealt damage")
        if (event is DamageDealtEvent) {
            damageDetector.detectDamageObserverTriggers(state, event, triggers, index)
        }

        // Handle "whenever a [subtype] deals combat damage to a player" triggers (e.g., Cabal Slaver)
        if (event is DamageDealtEvent && event.sourceId != null && event.isCombatDamage && event.targetId in state.turnOrder) {
            damageDetector.detectSubtypeDamageToPlayerTriggers(state, event, triggers, projected, index)
        }

        // Handle all ATTACHED-bound triggers on auras/equipment (e.g., Frozen Solid, One with Nature,
        // Guilty Conscience, Extra Arms, Heart-Piercer Bow, Fatal Mutation, Uncontrolled Infestation)
        attachmentDetector.detectAttachmentTriggers(state, event, triggers, index)

        // Handle "when you gain control of this from another player" triggers (e.g., Risky Move)
        // and "whenever an opponent gains control of a permanent from you" triggers (e.g., Zidane).
        if (event is ControlChangedEvent) {
            detectControlChangeTriggers(state, index.statics, event, triggers)
            detectOpponentGainsControlTriggers(state, index.statics, event, triggers)
        }

        // Handle self-cast triggers on the spell currently being cast — both NthSpellCast
        // (e.g. Hearthborn Battler cast as the second spell of the turn) and "when you cast
        // this spell" cast triggers (e.g. Sage of the Skies). The spell is on the stack, not
        // the battlefield, so the main index scan above skips it.
        if (event is SpellCastEvent) {
            detectSelfCastTriggers(state, index.statics, event, triggers)
        }

        // Handle a self-exploiting creature's own exploit watcher (CR 603.10a look-back). When an
        // exploiter sacrifices *itself* it is in the graveyard by the time the ExploitedEvent fires,
        // so the battlefield index scan above misses its own "whenever a creature you control
        // exploits ..." trigger (Skull Skaab). The exploiter was on the battlefield as its exploit
        // ability resolved, so the sacrifice look-back requires that watcher to still fire.
        if (event is com.wingedsheep.engine.core.ExploitedEvent) {
            detectExploitedSelfSacrificeTriggers(state, index.statics, event, triggers)
        }

        // Handle a "becomes unattached" trigger borne by an attachment that unattached *because* it
        // left the battlefield — it is in the graveyard/exile by now, so the battlefield index scan
        // above can't see it.
        if (event is com.wingedsheep.engine.core.PermanentUnattachedEvent) {
            detectUnattachedAfterLeavingTriggers(state, index.statics, event, triggers)
        }

        return triggers
    }

    /**
     * Detect a [EventPattern.BecomesUnattachedEvent] trigger on an attachment that is no longer on
     * the battlefield — it became unattached precisely *because* it left (destroyed, bounced,
     * exiled), which is one of the paths the card asks for.
     *
     * CR 603.6e / 603.10: the ability triggers based on the game state before the event, so an
     * Equipment destroyed while equipping something still sees its own unattach. Stitcher's Graft is
     * the card that needs it — destroying the Graft is how the equipped creature dies.
     *
     * Guarded on the attachment having actually left, so this never double-fires with the index scan
     * that covers the three unattaches where the attachment stays on the battlefield (an explicit
     * unattach effect, re-equipping elsewhere, and the CR 704.5n state-based unattach).
     */
    private fun detectUnattachedAfterLeavingTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: com.wingedsheep.engine.core.PermanentUnattachedEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val attachmentId = event.attachmentId
        if (attachmentId in state.getBattlefield()) return

        val container = state.getEntity(attachmentId) ?: return
        val cardComponent = container.get<CardComponent>() ?: return

        val abilities = abilityResolver.getTriggeredAbilities(attachmentId, cardComponent.cardDefinitionId, state, statics)
        for (ability in abilities) {
            if (ability.trigger !is EventPattern.BecomesUnattachedEvent) continue
            // The ability functioned from the battlefield right up to the moment it left; a
            // graveyard/exile-active ability is a different thing entirely.
            if (Zone.BATTLEFIELD !in ability.activeZones) continue
            if (!matcher.matchesTrigger(
                    ability.trigger, ability.binding, event, attachmentId, event.controllerId, state
                )
            ) continue
            triggers.add(
                PendingTrigger(
                    ability = ability,
                    sourceId = attachmentId,
                    sourceName = cardComponent.name,
                    controllerId = event.controllerId,
                    triggerContext = TriggerContext.fromEvent(event)
                )
            )
        }
    }

    /**
     * Detect an exploit watcher borne by an exploiter that sacrificed *itself* and so is no longer on
     * the battlefield when its [com.wingedsheep.engine.core.ExploitedEvent] fires.
     *
     * CR 603.10a: abilities that trigger when a player sacrifices a permanent "look back in time" — the
     * game uses the appearance of objects immediately before the sacrifice. A creature with exploit is on
     * the battlefield as its own exploit ability resolves (that resolution is what performs the sacrifice),
     * so its own "whenever a creature you control exploits a[nontoken] creature" watcher (Skull Skaab)
     * must still fire even when the exploiter sacrifices itself. This matches the DTK Silumgar Butcher
     * ruling. The main index scan in [detectTriggersForEvent] only covers battlefield permanents, so a
     * self-exploiting Skull Skaab — now in the graveyard — would otherwise miss its own trigger.
     *
     * Guards:
     *  - Fires only when the exploiter has actually left the battlefield, so this never double-fires with
     *    the battlefield index scan (which handles the exploiter-still-present case, e.g. exploiting
     *    another creature).
     *  - Skips [TriggerBinding.OTHER] — "whenever *another* creature you control exploits" never fires for
     *    the exploiter observing its own exploit.
     */
    private fun detectExploitedSelfSacrificeTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: com.wingedsheep.engine.core.ExploitedEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val exploiterId = event.exploiterId
        // Still on the battlefield → already covered by the main index scan; avoid a double fire.
        if (exploiterId in state.getBattlefield()) return

        val container = state.getEntity(exploiterId) ?: return
        val cardComponent = container.get<CardComponent>() ?: return
        val controllerId = event.exploiterControllerId

        val abilities = abilityResolver.getTriggeredAbilities(exploiterId, cardComponent.cardDefinitionId, state, statics)
        for (ability in abilities) {
            if (ability.trigger !is EventPattern.ExploitedEvent) continue
            if (ability.binding == TriggerBinding.OTHER) continue
            if (!matcher.matchesTrigger(ability.trigger, ability.binding, event, exploiterId, controllerId, state)) continue
            triggers.add(
                PendingTrigger(
                    ability = ability,
                    sourceId = exploiterId,
                    sourceName = cardComponent.name,
                    controllerId = controllerId,
                    triggerContext = TriggerContext.fromEvent(event)
                )
            )
        }
    }

    /**
     * Detect self-cast triggers on the spell currently being cast — triggers whose event keys off
     * the spell's own casting and travels with it onto the stack.
     *
     * Two kinds qualify:
     *  - [EventPattern.NthSpellCastEvent] — when a card like Hearthborn Battler is itself the Nth
     *    spell cast this turn ("whenever a player casts their second spell each turn").
     *  - [EventPattern.CastThisSpellEvent] — a "when you cast this spell" cast trigger (Sage of the
     *    Skies). These are never indexed against battlefield permanents, so this is the only path
     *    that fires them.
     *
     * The spell is on the stack rather than the battlefield, so the main index scan skips it; this
     * pass reads the cast spell's own triggered abilities and matches them against the cast event.
     */
    private fun detectSelfCastTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: SpellCastEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val entityId = event.spellEntityId
        val container = state.getEntity(entityId) ?: return
        val cardComponent = container.get<CardComponent>() ?: return
        if (container.has<FaceDownComponent>()) return

        val abilities = abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, statics)
        val controllerId = event.casterId

        for (ability in abilities) {
            if (ability.trigger !is EventPattern.NthSpellCastEvent &&
                ability.trigger !is EventPattern.CastThisSpellEvent
            ) continue
            if (matcher.matchesTrigger(ability.trigger, ability.binding, event, entityId, controllerId, state)) {
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entityId,
                        sourceName = cardComponent.name,
                        controllerId = controllerId,
                        triggerContext = TriggerContext.fromEvent(event)
                    )
                )
            }
        }
    }

    /**
     * Detect triggers from global granted triggered abilities (e.g., False Cure).
     * These are triggered abilities not attached to any permanent, created by
     * spell effects and stored in GameState.globalGrantedTriggeredAbilities.
     */
    private fun detectGlobalGrantedTriggers(
        state: GameState,
        event: EngineGameEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        if (state.globalGrantedTriggeredAbilities.isEmpty()) return

        for (global in state.globalGrantedTriggeredAbilities) {
            val ability = global.ability
            // Use a dummy sourceId for matchesTrigger (global abilities aren't attached to entities)
            if (matcher.matchesTrigger(ability.trigger, ability.binding, event, global.sourceId, global.controllerId, state)) {
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = global.sourceId,
                        sourceName = global.sourceName,
                        controllerId = global.controllerId,
                        triggerContext = TriggerContext.fromEvent(event)
                    )
                )
            }
        }
    }

    /**
     * Detect the inherent speed trigger (Aetherdrift, CR 702.179d): "Whenever one or more opponents
     * lose life during your turn, if your speed is less than 4, your speed increases by 1."
     *
     * The rule gives this ability no source and one copy to every player with 1 or more speed, so
     * there is nothing on the battlefield to hang it off — it is synthesized here, per player, with
     * the *player entity* as its source. That choice is what makes the "triggers only once each turn"
     * clause work without new machinery: the generic `oncePerTurn` tracker is keyed on
     * `(sourceId, abilityId)`, so a stable ability id on the player entity gives exactly one fire per
     * player per turn, reset by the normal cleanup sweep. See [SpeedAbilities].
     *
     * Players with no speed have no such ability at all (CR 702.179b/d), which is the early-out here —
     * and also why a game with no Aetherdrift cards pays only one `hasSpeed` read per player per event.
     * The "during your turn" and "less than 4" clauses ride on the ability's intervening-if, applied
     * downstream by [TriggerMatcher.filterByTriggerCondition].
     */
    private fun detectInherentSpeedTriggers(
        state: GameState,
        event: EngineGameEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val ability = SpeedAbilities.inherentSpeedIncrease
        for (playerId in state.turnOrder) {
            if (!state.hasSpeed(playerId)) continue
            if (!matcher.matchesTrigger(
                    ability.trigger, ability.binding, event, playerId, playerId, state
                )
            ) continue
            triggers.add(
                PendingTrigger(
                    ability = ability,
                    sourceId = playerId,
                    sourceName = SpeedAbilities.SOURCE_NAME,
                    controllerId = playerId,
                    triggerContext = TriggerContext.fromEvent(event)
                )
            )
        }
    }

    /**
     * Detect cycling triggers on the card that was cycled.
     * Cards like Renewed Faith have "When you cycle this card, you may gain 2 life."
     * The card is now in the graveyard, but its cycling trigger still fires.
     */
    private fun detectCyclingCardTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: CardCycledEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val entityId = event.cardId
        val container = state.getEntity(entityId) ?: return
        val cardComponent = container.get<CardComponent>() ?: return

        val abilities = abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, statics)

        for (ability in abilities) {
            if (ability.trigger is EventPattern.CycleEvent) {
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entityId,
                        sourceName = cardComponent.name,
                        controllerId = event.playerId,
                        // fromEvent, not a hand-built context: it also carries the X announced for
                        // an `{X}` cycling cost, which the payoff reads (Webstrike Elite's "mana
                        // value X" target filter, Valor's Flagship's "create X tokens").
                        triggerContext = TriggerContext.fromEvent(event)
                    )
                )
            }
        }
    }

    /**
     * Detect "when you discard this card" triggers on the card that was discarded (Edgar's
     * Awakening). The ability functions in hand but the card is already in the graveyard — or in
     * exile, if it also had madness — by the time the event fires, so the main index scan never
     * sees it. Mirrors [detectCyclingCardTriggers].
     *
     * Only [TriggerBinding.SELF] discard triggers belong here: an `ANY`-bound
     * [EventPattern.DiscardEvent] is an observer ("whenever you discard a card") owned by the
     * battlefield pass, and would fire twice if this pass also claimed it.
     *
     * The trigger's controller is the discarding player, which is what "when *you* discard this
     * card" means — an opponent's Mind Rot on your hand is your discard, and the card's owner is
     * the one holding it.
     */
    private fun detectSelfDiscardTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: CardsDiscardedEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        for (entityId in event.cardIds) {
            val container = state.getEntity(entityId) ?: continue
            val cardComponent = container.get<CardComponent>() ?: continue

            val abilities =
                abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, statics)

            for (ability in abilities) {
                if (ability.trigger !is EventPattern.DiscardEvent) continue
                if (ability.binding != TriggerBinding.SELF) continue
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entityId,
                        sourceName = cardComponent.name,
                        controllerId = event.playerId,
                        triggerContext = TriggerContext.fromEvent(event)
                            .copy(triggeringEntityId = entityId)
                    )
                )
            }
        }
    }

    /**
     * Self-bound graveyard-to-hand triggers look back at the card that left the graveyard
     * (CR 603.10a). Only the moving card is inspected; unrelated draws do not scan any hands.
     * The owner controls the ability even when another player caused the return.
     */
    private fun isGraveyardToHandSelfTrigger(
        ability: com.wingedsheep.sdk.scripting.TriggeredAbility,
        event: EngineGameEvent,
        sourceId: EntityId
    ): Boolean = event is ZoneChangeEvent && event.fromZone == Zone.GRAVEYARD &&
        event.toZone == Zone.HAND && event.entityId == sourceId &&
        Zone.GRAVEYARD in ability.activeZones && ability.binding == TriggerBinding.SELF &&
        ability.trigger is EventPattern.ZoneChangeEvent

    private fun detectGraveyardToHandTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: ZoneChangeEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val card = state.getEntity(event.entityId)?.get<CardComponent>() ?: return
        val abilities = abilityResolver.getTriggeredAbilities(event.entityId, card.cardDefinitionId, state, statics)
        for (ability in abilities) {
            if (Zone.GRAVEYARD !in ability.activeZones || ability.binding != TriggerBinding.SELF) continue
            val pattern = ability.trigger as? EventPattern.ZoneChangeEvent ?: continue
            if (!matcher.matchesZoneChangeTrigger(pattern, ability.binding, event,
                    event.entityId, event.ownerId, state)) continue
            triggers.add(PendingTrigger(
                ability = ability,
                sourceId = event.entityId,
                sourceName = event.entityName,
                controllerId = event.ownerId,
                triggerContext = TriggerContext.fromEvent(event)
            ))
        }
    }

    /**
     * Detect "when this card becomes plotted" triggers on the plotted card itself (e.g.,
     * Aloe Alchemist). After the plot special action resolves the card sits face up in exile,
     * not on the battlefield, so the main index scan never sees it. This mirrors
     * [detectCyclingCardTriggers]: read the plotted card's own triggered abilities and fire any
     * that key off [EventPattern.BecomesPlottedEvent].
     */
    private fun detectPlottedCardTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: CardPlottedEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val entityId = event.cardId
        val container = state.getEntity(entityId) ?: return
        val cardComponent = container.get<CardComponent>() ?: return

        val abilities = abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, statics)

        for (ability in abilities) {
            if (ability.trigger is EventPattern.BecomesPlottedEvent) {
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entityId,
                        sourceName = cardComponent.name,
                        controllerId = event.playerId,
                        triggerContext = TriggerContext(triggeringPlayerId = event.playerId)
                    )
                )
            }
        }
    }

    /**
     * The CR 702.35a madness trigger — "when this card is exiled this way, its owner may cast it by
     * paying [cost] rather than paying its mana cost. If that player doesn't, they put this card
     * into their graveyard."
     *
     * Synthesized rather than resolved off the card's script, because madness is a keyword the
     * engine drives (like Suspend and Paradigm) and because an exiled card's non-step triggers have
     * no generic detection pass — only graveyard cards do. Controlled by the card's *owner*, who is
     * whom CR 702.35a offers the cast to, not whoever caused the discard.
     */
    private fun detectMadnessCastTriggers(
        state: GameState,
        event: CardExiledWithMadnessEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        // The card must still be the discarded-into-exile object; anything that moved it out of
        // exile in the same event batch has already stripped the marker.
        val container = state.getEntity(event.cardId) ?: return
        if (!container.has<MadnessExiledComponent>()) return
        // The cost comes off the fixed alternative cost stamped alongside the marker rather than
        // off the card's printed MadnessComponent: madness can also be *granted* (Falkenrath
        // Gorger), and the stamped cost is the one the cast will actually charge either way.
        val cost = container.get<PlayWithFixedAlternativeManaCostComponent>()?.fixedCost ?: return

        triggers.add(
            PendingTrigger(
                ability = Madness.castAbility(cost),
                sourceId = event.cardId,
                sourceName = event.cardName,
                controllerId = event.ownerId,
                triggerContext = TriggerContext(
                    triggeringEntityId = event.cardId,
                    triggeringPlayerId = event.ownerId
                )
            )
        )
    }

    /**
     * Detect "whenever one or more [filter] cards are put into your graveyard from your library"
     * batching triggers. Groups all library→graveyard zone changes by owner and fires matching
     * triggers at most once per controller, regardless of how many cards were moved.
     */
    private fun detectLibraryToGraveyardBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        // Collect all library→graveyard zone change events, grouped by owner
        val libToGravByOwner = mutableMapOf<EntityId, MutableList<ZoneChangeEvent>>()
        for (event in events) {
            if (event is ZoneChangeEvent && event.fromZone == Zone.LIBRARY && event.toZone == Zone.GRAVEYARD) {
                libToGravByOwner.getOrPut(event.ownerId) { mutableListOf() }.add(event)
            }
        }
        if (libToGravByOwner.isEmpty()) return

        // Check battlefield permanents with library-to-graveyard batch triggers
        for (entry in index.getEntitiesForCategory(TriggerCategory.LIBRARY_TO_GRAVEYARD)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.CardsPutIntoGraveyardFromLibraryEvent) continue

                // This trigger watches the controller's own graveyard
                val controllerId = entry.controllerId
                val ownerEvents = libToGravByOwner[controllerId] ?: continue

                // The milled cards matching the filter. These "caused" the trigger and are exposed
                // to the payoff via TRIGGER_CAPTURED_COLLECTION (a single trigger event fires once
                // for the whole batch, CR 603.2c) so an effect can act on exactly them — e.g. Hedge
                // Shredder's "put them onto the battlefield tapped".
                val matchingIds = ownerEvents.filter { event ->
                    if (trigger.filter == GameObjectFilter.Any) return@filter true
                    val cardComponent = state.getEntity(event.entityId)?.get<CardComponent>()
                        ?: return@filter false
                    trigger.filter.cardPredicates.all { predicate ->
                        when (predicate) {
                            is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsCreature ->
                                cardComponent.typeLine.isCreature
                            is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsLand ->
                                cardComponent.typeLine.isLand
                            is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNonland ->
                                !cardComponent.typeLine.isLand
                            is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasSubtype ->
                                cardComponent.typeLine.hasSubtype(predicate.subtype)
                            else -> true
                        }
                    }
                }.map { it.entityId }

                if (matchingIds.isNotEmpty()) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = entry.entityId,
                            sourceName = entry.cardComponent.name,
                            controllerId = controllerId,
                            triggerContext = TriggerContext(capturedEntityIds = matchingIds)
                        )
                    )
                }
            }
        }
    }

    /**
     * Detect "whenever one or more [filter] cards are put into your graveyard from anywhere"
     * batching triggers. Groups all to-graveyard zone changes by the owner of the moved card
     * and fires matching triggers at most once per controller, regardless of how many cards
     * were moved or from which source zones.
     */
    private fun detectAnyToGraveyardBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        // Collect all zone change events targeting graveyard, grouped by owner
        val toGravByOwner = mutableMapOf<EntityId, MutableList<ZoneChangeEvent>>()
        for (event in events) {
            if (event is ZoneChangeEvent && event.toZone == Zone.GRAVEYARD && event.fromZone != Zone.GRAVEYARD) {
                toGravByOwner.getOrPut(event.ownerId) { mutableListOf() }.add(event)
            }
        }
        if (toGravByOwner.isEmpty()) return

        for (entry in index.getEntitiesForCategory(TriggerCategory.ANY_TO_GRAVEYARD)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.CardsPutIntoYourGraveyardEvent) continue

                val controllerId = entry.controllerId
                val ownerEvents = toGravByOwner[controllerId] ?: continue

                // Check if any of the moved cards match the filter
                val hasMatch = ownerEvents.any { event ->
                    cardMatchesGraveyardBatchFilter(state, event.entityId, trigger.filter)
                }

                if (hasMatch) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = entry.entityId,
                            sourceName = entry.cardComponent.name,
                            controllerId = controllerId,
                            triggerContext = TriggerContext()
                        )
                    )
                }
            }
        }
    }

    /**
     * Detect "whenever one or more cards leave your graveyard" batching triggers
     * (e.g., Attuned Hunter, Kishla Skimmer, Kheru Goldkeeper).
     *
     * Groups all from-graveyard zone changes by the owner of that graveyard ("your graveyard")
     * and fires the trigger at most once per controller, regardless of how many matching cards
     * left or where they went (cast/exiled/reanimated/returned to hand). The "during your turn"
     * restriction is expressed on the card as `triggerRestriction = Conditions.IsYourTurn`, and
     * "only once each turn" via `oncePerTurn = true`, both applied later in detectTriggers.
     */
    private fun detectCardsLeftGraveyardBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        // Collect all zone change events leaving a graveyard, grouped by the graveyard's owner
        val fromGravByOwner = mutableMapOf<EntityId, MutableList<ZoneChangeEvent>>()
        for (event in events) {
            if (event is ZoneChangeEvent && event.fromZone == Zone.GRAVEYARD && event.toZone != Zone.GRAVEYARD) {
                fromGravByOwner.getOrPut(event.ownerId) { mutableListOf() }.add(event)
            }
        }
        if (fromGravByOwner.isEmpty()) return

        for (entry in index.getEntitiesForCategory(TriggerCategory.CARDS_LEFT_GRAVEYARD)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.CardsLeftYourGraveyardEvent) continue

                val controllerId = entry.controllerId
                val ownerEvents = fromGravByOwner[controllerId] ?: continue

                // Check if any of the departed cards match the filter
                val hasMatch = ownerEvents.any { event ->
                    cardMatchesGraveyardBatchFilter(state, event.entityId, trigger.filter)
                }

                if (hasMatch) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = entry.entityId,
                            sourceName = entry.cardComponent.name,
                            controllerId = controllerId,
                            triggerContext = TriggerContext()
                        )
                    )
                }
            }
        }
    }

    /**
     * Detect "whenever one or more cards are put into exile from graveyards and/or the
     * battlefield" batching triggers (Ketramose, the New Dawn).
     *
     * Unlike the graveyard batch passes this is **not** scoped to one player's zone — the printed
     * text says "graveyards" (plural) and doesn't restrict whose battlefield the permanent left,
     * so every exile out of a watched zone counts for every controller with the trigger. The batch
     * fires at most once per detection pass (CR 603.2c), no matter how many cards moved or which
     * of the watched zones they came from.
     *
     * The "during your turn" restriction is expressed on the card as
     * `triggerRestriction = Conditions.IsYourTurn` and applied later in detectTriggers.
     */
    private fun detectCardsPutIntoExileBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        val exiled = events.filterIsInstance<ZoneChangeEvent>()
            .filter { it.toZone == Zone.EXILE && it.fromZone != Zone.EXILE }
        if (exiled.isEmpty()) return

        for (entry in index.getEntitiesForCategory(TriggerCategory.CARDS_EXILED_BATCH)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.CardsPutIntoExileEvent) continue

                // The objects that caused this firing. They are handed to the payoff as the
                // ability's captured collection so "choose a creature card from among them" has a
                // referent (Kaya, Spirits' Justice); an unfiltered Ketramose-style trigger simply
                // ignores it.
                val matchingIds = exiled.filter { event ->
                    event.fromZone in trigger.fromZones &&
                        exileBatchOwnershipMatches(event, trigger.filter, entry.controllerId) &&
                        cardMatchesGraveyardBatchFilter(
                            state = state,
                            entityId = event.entityId,
                            filter = trigger.filter,
                            includeTokens = trigger.includeTokens
                        )
                }.map { it.entityId }
                if (matchingIds.isEmpty()) continue

                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entry.entityId,
                        sourceName = entry.cardComponent.name,
                        controllerId = entry.controllerId,
                        triggerContext = TriggerContext(capturedEntityIds = matchingIds)
                    )
                )
            }
        }
    }

    /**
     * Whether the object this [event] moved into exile satisfies [filter]'s controller predicate for
     * a trigger controlled by [observerId].
     *
     * The object is already in exile when this runs, so control is read from last-known information
     * (CR 603.10) for a battlefield exit and from ownership for every other zone — a card in a
     * graveyard, hand or library has no controller, and "creature cards in **your** graveyard" is a
     * statement about whose graveyard it is. Predicates the exile batch can't meaningfully answer
     * (the target-relative ones, which have no target at detection time) fall through as matching,
     * the same way [cardMatchesGraveyardBatchFilter] treats card predicates it doesn't model.
     */
    private fun exileBatchOwnershipMatches(
        event: ZoneChangeEvent,
        filter: GameObjectFilter,
        observerId: EntityId
    ): Boolean {
        val holderId = if (event.fromZone == Zone.BATTLEFIELD) {
            event.lastKnown?.controllerId ?: event.ownerId
        } else {
            event.ownerId
        }
        return when (filter.controllerPredicate) {
            ControllerPredicate.ControlledByYou -> holderId == observerId
            ControllerPredicate.ControlledByOpponent -> holderId != observerId
            else -> true
        }
    }

    /**
     * Whether the card now identified by [entityId] (which may have moved to a new zone)
     * matches [filter] for graveyard batching triggers. Card-characteristic predicates are
     * evaluated against the card's base [CardComponent]; [GameObjectFilter.Any] always matches.
     */
    private fun cardMatchesGraveyardBatchFilter(
        state: GameState,
        entityId: EntityId,
        filter: GameObjectFilter,
        includeTokens: Boolean = false
    ): Boolean {
        // Tokens aren't cards (CR 111.6), so a token put into a graveyard never satisfies a
        // "one or more [permanent] cards are put into your graveyard" trigger — even though it
        // momentarily occupies the graveyard zone before CR 704.5s/111.7 sweeps it away (which
        // is also why it can still be present here at trigger-detection time). [includeTokens]
        // is the opposite reading, for a trigger whose printed noun is permanents rather than
        // cards ("one or more creatures you control … are put into exile").
        val entity = state.getEntity(entityId) ?: return false
        if (!includeTokens && entity.has<TokenComponent>()) return false
        if (filter == GameObjectFilter.Any) return true
        val cardComponent = entity.get<CardComponent>() ?: return false
        return filter.cardPredicates.all { predicate ->
            when (predicate) {
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsCreature ->
                    cardComponent.typeLine.isCreature
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsArtifact ->
                    cardComponent.typeLine.isArtifact
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsEnchantment ->
                    cardComponent.typeLine.isEnchantment
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsLand ->
                    cardComponent.typeLine.isLand
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsPlaneswalker ->
                    com.wingedsheep.sdk.core.CardType.PLANESWALKER in cardComponent.typeLine.cardTypes
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsPermanent ->
                    cardComponent.typeLine.isPermanent
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNonland ->
                    !cardComponent.typeLine.isLand
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNoncreature ->
                    !cardComponent.typeLine.isCreature
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNonartifact ->
                    !cardComponent.typeLine.isArtifact
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasSubtype ->
                    cardComponent.typeLine.hasSubtype(predicate.subtype)
                else -> true
            }
        }
    }

    /**
     * Turn each [ReflexiveAbilityTriggeredEvent] into a real [PendingTrigger] for the reflexive
     * ("when you do") half of a `ReflexiveTriggerEffect` (CR 603.12). Unlike every other detector
     * in this file, this doesn't scan [TriggerIndex] for a matching registered ability — the event
     * itself unconditionally IS the trigger, carrying its own effect/target requirements/pipeline
     * state, so one `PendingTrigger` is built directly per event. Placing it through the normal
     * `TriggerProcessor`/`StackResolver` pipeline (rather than resolving inline, as the old
     * `ReflexiveTriggerEffectExecutor` did) is what gives opponents the real priority window CR
     * 603.12 requires between the reflexive ability's target being locked in and it resolving.
     */
    private fun detectReflexiveTriggers(
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        for (event in events) {
            if (event !is ReflexiveAbilityTriggeredEvent) continue
            val reqs = event.reflexiveTargetRequirements
            val syntheticAbility = TriggeredAbility.create(
                // Never re-matched — this PendingTrigger is constructed directly, bypassing the
                // usual TriggerIndex scan, so the trigger pattern itself is inert.
                trigger = EventPattern.DamageEvent(),
                effect = event.reflexiveEffect,
                targetRequirement = reqs.firstOrNull(),
                additionalTargetRequirements = reqs.drop(1),
                descriptionOverride = event.descriptionOverride ?: event.reflexiveEffect.description
            )
            triggers.add(
                PendingTrigger(
                    ability = syntheticAbility,
                    sourceId = event.sourceId,
                    sourceName = event.sourceName,
                    controllerId = event.controllerId,
                    granterId = event.granterId,
                    triggerContext = event.carriedTriggerContext,
                    carriedPipeline = event.carriedPipeline,
                    objectReferences = event.carriedObjectReferences.copy(captured = true)
                )
            )
        }
    }

    /**
     * Detect "whenever you sacrifice one or more [permanents]" batching triggers
     * (ANY binding) and "when you sacrifice this" self-targeted triggers (SELF binding).
     *
     * For ANY binding: groups PermanentsSacrificedEvent by controller and fires the
     * trigger at most once per controller, regardless of how many sacrifice events
     * occurred.
     *
     * For SELF binding: fires once per sacrificed permanent that has a matching trigger.
     * The source has already moved to the graveyard by the time detection runs, so it
     * is not in the trigger index — abilities are looked up directly by card definition.
     */
    private fun detectSacrificeBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        // Collect all sacrifice events, grouped by controller
        val sacrificeByController = mutableMapOf<EntityId, MutableList<PermanentsSacrificedEvent>>()
        for (event in events) {
            if (event is PermanentsSacrificedEvent) {
                sacrificeByController.getOrPut(event.playerId) { mutableListOf() }.add(event)
            }
        }
        if (sacrificeByController.isEmpty()) return

        // ANY binding: check battlefield permanents with sacrifice batch triggers
        for (entry in index.getEntitiesForCategory(TriggerCategory.SACRIFICE)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.PermanentsSacrificedEvent) continue
                // ANY ("a permanent, incl. itself") and OTHER ("another permanent", excl. itself)
                // both watch sacrifices while the source is on the battlefield. SELF is handled by
                // the self-sacrifice pass below (the source has left the battlefield by then).
                if (ability.binding != TriggerBinding.ANY && ability.binding != TriggerBinding.OTHER) continue

                // Whose sacrifices this trigger watches. Player.You (default) is the source
                // controller's own ("Whenever you sacrifice…"); Player.Each is every player's
                // ("Whenever a player sacrifices…", Zodiark); Player.EachOpponent is the source
                // controller's opponents' ("Whenever an opponent sacrifices…", Vengeful Tracker).
                // The multi-player scopes fire once per sacrificing player.
                val controllerId = entry.controllerId
                val watchedPlayers = when (trigger.sacrificedBy) {
                    Player.Each -> sacrificeByController.keys.toList()
                    // CR 102.3 — teammates are not opponents, so go through getOpponents rather
                    // than "everyone but me".
                    Player.EachOpponent ->
                        state.getOpponents(controllerId).filter { sacrificeByController.containsKey(it) }
                    else ->
                        if (sacrificeByController.containsKey(controllerId)) listOf(controllerId) else emptyList()
                }

                for (sacrificingPlayerId in watchedPlayers) {
                    val playerEvents = sacrificeByController[sacrificingPlayerId] ?: continue

                    // Find the matching sacrificed permanents. The first match is bound as the
                    // triggering entity so payoffs can read "its mana value / power" off the
                    // sacrificed creature (e.g. Rakdos, the Muscle — "exile cards equal to its mana
                    // value"). Characteristics like mana value survive in the graveyard via the
                    // card's CardComponent; P/T payoffs should use a captured snapshot instead.
                    val matchingSacrificed = playerEvents.flatMap { event ->
                        event.permanentIds.filter { permanentId ->
                            sacrificedPermanentMatchesFilter(state, permanentId, trigger.filter)
                        }
                    }.let { matches ->
                        // "another" (OTHER) excludes the source sacrificing itself. The source is on
                        // the battlefield in this pass, so it won't be in the batch — but guard anyway.
                        if (ability.binding == TriggerBinding.OTHER) matches.filter { it != entry.entityId }
                        else matches
                    }

                    if (matchingSacrificed.isEmpty()) continue

                    // Per-permanent template ("a/another permanent") fires once for EACH matching
                    // permanent (CR 603.2c); batch template ("one or more permanents") fires once.
                    // The triggering entity is bound so payoffs can read "its mana value / power"
                    // off the sacrificed permanent (e.g. Rakdos, the Muscle); characteristics like
                    // mana value survive in the graveyard via the card's CardComponent.
                    val triggeringPermanents =
                        if (trigger.perPermanent) matchingSacrificed else listOf(matchingSacrificed.first())
                    for (triggeringPermanentId in triggeringPermanents) {
                        triggers.add(
                            PendingTrigger(
                                ability = ability,
                                sourceId = entry.entityId,
                                sourceName = entry.cardComponent.name,
                                controllerId = controllerId,
                                triggerContext = TriggerContext(
                                    triggeringEntityId = triggeringPermanentId,
                                    triggeringPlayerId = sacrificingPlayerId
                                )
                            )
                        )
                    }
                }
            }
        }

        // Self-sacrifice: when a permanent with a sacrifice trigger is itself sacrificed it has
        // already left the battlefield, so it isn't in the index and the loop above (which iterates
        // the battlefield index) can't catch it. Look up triggered abilities directly from each
        // sacrificed permanent instead. SELF ("whenever you sacrifice this permanent") and ANY
        // ("whenever you sacrifice a <filter>") include the source sacrificing itself; OTHER
        // ("another") excludes it but a source sacrificed *alongside* other permanents still reacts
        // to those others (Mazirek/Zhao sacrificed in the same batch as its fodder).
        for ((controllerId, controllerEvents) in sacrificeByController) {
            val batchPermanentIds = controllerEvents.flatMap { it.permanentIds }
            for (event in controllerEvents) {
                for (permanentId in event.permanentIds) {
                    val container = state.getEntity(permanentId) ?: continue
                    if (container.has<FaceDownComponent>()) continue
                    val cardComponent = container.get<CardComponent>() ?: continue

                    val abilities = abilityResolver.getTriggeredAbilities(
                        permanentId, cardComponent.cardDefinitionId, state, index.statics
                    )
                    for (ability in abilities) {
                        val trigger = ability.trigger
                        if (trigger !is EventPattern.PermanentsSacrificedEvent) continue
                        if (Zone.BATTLEFIELD !in ability.activeZones) continue
                        // This pass only ever sees a permanent sacrificed by its own controller, so
                        // an opponent-scoped trigger ("Whenever an opponent sacrifices…") can never
                        // be satisfied here.
                        if (trigger.sacrificedBy == Player.EachOpponent) continue

                        if (trigger.perPermanent) {
                            // Per-permanent template ("a/another permanent") where the source is
                            // itself among the simultaneously-sacrificed permanents. Fire once per
                            // matching batch member (CR 603.2c): ANY counts itself, OTHER excludes
                            // it, SELF only itself.
                            val eligible = batchPermanentIds.filter { pid ->
                                sacrificedPermanentMatchesFilter(state, pid, trigger.filter) &&
                                    when (ability.binding) {
                                        TriggerBinding.SELF -> pid == permanentId
                                        TriggerBinding.OTHER -> pid != permanentId
                                        else -> true
                                    }
                            }
                            for (triggeringPermanentId in eligible) {
                                triggers.add(
                                    PendingTrigger(
                                        ability = ability,
                                        sourceId = permanentId,
                                        sourceName = cardComponent.name,
                                        controllerId = controllerId,
                                        triggerContext = TriggerContext(triggeringEntityId = triggeringPermanentId)
                                    )
                                )
                            }
                            continue
                        }

                        // Batch template ("one or more permanents"): SELF and ANY include the
                        // source sacrificing itself; fires once.
                        if (ability.binding != TriggerBinding.SELF &&
                            ability.binding != TriggerBinding.ANY
                        ) continue
                        if (!sacrificedPermanentMatchesFilter(state, permanentId, trigger.filter)) continue

                        triggers.add(
                            PendingTrigger(
                                ability = ability,
                                sourceId = permanentId,
                                sourceName = cardComponent.name,
                                controllerId = controllerId,
                                triggerContext = TriggerContext(
                                    triggeringEntityId = permanentId
                                )
                            )
                        )
                    }
                }
            }
        }
    }

    /**
     * Detect "whenever one or more [filtered] permanents become tapped" batching triggers
     * (`TapEvent(batch = true)`, ANY binding — Deeproot Pilgrimage). A simultaneous tap of several
     * matching permanents (attacking, convoke, crew) emits several [TappedEvent]s in one batch; this
     * fires the trigger **once** for that batch, not once per permanent (the over-count the per-event
     * path — which skips batch taps — would produce). The filter (e.g. "nontoken Merfolk you
     * control") is evaluated against projected state relative to the source's controller.
     */
    private fun detectTapBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        val tapEvents = events.filterIsInstance<TappedEvent>()
        if (tapEvents.isEmpty()) return

        for (entry in index.getEntitiesForCategory(TriggerCategory.TAPPED)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.TapEvent || !trigger.batch) continue
                // Batch tap triggers are "one or more … become tapped" observers (ANY binding).
                if (ability.binding != TriggerBinding.ANY) continue

                // "Whenever you tap one or more …" (Sharae of Numbing Depths) — only the taps this
                // trigger's controller caused count toward the batch. A batch mixing tappers is
                // therefore narrowed, not discarded, before the filter runs. The tap *cause*
                // narrows the same way: a batch that also contains taps from an unnamed cause still
                // fires a "to pay a teamwork cost" batch trigger, on its teamwork taps alone.
                val tapper = trigger.tapper
                val reason = trigger.reason
                // No `firstTimeEachTurn` axis here: it is per-permanent and `TapEvent` rejects it
                // alongside `batch`, so a batch trigger can never carry it.
                val tappedIds = tapEvents.filter { event ->
                    if (reason != null && event.reason != reason) return@filter false
                    if (tapper == null) return@filter true
                    event.tappedById != null &&
                        matcher.matchesPlayer(state, tapper, event.tappedById, entry.controllerId)
                }.map { it.entityId }
                if (tappedIds.isEmpty()) continue

                val filter = trigger.filter
                val matched = if (filter == null) {
                    tappedIds
                } else {
                    val predicateContext = com.wingedsheep.engine.handlers.PredicateContext(
                        controllerId = entry.controllerId,
                        sourceId = entry.entityId
                    )
                    tappedIds.filter { tappedId ->
                        predicateEvaluator.matches(
                            state, state.projectedState, tappedId, filter, predicateContext
                        )
                    }
                }
                if (matched.isEmpty()) continue

                // Fire once for the whole batch; bind the first matching permanent as the triggering
                // entity so any "it" payoff has a referent (CR 603.2c).
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entry.entityId,
                        sourceName = entry.cardComponent.name,
                        controllerId = entry.controllerId,
                        triggerContext = TriggerContext(triggeringEntityId = matched.first())
                    )
                )
            }
        }
    }

    /**
     * Detect "whenever you untap one or more permanents during your untap step" batching triggers
     * (`UntapEvent(batch = true)`, ANY binding — The Millennium Calendar). The untap step untaps all
     * of a player's permanents at once, emitting several [UntappedEvent]s in one batch; this fires
     * the trigger **once** for that batch, not once per permanent (the over-count the per-event path
     * — which skips batch untaps — would produce). The matching untapped permanents are exposed as
     * `capturedEntityIds` (seeded into the resolving ability's pipeline under
     * `PipelineState.TRIGGER_CAPTURED_COLLECTION`) so a "put that many counters" payoff reads the
     * count via `DynamicAmount.DistinctEntitiesInCollections(TRIGGER_CAPTURED_COLLECTION)`.
     *
     * The "during your untap step" restriction is enforced here rather than as a `triggerRestriction`:
     * the untap step advances straight to upkeep (no priority), so by the time these events reach
     * detection `state.step` is already `UPKEEP` and an `IsInStep(UNTAP)` intervening-if would read
     * false. The reliable "these untaps are the untap step's turn-based action" signal is instead the
     * `UPKEEP` `StepChangedEvent` bundled in the same event batch (the untap step emits no
     * `StepChangedEvent` of its own here) — or, on the `MAY_NOT_UNTAP` keep-tapped decision resume,
     * `state.step` still being `UNTAP`. "Your" scopes to the trigger controller being the active
     * player whose untap step just ran (so an opponent-turn Seedborn Muse untap of your permanents
     * does not fire it), and a later upkeep-triggered untap resolves in its own batch (no `UPKEEP`
     * `StepChangedEvent`) so it is correctly excluded.
     */
    private fun detectUntapBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        val untappedIds = events.filterIsInstance<UntappedEvent>().map { it.entityId }
        if (untappedIds.isEmpty()) return
        // "during your untap step": only the untap step's turn-based untap fires this trigger — not
        // instant-speed untaps, nor an opponent-turn Seedborn Muse untap of your permanents. The
        // untap step grants no priority and advances straight to upkeep without its own priority
        // point, so in the normal flow these UntappedEvents reach detection once the step is already
        // UPKEEP, bundled in the same event batch as the entry into upkeep (a StepChangedEvent whose
        // newStep is UPKEEP; the untap step itself emits no StepChangedEvent here). The rare
        // MAY_NOT_UNTAP keep-tapped decision instead resumes and detects them while the step is still
        // UNTAP. Either signal marks the beginning-of-turn untap; a later upkeep-triggered untap
        // resolves in its own batch (no UPKEEP StepChangedEvent) and is correctly excluded.
        val isUntapStepBatch = state.step == Step.UNTAP ||
            events.any { it is StepChangedEvent && it.newStep == Step.UPKEEP }
        if (!isUntapStepBatch) return
        val activePlayer = state.activePlayerId ?: return

        for (entry in index.getEntitiesForCategory(TriggerCategory.UNTAPPED)) {
            // "your untap step" — the observer must be on the active team whose untap step just ran
            // (both heads untap in a shared team turn, CR 805.4).
            if (!state.isActiveTurnFor(entry.controllerId)) continue
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.UntapEvent || !trigger.batch) continue
                // Batch untap triggers are "one or more … become untapped" observers (ANY binding).
                if (ability.binding != TriggerBinding.ANY) continue

                val filter = trigger.filter
                val matched = if (filter == null) {
                    untappedIds
                } else {
                    val predicateContext = com.wingedsheep.engine.handlers.PredicateContext(
                        controllerId = entry.controllerId,
                        sourceId = entry.entityId
                    )
                    untappedIds.filter { untappedId ->
                        predicateEvaluator.matches(
                            state, state.projectedState, untappedId, filter, predicateContext
                        )
                    }
                }
                if (matched.isEmpty()) continue

                // Fire once for the whole batch; expose the untapped permanents as the captured
                // collection so "put that many counters" can count them (CR 603.2c). Bind the first
                // matching permanent as the triggering entity for any "it" referent.
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entry.entityId,
                        sourceName = entry.cardComponent.name,
                        controllerId = entry.controllerId,
                        triggerContext = TriggerContext(
                            triggeringEntityId = matched.first(),
                            capturedEntityIds = matched
                        )
                    )
                )
            }
        }
    }

    /**
     * Detect "whenever you put one or more counters on one or more [permanents]" batching triggers
     * (`CountersPlacedEvent(batch = true)` — Invisible Woman, Sue Storm).
     *
     * One effect that puts counters on several permanents emits one [CountersAddedEvent] per
     * recipient, and a placement of several counters on one permanent emits a single event with
     * `amount > 1`. CR 603.2c makes both of those *one* occurrence of the trigger event for a batch
     * template, so this fires the ability **once** for the whole detection pass — the over-count the
     * per-event path (which skips batch placements) would produce for the multi-recipient case.
     *
     * Every axis of the pattern *narrows* the batch rather than discarding it, mirroring
     * [detectTapBatchTriggers]: a batch that also placed counters of another type, by another
     * player, or on non-matching permanents still fires, once, on its matching placements alone.
     * The narrowing itself is [TriggerMatcher.matchesCountersPlacedAxes] — the same function the
     * per-permanent path uses, so the two multiplicities can never disagree about which placements
     * count (the shape [DamageTriggerDetector.detectDamageObserverBatchTriggers] uses).
     *
     * A permanent that can't have counters put on it (`ProjectedState.canReceiveCounters`) stays out
     * of the batch only when the executor doing the placing checks that prohibition before emitting:
     * [com.wingedsheep.engine.handlers.effects.permanent.counters.AddCountersExecutor] and its
     * single-target siblings do, but `AddCountersToCollectionExecutor` and
     * `DistributeCountersAmongTargetsExecutor` — the multi-recipient paths this batch template most
     * often observes — do not, and a no-op placement from those would enter the batch. That gap is
     * per-executor and pre-dates this pass (the counters are wrongly added to the component too, not
     * just reported), so this is not the place to fix it; it is recorded here so no one reads a
     * guarantee into the batch that the engine doesn't provide.
     *
     * Separate resolutions are separate detection passes and so separate batches: two effects each
     * placing counters in the same turn fire the trigger twice.
     */
    private fun detectCountersPlacedBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        val counterEvents = events.filterIsInstance<CountersAddedEvent>()
        if (counterEvents.isEmpty()) return

        for (entry in index.getEntitiesForCategory(TriggerCategory.COUNTERS_ADDED)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.CountersPlacedEvent || !trigger.batch) continue

                // "one or more **other** …" excludes counters that landed on the source itself;
                // SELF is the degenerate single-permanent batch ("counters put on this"). Unlike
                // the ANY-only tap/untap batch passes, all three bindings are supported here.
                val matched = counterEvents.filter { event ->
                    matcher.matchesCountersPlacedAxes(
                        trigger, event, ability.binding, entry.entityId, entry.controllerId, state
                    )
                }
                if (matched.isEmpty()) continue

                // Fire once for the whole batch; bind the first matching recipient as the triggering
                // entity so any "it" payoff has a referent (CR 603.2c), and expose the recipients as
                // the captured collection so a "for each of those creatures" payoff can count them
                // (as [detectUntapBatchTriggers] does). `counterCount` is the batch total — the
                // per-event path reports the counters of its single placement, so the batch's
                // analogue is the counters of all the placements it collapsed.
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entry.entityId,
                        sourceName = entry.cardComponent.name,
                        controllerId = entry.controllerId,
                        triggerContext = TriggerContext(
                            triggeringEntityId = matched.first().entityId,
                            capturedEntityIds = matched.map { it.entityId }.distinct(),
                            counterCount = matched.sumOf { it.amount }
                        )
                    )
                )
            }
        }
    }

    private fun sacrificedPermanentMatchesFilter(
        state: GameState,
        permanentId: EntityId,
        filter: GameObjectFilter
    ): Boolean {
        if (filter == GameObjectFilter.Any) return true
        val entity = state.getEntity(permanentId) ?: return false
        val cardComponent = entity.get<CardComponent>() ?: return false
        return filter.cardPredicates.all { predicate ->
            when (predicate) {
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsCreature ->
                    cardComponent.typeLine.isCreature
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsArtifact ->
                    cardComponent.typeLine.isArtifact
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasSubtype ->
                    cardComponent.typeLine.hasSubtype(predicate.subtype)
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsToken ->
                    entity.has<TokenComponent>()
                is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNontoken ->
                    !entity.has<TokenComponent>()
                else -> true
            }
        }
    }

    /**
     * Detect "whenever one or more [creatures] you control deal combat damage to a player"
     * batching triggers. Groups all combat damage-to-player events and fires matching
     * triggers at most once per observer, regardless of how many creatures connected.
     *
     * A **face-down** attacker counts. It is a creature (a 2/2 with no name, no subtypes, no
     * colors and mana value 0 — CR 708.2), so it satisfies an unfiltered "creatures you control"
     * batch trigger, and the filtered variants are decided by [predicateEvaluator] alone: that
     * evaluator masks every printed characteristic behind `isFaceDown`, name included, so a
     * "Bird you control"-style filter still excludes it without a separate guard here. This used
     * to carry a blanket `FaceDownComponent` skip, which pre-dated the masking and silently made
     * unfiltered batch triggers (Kastral, the Windcrested; Yarus, Roar of the Old Gods) miss
     * whenever a morphed, manifested, disguised or cloaked creature connected.
     */
    private fun detectCombatDamageBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        projected: ProjectedState,
        index: TriggerIndex
    ) {
        // Collect all combat damage-to-player events, grouped by the controller of the damage
        // source (offensive batch) and, separately, by the damaged player (defensive batch).
        data class CombatDamageInfo(val sourceId: EntityId, val targetPlayerId: EntityId)
        val combatDamageByController = mutableMapOf<EntityId, MutableList<CombatDamageInfo>>()
        val combatDamageByDamagedPlayer = mutableMapOf<EntityId, MutableList<CombatDamageInfo>>()
        for (event in events) {
            if (event is DamageDealtEvent && event.isCombatDamage && event.sourceId != null &&
                event.targetId in state.turnOrder) {
                val sourceContainer = state.getEntity(event.sourceId) ?: continue
                val controller = sourceContainer.get<ControllerComponent>()?.playerId ?: continue
                val info = CombatDamageInfo(event.sourceId, event.targetId)
                combatDamageByController.getOrPut(controller) { mutableListOf() }.add(info)
                combatDamageByDamagedPlayer.getOrPut(event.targetId) { mutableListOf() }.add(info)
            }
        }
        if (combatDamageByController.isEmpty()) return

        for (entry in index.getEntitiesForCategory(TriggerCategory.COMBAT_DAMAGE_BATCH)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger

                // Defensive variant: "one or more creatures deal combat damage to you" — group by
                // the damaged player (the observer's controller) instead of the source controller.
                if (trigger is EventPattern.OneOrMoreDealCombatDamageToYouEvent) {
                    val controllerId = entry.controllerId
                    val damageEvents = combatDamageByDamagedPlayer[controllerId] ?: continue
                    val firstMatchingInfo = damageEvents.firstOrNull { info ->
                        val sourceContainer = state.getEntity(info.sourceId) ?: return@firstOrNull false
                        sourceContainer.get<CardComponent>() ?: return@firstOrNull false
                        if (!projected.isCreature(info.sourceId)) return@firstOrNull false
                        predicateEvaluator.matches(
                            state, projected, info.sourceId, trigger.sourceFilter,
                            PredicateContext(controllerId = controllerId, sourceId = entry.entityId)
                        )
                    }
                    if (firstMatchingInfo != null) {
                        triggers.add(
                            PendingTrigger(
                                ability = ability,
                                sourceId = entry.entityId,
                                sourceName = entry.cardComponent.name,
                                controllerId = controllerId,
                                triggerContext = TriggerContext(triggeringEntityId = firstMatchingInfo.sourceId)
                            )
                        )
                    }
                    continue
                }

                if (trigger !is EventPattern.OneOrMoreDealCombatDamageToPlayerEvent) continue

                val controllerId = entry.controllerId
                val damageEvents = combatDamageByController[controllerId] ?: continue

                // Find every matching damage event. Damage events are already grouped by source
                // controller and matched to observers with the same controller, so "you control"
                // is satisfied; we still run the full filter via the canonical evaluator so state
                // predicates (e.g. +1/+1 counters) and any other card/controller predicates are
                // honored — not just the handful of card predicates handled inline.
                val matchingInfos = damageEvents.filter { info ->
                    val sourceContainer = state.getEntity(info.sourceId) ?: return@filter false
                    sourceContainer.get<CardComponent>() ?: return@filter false
                    if (!projected.isCreature(info.sourceId)) return@filter false

                    predicateEvaluator.matches(
                        state,
                        projected,
                        info.sourceId,
                        trigger.sourceFilter,
                        PredicateContext(controllerId = controllerId, sourceId = entry.entityId)
                    )
                }

                // "deal combat damage to a player" batches per damaged player: the ability
                // triggers once for each player dealt combat damage by one or more matching
                // creatures (multiple matching creatures hitting the same player still fire a
                // single trigger). `triggeringPlayerId` is set to the damaged player so effects
                // can reference "that player" (Vaan, Street Thief); `triggeringEntityId` is an
                // arbitrary matching source for that player — batch triggers don't dispatch
                // per source, so cards needing per-source dispatch use a singular trigger event.
                for ((damagedPlayerId, infos) in matchingInfos.groupBy { it.targetPlayerId }) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = entry.entityId,
                            sourceName = entry.cardComponent.name,
                            controllerId = controllerId,
                            triggerContext = TriggerContext(
                                triggeringEntityId = infos.first().sourceId,
                                triggeringPlayerId = damagedPlayerId
                            )
                        )
                    )
                }
            }
        }
    }

    /**
     * Detect "whenever one or more creatures you control leave the battlefield without dying"
     * batching triggers. Groups zone changes from battlefield to non-graveyard zones and fires
     * matching triggers at most once per observer, regardless of how many creatures left.
     */
    private fun detectLeaveBattlefieldWithoutDyingBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        // Collect all zone changes from battlefield to non-graveyard zones, grouped by owner
        // (owner approximates controller; the entity has already left the battlefield)
        data class LeaveInfo(val entityId: EntityId, val cardComponent: CardComponent)
        val leavesByController = mutableMapOf<EntityId, MutableList<LeaveInfo>>()
        for (event in events) {
            if (event is ZoneChangeEvent && event.fromZone == Zone.BATTLEFIELD &&
                event.toZone != Zone.GRAVEYARD) {
                val entity = state.getEntity(event.entityId) ?: continue
                val card = entity.get<CardComponent>() ?: continue
                if (!card.typeLine.isCreature) continue
                leavesByController.getOrPut(event.ownerId) { mutableListOf() }
                    .add(LeaveInfo(event.entityId, card))
            }
        }
        if (leavesByController.isEmpty()) return

        for (entry in index.getEntitiesForCategory(TriggerCategory.LEAVE_WITHOUT_DYING)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.LeaveBattlefieldWithoutDyingEvent) continue

                val controllerId = entry.controllerId
                val controllerLeaves = leavesByController[controllerId] ?: continue

                // Filter out self if excludeSelf is set
                val relevantLeaves = if (trigger.excludeSelf) {
                    controllerLeaves.filter { it.entityId != entry.entityId }
                } else {
                    controllerLeaves
                }
                if (relevantLeaves.isEmpty()) continue

                // Check if any leaving creature matches the filter
                val hasMatch = relevantLeaves.any { info ->
                    trigger.filter.cardPredicates.all { predicate ->
                        when (predicate) {
                            is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsCreature ->
                                info.cardComponent.typeLine.isCreature
                            is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasSubtype ->
                                info.cardComponent.typeLine.hasSubtype(predicate.subtype)
                            else -> true
                        }
                    }
                }

                if (hasMatch) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = entry.entityId,
                            sourceName = entry.cardComponent.name,
                            controllerId = controllerId,
                            triggerContext = TriggerContext()
                        )
                    )
                }
            }
        }
    }

    private data class CreatureDeathInfo(
        val entityId: EntityId,
        val typeLine: com.wingedsheep.sdk.core.TypeLine?,
        /** Power the instant the creature left the battlefield (CR 603.10 LKI), for batch power sums. */
        val lastKnownPower: Int? = null,
        /** Whether the dead creature was a token, so the filter's nontoken/token predicate is honored. */
        val wasToken: Boolean = false
    )

    /**
     * Detect "whenever one or more [other] creatures you control die" batching triggers
     * (e.g., Vengeful Townsfolk).
     *
     * Groups battlefield→graveyard zone changes by each dying creature's last-known controller
     * and fires the trigger at most once per qualifying controller, regardless of how many
     * creatures died simultaneously. This is the once-per-batch shape a per-creature death
     * trigger (one [ZoneChangeEvent] each) cannot express — a board wipe killing five of a
     * player's creatures fires this once, not five times.
     *
     * Controller is read from [ZoneChangeEvent.lastKnownController] (falling back to owner),
     * since the creature has already left the battlefield. The creature's type line comes from
     * [ZoneChangeEvent.lastKnownTypeLine] so it survives the 704.5s token cleanup that can remove
     * a dead token from the graveyard in the same pass.
     *
     * Two source populations are considered: permanents that survived the batch (taken from the
     * post-batch battlefield index) and — for Rule 603.10 "look back in time" — a source that
     * itself died in this same batch, recovered from its last-known card definition since it is no
     * longer on the battlefield (mirrors [DeathAndLeaveTriggerDetector.detectSimultaneousDeathTriggers]).
     */
    private fun detectCreaturesDiedBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        // Collect creature deaths (battlefield → graveyard), grouped by last-known controller.
        val deathsByController = mutableMapOf<EntityId, MutableList<CreatureDeathInfo>>()
        for (event in events) {
            if (event !is ZoneChangeEvent) continue
            if (event.fromZone != Zone.BATTLEFIELD || event.toZone != Zone.GRAVEYARD) continue
            val typeLine = event.lastKnown?.typeLine
                ?: state.getEntity(event.entityId)?.get<CardComponent>()?.typeLine
            if (typeLine?.isCreature != true) continue
            val controllerId = event.lastKnown?.controllerId ?: event.ownerId
            deathsByController.getOrPut(controllerId) { mutableListOf() }
                .add(
                    CreatureDeathInfo(
                        entityId = event.entityId,
                        typeLine = typeLine,
                        lastKnownPower = event.lastKnown?.power,
                        wasToken = event.lastKnown?.wasToken ?: false
                    )
                )
        }
        if (deathsByController.isEmpty()) return

        // (1) Sources that survived the batch — taken from the (post-batch) battlefield index.
        for (entry in index.getEntitiesForCategory(TriggerCategory.CREATURES_DIED_BATCH)) {
            for (ability in entry.abilities) {
                fireCreaturesDiedBatchTrigger(
                    state = state,
                    ability = ability,
                    sourceId = entry.entityId,
                    sourceName = entry.cardComponent.name,
                    controllerId = entry.controllerId,
                    deathsByController = deathsByController,
                    triggers = triggers
                )
            }
        }

        // (2) Rule 603.10 "look back in time": a source that itself died in this same batch must
        // still see the *other* creatures that died alongside it. The index is built from the
        // current (post-batch) battlefield, so such a source is absent from it — recover its
        // abilities from its last-known card definition, exactly as detectSimultaneousDeathTriggers
        // does for the per-creature path. (For Vengeful Townsfolk the on-self +1/+1 is a harmless
        // no-op once it is in the graveyard, but a non-self payoff — draw a card, make a token,
        // deal damage — would otherwise be silently dropped on a board wipe that also kills it.)
        for (event in events) {
            if (event !is ZoneChangeEvent) continue
            if (event.fromZone != Zone.BATTLEFIELD || event.toZone != Zone.GRAVEYARD) continue
            // Still on the battlefield → already covered by the index path above.
            if (event.entityId in state.getBattlefield()) continue
            val container = state.getEntity(event.entityId)
            // Face-down permanents have no abilities (Rule 708.2).
            if (container?.has<FaceDownComponent>() == true) continue
            val cardDefId = container?.get<CardComponent>()?.cardDefinitionId
                ?: event.lastKnown?.cardDefinitionId ?: continue
            val controllerId = event.lastKnown?.controllerId ?: event.ownerId
            val sourceName = container?.get<CardComponent>()?.name ?: event.entityName
            for (ability in abilityResolver.getTriggeredAbilities(event.entityId, cardDefId, state, index.statics)) {
                if (ability.trigger !is EventPattern.CreaturesYouControlDiedEvent) continue
                fireCreaturesDiedBatchTrigger(
                    state = state,
                    ability = ability,
                    sourceId = event.entityId,
                    sourceName = sourceName,
                    controllerId = controllerId,
                    deathsByController = deathsByController,
                    triggers = triggers
                )
            }
        }
    }

    /**
     * Evaluate a single batched "whenever one or more [filtered] creatures die" ability against
     * the batch of deaths grouped by controller, firing it at most once. Shared by the
     * surviving-source (battlefield index) and dead-source (Rule 603.10 look-back) paths.
     *
     * The filter's controller predicate scopes which players' creature deaths count, mirroring the
     * enter-batch trigger: no predicate (or `ControlledByYou`) means "creatures you control",
     * `ControlledByOpponent` scopes to the observer's opponents (Spiteful Banditry).
     */
    private fun fireCreaturesDiedBatchTrigger(
        state: GameState,
        ability: TriggeredAbility,
        sourceId: EntityId,
        sourceName: String,
        controllerId: EntityId,
        deathsByController: Map<EntityId, List<CreatureDeathInfo>>,
        triggers: MutableList<PendingTrigger>
    ) {
        val trigger = ability.trigger
        if (trigger !is EventPattern.CreaturesYouControlDiedEvent) return

        // The filter's controller predicate scopes which players' deaths count, relative to the
        // observer (the trigger's controller). Defaults to "you control".
        val controllerPredicate = trigger.filter.controllerPredicate
        fun controllerMatches(deathControllerId: EntityId): Boolean = when (controllerPredicate) {
            null, com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByYou ->
                deathControllerId == controllerId
            com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByOpponent ->
                deathControllerId in state.getOpponents(controllerId)
            // "whenever one or more creatures die" — any controller's creatures count (Chainsaw).
            com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByAny -> true
            else -> controllerPredicate.evaluateWith { leaf ->
                when (leaf) {
                    com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByYou ->
                        deathControllerId == controllerId
                    com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByOpponent ->
                        deathControllerId in state.getOpponents(controllerId)
                    else -> null
                }
            }
        }

        val scopedDeaths = deathsByController.entries
            .filter { controllerMatches(it.key) }
            .flatMap { it.value }

        // "one or more *other* creatures you control die" excludes the source's own death.
        val relevantDeaths = if (trigger.excludeSelf) {
            scopedDeaths.filter { it.entityId != sourceId }
        } else {
            scopedDeaths
        }
        if (relevantDeaths.isEmpty()) return

        // Which of the batch's deaths satisfy the trigger's filter. Evaluated against last-known
        // information (the creatures are already in the graveyard) — including the token/nontoken
        // predicate, so "one or more *nontoken* creatures you control die" (The Skullspore Nexus,
        // Ghoulish Procession) ignores dying tokens both for firing and for the power sum below.
        fun deathMatchesFilter(info: CreatureDeathInfo): Boolean =
            trigger.filter.cardPredicates.all { predicate ->
                when (predicate) {
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsCreature ->
                        info.typeLine?.isCreature == true
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasSubtype ->
                        info.typeLine?.hasSubtype(predicate.subtype) == true
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNontoken ->
                        !info.wasToken
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsToken ->
                        info.wasToken
                    else -> true
                }
            }

        val matchingDeaths = relevantDeaths.filter { deathMatchesFilter(it) }
        if (matchingDeaths.isEmpty()) return

        // "the total power of those creatures" — CR uses each creature's last-known power (buffs and
        // counters included); a graveyard card would report only printed power. Individual powers can
        // be negative, so the sum can be too (a token whose base P/T is that sum dies to state-based
        // actions if it is 0 or less).
        val batchTotalPower = matchingDeaths.sumOf { it.lastKnownPower ?: 0 }

        triggers.add(
            PendingTrigger(
                ability = ability,
                sourceId = sourceId,
                sourceName = sourceName,
                controllerId = controllerId,
                triggerContext = TriggerContext(diedBatchTotalPower = batchTotalPower)
            )
        )
    }

    /**
     * Detect "whenever one or more [filtered] permanents you control enter the battlefield"
     * batching triggers.
     *
     * Groups ZoneChangeEvent with toZone == BATTLEFIELD by controller and fires the trigger
     * at most once per observer, regardless of how many permanents entered.
     */
    private fun detectPermanentsEnteredBatchTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>,
        index: TriggerIndex
    ) {
        // Collect all permanents that entered the battlefield this batch, with their controller.
        data class EnterInfo(
            val entityId: EntityId,
            val cardComponent: CardComponent,
            val isToken: Boolean,
            val controllerId: EntityId
        )
        val enters = mutableListOf<EnterInfo>()
        for (event in events) {
            if (event is ZoneChangeEvent && event.toZone == Zone.BATTLEFIELD) {
                val entity = state.getEntity(event.entityId) ?: continue
                val card = entity.get<CardComponent>() ?: continue
                val isToken = entity.has<TokenComponent>()
                val controllerId = entity.get<ControllerComponent>()?.playerId ?: event.ownerId
                enters.add(EnterInfo(event.entityId, card, isToken, controllerId))
            }
        }
        if (enters.isEmpty()) return

        fun matchesCardPredicates(info: EnterInfo, filter: GameObjectFilter): Boolean =
            filter.cardPredicates.all { predicate ->
                when (predicate) {
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsCreature -> info.cardComponent.typeLine.isCreature
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNoncreature -> !info.cardComponent.typeLine.isCreature
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNonland -> !info.cardComponent.typeLine.isLand
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNonartifact -> !info.cardComponent.typeLine.isArtifact
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsPermanent -> info.cardComponent.typeLine.isPermanent
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasSubtype -> info.cardComponent.typeLine.hasSubtype(predicate.subtype)
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.HasAnyOfSubtypes ->
                        predicate.subtypes.any { info.cardComponent.typeLine.hasSubtype(it) }
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsArtifact -> info.cardComponent.typeLine.isArtifact
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsEnchantment -> info.cardComponent.typeLine.isEnchantment
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsToken -> info.isToken
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsNontoken -> !info.isToken
                    is com.wingedsheep.sdk.scripting.predicates.CardPredicate.IsDoubleFaced ->
                        info.cardComponent.isDoubleFaced
                    else -> true
                }
            }

        for (entry in index.getEntitiesForCategory(TriggerCategory.PERMANENTS_ENTERED_BATCH)) {
            for (ability in entry.abilities) {
                val trigger = ability.trigger
                if (trigger !is EventPattern.PermanentsEnteredEvent) continue

                val observerId = entry.controllerId
                // The filter's controller predicate scopes which players' permanents count.
                // No predicate defaults to "you control" (the historical PermanentsEnteredEvent
                // semantics — "one or more permanents you control enter"); ControlledByOpponent
                // scopes to the observer's opponents (Kambal); ControlledByAny / others fall back
                // to the shared three-valued fold against the observer.
                val controllerPredicate = trigger.filter.controllerPredicate
                fun controllerMatches(enterControllerId: EntityId): Boolean = when (controllerPredicate) {
                    null, com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByYou ->
                        enterControllerId == observerId
                    com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByOpponent ->
                        enterControllerId in state.getOpponents(observerId)
                    else -> controllerPredicate.evaluateWith { leaf ->
                        when (leaf) {
                            com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByYou ->
                                enterControllerId == observerId
                            com.wingedsheep.sdk.scripting.predicates.ControllerPredicate.ControlledByOpponent ->
                                enterControllerId in state.getOpponents(observerId)
                            else -> null
                        }
                    }
                }

                // The permanents in this batch matching both the card filter and the controller
                // scope — these "caused" the trigger and are exposed to the payoff (CR 603.3b
                // groups them into a single batch trigger). "One or more OTHER …" wordings
                // (excludeSource) never count the trigger's own source entering.
                val matching = enters.filter { info ->
                    (!trigger.excludeSource || info.entityId != entry.entityId) &&
                        controllerMatches(info.controllerId) &&
                        matchesCardPredicates(info, trigger.filter)
                }

                if (matching.isNotEmpty()) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = entry.entityId,
                            sourceName = entry.cardComponent.name,
                            controllerId = observerId,
                            triggerContext = TriggerContext(
                                capturedEntityIds = matching.map { it.entityId }
                            )
                        )
                    )
                }
            }
        }
    }

    /**
     * Detect "When this Class becomes level N" triggers.
     *
     * When a ClassLevelChangedEvent is emitted, checks if the newly gained class level
     * has any ETB triggers (trigger = ZoneChangeEvent(to = BATTLEFIELD) with SELF binding)
     * and fires them.
     */
    private fun detectClassLevelUpTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        for (event in events) {
            if (event !is ClassLevelChangedEvent) continue

            val entity = state.getEntity(event.entityId) ?: continue
            val card = entity.get<CardComponent>() ?: continue
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue

            // Find the class level that was just gained
            val levelAbility = cardDef.classLevels.find { it.level == event.newLevel } ?: continue

            // Check for ETB triggers in the newly gained level
            for (ability in levelAbility.triggeredAbilities) {
                val trigger = ability.trigger
                // "When this Class becomes level N" is modeled as an ETB trigger
                if (trigger is EventPattern.ZoneChangeEvent &&
                    trigger.to == Zone.BATTLEFIELD &&
                    ability.binding == TriggerBinding.SELF
                ) {
                    triggers.add(
                        PendingTrigger(
                            ability = ability,
                            sourceId = event.entityId,
                            sourceName = card.name,
                            controllerId = event.controllerId,
                            triggerContext = TriggerContext()
                        )
                    )
                }
            }
        }
    }

    /**
     * Detect Saga chapter triggers from lore counter additions.
     *
     * When lore counters are added to a Saga, checks which chapter abilities should trigger.
     * The SagaComponent in the state has already been updated with the newly triggered chapters
     * (by TurnManager.addLoreCountersToSagas or StackResolver.enterPermanentOnBattlefield),
     * so we use the current lore count and the triggered chapters set to determine which
     * chapters to fire.
     */
    private fun detectSagaChapterTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        val registry = cardRegistry

        // Find all LORE counter addition events
        val loreEvents = events.filterIsInstance<CountersAddedEvent>().filter { it.counterType == "LORE" }
        if (loreEvents.isEmpty()) return

        for (event in loreEvents) {
            val entityId = event.entityId
            val container = state.getEntity(entityId) ?: continue
            val cardComponent = container.get<CardComponent>() ?: continue
            val sagaComponent = container.get<SagaComponent>() ?: continue
            val counters = container.get<CountersComponent>() ?: continue

            val cardDef = registry.getCard(cardComponent.cardDefinitionId) ?: continue
            val sagaChapters = cardDef.sagaChapters
            if (sagaChapters.isEmpty()) continue

            val loreCount = counters.getCount(CounterType.LORE)
            // The previous lore count is current minus what was just added
            val previousLoreCount = loreCount - event.amount
            val controllerId = container.get<ControllerComponent>()?.playerId
                ?: cardComponent.ownerId ?: continue
            val finalChapter = sagaChapters.maxOf { it.chapter }

            // Fire chapters that are newly reached by this counter addition
            for (chapter in sagaChapters.sortedBy { it.chapter }) {
                // Chapter triggers if lore count now >= chapter number
                // AND it wasn't already triggered before this counter addition
                if (loreCount >= chapter.chapter && previousLoreCount < chapter.chapter) {
                    // Create a triggered ability for this chapter
                    val chapterAbility = TriggeredAbility.create(
                        trigger = EventPattern.StepEvent(Step.PRECOMBAT_MAIN, Player.You),
                        binding = TriggerBinding.SELF,
                        effect = chapter.effect,
                        targetRequirement = chapter.targetRequirement,
                        additionalTargetRequirements = chapter.additionalTargetRequirements
                    )

                    triggers.add(
                        PendingTrigger(
                            ability = chapterAbility,
                            sourceId = entityId,
                            sourceName = cardComponent.name,
                            controllerId = controllerId,
                            triggerContext = TriggerContext(),
                            // Mark this as a Saga chapter ability so a SagaChapterResolvedEvent is
                            // emitted when it resolves (Tom Bombadil's "final chapter resolves" cue).
                            sagaChapterInfo = SagaChapterInfo(
                                chapterNumber = chapter.chapter,
                                finalChapterNumber = finalChapter
                            )
                        )
                    )
                }
            }
        }
    }

    /**
     * Duplicate ETB and LTB triggers for [AdditionalETBOrLTBTriggers] static abilities
     * (Naban, Panharmonicon, Starfield Vocalist, Gandalf the White).
     *
     * For each ZoneChangeEvent whose `toZone == BATTLEFIELD` (entering) or whose `fromZone
     * == BATTLEFIELD` (leaving), checks every battlefield permanent whose static matches the
     * filter and the direction. For each match, duplicates triggers belonging to the
     * static's controller whose triggering entity is the cause and whose trigger pattern
     * matches the direction.
     *
     * Multiple copies are additive: N copies add N extra copies of each trigger.
     */
    private fun duplicateETBOrLTBTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        val registry = cardRegistry
        val projected = state.projectedState

        // Battlefield-boundary-crossing events: pure entering, or pure leaving. A same-batch
        // zone change that goes battlefield → battlefield is not a thing the engine emits, so
        // we don't have to disambiguate.
        val zoneEvents = events.filterIsInstance<ZoneChangeEvent>().filter {
            it.toZone == Zone.BATTLEFIELD ||
                (it.fromZone == Zone.BATTLEFIELD && it.toZone != Zone.BATTLEFIELD)
        }
        if (zoneEvents.isEmpty()) return

        data class Doubler(
            val controllerId: EntityId,
            val filter: GameObjectFilter,
            val sourceId: EntityId,
            val mustBeYouControl: Boolean,
            val directions: Set<BattlefieldDirection>,
        )
        val doublers = mutableListOf<Doubler>()

        for (permanentId in state.getBattlefield()) {
            val container = state.getEntity(permanentId) ?: continue
            val card = container.get<CardComponent>() ?: continue
            if (container.has<FaceDownComponent>()) continue
            val controllerId = projected.getController(permanentId) ?: continue
            val cardDef = registry.getCard(card.cardDefinitionId) ?: continue

            // Route through RoomFaceStatics so a doubler printed on an *unlocked* Room face
            // (CR 709.5) is honoured, not just one in the card's top-level script.
            for (ability in RoomFaceStatics.activeStaticAbilities(container, cardDef)) {
                if (ability is AdditionalETBOrLTBTriggers) {
                    doublers.add(
                        Doubler(
                            controllerId = controllerId,
                            filter = ability.filter,
                            sourceId = permanentId,
                            mustBeYouControl = ability.mustBeYouControl,
                            directions = ability.directions,
                        )
                    )
                }
            }
        }

        if (doublers.isEmpty()) return

        val duplicates = mutableListOf<PendingTrigger>()

        for (event in zoneEvents) {
            val direction = if (event.toZone == Zone.BATTLEFIELD) BattlefieldDirection.ENTERING
                else BattlefieldDirection.LEAVING
            val causeEntityId = event.entityId

            for (doubler in doublers) {
                if (direction !in doubler.directions) continue

                if (doubler.mustBeYouControl) {
                    // Entering → consult projected controller (entity is on the battlefield now).
                    // Leaving → projected state has no entry; use the last-known controller
                    // snapshotted on the ZoneChangeEvent, falling back to owner.
                    val causeController = when (direction) {
                        BattlefieldDirection.ENTERING ->
                            projected.getController(causeEntityId) ?: event.ownerId
                        BattlefieldDirection.LEAVING ->
                            event.lastKnown?.controllerId ?: event.ownerId
                    }
                    if (causeController != doubler.controllerId) continue
                }

                if (doubler.filter != GameObjectFilter.Any) {
                    if (!causeMatchesDoublerFilter(
                            state, projected, event, direction,
                            doubler.filter, doubler.controllerId, doubler.sourceId
                        )) continue
                }

                for (trigger in triggers) {
                    if (trigger.triggerContext.triggeringEntityId != causeEntityId) continue
                    if (trigger.controllerId != doubler.controllerId) continue

                    val triggerEvent = trigger.ability.trigger
                    if (triggerEvent !is EventPattern.ZoneChangeEvent) continue
                    when (direction) {
                        BattlefieldDirection.ENTERING ->
                            if (triggerEvent.to != Zone.BATTLEFIELD) continue
                        BattlefieldDirection.LEAVING ->
                            if (triggerEvent.from != Zone.BATTLEFIELD) continue
                    }

                    duplicates.add(trigger)
                }
            }
        }

        triggers.addAll(duplicates)
    }

    /**
     * Does the entity that crossed the battlefield boundary in [event] match the doubler's [filter]?
     *
     * Entering: the cause is live on the battlefield, so projected state is authoritative — match
     * directly.
     *
     * Leaving: the cause is no longer on the battlefield. Its base entity (now in the graveyard)
     * carries only its printed type line — the projected types it had on the battlefield are gone —
     * and a token cause may even have been swept by 704.5d. Per CR 603.10a leaves-the-battlefield
     * checks look back in time, so we evaluate the filter against the entity's last-known type line
     * (snapshotted on the [ZoneChangeEvent]), mirroring `TriggerMatcher.matchesZoneChangeTrigger`.
     * We overlay that type line onto the cause entity (synthesizing a minimal one if it was swept)
     * and reuse the full filter engine, so `or`/color/subtype predicates all resolve correctly.
     * Without this, a creature that was an artifact/legendary only via a continuous effect (e.g.
     * a creature turned into an artifact, then destroyed) would silently fail Gandalf the White's
     * `Artifact ∨ Legendary` filter and the trigger it caused wouldn't be doubled.
     */
    private fun causeMatchesDoublerFilter(
        state: GameState,
        projected: ProjectedState,
        event: ZoneChangeEvent,
        direction: BattlefieldDirection,
        filter: GameObjectFilter,
        controllerId: EntityId,
        sourceId: EntityId
    ): Boolean {
        val context = PredicateContext(controllerId = controllerId, sourceId = sourceId)

        if (direction == BattlefieldDirection.ENTERING) {
            return predicateEvaluator.matches(state, projected, event.entityId, filter, context)
        }

        val lastKnownTypeLine = event.lastKnown?.typeLine
        val existing = state.getEntity(event.entityId)
        val existingCard = existing?.get<CardComponent>()
        val overlayCard = when {
            existingCard != null ->
                existingCard.copy(typeLine = lastKnownTypeLine ?: existingCard.typeLine)
            lastKnownTypeLine != null -> CardComponent(
                cardDefinitionId = event.lastKnown.cardDefinitionId ?: event.entityName,
                name = event.entityName,
                manaCost = ManaCost.ZERO,
                typeLine = lastKnownTypeLine
            )
            else -> return false
        }
        // Off-battlefield, so the original `projected` has no entry for this id and matches() falls
        // back to the overlaid card's type line. No projection recompute needed.
        val overlayState = state.withEntity(
            event.entityId,
            (existing ?: ComponentContainer.EMPTY).withComponent(overlayCard)
        )
        return predicateEvaluator.matches(overlayState, projected, event.entityId, filter, context)
    }

    /**
     * Duplicate triggers caused by a creature being declared as an attacker for
     * [AdditionalAttackTriggers] static abilities (Windcrag Siege's Mardu mode).
     *
     * The attack-cause analogue of [duplicateETBTriggers]: for each [AttackersDeclaredEvent], if a
     * permanent the doubler controls has an attack-related triggered ability ("whenever a creature
     * attacks" / "whenever you attack") that fired from that event, that trigger fires an additional
     * time per copy. Only the declared attackers matching [AdditionalAttackTriggers.attackerFilter]
     * count as the cause; if the trigger names a specific attacker (per-attacker AttackEvent), that
     * attacker must match.
     *
     * Multiple copies are additive: N copies add N extra firings of each affected trigger.
     */
    private fun duplicateAttackTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        val attackEvents = events.filterIsInstance<AttackersDeclaredEvent>()
        if (attackEvents.isEmpty() || triggers.isEmpty()) return

        val registry = cardRegistry
        val projected = state.projectedState

        data class AttackDoubler(
            val controllerId: EntityId,
            val filter: GameObjectFilter,
            val sourceId: EntityId,
        )
        val doublers = mutableListOf<AttackDoubler>()

        for (permanentId in state.getBattlefield()) {
            val container = state.getEntity(permanentId) ?: continue
            val card = container.get<CardComponent>() ?: continue
            if (container.has<FaceDownComponent>()) continue
            val controllerId = projected.getController(permanentId) ?: continue
            val cardDef = registry.getCard(card.cardDefinitionId) ?: continue
            val classLevel = container.get<ClassLevelComponent>()?.currentLevel
            for (ability in cardDef.script.effectiveStaticAbilities(classLevel)) {
                // Unwrap mode/condition-gated abilities (e.g. Windcrag Siege's Mardu mode) and
                // honor the gate against this source permanent.
                val unwrapped: AdditionalAttackTriggers? = when (ability) {
                    is AdditionalAttackTriggers -> ability
                    is ConditionalStaticAbility ->
                        (ability.ability as? AdditionalAttackTriggers)?.takeIf {
                            conditionEvaluator.evaluate(
                                state, ability.condition,
                                EffectContext(sourceId = permanentId, controllerId = controllerId)
                            )
                        }
                    else -> null
                }
                if (unwrapped != null) {
                    doublers.add(AttackDoubler(controllerId, unwrapped.attackerFilter, permanentId))
                }
            }
        }

        if (doublers.isEmpty()) return

        val duplicates = mutableListOf<PendingTrigger>()

        for (attackEvent in attackEvents) {
            for (doubler in doublers) {
                // Which declared attackers satisfy this doubler's filter (the "cause").
                val matchingAttackers = attackEvent.attackers.filter { attackerId ->
                    doubler.filter == GameObjectFilter.Any ||
                        predicateEvaluator.matches(
                            state, projected, attackerId, doubler.filter,
                            PredicateContext(controllerId = doubler.controllerId, sourceId = doubler.sourceId)
                        )
                }
                if (matchingAttackers.isEmpty()) continue

                for (trigger in triggers) {
                    if (trigger.controllerId != doubler.controllerId) continue

                    // Only attack-caused triggers: "whenever a creature attacks" / "whenever you attack".
                    val triggerEvent = trigger.ability.trigger
                    val isAttackTrigger = triggerEvent is EventPattern.AttackEvent ||
                        triggerEvent is EventPattern.YouAttackEvent
                    if (!isAttackTrigger) continue

                    // If the trigger names a specific attacker (per-attacker AttackEvent), that
                    // attacker must be one of the cause attackers. Triggers without a specific
                    // attacker (e.g. "whenever you attack") are caused by the attack as a whole.
                    val triggeringAttacker = trigger.triggerContext.triggeringEntityId
                    if (triggeringAttacker != null && triggeringAttacker !in matchingAttackers) continue

                    duplicates.add(trigger)
                }
            }
        }

        triggers.addAll(duplicates)
    }

    /**
     * Duplicate death/leave-the-battlefield triggers for [AdditionalDeathTriggers] static abilities
     * (Teysa Karlov; The Masamune's granted ability). The death-cause analogue of
     * [duplicateAttackTriggers]: for each creature put into a graveyard from the battlefield this
     * batch, a scoped source's triggered ability that fired *from that death* triggers an additional
     * time per doubler.
     *
     * Only *death/leave-the-battlefield* triggers are doubled ("dies", "leaves the battlefield" by
     * dying) - abilities responding to the event that *caused* the death (e.g. "whenever you
     * sacrifice a creature") are not doubled, per the printed rulings. That falls out naturally:
     * their EventPattern is not a battlefield-exit [EventPattern.ZoneChangeEvent], so
     * [isDeathCausedTrigger] rejects them.
     *
     * Multiple copies are additive: N doublers add N extra firings of each affected trigger (N+1
     * total), matching the rulings (two Masamunes on emblems -> three firings, not four).
     *
     * Known limitation: a scoped source's own "when this creature dies" trigger fired by *that same
     * source* dying is not doubled - once the source is in the graveyard the doubler's attachment to
     * it is no longer exposed to the (post-death) trigger pipeline. See [AdditionalDeathTriggers].
     */
    private fun duplicateDeathTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        if (triggers.isEmpty()) return

        // Creatures put into a graveyard from the battlefield this batch, taking continuous effects
        // into account via last-known type line (an animated land that dies counts, CR 700.4).
        val dyingCreatures = events.filterIsInstance<ZoneChangeEvent>()
            .filter { it.fromZone == Zone.BATTLEFIELD && it.toZone == Zone.GRAVEYARD }
            .filter { it.lastKnown?.typeLine?.isCreature == true }
            .map { it.entityId }
            .toSet()
        if (dyingCreatures.isEmpty()) return

        val registry = cardRegistry
        val projected = state.projectedState

        data class DeathDoubler(
            val sourceId: EntityId,
            val controllerId: EntityId,
            val ability: AdditionalDeathTriggers,
        )
        val doublers = mutableListOf<DeathDoubler>()
        for (permanentId in state.getBattlefield()) {
            val container = state.getEntity(permanentId) ?: continue
            val card = container.get<CardComponent>() ?: continue
            if (container.has<FaceDownComponent>()) continue
            val controllerId = projected.getController(permanentId) ?: continue
            val cardDef = registry.getCard(card.cardDefinitionId) ?: continue
            val classLevel = container.get<ClassLevelComponent>()?.currentLevel
            for (ability in cardDef.script.effectiveStaticAbilities(classLevel)) {
                val unwrapped: AdditionalDeathTriggers? = when (ability) {
                    is AdditionalDeathTriggers -> ability
                    is ConditionalStaticAbility ->
                        (ability.ability as? AdditionalDeathTriggers)?.takeIf {
                            conditionEvaluator.evaluate(
                                state, ability.condition,
                                EffectContext(sourceId = permanentId, controllerId = controllerId)
                            )
                        }
                    else -> null
                }
                if (unwrapped != null) doublers.add(DeathDoubler(permanentId, controllerId, unwrapped))
            }
        }
        if (doublers.isEmpty()) return

        val duplicates = mutableListOf<PendingTrigger>()
        val originals = triggers.toList()
        for (doubler in doublers) {
            val attachedCreatureId =
                if (doubler.ability.attachedCreature) {
                    state.getEntity(doubler.sourceId)?.get<AttachedToComponent>()?.targetId
                } else null
            val controlledFilter = doubler.ability.permanentsYouControl
            for (trigger in originals) {
                if (trigger.controllerId != doubler.controllerId) continue
                if (!isDeathCausedTrigger(trigger, dyingCreatures)) continue
                val src = trigger.sourceId
                val inScope = when {
                    attachedCreatureId != null && src == attachedCreatureId -> true
                    controlledFilter != null && src in state.getBattlefield() &&
                        predicateEvaluator.matches(
                            state, projected, src, controlledFilter,
                            PredicateContext(controllerId = doubler.controllerId, sourceId = doubler.sourceId)
                        ) -> true
                    doubler.ability.includeEmblems && isEmblemOwnedBy(state, src, doubler.controllerId) -> true
                    else -> false
                }
                if (inScope) duplicates.add(trigger)
            }
        }
        triggers.addAll(duplicates)
    }

    /**
     * A pending trigger is "death-caused" when its [EventPattern] responds to a permanent being put
     * into a graveyard from the battlefield (dies / leaves-the-battlefield-by-dying) and the specific
     * triggering entity is one of the creatures that died this batch. Batch "creatures you control
     * died" triggers are inherently death-caused. Sacrifice/destroy triggers use non-battlefield-exit
     * patterns and so never match here.
     */
    private fun isDeathCausedTrigger(trigger: PendingTrigger, dyingCreatures: Set<EntityId>): Boolean {
        return when (val pattern = trigger.ability.trigger) {
            is EventPattern.ZoneChangeEvent -> {
                if (pattern.from != Zone.BATTLEFIELD) return false
                if (pattern.to != null && pattern.to != Zone.GRAVEYARD) return false
                trigger.triggerContext.triggeringEntityId in dyingCreatures
            }
            is EventPattern.CreatureDealtDamageBySourceDiesEvent ->
                trigger.triggerContext.triggeringEntityId in dyingCreatures
            is EventPattern.CreaturesYouControlDiedEvent -> true
            else -> false
        }
    }

    /** True if [entityId] is an emblem (synthetic [EmblemSourceComponent] source) owned by [controllerId]. */
    private fun isEmblemOwnedBy(state: GameState, entityId: EntityId, controllerId: EntityId): Boolean {
        val container = state.getEntity(entityId) ?: return false
        if (container.get<EmblemSourceComponent>() == null) return false
        return container.get<ControllerComponent>()?.playerId == controllerId
    }

    /**
     * Duplicate triggers for [AdditionalSourceTriggers] static abilities (e.g., Twinflame Travelers).
     *
     * For each pending trigger whose source permanent matches a doubler's filter and is
     * controlled by the doubler's controller, add an extra copy. Self-exclusion (the doubler's
     * own source) is honoured per [AdditionalSourceTriggers.excludeSelf].
     *
     * Multiple copies are additive: N doublers each cause one extra firing per matching trigger,
     * yielding N+1 total firings.
     */
    private fun duplicateSourceTriggers(
        state: GameState,
        triggers: MutableList<PendingTrigger>
    ) {
        if (triggers.isEmpty()) return
        val registry = cardRegistry
        val projected = state.projectedState

        data class SourceDoubler(
            val doublerSourceId: EntityId,
            val controllerId: EntityId,
            val filter: GameObjectFilter,
            val excludeSelf: Boolean,
            val alsoSource: Boolean
        )
        val doublers = mutableListOf<SourceDoubler>()

        for (permanentId in state.getBattlefield()) {
            val container = state.getEntity(permanentId) ?: continue
            val card = container.get<CardComponent>() ?: continue
            if (container.has<FaceDownComponent>()) continue
            val controllerId = projected.getController(permanentId) ?: continue
            val cardDef = registry.getCard(card.cardDefinitionId) ?: continue
            // Route through RoomFaceStatics so a doubler printed on an *unlocked* Room face
            // (CR 709.5) is honoured, not just one in the card's top-level script.
            for (ability in RoomFaceStatics.activeStaticAbilities(container, cardDef)) {
                if (ability is AdditionalSourceTriggers) {
                    // Optional gate ("As long as Cloud is equipped, …") — evaluated against the
                    // doubler source. When it fails, the whole doubler is inert this batch.
                    val gate = ability.condition
                    if (gate != null && !conditionEvaluator.evaluate(
                            state, gate,
                            EffectContext(sourceId = permanentId, controllerId = controllerId)
                        )
                    ) continue
                    doublers.add(
                        SourceDoubler(
                            doublerSourceId = permanentId,
                            controllerId = controllerId,
                            filter = ability.sourceFilter,
                            excludeSelf = ability.excludeSelf,
                            alsoSource = ability.alsoSource
                        )
                    )
                }
            }
        }

        if (doublers.isEmpty()) return

        val duplicates = mutableListOf<PendingTrigger>()
        // Iterate over a snapshot so duplicates added by earlier doublers don't re-multiply.
        val originals = triggers.toList()
        for (doubler in doublers) {
            for (trigger in originals) {
                if (trigger.controllerId != doubler.controllerId) continue
                val triggerSourceId = trigger.sourceId
                // `alsoSource` doubles the doubler's own triggered abilities regardless of the
                // filter — the "or ~ itself" leg of "a triggered ability of ~ or an Equipment
                // attached to it" (Cloud, Midgar Mercenary).
                if (doubler.alsoSource && triggerSourceId == doubler.doublerSourceId) {
                    duplicates.add(trigger)
                    continue
                }
                if (doubler.excludeSelf && triggerSourceId == doubler.doublerSourceId) continue
                if (!predicateEvaluator.matches(
                        state, projected, triggerSourceId, doubler.filter,
                        PredicateContext(controllerId = doubler.controllerId, sourceId = doubler.doublerSourceId)
                    )
                ) continue
                duplicates.add(trigger)
            }
        }

        triggers.addAll(duplicates)
    }

    /**
     * Detect "When you unlock this door" triggers (CR 709.5h, DSK Rooms).
     *
     * Face-aware: for each [DoorUnlockedEvent], we look up the Room's `cardFaces[i]` whose
     * id matches the unlocked face id and add SELF-bound `OnDoorUnlocked` triggers from
     * *that* face's script only. This ensures that already-unlocked faces' "when you
     * unlock this door" abilities don't re-fire when a *different* door is unlocked.
     *
     * Both ETB-time unlocks (from the cast face) and unlock-action transitions emit
     * [DoorUnlockedEvent], so both paths feed through here.
     */
    private fun detectDoorUnlockedTriggers(
        state: GameState,
        events: List<EngineGameEvent>,
        triggers: MutableList<PendingTrigger>
    ) {
        for (event in events) {
            if (event !is DoorUnlockedEvent) continue
            val container = state.getEntity(event.roomId) ?: continue
            val cardComponent = container.get<CardComponent>() ?: continue
            val roomComp = container.get<RoomComponent>() ?: continue
            val cardDef = cardRegistry.getCard(cardComponent.cardDefinitionId) ?: continue
            val face = cardDef.cardFaces.firstOrNull {
                RoomFaceId(it.name) == event.faceId
            } ?: continue

            // Sanity-check: only fire if the face is currently unlocked (the engine emits
            // the event right after applying the unlock, so this should always be true).
            if (event.faceId !in roomComp.unlocked) continue

            for (ability in face.script.effectiveTriggeredAbilities(null)) {
                if (ability.trigger !is EventPattern.DoorUnlockedEvent) continue
                if (ability.binding != TriggerBinding.SELF) continue
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = event.roomId,
                        sourceName = cardComponent.name,
                        controllerId = event.controllerId,
                        triggerContext = TriggerContext(triggeringEntityId = event.roomId)
                    )
                )
            }
        }
    }

    /**
     * Detect "when you gain control of this from another player" triggers.
     * Fires on the permanent whose control just changed, when the new controller
     * is different from the old controller.
     */
    private fun detectControlChangeTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: ControlChangedEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val entityId = event.permanentId
        val container = state.getEntity(entityId) ?: return
        val cardComponent = container.get<CardComponent>() ?: return

        // Face-down creatures have no abilities (Rule 708.2)
        if (container.has<FaceDownComponent>()) return

        // Only fire if control actually changed
        if (event.oldControllerId == event.newControllerId) return

        val abilities = abilityResolver.getTriggeredAbilities(entityId, cardComponent.cardDefinitionId, state, statics)

        for (ability in abilities) {
            val controlTrigger = ability.trigger as? EventPattern.ControlChangeEvent
            // Resident "when you gain control of this" self-trigger (Risky Move): only the GAINED
            // direction fires here, where the *new* controller controls the ability. A LOST-shaped
            // ControlChangeEvent is exclusively an entity-scoped delayed trigger (Stolen Uniform).
            if (controlTrigger != null &&
                controlTrigger.direction == com.wingedsheep.sdk.scripting.ControlChangeDirection.GAINED &&
                ability.binding == TriggerBinding.SELF
            ) {
                // The new controller controls this triggered ability
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = entityId,
                        sourceName = cardComponent.name,
                        controllerId = event.newControllerId,
                        triggerContext = TriggerContext(
                            triggeringEntityId = entityId,
                            triggeringPlayerId = event.newControllerId
                        )
                    )
                )
            }
        }
    }

    /**
     * Detect resident "whenever an opponent gains control of a permanent from you" triggers
     * (Zidane, Tantalus Thief) — [EventPattern.ControlChangeEvent] with
     * [ControlChangeDirection.LOST], `requireOpponent = true`, and [TriggerBinding.ANY].
     *
     * Unlike [detectControlChangeTriggers], the ability does not live on the permanent whose control
     * changed: it lives on any battlefield permanent the *old* controller controlled immediately
     * before this event (look-back-in-time, CR 603.10), including that very permanent when it is the
     * ability's own source. The trigger fires once per opponent-gain and belongs to the old
     * controller (so a stolen permanent still produces its payoff for the player it was taken from).
     */
    private fun detectOpponentGainsControlTriggers(
        state: GameState,
        statics: BattlefieldStaticsIndex,
        event: ControlChangedEvent,
        triggers: MutableList<PendingTrigger>
    ) {
        val oldController = event.oldControllerId
        val newController = event.newControllerId
        if (oldController == newController) return
        // "an opponent" — team-aware (CR 810): a teammate gaining control does not trigger.
        if (newController !in state.getOpponents(oldController)) return

        for (holderId in state.getBattlefield()) {
            val container = state.getEntity(holderId) ?: continue
            // Face-down permanents have no abilities (Rule 708.2).
            if (container.has<FaceDownComponent>()) continue
            val cardComponent = container.get<CardComponent>() ?: continue

            // The ability's controller as of immediately before the event: for the permanent that
            // just changed control that is the *old* controller; every other permanent is unaffected
            // by this single-permanent control change.
            val holderControllerBefore =
                if (holderId == event.permanentId) oldController
                else state.projectedState.getController(holderId)
            if (holderControllerBefore != oldController) continue

            val abilities = abilityResolver.getTriggeredAbilities(holderId, cardComponent.cardDefinitionId, state, statics)
            for (ability in abilities) {
                val controlTrigger = ability.trigger as? EventPattern.ControlChangeEvent ?: continue
                if (controlTrigger.direction != com.wingedsheep.sdk.scripting.ControlChangeDirection.LOST) continue
                if (!controlTrigger.requireOpponent) continue
                if (ability.binding != TriggerBinding.ANY) continue
                triggers.add(
                    PendingTrigger(
                        ability = ability,
                        sourceId = holderId,
                        sourceName = cardComponent.name,
                        controllerId = oldController,
                        triggerContext = TriggerContext(
                            triggeringEntityId = event.permanentId,
                            triggeringPlayerId = newController
                        )
                    )
                )
            }
        }
    }

    private companion object {
        /**
         * Every non-battlefield zone an ability can declare in `activeZones` (CR 113.6b). All three
         * are per-player zones keyed the same way, so one loop covers them. Used by the trigger-index
         * batch pass and the step-trigger pass, both of which are safe for all three.
         */
        val NON_BATTLEFIELD_ACTIVE_ZONES = listOf(Zone.GRAVEYARD, Zone.EXILE, Zone.COMMAND)

        /**
         * The non-battlefield zones scanned for per-*event* triggers. Exile is excluded on purpose:
         * suspend, madness and paradigm are the only exile-active shapes, and each already has a
         * dedicated detection path that a general pass here would duplicate.
         */
        val NON_BATTLEFIELD_EVENT_TRIGGER_ZONES = listOf(Zone.GRAVEYARD, Zone.COMMAND)
    }
}
