package com.wingedsheep.engine.handlers

import com.wingedsheep.engine.state.components.battlefield.chosenOpponent

import com.wingedsheep.engine.handlers.effects.TargetResolutionUtils
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.stack.ChosenTarget
import com.wingedsheep.engine.state.components.stack.EntitySnapshot
import com.wingedsheep.engine.state.components.stack.TriggeredAbilityOnStackComponent
import com.wingedsheep.sdk.core.Color
import com.wingedsheep.sdk.core.Zone
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.ChoiceSlot
import com.wingedsheep.sdk.scripting.targets.EffectTarget
import com.wingedsheep.sdk.scripting.targets.TargetRequirement
import kotlinx.serialization.Serializable

/**
 * Context for effect execution.
 *
 * Core fields (sourceId, controllerId, targets, etc.) are always relevant.
 * Pipeline-specific state (collections, named values, iteration targets) lives
 * in [pipeline] to keep the two concerns separate and make pipeline extensions
 * self-contained.
 */
@Serializable
data class EffectContext(
    // --- Core ---
    val sourceId: EntityId?,
    val controllerId: EntityId,
    /**
     * The controller of the *overall* effect/ability, stable across per-player iteration.
     * `ForEachEffect(IterationSpace.Players)` rebinds [controllerId] to each iterated player so
     * `Player.You` resolves to them, but some sub-effects still need the original activating
     * player — e.g. a "until **your** next turn" window whose "your" is the activating player for
     * every affected player (Memory Vessel). Captured on the first Players-iteration and preserved
     * across nested iterations. Null outside iteration; read as `effectControllerId ?: controllerId`.
     */
    val effectControllerId: EntityId? = null,
    /**
     * The permanent whose static ability granted the currently-resolving ability (the
     * Equipment/Aura/permanent bearing the `GrantActivatedAbility` static), captured when the
     * ability was put on the stack. Resolves [com.wingedsheep.sdk.scripting.targets.EffectTarget.GrantingSource]
     * so a granted ability can name its granter — e.g. an Equipment that gives its bearer
     * "...Return [this Equipment] to its owner's hand" (Trusty Boomerang). Null for non-granted
     * abilities and for spell resolution; the granter may have left play by resolution, so the
     * referencing effect must tolerate a now-absent entity (CR 113.7a).
     */
    val granterId: EntityId? = null,
    /**
     * Definition-scoped identity of the triggered/activated ability currently resolving, copied
     * from its stack component (see [com.wingedsheep.sdk.scripting.AbilityIdentity]). Lets a
     * resolution-time may-question consult the controller's persistent auto-answer yields without
     * re-deriving the key. Null for spell resolution, sources with no card definition, and
     * activated abilities whose lookup did not prove definition ownership (backlog §C).
     */
    val abilityIdentity: com.wingedsheep.sdk.scripting.AbilityIdentity? = null,
    /**
     * The concrete ability captured at activation. Resolution must not rediscover it from a
     * source or grant that can change before resolving (including "retain this ability" copies).
     * Null for spells, triggers, and synthesized activations without an ActivatedAbility.
     */
    val activatedAbility: com.wingedsheep.sdk.scripting.ActivatedAbility? = null,
    /**
     * The player currently under consideration as a target, bound while evaluating a
     * `TargetPlayer.restriction` / `TargetOpponent.restriction` (CR 115). Resolves
     * [com.wingedsheep.sdk.scripting.references.Player.Candidate]. Null in every normal
     * effect-resolution context — there is no candidate once an effect is executing.
     */
    val candidatePlayerId: EntityId? = null,
    /**
     * The face-change tally [sourceId] carried when this ability was put onto the stack (CR
     * 701.28f). `TransformEffectExecutor` compares it against the source's current tally and
     * ignores a self-transform when the two differ — the permanent has already turned over since,
     * so the instruction does nothing. Null for spells, for a non-double-faced source, and for
     * synthesized abilities that carry no such restriction.
     */
    val sourceFaceChanges: Int? = null,
    /** Battlefield visit of the resolving ability's source. */
    val sourceBattlefieldTimestamp: Long? = null,
    /**
     * The source had already returned as a different permanent when this ability began resolving.
     * Retain sourceId for linked data and last-known information, but do not act on that new permanent.
     * Frozen at resolution start so instructions can still track a source they themselves return.
     */
    val sourceReferenceLost: Boolean = false,
    val triggeringReferenceLost: Boolean = false,
    val objectReferences: ObjectReferenceEnvironment = ObjectReferenceEnvironment(),
    val targets: List<ChosenTarget> = emptyList(),
    /**
     * Positionally-aligned view of [targets]: the same length as the originally-chosen target
     * list, with `null` in any slot whose target was dropped by resolution-time legality
     * validation (CR 608.2b). Populated on the spell-resolution path (and copied through
     * composite/iteration sub-effects); empty elsewhere, where it coincides with [targets].
     *
     * Positional target references — [EffectTarget.ContextTarget], [EntityReference.Target],
     * [com.wingedsheep.sdk.scripting.references.Player.ContextPlayer], and indexed conditions —
     * MUST resolve through [positionalTarget] so a now-illegal slot reads `null` (and the
     * sub-effect fizzles, CR 608.2b) instead of silently consuming the next still-legal target
     * whose position shifted forward in the compacted [targets] list. Diplomatic Relations is
     * the canonical case: "creature you control" dies in response, and without this the damage
     * amount's `Target(0)` power read would land on the surviving opponent's creature.
     */
    val alignedTargets: List<ChosenTarget?> = emptyList(),
    /**
     * The X chosen for an X-cost spell/ability. Also reused by `ChooseNumberThenEffect` to
     * carry a "choose a number" value into the inner effect (read via `CardPredicate.ManaValueEqualsX`,
     * Void). These two uses share one slot, so a future card that both pays `{X}` *and* chooses a
     * number would collide here — split the slot before authoring such a card.
     */
    val xValue: Int? = null,
    /**
     * Total mana paid from the pool to cast this spell — sum of every `manaSpent{Color}`
     * bucket on the [com.wingedsheep.engine.state.components.stack.SpellOnStackComponent].
     * For `{X}` spells the X portion is already included in those buckets, so this is
     * not the same as [xValue]. Used by `DynamicAmount.TotalManaSpent`.
     */
    val totalManaSpent: Int = 0,
    /**
     * Per-color mana spent on the `{X}` portion of the spell or activated ability, for a
     * color-restricted X (e.g. Soul Burn's "spend only black and/or red mana on X").
     * Read by `DynamicAmount.ManaSpentOnX`. Empty when X was unrestricted.
     */
    val manaSpentOnXByColor: Map<Color, Int> = emptyMap(),
    /**
     * The optional-additional-cost mechanic declared for the spell being cast or resolved
     * ([com.wingedsheep.sdk.scripting.ChoiceSlot.KICKED] for kicker, `BARGAINED` for bargain), or
     * null when none was. Read by `WasKicked` and by `CastChoiceMade(slot)` — the latter is how a
     * spell's own "if this spell was bargained" rider resolves while the spell is still on the
     * stack, before any durable cast-choices bag exists, and how a `CostGating.OnlyIf` cost
     * reduction is priced against the branch being enumerated.
     */
    val declaredCostSlot: ChoiceSlot? = null,
    /** True if the spell's optional Blight additional cost was paid (BlightOrPay path chosen). */
    val wasBlightPaid: Boolean = false,
    /**
     * True if the spell's waterbend additional cost was paid (Avatar: The Last Airbender) —
     * mandatory always, optional "you may waterbend {N}" only when elected. Read by
     * `WaterbendWasPaid`.
     */
    val wasWaterbendPaid: Boolean = false,
    /** True if the spell was cast for its sneak cost (CR 702.190). Read by `SneakCostWasPaid`. */
    val wasSneaked: Boolean = false,
    /** True if the spell was cast using web-slinging (CR 702.188). Read by `WebSlungCostWasPaid`. */
    val wasWebSlung: Boolean = false,
    /** True if the spell was cast for its mayhem cost (CR 702.187). Read by `MayhemCostWasPaid`. */
    val wasMayhem: Boolean = false,
    // --- Cast-time state ---
    /**
     * Projected snapshots of permanents sacrificed as part of the cost (Rule 113.7a /
     * 608.2h — "as it last existed on the battlefield"). Captured before the zone change
     * so downstream effects can read power, toughness, and subtypes after the permanent
     * has left the battlefield.
     */
    val sacrificedPermanents: List<EntitySnapshot> = emptyList(),
    /**
     * Entity ids of cards discarded to pay this spell's additional discard cost
     * (`Costs.additional.DiscardCards(...)`). By resolution these cards live in their owner's
     * graveyard (CR 608.2), so [EffectTarget.DiscardedAsCost] resolves to the id and an
     * `EntityMatches` reads the card's graveyard characteristics (Grab the Prize). Empty when the
     * spell carried no discard cost.
     */
    val discardedAsCostCards: List<EntityId> = emptyList(),
    /** Pre-chosen damage distribution for DividedDamageEffect spells (target ID -> damage amount) */
    val damageDistribution: Map<EntityId, Int>? = null,
    /**
     * Pre-chosen modes for modal spells/abilities (700.2). Populated at stack resolution
     * from either [SpellOnStackComponent] or [TriggeredAbilityOnStackComponent]. When
     * non-empty, [ModalEffectExecutor] iterates these modes with per-mode targets from
     * [modeTargetsOrdered] instead of prompting for a mode decision.
     */
    val chosenModes: List<Int> = emptyList(),
    val modeTargetsOrdered: List<List<ChosenTarget>> = emptyList(),
    val modeTargetRequirements: Map<Int, List<TargetRequirement>> = emptyMap(),
    /** Number of cards exiled as an additional cost (for ExileVariableCards) */
    val exiledCardCount: Int = 0,
    /** X chosen for [com.wingedsheep.sdk.scripting.AdditionalCost.BlightVariable] */
    val additionalCostBlightAmount: Int = 0,
    /** Permanents tapped as part of an activated ability's cost (e.g., Cryptic Gateway) */
    val tappedPermanents: List<EntityId> = emptyList(),
    /**
     * Cards exiled to pay an activated ability's cost, recorded at payment time (CR 601.2h — the
     * cost is paid on activation, long before the ability resolves). Read by
     * [com.wingedsheep.sdk.scripting.effects.CardSource.ExiledAsCost] so the resolving effect can
     * name "those exiled cards" (Baron Helmut Zemo). The exile counterpart of [tappedPermanents],
     * and scoped to *this* activation's payment — unlike a permanent's linked-exile pile, which
     * accumulates across activations.
     */
    val exiledAsCostCards: List<EntityId> = emptyList(),
    /**
     * LKI snapshots (Rule 113.7a) for the entries of [exiledAsCostCards] that were exiled **from
     * the battlefield**, captured before the zone change. A permanent exiled as a cost may be a
     * token — which ceases to exist and can't be read at resolution — or may have been a Thrull
     * only through a continuous effect, so "the exiled creature was a Thrull" (Soul Exchange) has
     * to read what it last was on the battlefield rather than what its card prints. Empty for
     * exile costs paid from any other zone, where the card is still a real object in exile and its
     * printed characteristics are the right answer.
     */
    val exiledAsCostSnapshots: List<EntitySnapshot> = emptyList(),
    /** LKI snapshots for [tappedPermanents] (Rule 113.7a). See [EntitySnapshot]. */
    val tappedEntitySnapshots: List<EntitySnapshot> = emptyList(),
    /**
     * Counters (counter-type-string → count) the source had the moment a self-exile /
     * self-sacrifice cost wiped them (CR 113.7a). Read by
     * [com.wingedsheep.sdk.scripting.values.DynamicAmount.LastKnownSourceCounters] so an effect
     * like "Draw a card for each verse counter on this. If it had seven or more..." (Lost Isle
     * Calling) sees the pre-cost count rather than zero.
     */
    val lastKnownSourceCounters: Map<String, Int> = emptyMap(),
    /**
     * Frozen projected characteristics the source had when it left the battlefield, including
     * a self-exile / self-sacrifice cost (CR 113.7a / 608.2h — "as it last existed
     * on the battlefield"). Mirrors [lastKnownSourceCounters]. Read by [DynamicAmountEvaluator]
     * when an `EntityProperty(EntityReference.Source, …)` power/toughness read resolves after the
     * source is gone, so "Sacrifice this creature: it deals damage equal to its power" reads the
     * pre-sacrifice power rather than zero (Blazing Bomb's Blow Up, Cinder Shade, Ghitu Fire-Eater).
     * Damage reads the same snapshot for source keywords, colors and controller after departure.
     * Null while the original source remains present; its characteristics are read live.
     */
    val lastKnownSourceSnapshot: EntitySnapshot? = null,
    /**
     * Entity ids of the permanents (Equipment/Auras) that were attached to the source the moment a
     * self-sacrifice / self-exile cost moved it off the battlefield (CR 113.7a). Captured before the
     * cost is paid, while the source still carries its `AttachmentsComponent`. Read by
     * [com.wingedsheep.sdk.scripting.effects.CardSource.LastKnownEquipmentAttachedToSource] so an
     * effect can "attach an Equipment that was attached to it to that creature" (Zack Fair) after the
     * source — and its live attachment index — are gone. Empty when the cost did not sacrifice/exile
     * the source or it had no attachments.
     */
    val lastKnownSourceAttachments: List<EntityId> = emptyList(),
    /**
     * LKI snapshots (Rule 113.7a) for entities chosen via an additional cost
     * step like [com.wingedsheep.sdk.scripting.AdditionalCost.ChooseEntity]
     * with `captureSnapshot = true`. Indexed by entity id via
     * [com.wingedsheep.engine.state.components.stack.snapshotFor]. Read by
     * [DynamicAmountEvaluator] when the `EntityProperty` path resolves an
     * [com.wingedsheep.sdk.scripting.values.EntityReference.FromCostStorage].
     */
    val chosenEntitySnapshots: List<EntitySnapshot> = emptyList(),
    // --- Trigger state ---
    /** Amount of damage from a trigger context (e.g., "Whenever ~ is dealt damage") */
    val triggerDamageAmount: Int? = null,
    /**
     * Counter count from the triggering event payload.
     * - Death triggers: last-known +1/+1 counter count when the source left the battlefield (Hooded Hydra).
     * - CountersPlacedEvent triggers: number of counters placed in the triggering event (Simic Ascendancy).
     */
    val triggerCounterCount: Int? = null,
    /** Last known total counter count (all types) from a death trigger context (e.g., Shadow Urchin) */
    val triggerTotalCounterCount: Int? = null,
    /** Last known -1/-1 counter count from a death trigger context (e.g., Retched Wretch) */
    val triggerMinusOneMinusOneCounterCount: Int? = null,
    /**
     * Last-known projected subtypes from a dies/leaves trigger context (CR 603.10). Read by
     * `TriggeringEntityHadSubtype` as an intervening-if — e.g. Infernal Vessel's "if it wasn't a
     * Demon". Null when the trigger wasn't driven by a permanent leaving the battlefield.
     */
    val triggerLastKnownSubtypes: Set<String>? = null,
    /**
     * Last-known projected card types from a dies/leaves trigger context (CR 603.10). Read by
     * `TriggeringEntityHadCardType` as an intervening-if — e.g. Tom, Bert, and William's "if they
     * were a creature". Null when the trigger wasn't driven by a permanent leaving the battlefield.
     */
    val triggerLastKnownCardTypes: Set<String>? = null,
    /** The entity that caused the trigger to fire (e.g., creature that dealt damage for Aurification) */
    val triggeringEntityId: EntityId? = null,
    /** The player associated with the trigger event (e.g., the player who cast a spell for SpellCastEvent) */
    val triggeringPlayerId: EntityId? = null,
    /** The spell or ability that targeted a permanent (for ward triggers) */
    val targetingSourceEntityId: EntityId? = null,
    /**
     * The host an attachment came *off*, captured when a "becomes unattached" trigger fired. Backs
     * [com.wingedsheep.sdk.scripting.targets.EffectTarget.AttachedToTriggeringPermanent] there,
     * where the live `AttachedToComponent` is by resolution either gone or already re-pointed at a
     * new host — Stitcher's Graft's "sacrifice that permanent". Null for every other trigger.
     */
    val triggerUnattachedFromEntityId: EntityId? = null,
    /**
     * The defending player for a per-defender combat legality check (CR 508.1 attack
     * declaration). Bound by [com.wingedsheep.engine.mechanics.combat.rules.CantAttackUnlessDefenderRule]
     * so `Player.DefendingPlayer` conditions ("can't attack unless defending player controls
     * an Island") evaluate against the player actually being attacked — the source has no
     * `AttackingComponent` yet at declaration time, so the attack-time resolution path can't
     * supply it.
     */
    val defendingPlayerId: EntityId? = null,
    /** Power of the triggering entity the moment it left the battlefield (dies/leaves triggers) */
    val triggerLastKnownPower: Int? = null,
    /** Toughness of the triggering entity the moment it left the battlefield (dies/leaves triggers) */
    val triggerLastKnownToughness: Int? = null,
    /** Total last-known power of a creatures-died batch (CR 603.2c). Read via
     *  `ContextPropertyKey.DIED_BATCH_TOTAL_POWER` (The Skullspore Nexus). Null for non-batch triggers. */
    val triggerDiedBatchTotalPower: Int? = null,
    /**
     * Power of the creature an Aura/Equipment was attached to, captured when its triggered
     * ability fired. Read by [EntityReference.EnchantedCreature] power reads as last-known
     * information (CR 608.2h) when the attached creature — and the aura — have left the
     * battlefield before the ability resolves (e.g. the creature is removed in response to
     * the aura's enters-the-battlefield trigger). Null for non-attached sources.
     */
    val enchantedCreatureLastKnownPower: Int? = null,
    /**
     * Last-known counter map (counter-type-string → count) of the trigger's source the
     * moment it left the battlefield. Read by `MoveAllLastKnownCountersEffect` when a
     * dies/leaves trigger needs to put every counter — not just +1/+1 — onto another
     * permanent (e.g., Essence Channeler).
     */
    val triggerLastKnownCounters: Map<String, Int>? = null,
    /**
     * Per-player damage dealt to the trigger's source the moment it left the battlefield.
     * Read by Grothama's LTB effect: "each player draws cards equal to the damage dealt
     * to ~ this turn by sources they controlled."
     */
    val triggerLastKnownDamageDealtByPlayers: Map<EntityId, Int>? = null,
    /**
     * Creatures that were blocking, or blocked by, the trigger's source when it left the
     * battlefield (CR 509 combat pairing), captured as last-known information. Resolved by
     * `CardSource.LastKnownCombatPairedWithSource` for "destroy all creatures blocking or
     * blocked by it" (Abu Ja'far). Null when the source never left combat.
     */
    val triggerLastKnownBlockingOrBlockedByIds: List<EntityId>? = null,
    /**
     * Number of mode picks the triggering spell-cast recorded. Read by
     * `ContextPropertyKey.MODES_CHOSEN_ON_TRIGGERING_SPELL` (Riku of Many Paths).
     */
    val triggerModesChosenCount: Int? = null,
    /**
     * Total mana spent to cast the spell that fired this trigger. Read by
     * `ContextPropertyKey.MANA_SPENT_ON_TRIGGERING_SPELL` (Aberrant Manawurm, Expressive
     * Firedancer). Distinct from [totalManaSpent], which is the *resolving object's own* cast.
     */
    val triggerManaSpentOnTriggeringSpell: Int? = null,
    /**
     * Number of distinct colors of mana spent to cast the spell that fired this trigger. Read by
     * `ContextPropertyKey.COLORS_SPENT_ON_TRIGGERING_SPELL` (Magmablood Archaic). Distinct from
     * [com.wingedsheep.sdk.scripting.values.DynamicAmount.DistinctColorsManaSpent] (Converge),
     * which reads the *resolving object's own* cast.
     */
    val triggerColorsSpentOnTriggeringSpell: Int? = null,
    /**
     * Mana value (CR 202.3) of the spell that fired this trigger. Read by
     * `ContextPropertyKey.TRIGGERING_SPELL_MANA_VALUE` (Kellan, the Kid). Distinct from
     * [triggerManaSpentOnTriggeringSpell], which is the mana actually paid.
     */
    val triggerManaValueOfTriggeringSpell: Int? = null,
    /**
     * The value chosen for `{X}` on the spell that fired this trigger (CR 601.2b). Read by
     * `ContextPropertyKey.X_VALUE_OF_TRIGGERING_SPELL` (Geometer's Arthropod). Distinct from
     * [triggerManaValueOfTriggeringSpell] (printed mana value, where {X} counts as 0) and
     * [triggerManaSpentOnTriggeringSpell] (total mana paid).
     */
    val triggerXValueOfTriggeringSpell: Int? = null,
    /**
     * Number of cards actually looked at by the scry that fired this trigger. Read by
     * `ContextPropertyKey.TRIGGER_SCRY_COUNT` (Celeborn the Wise, Elrond Master of Healing).
     */
    val triggerScryCount: Int? = null,
    /**
     * Whether the clash that fired this trigger was won by its controller (CR 701.30d). Read by
     * [com.wingedsheep.sdk.scripting.conditions.YouWonTheClash] as the "if you won" rider on a
     * "Whenever you clash" ability (Entangling Trap, Rebellion of the Flamekin). `null` when the
     * trigger was not driven by a clash, which reads as "did not win".
     */
    val triggerClashWon: Boolean? = null,
    /**
     * Number of cards discarded in the batch that fired this trigger (CR 603.2c). Read by
     * `ContextPropertyKey.TRIGGER_DISCARD_COUNT` (Magmakin Artillerist).
     */
    val triggerDiscardCount: Int? = null,
    /**
     * Discover value N of the discover that fired this trigger (CR 701.57). Read by
     * `ContextPropertyKey.TRIGGER_DISCOVER_VALUE` (Curator of Sun's Creation).
     */
    val triggerDiscoverValue: Int? = null,
    /**
     * Damage past lethal dealt to the trigger's creature recipient (CR 120.4a). Read by
     * `ContextPropertyKey.TRIGGER_EXCESS_DAMAGE_AMOUNT` (Fall of Cair Andros).
     */
    val triggerExcessDamageAmount: Int? = null,
    /**
     * The damage recipient creature's toughness at the instant the triggering damage was dealt
     * (CR 603.10 LKI). Read by `ContextPropertyKey.TRIGGER_RECIPIENT_TOUGHNESS` (Taii Wakeen,
     * Perfect Shot — "damage equal to that creature's toughness"). `null` for non-creature recipients.
     */
    val triggerRecipientToughness: Int? = null,
    // --- Choice state ---
    /** Color chosen for "add one mana of any color" abilities */
    val manaColorChoice: Color? = null,
    /**
     * Color chosen during a [com.wingedsheep.sdk.scripting.effects.ChooseColorThenEffect]
     * resolution. Set by the resumer before dispatching the inner effect; read by atomic
     * "...FromChosenColor" executors.
     */
    val chosenColor: Color? = null,
    /** Creature type chosen during casting (e.g., Aphetto Dredging) */
    val chosenCreatureType: String? = null,
    /**
     * The opponent the controller picked to make a
     * [com.wingedsheep.sdk.scripting.effects.Chooser.Opponent] decision, when the game has more
     * than one opponent to choose from (CR 601.7a / 602.3a and the matching resolution-time
     * rulings). Set by
     * [com.wingedsheep.engine.core.ChooseOpponentDeciderContinuation]'s resumer just before the
     * effect is re-executed, and read back by
     * [com.wingedsheep.engine.handlers.effects.ChooserResolution.resolve].
     *
     * Resolution-scoped on purpose: the stamp rides only the re-run context, so each separate
     * "an opponent chooses" step gets its own prompt. Null in two-player games (a sole opponent
     * is a forced choice, never asked) and before the pick is made.
     */
    val opponentDeciderId: EntityId? = null,
    // --- Zone state ---
    /** Zone the spell was cast from (e.g., HAND, GRAVEYARD for flashback) */
    val castFromZone: Zone? = null,
    // --- Projection state ---
    /** The entity being modified during continuous effect projection (for DynamicAmount evaluation) */
    val affectedEntityId: EntityId? = null,
    // --- Pipeline state ---
    val pipeline: PipelineState = PipelineState.EMPTY,
    // --- Safety ---
    /**
     * How many effect-executions deep this context is within a single resolution. Bumped by one
     * each time [com.wingedsheep.engine.handlers.effects.EffectExecutorRegistry] recurses into a
     * sub-effect (composite / iteration / draw / chain executors), and per iteration by
     * `RepeatWhileEffect`. The registry aborts the branch once this exceeds
     * [com.wingedsheep.engine.core.GameLimits.MAX_RESOLUTION_DEPTH], so an unbounded effect loop
     * fails closed instead of `StackOverflowError`. Lives on the (immutable) context rather than
     * on the shared registry so it stays correct under the AI's parallel state evaluation.
     */
    val resolutionDepth: Int = 0
) {
    val activatedAbilityId: com.wingedsheep.sdk.scripting.AbilityId?
        get() = activatedAbility?.id

    /**
     * Resolve a symbolic effect target to a concrete entity id using just the context.
     *
     * Stateless resolution — handles self, controller, context targets, bound variables,
     * pipeline targets, triggering entity, etc. For relational references that need to look
     * up components (e.g., [EffectTarget.EnchantedCreature], [EffectTarget.TargetController]),
     * use the overload that also takes [GameState].
     */
    /**
     * Resolve a chosen target by its ORIGINAL declared position, stable even when CR 608.2b
     * validation dropped an earlier target before resolution. Every positional
     * `targets[index]` read that uses a card-definition-supplied index goes through here so a
     * dropped target doesn't shift later targets forward in the compacted [targets] list.
     *
     * [alignedTargets] is only consulted when it is genuinely the position-preserving partner
     * of the CURRENT [targets] — i.e. dropping its `null` slots reproduces [targets] exactly.
     * That guard matters because executors re-scope [targets] to a different list (e.g.
     * [com.wingedsheep.sdk.scripting.effects.ForEachTargetEffect] iterates one target at a time,
     * continuation resumers narrow to the remaining/selected targets) via `copy()`, which
     * carries the now-stale parent [alignedTargets]. In that case we fall back to [targets] so
     * `ContextTarget(0)` reads the re-scoped target, not the stale slot 0. When the lists do
     * coincide (top-level spell resolution), [alignedTargets] supplies the `null` for any
     * dropped slot.
     */
    fun positionalTarget(index: Int): ChosenTarget? =
        if (alignedTargets.isNotEmpty() && alignedTargets.filterNotNull() == targets) {
            alignedTargets.getOrNull(index)
        } else {
            targets.getOrNull(index)
        }

    /** Capture legacy battlefield validity and bind this resolution's independent identity scope. */
    fun forAbilityResolution(state: GameState, resolutionId: EntityId? = null): EffectContext {
        val currentVisit = sourceId?.let { state.getEntity(it) }
            ?.get<com.wingedsheep.engine.state.components.battlefield.BattlefieldEntryTimestampComponent>()?.timestamp
        // Older serialized abilities have no provable historical identity. Keep their LKI and
        // remaining instructions, but fail closed for actionable source/trigger references.
        val captured = objectReferences.copy(captured = true)
        return copy(
            objectReferences = captured.copy(resolutionKey = resolutionId?.let { id ->
                "$id:${state.objectRef(id)?.generation}"
            } ?: captured.resolutionKey),
            sourceReferenceLost = sourceBattlefieldTimestamp != null && currentVisit != null &&
                currentVisit != sourceBattlefieldTimestamp,
        ).withCurrentObjectReferences(state)
    }

    /** Recheck on every instruction/resume; an unrelated move while paused cannot be followed. */
    fun withCurrentObjectReferences(state: GameState): EffectContext = copy(
        sourceReferenceLost = if (objectReferences.captured || objectReferences.selfBinding != null) {
            !objectReferences.isSelfCurrent(state)
        } else sourceReferenceLost,
        triggeringReferenceLost = triggeringEntityId !in state.turnOrder &&
            !objectReferences.isCurrent(objectReferences.triggering, state),
    )

    fun authorizeObjectMoves(events: List<com.wingedsheep.engine.core.GameEvent>): EffectContext =
        copy(
            objectReferences = objectReferences.authorize(events),
            // Effects in one resolution may themselves move their source. Retain departure
            // characteristics before a later sibling returns it or a continuation pauses.
            lastKnownSourceSnapshot = lastKnownSourceSnapshot ?: events
                .filterIsInstance<com.wingedsheep.engine.core.ZoneChangeEvent>()
                .mapNotNull { it.lastKnown }
                .firstOrNull { it.objectRef != null && it.objectRef == objectReferences.origin },
        )

    fun chosenOpponent(state: GameState): EntityId? =
        pipeline.storedCollections[RESOLUTION_CHOSEN_OPPONENT]?.firstOrNull()
            ?: sourceId?.takeIf { objectReferences.isCurrent(objectReferences.source, state) }
                ?.let { state.getEntity(it)?.chosenOpponent() }


    /** Battlefield-only instructions cannot affect a source that has left or already returned. */
    fun isUnavailableBattlefieldSource(target: EffectTarget, state: GameState): Boolean =
        target == EffectTarget.Self &&
            (sourceReferenceLost || ((objectReferences.selfBinding != null || sourceBattlefieldTimestamp != null) &&
                (pipeline.iterationTarget ?: objectReferences.selfBinding?.entityId ?: sourceId) !in state.getBattlefield()))

    fun resolveTarget(target: EffectTarget): EntityId? =
        TargetResolutionUtils.resolveTarget(target, this)

    /**
     * Resolve a symbolic effect target to a concrete entity id, consulting [state] for
     * relational references (attachments, controllers, owners).
     */
    fun resolveTarget(target: EffectTarget, state: GameState): EntityId? =
        TargetResolutionUtils.resolveTarget(target, this, state)

    /**
     * Resolve a symbolic effect target and throw if it cannot be resolved.
     * Use when the caller knows by construction that the target must exist.
     */
    fun requireTarget(target: EffectTarget): EntityId =
        resolveTarget(target) ?: error("Cannot resolve target: $target")

    /**
     * Resolve a symbolic effect target using [state] and throw if it cannot be resolved.
     */
    fun requireTarget(target: EffectTarget, state: GameState): EntityId =
        resolveTarget(target, state) ?: error("Cannot resolve target: $target")

    /**
     * Resolve a player reference target (e.g., "target player", "each opponent") to a
     * single player entity id. Stateless overload — see [resolvePlayerTargets] for
     * multi-player results.
     */
    fun resolvePlayerTarget(target: EffectTarget): EntityId? =
        TargetResolutionUtils.resolvePlayerTarget(target, this)

    /**
     * Resolve a player reference target, consulting [state] for relational references
     * like [com.wingedsheep.sdk.scripting.references.Player.OwnerOf] /
     * [com.wingedsheep.sdk.scripting.references.Player.ControllerOf].
     */
    fun resolvePlayerTarget(target: EffectTarget, state: GameState): EntityId? =
        TargetResolutionUtils.resolvePlayerTarget(target, this, state)

    /**
     * Resolve a player reference target to a list of player ids (for multi-player effects
     * like "each player" / "each opponent").
     */
    fun resolvePlayerTargets(target: EffectTarget, state: GameState): List<EntityId> =
        TargetResolutionUtils.resolvePlayerTargets(target, state, this)

    companion object {
        /**
         * Build a named targets map from target requirements and chosen targets.
         *
         * For each requirement with a non-null `id`:
         * - If count == 1: maps `id` -> chosenTarget
         * - If count > 1: maps `id[0]` -> target0, `id[1]` -> target1, etc.
         *
         * Requirements with `id == null` are skipped (backward compat with ContextTarget).
         *
         * `targets` is accepted as `List<ChosenTarget?>` so callers can pass a
         * **positionally-aligned** list where slots whose target was dropped by
         * resolution-time legality validation (CR 608.2b) are `null`. Such slots
         * leave the corresponding `id` unmapped so any sub-effect that references
         * the now-illegal target via [EffectTarget.BoundVariable] resolves to
         * `null` and fizzles instead of silently consuming a later target whose
         * position shifted forward in the compacted list. The non-null
         * `List<ChosenTarget>` form is still accepted (Kotlin covariance) for
         * callers that already filter targets up-front.
         */
        fun buildNamedTargets(
            requirements: List<TargetRequirement>,
            targets: List<ChosenTarget?>
        ): Map<String, ChosenTarget> {
            val result = mutableMapOf<String, ChosenTarget>()
            var targetIndex = 0
            for (req in requirements) {
                val id = req.id
                if (id != null) {
                    if (req.count == 1) {
                        targets.getOrNull(targetIndex)?.let { result[id] = it }
                    } else {
                        for (i in 0 until req.count) {
                            targets.getOrNull(targetIndex + i)?.let { result["$id[$i]"] = it }
                        }
                    }
                }
                targetIndex += req.count
            }
            return result
        }

        /**
         * Build the execution context for a triggered ability sitting on the stack.
         *
         * Shared by the two places that need to evaluate the ability's own text against the game
         * state: [com.wingedsheep.engine.mechanics.stack.StackResolver] when the ability resolves,
         * and [com.wingedsheep.engine.event.TriggerProcessor] when it resolves a modal
         * `dynamicChooseCount` as the ability goes onto the stack (CR 603.3c). Both must see the
         * same trigger payload — an `xValue`, a `MODES_CHOSEN_ON_TRIGGERING_SPELL` count or a
         * carried pipeline collection that only one of them populated would read as zero/absent.
         */
        fun forTriggeredAbility(
            ability: TriggeredAbilityOnStackComponent,
            targets: List<ChosenTarget> = emptyList(),
            targetRequirements: List<TargetRequirement> = emptyList()
        ): EffectContext = EffectContext(
            sourceId = ability.sourceId,
            controllerId = ability.controllerId,
            granterId = ability.granterId,
            abilityIdentity = ability.abilityIdentity,
            sourceFaceChanges = ability.sourceFaceChanges,
            sourceBattlefieldTimestamp = ability.sourceBattlefieldTimestamp,
            lastKnownSourceSnapshot = ability.lastKnownSourceSnapshot,
            objectReferences = ability.objectReferences,
            targets = targets,
            triggerDamageAmount = ability.triggerDamageAmount,
            triggerCounterCount = ability.triggerCounterCount,
            triggerTotalCounterCount = ability.triggerTotalCounterCount,
            triggerLastKnownCounters = ability.triggerLastKnownCounters,
            triggerLastKnownSubtypes = ability.triggerLastKnownSubtypes,
            triggerLastKnownCardTypes = ability.triggerLastKnownCardTypes,
            triggerLastKnownDamageDealtByPlayers = ability.triggerLastKnownDamageDealtByPlayers,
            triggerLastKnownBlockingOrBlockedByIds = ability.triggerLastKnownBlockingOrBlockedByIds,
            triggeringEntityId = ability.triggeringEntityId,
            triggeringPlayerId = ability.triggeringPlayerId,
            targetingSourceEntityId = ability.targetingSourceEntityId,
            triggerUnattachedFromEntityId = ability.triggerUnattachedFromEntityId,
            triggerLastKnownPower = ability.lastKnownPower,
            triggerLastKnownToughness = ability.lastKnownToughness,
            triggerDiedBatchTotalPower = ability.diedBatchTotalPower,
            enchantedCreatureLastKnownPower = ability.enchantedCreatureLastKnownPower,
            triggerModesChosenCount = ability.triggerModesChosenCount,
            triggerScryCount = ability.triggerScryCount,
            triggerClashWon = ability.triggerClashWon,
            triggerDiscardCount = ability.triggerDiscardCount,
            triggerDiscoverValue = ability.triggerDiscoverValue,
            triggerExcessDamageAmount = ability.triggerExcessDamageAmount,
            triggerRecipientToughness = ability.triggerRecipientToughness,
            triggerManaSpentOnTriggeringSpell = ability.triggerManaSpentOnTriggeringSpell,
            triggerColorsSpentOnTriggeringSpell = ability.triggerColorsSpentOnTriggeringSpell,
            triggerManaValueOfTriggeringSpell = ability.triggerManaValueOfTriggeringSpell,
            triggerXValueOfTriggeringSpell = ability.triggerXValueOfTriggeringSpell,
            xValue = ability.xValue,
            damageDistribution = ability.damageDistribution,
            chosenModes = ability.chosenModes,
            modeTargetsOrdered = ability.modeTargetsOrdered,
            modeTargetRequirements = ability.modeTargetRequirements,
            pipeline = PipelineState(
                namedTargets = buildNamedTargets(targetRequirements, targets) +
                    (ability.carriedPipeline?.namedTargets ?: emptyMap()),
                // Expose a batch trigger's captured permanents (the matching members of a
                // PermanentsEnteredEvent batch) so a ForEachInCollectionEffect payoff can iterate
                // them — "for each of them, create a tapped copy of it" (Kambal). The copy executor
                // reads each entity at resolution, so any that left the battlefield meanwhile no-op.
                storedCollections = (if (ability.capturedEntityIds.isNotEmpty()) {
                    mapOf(PipelineState.TRIGGER_CAPTURED_COLLECTION to ability.capturedEntityIds)
                } else emptyMap()) + (ability.carriedPipeline?.storedCollections ?: emptyMap()),
                // A `ReflexiveTriggerEffect`'s action half (e.g. `Amass`, a discard) may have stashed
                // subtype groups or scalar values the reflexive effect reads (CR 603.12) — carried
                // across the stack round-trip since this ability builds a fresh context on resolve.
                storedSubtypeGroups = ability.carriedPipeline?.storedSubtypeGroups ?: emptyMap(),
                chosenValues = ability.carriedPipeline?.chosenValues ?: emptyMap(),
                storedNumbers = ability.carriedPipeline?.storedNumbers ?: emptyMap(),
                storedStringLists = ability.carriedPipeline?.storedStringLists ?: emptyMap()
            )
        )
    }
}

internal const val RESOLUTION_CHOSEN_OPPONENT = "resolution.chosenOpponent"
