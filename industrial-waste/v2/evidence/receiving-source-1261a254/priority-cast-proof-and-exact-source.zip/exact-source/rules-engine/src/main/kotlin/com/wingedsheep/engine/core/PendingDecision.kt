package com.wingedsheep.engine.core

import com.wingedsheep.sdk.core.Color
import com.wingedsheep.sdk.model.EntityId
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Represents a decision the engine needs from a player before it can continue.
 *
 * When the engine encounters a point where player input is required (choosing targets,
 * selecting cards, making choices), it pauses and returns a PendingDecision describing
 * what input is needed.
 *
 * The game state is frozen until the player submits a DecisionResponse via SubmitDecision action.
 */
@Serializable
sealed interface PendingDecision {
    /** Unique identifier for this decision (used to correlate responses) */
    val id: String

    /** The player who must make this decision */
    val playerId: EntityId

    /** Human-readable prompt to display */
    val prompt: String

    /** Context about what triggered this decision (for UI display) */
    val context: DecisionContext
}

/**
 * Context information about why this decision is being requested.
 */
@Serializable
data class DecisionContext(
    /** The spell/ability that caused this decision (if any) */
    val sourceId: EntityId? = null,

    /** Name of the source for display purposes */
    val sourceName: String? = null,

    /** What phase of execution we're in */
    val phase: DecisionPhase = DecisionPhase.RESOLUTION,

    /** The entity that triggered this decision (e.g., the blocked creature for combat triggers) */
    val triggeringEntityId: EntityId? = null,

    /** If true, render the yes/no decision inline on the triggering entity card (e.g., Dragon auras) */
    val inlineOnTrigger: Boolean = false,

    /** Resolved effect description for display (e.g., "-6/-6 until end of turn") */
    val effectHint: String? = null,

    /**
     * The specific object this decision is *about*, when one effect raises the same prompt once per
     * object. Distinct from [sourceId] (the spell/ability doing the asking) and
     * [triggeringEntityId] (what caused the ability to trigger): Killing Wave asks
     * "pay X life or sacrifice it" once per creature, and without this the player sees N identical
     * prompts with no way to tell which creature each one covers.
     *
     * Set from the enclosing per-entity iteration (`pipeline.iterationTarget` — the same binding
     * `EffectTarget.Self` reads inside a `ForEachInGroup` body), so any gate raised inside such a
     * loop names its subject for free.
     *
     * Only the id travels: the client resolves the card through its already-masked state map, so a
     * face-down subject can never leak its name through the prompt.
     */
    val subjectEntityId: EntityId? = null,

    /**
     * Definition-scoped identity of the ability that raised this decision, when it was raised by a
     * triggered or activated ability of a card. Lets the client offer "always yes/no to this
     * ability" and the engine match the answer against every current and future instance of the
     * same ability (persistent yields / batch decisions — see
     * [com.wingedsheep.sdk.scripting.AbilityIdentity]). Null for decisions not tied to a single
     * card ability.
     */
    val abilityIdentity: com.wingedsheep.sdk.scripting.AbilityIdentity? = null
)

/**
 * The phase of game execution when this decision was triggered.
 */
@Serializable
enum class DecisionPhase {
    /** During spell/ability casting (choosing targets, modes) */
    CASTING,

    /** During spell/ability resolution */
    RESOLUTION,

    /** During combat (declaring attackers/blockers) */
    COMBAT,

    /** State-based actions (legend rule, etc.) */
    STATE_BASED,

    /** Triggered ability handling */
    TRIGGER
}

// =============================================================================
// Specific Decision Types
// =============================================================================

/**
 * Player must choose targets for a spell or ability.
 *
 * @property targetRequirements Describes each target that needs to be chosen
 * @property legalTargets Map of requirement index to list of valid target IDs
 */
@Serializable
@SerialName("ChooseTargetsDecision")
data class ChooseTargetsDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val targetRequirements: List<TargetRequirementInfo>,
    val legalTargets: Map<Int, List<EntityId>>,
    val canCancel: Boolean = false
) : PendingDecision

/**
 * Information about a single target requirement.
 */
@Serializable
data class TargetRequirementInfo(
    val index: Int,
    val description: String,
    val minTargets: Int = 1,
    val maxTargets: Int = 1,
    /**
     * When true, every chosen card target for this requirement must be owned by the same
     * player — "from a single graveyard" (Arashin Sunshield). Enforced against each
     * selected card's owner in [DecisionValidators.validateTargets].
     */
    val sameOwner: Boolean = false,
    /**
     * When non-null, the combined mana value of the chosen card targets for this requirement may
     * not exceed this cap — "any number of target creature cards with total mana value X or less"
     * (Fire Lord Sozin). Already resolved to a concrete integer at decision-build time (so a
     * `DynamicAmount.XValue` cap reflects the X just paid); the interactive
     * [DecisionValidators.validateTargets] rejects a selection whose summed `manaValue` exceeds it.
     * `null` imposes no aggregate cap.
     */
    val totalManaValueAtMost: Int? = null,
    /**
     * When true, no two chosen targets for this requirement may share a name — "target creature
     * cards with different names" (Behold the Sinister Six!). Enforced against each selected
     * target's name in [DecisionValidators.validateTargets].
     */
    val differentNames: Boolean = false,
    /**
     * When true, no two chosen targets for this requirement may share a controller — "for each
     * other player, exile up to one target creature that player controls" (Kaya, Spirits'
     * Justice). Enforced against each selected permanent's projected controller in
     * [DecisionValidators.validateTargets].
     */
    val differentControllers: Boolean = false
)

/**
 * Player must select cards from a set (e.g., discard, sacrifice, search library).
 *
 * @property options The entity IDs that can be selected
 * @property minSelections Minimum number that must be selected
 * @property maxSelections Maximum number that can be selected
 * @property cardInfo Optional card info for displaying hidden cards (e.g., opponent's library)
 * @property useTargetingUI If true, use the targeting UI (click on battlefield) instead of modal
 */
@Serializable
@SerialName("SelectCardsDecision")
data class SelectCardsDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val options: List<EntityId>,
    val minSelections: Int,
    val maxSelections: Int,
    /** Whether the order of selection matters */
    val ordered: Boolean = false,
    /** Card info for displaying hidden cards (null if cards are visible to the player) */
    val cardInfo: Map<EntityId, SearchCardInfo>? = null,
    /** If true, use the targeting UI (click on battlefield) instead of modal overlay */
    val useTargetingUI: Boolean = false,
    /** Label describing where selected cards go (e.g., "Put on bottom") */
    val selectedLabel: String? = null,
    /** Label describing where non-selected cards go (e.g., "Put on top") */
    val remainderLabel: String? = null,
    /** Cards shown to the player but not selectable (used for "look at" effects) */
    val nonSelectableOptions: List<EntityId> = emptyList(),
    /** When true, at most one card of each card type may be selected */
    val onePerCardType: Boolean = false,
    /** When true, at most one card of each colour may be selected (colourless cards unconstrained) */
    val onePerColor: Boolean = false,
    /**
     * The colour budget for [onePerColor] when restricted to the chooser's permanent colours
     * (e.g., Sanar's Vivid trigger). One pip per colour name (e.g., ["WHITE","BLUE"]). When null
     * or empty, the UI falls back to a generic five-colour list.
     */
    val availableColors: List<String>? = null,
    /** When true, at most one card of each name may be selected */
    val onePerCardName: Boolean = false,
    /**
     * When true, at most one land of each basic land type may be selected; a selected
     * land claims every basic land type it has, and a land with no basic land type can't
     * be selected at all (Global Ruin). The server enforces this; the UI should disable
     * lands sharing an already-claimed basic land type.
     */
    val onePerBasicLandType: Boolean = false,
    /**
     * When true, at most one card of each (printed) power may be selected. A card with no
     * fixed power can't be selected at all (Rip, Spawn Hunter). The server enforces this; the
     * UI should disable cards sharing an already-claimed power.
     */
    val onePerPower: Boolean = false,
    /**
     * Maximum sum of mana values across selected cards (Scout for Survivors). null
     * means no cap. {X} contributes 0 (CR 202.3e for cards not on the stack). The
     * UI is expected to disable cards whose mana value would push the running total
     * over the cap; the server also trims oversubmits in selection order.
     */
    val maxTotalManaValue: Int? = null,
    /**
     * **Minimum** sum of mana values across selected cards — the mirror of [maxTotalManaValue],
     * for collect evidence N (CR 701.59a: "exile any number of cards from your graveyard with
     * total mana value N or greater"). null means no floor.
     *
     * The selection is otherwise unbounded in count: the player may exile as many cards as they
     * like and any number *beyond* the floor is legal (CR 701.59a), so this — not
     * [minSelections] — is the real gate. The UI must keep the confirm button disabled until the
     * running total reaches it and show that total; the server re-validates on submit and rejects
     * an under-total selection rather than trimming it, because there is no correct way to
     * complete an insufficient payment.
     *
     * {X} contributes 0 (CR 202.3e for cards not on the stack), as it does for [maxTotalManaValue].
     */
    val minTotalManaValue: Int? = null,
    /**
     * Maximum sum of (projected) power across selected creatures (Destined Confrontation).
     * null means no cap. A creature with undefined power contributes 0. The UI is expected
     * to disable creatures whose power would push the running total over the cap; the server
     * also trims oversubmits in selection order.
     */
    val maxTotalPower: Int? = null,
    /** Conditional lower minimums for decisions like "discard two unless one is a creature". */
    val conditionalMinimums: List<ConditionalSelectionMinimum> = emptyList()
) : PendingDecision

@Serializable
data class ConditionalSelectionMinimum(
    val requiredSelections: Int,
    val minimumSelections: Int,
    val matchingOptions: List<EntityId>,
    val requiredMatches: Int = 1,
    val description: String? = null
)

/**
 * Player must make a yes/no decision (may abilities).
 */
@Serializable
@SerialName("YesNoDecision")
data class YesNoDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    /** What "yes" means (for UI button text) */
    val yesText: String = "Yes",
    /** What "no" means (for UI button text) */
    val noText: String = "No",
    /** Optional hint text shown below the prompt (e.g., keyword reminder text) */
    val hint: String? = null
) : PendingDecision

/**
 * A single yes/no decision raised once on behalf of N simultaneous, structurally identical
 * optional triggers (same controller + same [DecisionContext.abilityIdentity]) so the controller
 * answers the repeated "you may …" once instead of N times — Magic Online's "auto-stack identical
 * triggers" affordance (see `backlog/stack-collapse-and-batch-decisions.md` §B).
 *
 * The answer is a [BatchYesNoResponse] carrying both `choice` (yes/no) and `applyToAll`:
 *  - `applyToAll = true` resolves the whole run of [count] instances with `choice`.
 *  - `applyToAll = false` peels one instance off (answered with `choice`) and re-raises the batch
 *    for the remaining `count - 1` — "this one, then ask me about the rest".
 *
 * Only the *yes/no* is batched. Per-instance target selection still happens individually after a
 * "yes" (a swarm of identical pingers shares the may-question but each still picks its own target),
 * so this never makes a meaningful target/ordering choice on the player's behalf.
 */
@Serializable
@SerialName("BatchYesNoDecision")
data class BatchYesNoDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    /** How many identical instances this one answer can cover. Always ≥ 2 when raised. */
    val count: Int,
    /** What "yes" means (for UI button text) */
    val yesText: String = "Yes",
    /** What "no" means (for UI button text) */
    val noText: String = "No",
) : PendingDecision

/**
 * Player must choose from multiple modes (modal spells like Cryptic Command).
 *
 * @property modes Available modes with descriptions
 * @property minModes Minimum modes to select
 * @property maxModes Maximum modes to select
 */
@Serializable
@SerialName("ChooseModeDecision")
data class ChooseModeDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val modes: List<ModeOption>,
    val minModes: Int = 1,
    val maxModes: Int = 1
) : PendingDecision

/**
 * A single mode option.
 */
@Serializable
data class ModeOption(
    val index: Int,
    val text: String,
    val available: Boolean = true
)

/**
 * Player must choose a color (e.g., protection from color of your choice).
 */
@Serializable
@SerialName("ChooseColorDecision")
data class ChooseColorDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val availableColors: Set<Color> = Color.entries.toSet()
) : PendingDecision

/**
 * Player must choose a number (e.g., X value, divide damage).
 */
@Serializable
@SerialName("ChooseNumberDecision")
data class ChooseNumberDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val minValue: Int,
    val maxValue: Int
) : PendingDecision

/**
 * Player must distribute a value among targets (e.g., divide 4 damage).
 *
 * @property totalAmount The total to distribute
 * @property targets The targets to distribute among
 * @property minPerTarget Minimum each target must receive (usually 1 for damage)
 */
@Serializable
@SerialName("DistributeDecision")
data class DistributeDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val totalAmount: Int,
    val targets: List<EntityId>,
    val minPerTarget: Int = 0,
    val maxPerTarget: Map<EntityId, Int> = emptyMap(),
    val allowPartial: Boolean = false
) : PendingDecision

/**
 * Player must order objects (e.g., damage assignment order, scry).
 *
 * @property objects The entity IDs that need to be ordered
 * @property cardInfo Optional card info for UI display (used for blocker ordering in combat)
 */
@Serializable
@SerialName("OrderObjectsDecision")
data class OrderObjectsDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val objects: List<EntityId>,
    val cardInfo: Map<EntityId, SearchCardInfo>? = null
) : PendingDecision

/**
 * Player must split cards into piles (e.g., Fact or Fiction).
 */
@Serializable
@SerialName("SplitPilesDecision")
data class SplitPilesDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val cards: List<EntityId>,
    val numberOfPiles: Int = 2,
    /** Labels for the piles (e.g., ["Keep", "Discard"]) */
    val pileLabels: List<String> = emptyList(),
    /** Card info for displaying hidden cards (e.g., top of library during surveil) */
    val cardInfo: Map<EntityId, SearchCardInfo>? = null
) : PendingDecision

/**
 * Per-option metadata accompanying a [ChooseOptionDecision].
 *
 * - [id] is a stable machine-readable identifier (when the caller wants to
 *   match the chosen option by id rather than by index, e.g. for named modes).
 * - [description] is optional rules-text shown alongside the option label.
 * - [iconKey] is an optional asset identifier the frontend can map to an SVG
 *   icon. Cards may omit it for a purely textual choice.
 */
@Serializable
data class OptionMetadata(
    val id: String? = null,
    val description: String? = null,
    val iconKey: String? = null
)

/**
 * Player must choose from a fixed set of options (generic choice).
 */
@Serializable
@SerialName("ChooseOptionDecision")
data class ChooseOptionDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val options: List<String>,
    val defaultSearch: String? = null,
    /** Maps option index to entity IDs of cards associated with that option (for preview) */
    val optionCardIds: Map<Int, List<EntityId>>? = null,
    /**
     * Optional per-option metadata aligned positionally with [options]. Empty
     * (the default) means no metadata; otherwise must be the same length as
     * [options]. The frontend uses [OptionMetadata.iconKey] to render visual
     * choices and [OptionMetadata.description] to show reminder text.
     */
    val optionMetadata: List<OptionMetadata> = emptyList(),
    /**
     * Whether the player may back out of this decision entirely via
     * [CancelDecisionResponse]. Used for cast-time modal mode selection (rules
     * 601.2b–c): cancelling before any cost is paid must roll back to the
     * pre-cast state. Defaults to `false` to preserve existing behavior.
     */
    val canCancel: Boolean = false
) : PendingDecision

/**
 * Player picks a replacement in one screen: a FROM word and a TO word, shown together as
 * "from → to". Used by text-changing cards (Crystal Spray, Artificial Evolution) so the two
 * halves of the choice are one component instead of two sequential prompts.
 *
 * @property fromOptions the words that may be replaced (already ordered "relevant first").
 * @property toOptions the candidate replacements.
 * @property fromMetadata / toMetadata per-option icon/description, positionally aligned.
 * @property allowedToByFrom index-aligned to [fromOptions]: entry i lists the [toOptions] indices
 *   allowed when FROM option i is chosen. An empty outer list means every TO is allowed for any FROM
 *   (Artificial Evolution). Crystal Spray populates it to keep the replacement in the same category
 *   (color↔color, land↔land) and exclude the chosen word.
 * @property defaultFromIndex a FROM option to pre-select (the first on-card word), or null.
 */
@Serializable
@SerialName("ChooseReplacementDecision")
data class ChooseReplacementDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val fromOptions: List<String>,
    val toOptions: List<String>,
    val fromMetadata: List<OptionMetadata> = emptyList(),
    val toMetadata: List<OptionMetadata> = emptyList(),
    val allowedToByFrom: List<List<Int>> = emptyList(),
    val defaultFromIndex: Int? = null
) : PendingDecision

/**
 * Player must assign combat damage from an attacker to blockers.
 *
 * Legacy serialized question; the live combat path uses [CombatResolutionDecision]. Under current
 * CR 510.1a/c, all available damage is divided freely among eligible blockers. Trample separately
 * requires lethal assignment to every blocker before assigning damage to the defender.
 *
 * @property attackerId The attacking creature assigning damage
 * @property availablePower Total damage available to assign
 * @property orderedTargets Eligible blockers in presentation/default order; this imposes no restriction
 * @property defenderId The defending player (only receives damage if attacker has trample)
 * @property minimumAssignments Lethal thresholds for the trample check, not mandatory per-target amounts
 * @property defaultAssignments A suggested complete damage distribution
 * @property hasTrample Whether excess damage can go to defending player
 * @property hasDeathtouch If true, 1 damage is lethal to any creature
 */
@Serializable
@SerialName("AssignDamageDecision")
data class AssignDamageDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val attackerId: EntityId,
    val availablePower: Int,
    val orderedTargets: List<EntityId>,
    val defenderId: EntityId?,
    val minimumAssignments: Map<EntityId, Int>,
    val defaultAssignments: Map<EntityId, Int>,
    val hasTrample: Boolean,
    val hasDeathtouch: Boolean
) : PendingDecision

/**
 * Information about a card available for selection during library search.
 * This is embedded in the decision because library cards are normally hidden.
 */
@Serializable
data class SearchCardInfo(
    val name: String,
    val manaCost: String,
    val typeLine: String,
    val imageUri: String? = null,
    /** Colour identity letters (e.g. ["W","U"]); empty for colourless cards */
    val colors: List<String> = emptyList(),
    /**
     * Printed (base) power, when fixed. Null for cards with no printed P/T or a
     * characteristic-defining `*` power. Lets a hidden-zone selection UI group cards
     * by power for [SelectCardsDecision.onePerPower].
     */
    val power: Int? = null
)

/**
 * Player must select cards from their library.
 *
 * Unlike SelectCardsDecision, this includes embedded card info because
 * library contents are normally hidden from the client. The client needs
 * the card metadata to display the search UI.
 *
 * @property options The entity IDs of cards matching the filter
 * @property minSelections Minimum cards to select (0 allows "fail to find")
 * @property maxSelections Maximum cards to select
 * @property cards Map of entity ID to card info for UI display
 * @property filterDescription Human-readable description of the filter
 */
@Serializable
@SerialName("SearchLibraryDecision")
data class SearchLibraryDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val options: List<EntityId>,
    val minSelections: Int,
    val maxSelections: Int,
    val cards: Map<EntityId, SearchCardInfo>,
    val filterDescription: String
) : PendingDecision

/**
 * Player must reorder cards from the top of their library.
 *
 * Used for "look at the top N cards and put them back in any order" effects
 * like Omen. The client displays the cards with drag-and-drop reordering,
 * with a clear indication of which end is the top of the library.
 *
 * @property cards List of entity IDs in their current order (first = top of library)
 * @property cardInfo Map of entity ID to card info for UI display
 */
@Serializable
@SerialName("ReorderLibraryDecision")
data class ReorderLibraryDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val cards: List<EntityId>,
    val cardInfo: Map<EntityId, SearchCardInfo>
) : PendingDecision

/**
 * Player must select mana sources to pay a cost (e.g., Lightning Rift's {1}).
 *
 * Shown after the player agrees to pay, before target selection.
 * Includes an "Auto Pay" shortcut that uses the solver's suggestion.
 *
 * @property availableSources List of mana source entity IDs + metadata for display
 * @property requiredCost The mana cost string to display
 * @property autoPaySuggestion Pre-computed auto-tap suggestion (entity IDs to tap)
 */
@Serializable
@SerialName("SelectManaSourcesDecision")
data class SelectManaSourcesDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val availableSources: List<ManaSourceOption>,
    val requiredCost: String,
    val autoPaySuggestion: List<EntityId>,
    val canDecline: Boolean = false,
    /**
     * For a Ward—Waterbend cost (Avatar: The Last Airbender), the untapped artifacts and
     * creatures the paying player may tap to help pay the generic portion of [requiredCost] —
     * each tapped permanent pays {1}. Empty for an ordinary mana payment. The chosen subset is
     * returned in [ManaSourcesSelectedResponse.waterbendPermanents]; mirrors the activated-ability
     * waterbend surface (`LegalAction.waterbendPermanents`).
     */
    val waterbendPermanents: List<WaterbendPermanentChoice> = emptyList()
) : PendingDecision

/**
 * An untapped artifact/creature offered as a Waterbend tap-to-help for a Ward—Waterbend payment.
 * [isCreature] lets the client distinguish creatures from artifacts for labelling only; the tap
 * always pays {1} generic regardless.
 */
@Serializable
data class WaterbendPermanentChoice(
    val entityId: EntityId,
    val name: String,
    val isCreature: Boolean
)

// =============================================================================
// Decision Responses
// =============================================================================

/**
 * A player's response to a PendingDecision.
 */
@Serializable
sealed interface DecisionResponse {
    /** Must match the PendingDecision.id */
    val decisionId: String

    /**
     * The same response retargeted at a different pending-decision id. The id is only a routing
     * nonce — the choice payload is unchanged — so this lets a caller that holds a recorded response
     * re-bind it to a reconstructed decision. Current routing IDs reproduce from serialized game
     * state; replay retains this operation for historical random or clock-based IDs.
     */
    fun withDecisionId(newId: String): DecisionResponse = when (this) {
        is TargetsResponse -> copy(decisionId = newId)
        is CardsSelectedResponse -> copy(decisionId = newId)
        is YesNoResponse -> copy(decisionId = newId)
        is BatchYesNoResponse -> copy(decisionId = newId)
        is ModesChosenResponse -> copy(decisionId = newId)
        is ColorChosenResponse -> copy(decisionId = newId)
        is NumberChosenResponse -> copy(decisionId = newId)
        is DistributionResponse -> copy(decisionId = newId)
        is OrderedResponse -> copy(decisionId = newId)
        is PilesSplitResponse -> copy(decisionId = newId)
        is OptionChosenResponse -> copy(decisionId = newId)
        is ReplacementChosenResponse -> copy(decisionId = newId)
        is BudgetModalResponse -> copy(decisionId = newId)
        is DamageAssignmentResponse -> copy(decisionId = newId)
        is ManaSourcesSelectedResponse -> copy(decisionId = newId)
        is CombatResolutionResponse -> copy(decisionId = newId)
        is CancelDecisionResponse -> copy(decisionId = newId)
    }
}

/**
 * Response to ChooseTargetsDecision.
 */
@Serializable
@SerialName("TargetsResponse")
data class TargetsResponse(
    override val decisionId: String,
    /** Map of requirement index to chosen target IDs */
    val selectedTargets: Map<Int, List<EntityId>>
) : DecisionResponse

/**
 * Response to SelectCardsDecision.
 */
@Serializable
@SerialName("CardsSelectedResponse")
data class CardsSelectedResponse(
    override val decisionId: String,
    val selectedCards: List<EntityId>
) : DecisionResponse

/**
 * Response to YesNoDecision.
 */
@Serializable
@SerialName("YesNoResponse")
data class YesNoResponse(
    override val decisionId: String,
    val choice: Boolean
) : DecisionResponse

/**
 * Response to [BatchYesNoDecision].
 *
 * @property choice the yes/no answer applied to the peeled instance (or whole run).
 * @property applyToAll when true, [choice] resolves every instance the batch covers; when false,
 *   it resolves a single instance and the batch re-raises for the rest.
 */
@Serializable
@SerialName("BatchYesNoResponse")
data class BatchYesNoResponse(
    override val decisionId: String,
    val choice: Boolean,
    val applyToAll: Boolean,
) : DecisionResponse

/**
 * Response to ChooseModeDecision.
 */
@Serializable
@SerialName("ModesChosenResponse")
data class ModesChosenResponse(
    override val decisionId: String,
    val selectedModes: List<Int>
) : DecisionResponse

/**
 * Response to ChooseColorDecision.
 */
@Serializable
@SerialName("ColorChosenResponse")
data class ColorChosenResponse(
    override val decisionId: String,
    val color: Color
) : DecisionResponse

/**
 * Response to ChooseNumberDecision.
 */
@Serializable
@SerialName("NumberChosenResponse")
data class NumberChosenResponse(
    override val decisionId: String,
    val number: Int
) : DecisionResponse

/**
 * Response to DistributeDecision.
 */
@Serializable
@SerialName("DistributionResponse")
data class DistributionResponse(
    override val decisionId: String,
    /** Map of target ID to amount assigned */
    val distribution: Map<EntityId, Int>
) : DecisionResponse

/**
 * Response to OrderObjectsDecision.
 */
@Serializable
@SerialName("OrderedResponse")
data class OrderedResponse(
    override val decisionId: String,
    val orderedObjects: List<EntityId>
) : DecisionResponse

/**
 * Response to SplitPilesDecision.
 */
@Serializable
@SerialName("PilesSplitResponse")
data class PilesSplitResponse(
    override val decisionId: String,
    /** List of piles, each containing entity IDs */
    val piles: List<List<EntityId>>
) : DecisionResponse

/**
 * Response to ChooseOptionDecision.
 */
@Serializable
@SerialName("OptionChosenResponse")
data class OptionChosenResponse(
    override val decisionId: String,
    val optionIndex: Int
) : DecisionResponse

/**
 * Response to [ChooseReplacementDecision]: the chosen FROM and TO option indices.
 */
@Serializable
@SerialName("ReplacementChosenResponse")
data class ReplacementChosenResponse(
    override val decisionId: String,
    val fromIndex: Int,
    val toIndex: Int
) : DecisionResponse

/**
 * Player must choose modes from a budget-based modal spell (Bloomburrow Season cycle).
 * Each mode has a pawprint cost, and the player has a budget to spend.
 * The same mode can be chosen multiple times if budget allows.
 */
@Serializable
@SerialName("BudgetModalDecision")
data class BudgetModalDecision(
    override val id: String,
    override val playerId: EntityId,
    override val prompt: String,
    override val context: DecisionContext,
    val budget: Int,
    val modes: List<BudgetModeOption>
) : PendingDecision

/**
 * A single mode option in a budget modal decision (cost + description, no effect data).
 */
@Serializable
data class BudgetModeOption(
    val cost: Int,
    val description: String
)

/**
 * Response to BudgetModalDecision.
 * Contains the selected mode indices in the order they should execute.
 * The same index can appear multiple times (repeated mode selection).
 */
@Serializable
@SerialName("BudgetModalResponse")
data class BudgetModalResponse(
    override val decisionId: String,
    val selectedModeIndices: List<Int>
) : DecisionResponse

/**
 * Response to AssignDamageDecision.
 */
@Serializable
@SerialName("DamageAssignmentResponse")
data class DamageAssignmentResponse(
    override val decisionId: String,
    /** Map of target ID (creature or player) to damage amount */
    val assignments: Map<EntityId, Int>
) : DecisionResponse

/**
 * Response to SelectManaSourcesDecision.
 *
 * @property selectedSources Entity IDs of the mana sources to tap (ignored if autoPay is true)
 * @property autoPay If true, use the auto-tap suggestion instead of manual selection
 */
@Serializable
@SerialName("ManaSourcesSelectedResponse")
data class ManaSourcesSelectedResponse(
    override val decisionId: String,
    val selectedSources: List<EntityId> = emptyList(),
    val autoPay: Boolean = false,
    /**
     * Untapped artifacts/creatures the player taps to help pay a Ward—Waterbend cost (Avatar:
     * The Last Airbender) — each pays {1} of the generic. Empty for an ordinary mana payment.
     */
    val waterbendPermanents: Set<EntityId> = emptySet(),
    /**
     * The player explicitly refused to pay (only meaningful when
     * [SelectManaSourcesDecision.canDecline]).
     *
     * Declining used to be inferred purely from an empty submission, which stopped being
     * unambiguous once a player could activate mana abilities during the payment itself
     * (CR 605.3a — see [com.wingedsheep.engine.mechanics.mana.ManaPaymentWindow]): "I tapped my
     * own sources and the mana is already floating, just take it" also submits nothing. The flag
     * separates the two; [isDecline] keeps the old inference as the fallback for clients and AI
     * players that don't set it.
     */
    val declined: Boolean = false
) : DecisionResponse {

    /**
     * Whether this submission refuses the payment.
     *
     * @param floatingCoversCost true when the player's mana pool already covers the whole cost, in
     *   which case an empty submission means "pay with what I floated", not "decline".
     */
    fun isDecline(floatingCoversCost: Boolean): Boolean = when {
        declined -> true
        autoPay -> false
        selectedSources.isNotEmpty() || waterbendPermanents.isNotEmpty() -> false
        else -> !floatingCoversCost
    }
}

/**
 * Response to cancel a decision and go back to the previous choice.
 * Used when a decision supports cancellation (e.g., modal target selection
 * can cancel back to mode selection).
 */
@Serializable
@SerialName("CancelDecisionResponse")
data class CancelDecisionResponse(
    override val decisionId: String
) : DecisionResponse
