import json,pathlib,zipfile,hashlib,re,gzip,xml.etree.ElementTree as E,datetime
p=pathlib.Path(__file__).parent; sha=lambda b:hashlib.sha256(b).hexdigest();z=zipfile.ZipFile(p/'card-original.zip');assert z.testzip() is None
expected=json.loads((p.parent/'produced-token-qualification/successor/expected-case-identities.json').read_text());source=json.loads((p.parent/'produced-token-qualification/successor/card-live-source-bindings.json').read_text());report={'schema':'industrial-produced-token-author-raw-audit-v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author':'/root/industrial','source':'1261a25494d93f588efbcd1c1e5798b212a058c9','tree':'7e635c7ff700094d840bb64fdba7699f724cf594','run':36283945576,'attempt':1,'job':108521000011,'artifact_id':10920645338,'artifact':{'bytes':(p/'card-original.zip').stat().st_size,'sha256':sha((p/'card-original.zip').read_bytes()),'members':len(z.namelist()),'crc_pass':True},'xml':[],'banks':{},'source_bindings':[]}
for bank,prefix,logpath,wanted in [('focused','tmp/iw-v2-produced-token-focused-xml/','tmp/iw-v2-produced-token-focused.log',20),('broad','home/runner/','tmp/iw-v2-card-receiving.log',154)]:
 cases=[]
 for n in z.namelist():
  if n.startswith(prefix) and n.endswith('.xml'):
   r=E.fromstring(z.read(n));c=[(x.get('classname'),x.get('name')) for x in r.findall('testcase')];cases+=c
   assert len(c)==int(r.get('tests')) and all(int(r.get(k,'0'))==0 for k in ['failures','errors','skipped'])
   assert all(len(x)==0 for x in r.findall('testcase'))
   report['xml'].append({'bank':bank,'name':n,'sha256':sha(z.read(n)),'tests':len(c),'timestamp':r.get('timestamp')})
 expect=[(x['class'],x['name']) for x in expected[bank]];assert len(cases)==len(set(cases))==wanted and set(cases)==set(expect)
 log=z.read(logpath).decode();tasks=re.findall(r'^> Task (\S+:test)(?=\s|$)([^\n]*)$',log,re.M);assert all(not tail.strip() for name,tail in tasks);assert 'BUILD SUCCESSFUL' in log
 passed=sum(1 for x in log.splitlines() if x.endswith(' PASSED'));assert passed==wanted
 report['banks'][bank]={'unique_cases':wanted,'expected_case_identity_exact':True,'pass_lines':passed,'failure':0,'error':0,'skip':0,'actual_test_tasks':sorted(set(name for name,tail in tasks)),'test_task_status_suffixes':sorted(set(tail for name,tail in tasks)),'raw_log_sha256':sha(z.read(logpath)),'build_successful':True}
assert len(report['banks']['focused']['actual_test_tasks'])==3 and len(report['banks']['broad']['actual_test_tasks'])==8
report.update({'focused_overlaps_broad':True,'unique_receiving_cases':154,'original_failed18_preserved':True,'prior_failed_original_sha256':'f83ef1fcdce0dc823f16efb3be93b50e2d153c7332da1176a76f832cda2c6049'})
prov=json.loads(z.read('tmp/iw-v2-produced-token-provenance.json'));status=json.loads(z.read('tmp/iw-v2-status-provenance.json'));assert status['source_head']==report['source']==status['expected_head']
tree_binding=json.loads((p/'card-current-tree-binding.json').read_text());assert tree_binding['tree']==report['tree'] and not tree_binding['truncated']
for path,h in prov['verified_source_sha256'].items():
 body=source[path]['content'].encode();assert sha(body)==h;blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest();assert blob==source[path]['sha']==tree_binding['paths'][path]['sha'];report['source_bindings'].append({'path':path,'sha256':h,'git_blob':blob,'retained_exact_body_bound_to_current_git_tree':True})
manifest_path=next(n for n in z.namelist() if n.endswith('/produced-token-qualification-source.json'));assert sha(z.read(manifest_path))==prov['manifest_sha256'];assert len(report['source_bindings'])==12
assert z.read('tmp/iw-v2-card-snapshot.diff')==b'';report['snapshot_diff_bytes']=0
ref=json.loads(z.read('tmp/iw-v2-assay/reference-inputs.json'));after=json.loads(z.read('tmp/iw-v2-assay/reference-after.json'));equiv=json.loads(z.read('tmp/iw-v2-assay/input-equivalence.json'));gz=z.read('tmp/iw-v2-assay/relevant-oracle-inputs.jsonl.gz');assert sha(gz)==ref['subset_sha256'];rows=gzip.decompress(gz).splitlines(keepends=True);assert len(rows)==len(ref['selected_rows'])==528
for row,meta in zip(rows,ref['selected_rows']):assert sha(row)==meta['raw_line_sha256']
assert ref['whole_bulk_sha256']==after['whole_bulk_sha256'] and after['unchanged'] and equiv['same_tracked_assay_sdk_build_and_two_golden_inputs'];assert equiv['candidate']==report['source']
report['assay']={'actual_exit_codes':{},'sets':{'VOW':{'total':253,'compared':70,'agree':70,'divergent':0,'undecodable':0,'excluded_grammar':127,'excluded_unmodelled_slots':5,'excluded_cannot_fold':1,'excluded_multiface':49,'excluded_oracle_text':1},'LCI':{'total':275,'compared':54,'agree':54,'divergent':0,'undecodable':0,'excluded_grammar':185,'excluded_unmodelled_slots':0,'excluded_cannot_fold':1,'excluded_multiface':34,'excluded_oracle_text':1}},'same_reference_before_after_sha256':ref['whole_bulk_sha256'],'retained_relevant_raw_rows':528,'raw_subset_sha256':sha(gz),'raw_subset_each_row_hash_verified':True,'whole_bulk_retained':False,'unchanged_assay_sdk_build_goldens_source_receipt':True,'coverage_is_limited_to_comparable_rows':True,'text_mismatch_identification':'assay-text-mismatch-identification.json','text_mismatch_attribution':'Unchanged golden/parser inputs; Halana/Alena keyword order and Walk with the Ancestors newline grouping differ from captured Oracle input; both remain excluded; source-informed Python identification is not JVM replay.'}
for name in ['corpus','VOW','LCI']:
 ex=int(z.read('tmp/iw-v2-assay/'+name+'-exit.txt'));assert ex==0;report['assay']['actual_exit_codes'][name]=ex
joblog=(p/'card-complete-decoded-job.log').read_text(encoding='utf-8-sig');assert '--rerun-tasks --no-build-cache' in joblog and report['source'] in joblog
report['freshness']={'card_checkout_actual_head':report['source'],'focused_test_tasks':3,'broad_test_tasks':8,'commands_have_rerun_tasks_and_no_build_cache':True,'actual_task_lines_no_cache_up_to_date_no_source_skipped_failed':True,'focused_passes':20,'broad_passes':154,'complete_decoded_job_log_sha256':sha((p/'card-complete-decoded-job.log').read_bytes()),'build_route':'prescribed just/scripts; runner reports shlock missing and existing unlocked fallback, not a working semaphore'}
report['scope']='Current card source receiving; full CI/runtime/priority are separate. No official gameplay admission.'
report['source_body_scope']='Twelve retained exact73394 source bodies match current1261 Gitblob identities on the same complete tree; not twelve fresh body downloads.'
report['disposition']='AUTHOR_BOUNDED_CARD_ASSAY_AUDIT_PASS_PENDING_INDEPENDENT_REVIEW; NO_COMPLETE_RUNTIME_OR_GAMEPLAY_ADMISSION'
(p/'AUTHOR_CARD_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'sha256':sha((p/'AUTHOR_CARD_AUDIT.json').read_bytes()),'cases':[20,154],'source_pins':12,'raw_rows':528}))
