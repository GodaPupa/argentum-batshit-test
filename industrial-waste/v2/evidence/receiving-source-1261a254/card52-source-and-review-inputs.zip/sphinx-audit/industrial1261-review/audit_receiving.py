"""Independent read-only XML/log/source/artifact audit; never launches the engine."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timedelta
import gzip, hashlib, json, re, zipfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
RAW=ROOT/'industrial/audit-1261'
SRC='1261a25494d93f588efbcd1c1e5798b212a058c9'
TREE='7e635c7ff700094d840bb64fdba7699f724cf594'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):return json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b)}
def dt(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
meta=read(OUT/'live-metadata-source-scope.json')
assert meta['source']['sha']==SRC and meta['source']['tree']['sha']==TREE
assert meta['merge']['tree']['sha']==TREE
assert meta['tree']['sha']==TREE and meta['tree']['truncated'] is False
tree={x['path']:x for x in meta['tree']['selected']}
bodies={x['path']:x['content'].encode() for x in read(ROOT/'industrial/audit-fc9bb/root-receiving52-exact-source.json')}
bodies.update({p:x['content'].encode() for p,x in read(ROOT/'industrial/produced-token-qualification/successor/card-live-source-bindings.json').items()})
bodies.update({x['path']:x['content'].encode() for x in read(OUT/'fresh-status-source-bodies.json')})
sources=[]
for p,b in bodies.items():
 assert blob(b)==tree[p]['sha'],p
 sources.append({'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
manifests=read(RAW/'current52-manifests.json')
for p,row in manifests.items():
 b=row['content'].encode();assert blob(b)==tree[p]['sha'];bodies[p]=b

def archive(p,run_id,artifact_id):
 m=meta['runs'][str(run_id)];run=m['run'];jobs=m['jobs']['jobs'];arts=m['artifacts']['artifacts']
 assert run['head_sha']==SRC and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success'
 assert len(jobs)==m['jobs']['total_count']==1 and jobs[0]['conclusion']=='success'
 art=next(a for a in arts if a['id']==artifact_id);b=p.read_bytes()
 assert art['digest']=='sha256:'+sha(b) and art['size_in_bytes']==len(b)
 assert art['workflow_run']['head_sha']==SRC and art['workflow_run']['id']==run_id
 z=zipfile.ZipFile(p);assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
 return z,{'run':run_id,'event':run['event'],'attempt':1,'job':jobs[0]['id'],'artifact_id':artifact_id,**pin(p),'crc':'PASS','members':[{'path':n,'bytes':len(z.read(n)),'sha256':sha(z.read(n))} for n in z.namelist()]},jobs[0]
def xml_cases(z,names,window):
 rows=[];suites=[]
 for n in names:
  b=z.read(n);e=ET.fromstring(b);cases=e.findall('testcase')
  assert len(cases)==int(e.attrib['tests'])
  assert all(int(e.attrib.get(k,0))==0 for k in ['failures','errors','skipped'])
  assert all(c.find(k) is None for c in cases for k in ['failure','error','skipped'])
  assert window[0]<=dt(e.attrib['timestamp'])<=window[1],(n,e.attrib['timestamp'],window)
  ids=[(c.attrib['classname'],c.attrib['name']) for c in cases]
  rows.extend(ids);suites.append({'path':n,'sha256':sha(b),'cases':len(cases),'timestamp':e.attrib['timestamp']})
 assert len(rows)==len(set(rows))
 return rows,suites
def window(job,prefix):
 s=next(s for s in job['steps'] if s['name'].startswith(prefix));assert s['conclusion']=='success'
 return dt(s['started_at']),dt(s['completed_at'])+timedelta(seconds=1)
def log_check(b,expected_tasks,workers,passes=None):
 s=b.decode();alltasks=re.findall(r'^> Task (\S+)(?: ([^\n]*))?$',s,re.M)
 tasks=[(p,tail) for p,tail in alltasks if p.endswith(':test')]
 assert tasks and set(p for p,_ in tasks)==set(expected_tasks),tasks
 assert all(not tail.strip() for _,tail in tasks),tasks
 assert 'BUILD SUCCESSFUL' in s and 'BUILD FAILED' not in s
 starts=s.count('started executing tests.');ends=s.count('finished executing tests.')
 assert starts==ends==workers,(starts,ends,workers)
 passed=re.findall(r'^(.+?) > (.+?) PASSED\s*$',s,re.M)
 if passes is not None:assert len(passed)==passes,(len(passed),passes)
 assert "'shlock' not found; running ./gradlew unlocked" in s
 return {'sha256':sha(b),'test_tasks':tasks,'fresh_worker_start_finish_pairs':workers,'pass_line_count':len(passed),'command':s.splitlines()[0],'build_successful':True,'semaphore':'missing shlock; existing unlocked fallback observed'}

report={'schema':'sphinx-independent-industrial1261-raw-audit-v1','source':SRC,'tree':TREE,'source_pins':sources,'banks':{}}
for name,rid,aid,expected_count,old in [('combat',36283941451,10919593751,32,'10915076010.zip'),('token',36283941475,10919887433,20,'10914682665.zip')]:
 z,rec,job=archive(RAW/(name+'-original.zip'),rid,aid)
 prov=json.loads(z.read('source-provenance.json'));assert prov['candidate_head']==SRC and prov['tree']==TREE
 assert prov['official_games']==0 and prov['gameplay_authorized'] is False
 for p,h in prov['source_sha256'].items(): assert sha(bodies[p])==h,p
 mp='industrial-waste/v2/'+('shared-current-combat-receiving.json' if name=='combat' else 'shared-attacking-token-receiving.json')
 assert sha(bodies[mp])==prov['manifest_sha256']
 man=json.loads(bodies[mp]);configured=man['banks']
 expected=[(x['class'],n) for x in configured for n in x['case_names']]
 cases,suites=xml_cases(z,[n for n in z.namelist() if n.endswith('.xml')],window(job,'Execute'))
 assert len(cases)==expected_count and set(cases)==set(expected)
 oldp=ROOT/'industrial/audit-fc9bb'/old
 with zipfile.ZipFile(oldp) as oz:
  assert oz.testzip() is None
  oldcases=[(c.attrib['classname'],c.attrib['name']) for n in oz.namelist() if n.endswith('.xml') for c in ET.fromstring(oz.read(n)).findall('testcase')]
 assert set(cases)==set(oldcases) and len(oldcases)==expected_count
 exits={n:int(z.read(n).strip()) for n in z.namelist() if n.endswith('exit-status.txt')};assert exits and all(v==0 for v in exits.values())
 logs={}
 for n in [n for n in z.namelist() if n.endswith('.log')]:
  task=':mtg-sets:2025:tests:test' if n=='dalkovan-2.log' else ':rules-engine:test'
  logs[n]=log_check(z.read(n),[task],1)
 rec.update({'unique_cases':len(cases),'case_identities':sorted(cases),'xml':suites,'raw_exits':exits,'logs':logs,'source_pin_count':len(prov['source_sha256']),'manifest_sha256':sha(bodies[mp]),'unchanged_identity_original':pin(oldp),'source_map_timing':'Pre-execution source-provenance map; no separate archived post-execution map.'})
 report['banks'][name]=rec

z,rec,job=archive(RAW/'card-original.zip',36283945576,10920645338)
expected=read(ROOT/'industrial/produced-token-qualification/successor/expected-case-identities.json')
for row in expected['inputs']:
 assert sha((ROOT/row['path']).read_bytes())==row['sha256']
card_ids={};allcard=[]
for bank,count,prefix in [('focused',20,'Qualify discard'),('broad',154,'Qualify cards')]:
 names=[n for n in z.namelist() if n.endswith('.xml') and ('/focused' in n or 'produced-token-focused-xml' in n)==(bank=='focused')]
 ids,suites=xml_cases(z,names,window(job,prefix))
 assert len(ids)==count and set(ids)=={(x['class'],x['name']) for x in expected[bank]}
 card_ids[bank]=set(ids);allcard.extend(ids)
 lp='tmp/iw-v2-produced-token-focused.log' if bank=='focused' else 'tmp/iw-v2-card-receiving.log'
 tasks=[':rules-engine:test',':mtg-sets:2017-2022:tests:test',':mtg-sets:2023:tests:test']
 if bank=='broad':tasks+=[':ai:test',':mtg-sets:2003-2007:tests:test',':mtg-sets:2008-2016:tests:test',':mtg-sets:2024:tests:test',':mtg-sets:2025:tests:test']
 log=log_check(z.read(lp),tasks,0,count)
 assert '--rerun-tasks --no-build-cache --no-daemon' in log['command']
 if bank=='broad':assert '--continue' in log['command']
 rec[bank]={'unique_cases':len(ids),'identities':sorted(ids),'xml':suites,'log':log,'worker_line_limit':'No --info worker-pair markers emitted; actual test task lines, named PASSED lines, XML timestamps and successful step/command provide freshness.'}
assert card_ids['focused']<=card_ids['broad'] and len(set(allcard))==154
with zipfile.ZipFile(ROOT/'industrial/audit-51607/cards-e5a0.zip') as prior:
 oldids={(c.attrib['classname'],c.attrib['name']) for n in prior.namelist() if n.endswith('.xml') for c in ET.fromstring(prior.read(n)).findall('testcase')}
 assert prior.testzip() is None and len(oldids)==136 and oldids<=card_ids['broad']
rec['prior136_identities_preserved']=True
rec['new_case_identities']=sorted(card_ids['broad']-oldids)
tok=json.loads(z.read('tmp/iw-v2-produced-token-provenance.json'))
sta=json.loads(z.read('tmp/iw-v2-status-provenance.json'))
assert sta['source_head']==sta['expected_head']==SRC
for prov,key in [(tok,'verified_source_sha256'),(sta,'verified_receiving_pins')]:
 for p,h in prov[key].items():assert sha(bodies[p])==h,p
prefix='home/runner/work/argentum-batshit-test/argentum-batshit-test/'
for p in ['industrial-waste/v2/produced-token-qualification-source.json','industrial-waste/v2/execution-status-capability.json','industrial-waste/v2/execution-status-receiving-source.json','mtg-sets/src/test/resources/snapshots/cards/TSP.json','mtg-sets/src/test/resources/snapshots/cards/ROE.json']:
 b=z.read(prefix+p);assert blob(b)==tree[p]['sha'],p
assert sha(z.read(prefix+'industrial-waste/v2/produced-token-qualification-source.json'))==tok['manifest_sha256']
assert sha(z.read(prefix+'industrial-waste/v2/execution-status-capability.json'))==sta['capability_sha256']
assert sha(z.read(prefix+'industrial-waste/v2/execution-status-receiving-source.json'))==sta['receiving_source_manifest_sha256']
assert z.read('tmp/iw-v2-card-snapshot.diff')==b''
joblog=(RAW/'card-complete-decoded-job.log').read_text()
assert SRC in joblog and 'HEAD is now at 1261a254' in joblog and 'Cleaning up orphan processes' in joblog
for bank in ['focused','broad']:
 for cls,n in rec[bank]['identities']:assert n+' PASSED' in joblog,(cls,n)
rec.update({'unique_receiving_cases':154,'focused_subset_of_broad':True,'tracked_snapshot_diff_bytes':0,'focused_source_pins':len(tok['verified_source_sha256']),'status_receiving_pins':len(sta['verified_receiving_pins']),'complete_decoded_job_log':pin(RAW/'card-complete-decoded-job.log'),'full_runtime_admitted':False})
report['banks']['card']=rec
report['proof_inputs']=[pin(OUT/'live-metadata-source-scope.json'),pin(OUT/'fresh-status-source-bodies.json'),pin(ROOT/'industrial/audit-fc9bb/root-receiving52-exact-source.json'),pin(ROOT/'industrial/produced-token-qualification/successor/card-live-source-bindings.json')]
report['scope_limits']=['Actual bounded card154 (focused20 subset), combat32 and token20 only. No complete runtime, official R1 action, full pilot or gameplay permit.', 'Current source proof rehashes retained immutable bodies and binds them to a newly fetched current tree; six additional status bodies freshly fetched. No claim of 80+ freshly downloaded source bodies.', 'All three complete ZIPs read and retained. Card assay files included in member hashing, but this audit does not independently accept Assay parser interpretation or claim whole Oracle bulk retention.', 'No new engine command, workflow, source mutation, journal replay, allocation or outcome was executed by this audit.']
(OUT/'independent-raw-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','source_bodies':len(sources),'card':154,'focused_subset':20,'combat':32,'token':20,'sha256':sha((OUT/'independent-raw-audit.json').read_bytes())}))
