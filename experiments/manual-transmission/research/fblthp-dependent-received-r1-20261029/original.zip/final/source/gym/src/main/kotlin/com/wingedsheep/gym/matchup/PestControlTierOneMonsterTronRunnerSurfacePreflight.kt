package com.wingedsheep.gym.matchup

data class MonsterTronRunnerSurfaceInventory(
    val workflowFiles: Map<String, String>,
    val commandFiles: Map<String, String>,
    val publicMethods: Map<String, Set<String>>,
)

data class MonsterTronRunnerSurfacePreflightResult(
    val errors: List<String>,
    val workflowFilesAudited: Int,
    val commandFilesAudited: Int,
    val classesAudited: Int,
    val runnerState: TierOneMonsterTronRunnerState = TierOneMonsterTronRunnerState.DISABLED,
    val officialGamesAuthorized: Int = 0,
    val officialSeedsGenerated: Int = 0,
    val officialGamesInitialized: Int = 0,
    val officialActionsSubmitted: Int = 0,
    val outcomeExposure: Int = 0,
    val guardedOfficialWorkflowPresent: Boolean = false,
) {
    val green: Boolean get() = errors.isEmpty()
}

/**
 * Pure repository/API surface audit for the frozen Monster Tron protocol.
 *
 * This object cannot discover files, create seeds, initialize a game, submit an action, or expose
 * an outcome. The caller supplies text/public-method inventories and this class only inspects them.
 */
object PestControlTierOneMonsterTronRunnerSurfacePreflight {
    internal const val CONSTRUCTION_WORKFLOW_PATH = ".github/workflows/pest-control-tier-one-monster-tron-one-shot-construction.yml"
    internal const val CONSTRUCTION_WORKFLOW_SHA256 = "412a771569f7a3bad4e4e41a037953140b39fa8a5d3c71870dc21776fd01cccb"

    internal const val OFFICIAL_WORKFLOW_PATH = ".github/workflows/pest-control-tier-one-monster-tron-official-smoke.yml"
    internal const val OFFICIAL_WORKFLOW_SHA256 = "6f37cdb939ab310655f78d82ffd711c9f0f389b51e8bd6f6f1a84eb732b9fa3f"

    // Recognize the historical R1 publication without changing or renewing its execution gate.
    // Its fixed source, branch, attempt, date admission and one-shot claim remain byte-pinned.
    internal const val R1_OFFICIAL_WORKFLOW_PATH = ".github/workflows/pest-control-tier-one-monster-tron-r1-official-smoke.yml"
    internal const val R1_OFFICIAL_WORKFLOW_SHA256 = "814cf66d558fa38eec5cac53458588824a8268419339b3b0f7391e6e97f244fb"

    private val forbiddenContent = listOf(
        "tier-one-monster-tron-official-execution",
        "PestControlTierOneMonsterTronOfficialExecutionRunner",
        "PestControlTierOneMonsterTronOfficialInitializer",
        "PEST_MONSTER_TRON_OFFICIAL_VECTOR",
        "PEST_MONSTER_TRON_EXECUTE",
        "PEST_MONSTER_TRON_OFFICIAL_MODE",
        "PestControlTierOneMonsterTronOneShotBoundary",
        "pest-monster-tron-one-shot-claim.py",
    )

    private val forbiddenMethodNames = setOf(
        "execute",
        "executeFromEnvironment",
        "run",
        "main",
        "initializeOfficial",
        "initializeGame",
        "generateSeeds",
        "freezeSeeds",
        "consumeSeed",
        "submitAction",
        "writeArtifact",
        "exposeOutcome",
    )

    fun inspect(
        inventory: MonsterTronRunnerSurfaceInventory,
    ): MonsterTronRunnerSurfacePreflightResult {
        val errors = mutableListOf<String>()

        (inventory.workflowFiles + inventory.commandFiles).forEach { (path, content) ->
            val normalizedPath = path.replace('\\', '/')
            val expectedHash = when {
                normalizedPath.endsWith(CONSTRUCTION_WORKFLOW_PATH) -> CONSTRUCTION_WORKFLOW_SHA256
                normalizedPath.endsWith(OFFICIAL_WORKFLOW_PATH) -> OFFICIAL_WORKFLOW_SHA256
                normalizedPath == R1_OFFICIAL_WORKFLOW_PATH ||
                    normalizedPath.endsWith("/$R1_OFFICIAL_WORKFLOW_PATH") -> R1_OFFICIAL_WORKFLOW_SHA256
                else -> null
            }
            if (expectedHash != null && monsterTronDigest(content.toByteArray(Charsets.UTF_8)) != expectedHash) {
                errors += "guarded workflow bytes changed: $path"
            }
            forbiddenContent.forEach { token ->
                if (expectedHash == null && content.contains(token, ignoreCase = true)) {
                    errors += "official Monster Tron runner surface reference in $path"
                }
            }
        }

        inventory.publicMethods.forEach { (className, methods) ->
            methods.intersect(forbiddenMethodNames).forEach { method ->
                if (className != "PestControlTierOneMonsterTronOneShotBoundary" || method != "executeFromEnvironment") {
                    errors += "forbidden public method $className.$method"
                }
            }
            if (className == "PestControlTierOneMonsterTronOneShotBoundary" && methods != setOf("executeFromEnvironment")) {
                errors += "sealed one-shot public surface mismatch"
            }
        }

        val policyMethods =
            inventory.publicMethods["PestControlTierOneMonsterTronPolicyReadiness"].orEmpty()
        if (policyMethods != setOf("validationErrors", "executionActivationErrors")) {
            errors += "policy-readiness public surface mismatch"
        }

        return MonsterTronRunnerSurfacePreflightResult(
            errors = errors.distinct(),
            workflowFilesAudited = inventory.workflowFiles.size,
            commandFilesAudited = inventory.commandFiles.size,
            classesAudited = inventory.publicMethods.size,
            guardedOfficialWorkflowPresent = inventory.workflowFiles.keys.any {
                it.replace('\\', '/').endsWith(OFFICIAL_WORKFLOW_PATH)
            },
        )
    }
}
