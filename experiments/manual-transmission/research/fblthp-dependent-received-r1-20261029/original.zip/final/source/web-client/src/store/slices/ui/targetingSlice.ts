/**
 * Targeting sub-slice — handles target selection for spells/abilities,
 * including sacrifice/discard/exile cost phases and multi-target flows.
 *
 * All routing logic lives in the pipeline coordinator. This slice only
 * manages the targeting UI state and reports results via advancePipeline.
 */
import type {
  SliceCreator,
  EntityId,
  TargetingState,
} from '../types'

export interface TargetingSliceState {
  targetingState: TargetingState | null
}

export interface TargetingSliceActions {
  startTargeting: (state: TargetingState) => void
  addTarget: (targetId: EntityId) => void
  removeTarget: (targetId: EntityId) => void
  cancelTargeting: (interactionEpoch: string | null) => void
  confirmTargeting: (interactionEpoch: string | null) => void
  goBackTargeting: () => void
}

export type TargetingSlice = TargetingSliceState & TargetingSliceActions

export const createTargetingSlice: SliceCreator<TargetingSlice> = (set, get) => ({
  targetingState: null,

  startTargeting: (targetingState) => {
    set({ targetingState })
  },

  addTarget: (targetId) => {
    set((state) => {
      if (!state.targetingState) return state
      const { selectedTargets, maxTargets } = state.targetingState
      if (selectedTargets.includes(targetId)) return state
      if (selectedTargets.length < maxTargets) {
        return {
          targetingState: {
            ...state.targetingState,
            selectedTargets: [...selectedTargets, targetId],
            warning: null,
          },
        }
      }
      if (maxTargets === 1) {
        // Single-target step: clicking a new target replaces the previous pick.
        return {
          targetingState: {
            ...state.targetingState,
            selectedTargets: [targetId],
            warning: null,
          },
        }
      }
      // Multi-target at cap: keep existing picks and flag a warning banner.
      return {
        targetingState: {
          ...state.targetingState,
          warning: `You can select at most ${maxTargets} target${maxTargets === 1 ? '' : 's'} here — deselect one first to pick a different target.`,
        },
      }
    })
  },

  removeTarget: (targetId) => {
    set((state) => {
      if (!state.targetingState) return state
      const newTargets = state.targetingState.selectedTargets.filter((id) => id !== targetId)
      return {
        targetingState: {
          ...state.targetingState,
          selectedTargets: newTargets,
          warning: null,
        },
      }
    })
  },

  cancelTargeting: (interactionEpoch) => {
    if (!interactionEpoch || interactionEpoch !== get().interactionEpoch) return
    const { pipelineState, cancelPipeline } = get()
    if (pipelineState) { cancelPipeline(); return }
    set({ targetingState: null })
  },

  goBackTargeting: () => {
    // Step back to the previous requirement of a multi-target spell, restoring it
    // exactly as it was presented (pool, bounds, zone) with its confirmed picks
    // still selected. The current requirement's in-progress picks are discarded;
    // re-confirming recomputes later pools against the revised selection.
    set((state) => {
      const prev = state.targetingState?.previousRequirementStates?.at(-1)
      if (!prev) return state
      return { targetingState: { ...prev, warning: null } }
    })
  },

  confirmTargeting: (interactionEpoch) => {
    if (!interactionEpoch || interactionEpoch !== get().interactionEpoch) return
    const { targetingState, pipelineState, gameState, startTargeting } = get()
    if (!targetingState || !gameState || !pipelineState) return

    const currentPhase = pipelineState.remainingPhases[0]

    // Cost payment phase (sacrifice/discard/tap/bounce/exile/blight selection). Escalate pays a
    // different cost from the same pickers, so it reads its costType off the modal enumeration.
    if (currentPhase?.type === 'costPayment' || currentPhase?.type === 'escalateCost') {
      const costInfo =
        currentPhase.type === 'escalateCost'
          ? pipelineState.actionInfo.modalEnumeration?.additionalCostPerExtraMode
          : pipelineState.actionInfo.additionalCostInfo
      const costType = costInfo?.costType ?? 'SacrificePermanent'
      set({ targetingState: null })
      get().advancePipeline({
        type: 'costPayment',
        costType,
        selectedTargets: [...targetingState.selectedTargets],
      })
      return
    }

    // Targeting phase
    if (currentPhase?.type === 'targeting') {
      // Multi-target advancement within the targeting phase
      if (targetingState.targetRequirements && targetingState.targetRequirements.length > 1) {
        const currentIndex = targetingState.currentRequirementIndex ?? 0
        const nextIndex = currentIndex + 1
        const allSelected = targetingState.allSelectedTargets
          ? [...targetingState.allSelectedTargets, targetingState.selectedTargets]
          : [targetingState.selectedTargets]

        const nextReq = targetingState.targetRequirements[nextIndex]
        if (nextReq) {
          // More requirements — stay within targeting phase
          const alreadySelected = allSelected.flat()
          const filteredValidTargets = nextReq.validTargets.filter(
            (t) => !alreadySelected.includes(t),
          )
          startTargeting({
            action: pipelineState.accumulatedAction,
            validTargets: filteredValidTargets,
            selectedTargets: [],
            minTargets: nextReq.minTargets,
            maxTargets: nextReq.maxTargets,
            currentRequirementIndex: nextIndex,
            allSelectedTargets: allSelected,
            targetRequirements: targetingState.targetRequirements,
            ...(nextReq.targetZone ? { targetZone: nextReq.targetZone } : {}),
            targetDescription: nextReq.description,
            ...(targetingState.totalRequirements != null
              ? { totalRequirements: targetingState.totalRequirements }
              : {}),
            ...(targetingState.requiresDamageDistribution
              ? { requiresDamageDistribution: true }
              : {}),
            // Snapshot the outgoing requirement so goBackTargeting can restore it.
            previousRequirementStates: [
              ...(targetingState.previousRequirementStates ?? []),
              targetingState,
            ],
          })
          return
        }

        // All requirements filled
        const allTargets = [...allSelected.flat()]
        set({ targetingState: null, pipelineState: { ...pipelineState, pendingTargetGroups: allSelected.map((group) => [...group]) } })
        get().advancePipeline({ type: 'targeting', selectedTargets: allTargets })
        return
      }

      // Single-target flow
      const nextPipeline = { ...pipelineState }
      delete nextPipeline.pendingTargetGroups
      if (pipelineState.actionInfo.targetRequirements?.length === 1) {
        nextPipeline.pendingTargetGroups = [[...targetingState.selectedTargets]]
      }
      set({ targetingState: null, pipelineState: nextPipeline })
      get().advancePipeline({
        type: 'targeting',
        selectedTargets: [...targetingState.selectedTargets],
      })
    }
  },
})
