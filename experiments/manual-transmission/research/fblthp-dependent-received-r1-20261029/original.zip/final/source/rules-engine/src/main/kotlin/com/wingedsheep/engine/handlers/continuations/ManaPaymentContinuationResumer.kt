package com.wingedsheep.engine.handlers.continuations
import com.wingedsheep.sdk.dsl.Patterns

import com.wingedsheep.engine.core.*
import com.wingedsheep.engine.handlers.costs.CollectEvidenceResolver
import com.wingedsheep.engine.handlers.effects.BattlefieldFilterUtils
import com.wingedsheep.engine.handlers.effects.ZoneTransitionService
import com.wingedsheep.engine.handlers.effects.life.LifePaymentService
import com.wingedsheep.engine.mechanics.mana.ManaPool
import com.wingedsheep.engine.mechanics.mana.ManaSolver
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.battlefield.TappedComponent
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.player.ManaPoolComponent
import com.wingedsheep.engine.state.components.stack.ChosenTarget
import com.wingedsheep.engine.state.components.stack.TargetsComponent
import com.wingedsheep.sdk.core.ManaCost
import com.wingedsheep.sdk.core.Zone
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.effects.CounterDestination
import com.wingedsheep.engine.handlers.PredicateContext
import com.wingedsheep.engine.handlers.PredicateEvaluator
import com.wingedsheep.engine.handlers.effects.composite.asOptionalManaPayment
import com.wingedsheep.engine.handlers.effects.composite.payManaCostFromPool

class ManaPaymentContinuationResumer(
    private val services: com.wingedsheep.engine.core.EngineServices
) : ContinuationResumerModule {

    override fun resumers(): List<ContinuationResumer<*>> = listOf(
        resumer(CounterUnlessPaysContinuation::class, ::resumeCounterUnlessPays),
        resumer(CounterUnlessPaysLifeContinuation::class, ::resumeCounterUnlessPaysLife),
        resumer(CounterUnlessDiscardContinuation::class, ::resumeCounterUnlessDiscard),
        resumer(CounterUnlessSacrificeContinuation::class, ::resumeCounterUnlessSacrifice),
        resumer(CounterUnlessCollectEvidenceContinuation::class, ::resumeCounterUnlessCollectEvidence),
        resumer(CounterUnlessPlayerCountersContinuation::class, ::resumeCounterUnlessPlayerCounters),
        resumer(WardCostChoiceContinuation::class, ::resumeWardCostChoice),
        resumer(CounterUnlessPaysManaSelectionContinuation::class, ::resumeCounterUnlessPaysManaSelection),
        resumer(WardTapPermanentsSubCostContinuation::class, ::resumeWardTapPermanentsSubCost),
        resumer(ChangeSpellTargetContinuation::class, ::resumeChangeSpellTarget),
        resumer(MayPayManaContinuation::class, ::resumeMayPayMana),
        resumer(MayPayManaSelectionContinuation::class, ::resumeMayPayManaSelection),
        resumer(MayPayManaTriggerContinuation::class, ::resumeMayPayManaTrigger),
        resumer(MayPayXContinuation::class, ::resumeMayPayX),
        resumer(PayManaCostRepeatedlyContinuation::class, ::resumePayManaCostRepeatedly),
        resumer(ManaSourceSelectionContinuation::class, ::resumeManaSourceSelection)
    )

    /**
     * Resume after the payer names how many times to pay a repeatable cost ("pay {1} up to three
     * times"). The repetitions are charged as a single `cost * n` auto-tapped payment — separate
     * payments of the same instruction during one resolution are indistinguishable, and one
     * payment lets the solver pick a legal combination of sources for the whole amount rather than
     * stranding itself on a greedy first pick.
     *
     * The count is then published to the frame beneath via [exposeCollectionsToNextFrame] rather
     * than `DrawUpToExecutor.injectStoredNumber`, because the consumer here is usually a
     * [ReflexiveTriggerTargetContinuation] ("when you do, choose up to that many"), which the
     * narrower injector does not reach.
     */
    fun resumePayManaCostRepeatedly(
        state: GameState,
        continuation: PayManaCostRepeatedlyContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is NumberChosenResponse) {
            return ExecutionResult.error(state, "Expected number chosen response for repeated payment")
        }
        // The prompt's floor is 1 — declining is the wrapper's question, not this one — so an
        // out-of-range answer is a protocol error, not a decline. Never clamp: clamping a 0 *up*
        // to 1 would spend mana the payer didn't authorize. (DecisionValidators already rejects
        // these, so this is the belt to that braces.)
        val times = response.number
        if (times < 1 || times > continuation.maxTimes) {
            return ExecutionResult.error(
                state, "Repeat count $times is outside 1..${continuation.maxTimes}"
            )
        }

        val paid = payManaCostFromPool(
            state, continuation.playerId, continuation.cost * times, services.cardRegistry
        )
        if (paid.error != null) return paid.toExecutionResult()

        val published = exposeCollectionsToNextFrame(
            paid.state,
            collections = emptyMap(),
            numbers = mapOf(continuation.storeCountAs to times)
        )
        return checkForMore(published, paid.events.toList())
    }

    fun resumeCounterUnlessPays(
        state: GameState,
        continuation: CounterUnlessPaysContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for counter unless pays")
        }

        if (response.choice) {
            // Player chose to pay — show mana source selection
            val playerId = continuation.payingPlayerId
            val playerEntity = state.getEntity(playerId)
                ?: return ExecutionResult.error(state, "Paying player not found")
            val manaPoolComponent = playerEntity.get<ManaPoolComponent>()
                ?: return ExecutionResult.error(state, "Player has no mana pool")
            val manaPool = ManaPool(
                manaPoolComponent.white, manaPoolComponent.blue, manaPoolComponent.black,
                manaPoolComponent.red, manaPoolComponent.green, manaPoolComponent.colorless
            )
            val partialResult = manaPool.payPartial(continuation.manaCost)

            if (partialResult.remainingCost.isEmpty()) {
                // Floating mana covers the cost — pay immediately
                val newPool = manaPool.pay(continuation.manaCost)
                    ?: return ExecutionResult.error(state, "Cannot pay mana cost from floating mana")
                val currentState = state.updateEntity(playerId) { container ->
                    container.with(
                        ManaPoolComponent(
                            white = newPool.white, blue = newPool.blue, black = newPool.black,
                            red = newPool.red, green = newPool.green, colorless = newPool.colorless
                        )
                    )
                }
                return runOnPaidThenCheckForMore(
                    currentState,
                    emptyList(),
                    continuation.onPaid,
                    continuation.controllerId ?: continuation.payingPlayerId,
                    continuation.sourceId,
                    checkForMore
                )
            }

            // Need to tap sources — show mana source selection UI
            val manaSolver = ManaSolver(services.cardRegistry)
            val sources = manaSolver.findAvailableManaSources(state, playerId)
            val sourceOptions = sources.map { source ->
                ManaSourceOption(
                    entityId = source.entityId,
                    name = source.name,
                    producesColors = source.producesColors,
                    producesColorless = source.producesColorless,
                    requiresSacrifice = source.requiresSacrifice,
                    manaAmount = source.manaAmount,
                    requiresTappingAnotherPermanent = source.tapPermanentsSubCost != null
                )
            }

            val solution = manaSolver.solve(state, playerId, partialResult.remainingCost)
            val autoPaySuggestion = solution?.sources?.map { it.entityId } ?: emptyList()

            val question = { decisionId: String -> SelectManaSourcesDecision(
                id = decisionId,
                playerId = playerId,
                prompt = "Pay ${continuation.manaCost}",
                context = DecisionContext(
                    sourceId = continuation.sourceId,
                    sourceName = continuation.sourceName ?: "Counter unless pays",
                    phase = DecisionPhase.RESOLUTION
                ),
                availableSources = sourceOptions,
                requiredCost = continuation.manaCost.toString(),
                autoPaySuggestion = autoPaySuggestion
            ) }

            val manaSelectionContinuation = CounterUnlessPaysManaSelectionContinuation(
                payingPlayerId = playerId,
                spellEntityId = continuation.spellEntityId,
                manaCost = continuation.manaCost,
                availableSources = sourceOptions,
                autoPaySuggestion = autoPaySuggestion,
                counterDestination = continuation.counterDestination,
                controllerId = continuation.controllerId,
                onPaid = continuation.onPaid,
                sourceId = continuation.sourceId,
            objectReferences = continuation.objectReferences
            )

            return state.suspendForDecision(
                question = question,
                answer = manaSelectionContinuation,
                events = emptyList(),
            )
        } else {
            // Player chose not to pay — counter the spell
            return counterForUnpaidCost(
                state, continuation.spellEntityId, continuation.counterDestination,
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore
            )
        }
    }

    /**
     * Resume after the controller decides whether to pay a life cost
     * for a ward—pay-life trigger.
     *
     * Yes → deduct life (LifeChangedEvent / markLifeLostThisTurn) and let the spell resolve.
     * No  → counter the spell (or counter-to-exile if exileOnCounter).
     */
    fun resumeCounterUnlessPaysLife(
        state: GameState,
        continuation: CounterUnlessPaysLifeContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for counter unless pays life")
        }

        if (response.choice) {
            val playerId = continuation.payingPlayerId
            if (state.getEntity(playerId)
                    ?.get<com.wingedsheep.engine.state.components.identity.LifeTotalComponent>() == null
            ) return ExecutionResult.error(state, "Paying player has no life total")
            // CR 810.9a — life paid as a cost comes out of the team's shared total.
            val currentLife = state.lifeTotal(playerId)

            // If the player can't actually pay (e.g., life dropped between trigger and decision),
            // counter the spell. Players can pay life that takes them below 0.
            // (CR 119.4 — paying life is a cost, not damage; players can pay life they have.)
            // Here we require the player has at least lifeCost life remaining.
            if (currentLife < continuation.lifeCost) {
                return counterForUnpaidCost(
                    state, continuation.spellEntityId, exileOrGraveyard(continuation.exileOnCounter),
                    continuation.controllerId ?: continuation.payingPlayerId, checkForMore
                )
            }

            val (newState, events) = LifePaymentService.pay(state, playerId, continuation.lifeCost)
                ?: return ExecutionResult.error(state, "Paying player has no life total")
            // If this life cost was one component of a composite ward cost, charge the next
            // component before the spell is allowed to resolve.
            chargeNextWardPartOrNull(
                newState, events,
                continuation.remainingWardParts, continuation.spellEntityId,
                continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
                checkForMore
            )?.let { return it }
            return checkForMore(newState, events)
        } else {
            return counterForUnpaidCost(
                state, continuation.spellEntityId, exileOrGraveyard(continuation.exileOnCounter),
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore
            )
        }
    }

    /**
     * Resume after the controller decides whether to discard cards for a
     * ward—discard trigger.
     *
     * Yes → run the standard discard pipeline (random or player's choice) against
     *       the caster's hand and let the spell resolve.
     * No  → counter the spell (or counter-to-exile if exileOnCounter).
     *
     * If the hand has fewer than `count` cards by the time we resume, treat that as
     * an inability to pay and counter the spell.
     */
    fun resumeCounterUnlessDiscard(
        state: GameState,
        continuation: CounterUnlessDiscardContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for counter unless discard")
        }

        if (!response.choice) {
            return counterForUnpaidCost(
                state, continuation.spellEntityId, exileOrGraveyard(continuation.exileOnCounter),
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore
            )
        }

        // Yes — re-verify the player can actually discard the required number of
        // eligible cards (matching the filter, when the ward cost specifies one).
        val eligibleCount = if (continuation.filter == null) {
            state.getHand(continuation.payingPlayerId).size
        } else {
            val predicateEvaluator = com.wingedsheep.engine.handlers.PredicateEvaluator()
            val predicateContext = com.wingedsheep.engine.handlers.PredicateContext(
                controllerId = continuation.payingPlayerId
            )
            state.getHand(continuation.payingPlayerId).count { cardId ->
                predicateEvaluator.matches(
                    state, state.projectedState, cardId, continuation.filter, predicateContext
                )
            }
        }
        if (eligibleCount < continuation.count) {
            return counterForUnpaidCost(
                state, continuation.spellEntityId, exileOrGraveyard(continuation.exileOnCounter),
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore
            )
        }

        val discardEffect = if (continuation.random) {
            com.wingedsheep.sdk.dsl.Patterns.Hand.discardRandom(continuation.count)
        } else if (continuation.filter != null) {
            com.wingedsheep.sdk.dsl.Patterns.Hand.discardCards(
                continuation.count,
                filter = continuation.filter,
            )
        } else {
            com.wingedsheep.sdk.dsl.Patterns.Hand.discardCards(continuation.count)
        }

        val discardContext = com.wingedsheep.engine.handlers.EffectContext(
            sourceId = continuation.controllerId,
            controllerId = continuation.payingPlayerId,
        )

        val discardResult = services.effectExecutorRegistry
            .execute(state, discardEffect, discardContext)
            .toExecutionResult()
        if (discardResult.error != null) return discardResult
        if (discardResult.isPaused) return discardResult

        chargeNextWardPartOrNull(
            discardResult.newState, discardResult.events.toList(),
            continuation.remainingWardParts, continuation.spellEntityId,
            continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
            checkForMore
        )?.let { return it }
        return checkForMore(discardResult.newState, discardResult.events.toList())
    }

    /**
     * Resume after the controller chooses which permanent(s) to sacrifice for a
     * ward—sacrifice trigger (e.g. Ygra's "Ward—Sacrifice a Food").
     *
     * Selected [count] qualifying permanents → sacrifice them and let the spell resolve.
     * Declined (fewer than [count] selected) → counter the spell.
     *
     * The selection is re-validated against projected state at resume time, so a permanent
     * that lost its qualifying subtype between the prompt and the response no longer counts.
     * Sacrifices emit [PermanentsSacrificedEvent] and run through [ZoneTransitionService] so
     * Food-death triggers (Ygra growing) still fire off the sacrificed permanent.
     */
    fun resumeCounterUnlessSacrifice(
        state: GameState,
        continuation: CounterUnlessSacrificeContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for counter unless sacrifice")
        }

        // Re-validate the selection against projected state — only permanents the paying
        // player controls that still match the ward fodder filter count toward payment.
        val valid = BattlefieldFilterUtils.findMatchingOnBattlefield(
            state, continuation.filter.youControl(), PredicateContext(controllerId = continuation.payingPlayerId)
        ).toSet()
        val selectedPermanents = response.selectedCards.filter { it in valid }

        // Declined / underpaid → counter the spell.
        if (selectedPermanents.size < continuation.count) {
            return counterForUnpaidCost(
                state, continuation.spellEntityId, exileOrGraveyard(continuation.exileOnCounter),
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore
            )
        }

        // Paid — sacrifice the chosen permanents and let the spell resolve.
        var newState = state
        val events = mutableListOf<GameEvent>()

        val permanentNames = selectedPermanents.map { id ->
            newState.getEntity(id)?.get<CardComponent>()?.name ?: "Unknown"
        }
        events.add(PermanentsSacrificedEvent(continuation.payingPlayerId, selectedPermanents, permanentNames))
        newState = ZoneTransitionService.trackPermanentSacrifice(newState, selectedPermanents, continuation.payingPlayerId)

        for (permanentId in selectedPermanents) {
            val transitionResult = ZoneTransitionService.moveToZone(newState, permanentId, Zone.GRAVEYARD)
            newState = transitionResult.state
            events.addAll(transitionResult.events)
        }

        chargeNextWardPartOrNull(
            newState, events.toList(),
            continuation.remainingWardParts, continuation.spellEntityId,
            continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
            checkForMore
        )?.let { return it }
        return checkForMore(newState, events)
    }

    /**
     * Resume after the controller picks which graveyard cards to exile for a Ward—Collect
     * evidence N trigger (CR 701.59 / 702.21 — Axebane Ferox).
     *
     * A legal collection (cards still in their graveyard whose mana values total at least
     * `amount`) pays the cost and the spell resolves; anything short of that — including the empty
     * selection, which is how the prompt expresses declining — counters it.
     *
     * The legality re-check and the exile both go through [CollectEvidenceResolver], so this path
     * cannot drift from the activated-ability / cast-cost / effect forms, and the
     * `EvidenceCollectedEvent` it emits fires "whenever you collect evidence" payoffs
     * (Surveillance Monitor) off a ward payment exactly as off any other.
     */
    fun resumeCounterUnlessCollectEvidence(
        state: GameState,
        continuation: CounterUnlessCollectEvidenceContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(
                state, "Expected card selection response for counter unless collect evidence"
            )
        }

        // Declined, or the graveyard shifted under the selection between prompt and response →
        // counter. `isLegalSelection` re-reads the graveyard, so a card that left it no longer pays.
        val legal = CollectEvidenceResolver.isLegalSelection(
            state, continuation.payingPlayerId, continuation.amount, response.selectedCards
        )
        if (!legal) {
            val counterResult = if (continuation.exileOnCounter) {
                services.stackResolver.counterSpellToExile(
                    state, continuation.spellEntityId,
                    grantFreeCast = false,
                    controllerId = continuation.controllerId ?: continuation.payingPlayerId
                )
            } else {
                services.stackResolver.counterSpellOrAbility(state, continuation.spellEntityId)
            }
            return checkForMore(counterResult.newState, counterResult.events)
        }

        val collected = CollectEvidenceResolver.collect(
            state,
            continuation.payingPlayerId,
            continuation.amount,
            response.selectedCards,
            sourceName = "Ward",
        )
        // Unreachable: isLegalSelection above already proved the collection legal.
        if (collected !is CollectEvidenceResolver.Result.Success) {
            return ExecutionResult.error(
                state, "Ward—Collect evidence: ${(collected as CollectEvidenceResolver.Result.Failure).reason}"
            )
        }

        chargeNextWardPartOrNull(
            collected.state, collected.events,
            continuation.remainingWardParts, continuation.spellEntityId,
            continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
            checkForMore
        )?.let { return it }
        return checkForMore(collected.state, collected.events)
    }

    /**
     * Resume after the controller decides whether to take counters on themselves for a
     * ward—get-counters trigger (The Serpent Society's "Ward—Get five poison counters").
     *
     * Yes → place the counters on the paying player through the ordinary `AddCountersEffect`
     *       executor (so counter-placement replacement effects and `CountersAddedEvent` behave as
     *       they do for any other source) and let the spell resolve.
     * No  → counter the spell (or counter-to-exile if exileOnCounter).
     *
     * No can-pay re-check: a player can always get counters, so unlike life / discard / sacrifice
     * this cost cannot become unpayable between the prompt and the response.
     */
    fun resumeCounterUnlessPlayerCounters(
        state: GameState,
        continuation: CounterUnlessPlayerCountersContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for counter unless player counters")
        }

        if (!response.choice) {
            return counterForUnpaidCost(
                state, continuation.spellEntityId, CounterDestination.Graveyard,
                controllerId = continuation.controllerId ?: continuation.payingPlayerId,
                checkForMore = checkForMore
            )
        }

        // The payer places the counters on themselves, so controllerId is the payer: that is what
        // AddCountersExecutor resolves Player.You against and reports as the counters' placer.
        val countersEffect = com.wingedsheep.sdk.scripting.effects.AddCountersEffect(
            counterType = continuation.counterType,
            count = continuation.amount,
            target = com.wingedsheep.sdk.scripting.targets.EffectTarget.PlayerRef(
                com.wingedsheep.sdk.scripting.references.Player.You
            )
        )
        val countersContext = com.wingedsheep.engine.handlers.EffectContext(
            sourceId = continuation.wardSourceId,
            controllerId = continuation.payingPlayerId,
        )

        val countersResult = services.effectExecutorRegistry
            .execute(state, countersEffect, countersContext)
            .toExecutionResult()
        if (countersResult.error != null) return countersResult
        if (countersResult.isPaused) {
            // AddCountersExecutor asks the payer nothing, so this is unreachable today. If it ever
            // does pause, the pause carries no `remainingWardParts` with it — with none left to
            // charge that is harmless, but an enclosing Composite's unpaid components would
            // silently vanish and the spell would neither be countered nor fully paid for. Fail
            // loudly in that case rather than letting the ward chain evaporate.
            if (continuation.remainingWardParts.isEmpty()) return countersResult
            return ExecutionResult.error(
                state,
                "Ward counter placement paused with unpaid ward cost components remaining"
            )
        }

        chargeNextWardPartOrNull(
            countersResult.newState, countersResult.events.toList(),
            continuation.remainingWardParts, continuation.spellEntityId,
            continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
            checkForMore
        )?.let { return it }
        return checkForMore(countersResult.newState, countersResult.events.toList())
    }

    /**
     * Resume after the controller picks which option of a disjunctive ward cost to pay
     * (`WardCost.Choice` — "Ward—Discard a card or pay {2}", CR 702.21a).
     *
     * The trailing option (index == `options.size`) is "Counter spell" and declines; any other
     * index charges that option through the ordinary per-cost ward machinery, with the enclosing
     * composite's not-yet-paid components carried along behind it.
     */
    fun resumeWardCostChoice(
        state: GameState,
        continuation: WardCostChoiceContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is OptionChosenResponse) {
            return ExecutionResult.error(state, "Expected option chosen response for ward cost choice")
        }

        val chosen = continuation.options.getOrNull(response.optionIndex)
            ?: return counterForUnpaidCost(
                state, continuation.spellEntityId, CounterDestination.Graveyard,
                controllerId = continuation.controllerId ?: continuation.payingPlayerId,
                checkForMore = checkForMore
            )

        // Charging the chosen option is exactly "charge the next ward part", with the option at
        // the head of the queue — same helper, so the spell-left-the-stack guard and the
        // composite chaining are single-sourced.
        return chargeNextWardPartOrNull(
            state, emptyList(),
            listOf(chosen) + continuation.remainingWardParts, continuation.spellEntityId,
            continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
            checkForMore
        ) ?: checkForMore(state, emptyList())
    }

    /**
     * Counter (or counter-to-exile) the spell/ability whose counter-unless-pays cost went unpaid,
     * then continue.
     *
     * Every decline path in this file routes through here — ward costs (CR 702.21a) and the generic
     * "counter target spell unless its controller pays" alike, both when the player declines the
     * prompt and when a re-check finds the cost became unpayable between prompt and response — so
     * the exile-on-counter branch and the controller fallback exist once.
     *
     * [precedingEvents] are events already produced before the counter (e.g. mana sub-costs that
     * were paid on the way to a payment that then failed); they stay ahead of the counter's own.
     */
    private fun counterForUnpaidCost(
        state: GameState,
        spellEntityId: EntityId,
        destination: CounterDestination,
        controllerId: EntityId,
        checkForMore: CheckForMore,
        precedingEvents: List<GameEvent> = emptyList()
    ): ExecutionResult {
        val result = when (destination) {
            is CounterDestination.Exile -> services.stackResolver.counterSpellToExile(
                state, spellEntityId, grantFreeCast = false, controllerId = controllerId
            )
            CounterDestination.Hand -> services.stackResolver.counterSpellToHand(state, spellEntityId)
            CounterDestination.LibraryTop -> services.stackResolver.counterSpellToLibraryTop(state, spellEntityId)
            CounterDestination.Graveyard -> services.stackResolver.counterSpellOrAbility(state, spellEntityId)
        }
        return checkForMore(result.newState, precedingEvents + result.events)
    }

    /**
     * The ward / pay-life / discard / sacrifice continuations still carry a plain
     * `exileOnCounter` flag: ward's own vocabulary has only those two destinations, and no printed
     * ward or punisher counter puts the spell into a hand. Only the two continuations reachable
     * from [com.wingedsheep.sdk.scripting.effects.CounterEffect] carry the full destination.
     */
    private fun exileOrGraveyard(exileOnCounter: Boolean): CounterDestination =
        if (exileOnCounter) CounterDestination.Exile() else CounterDestination.Graveyard

    /**
     * Resume after the controller selects mana sources to pay a "counter unless pays" cost.
     */
    fun resumeCounterUnlessPaysManaSelection(
        state: GameState,
        continuation: CounterUnlessPaysManaSelectionContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is ManaSourcesSelectedResponse) {
            return ExecutionResult.error(state, "Expected mana sources selected response")
        }

        // If the player declined (no mana sources, no auto-pay, no Ward—Waterbend taps to help,
        // and nothing floating that already covers the cost), counter the spell.
        if (response.isDecline(floatingCovers(state, continuation.payingPlayerId, continuation.manaCost))) {
            return counterForUnpaidCost(
                state, continuation.spellEntityId, continuation.counterDestination,
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore
            )
        }

        val playerId = continuation.payingPlayerId
        var currentState = state
        val events = mutableListOf<GameEvent>()

        // Ward—Waterbend (Avatar: The Last Airbender): tap the chosen artifacts/creatures first,
        // each paying {1} of the generic, through the shared waterbend payment machinery. The
        // remaining (reduced) cost is then paid with mana sources exactly as a plain ward {N}.
        var effectiveCost = continuation.manaCost
        if (continuation.waterbend && response.waterbendPermanents.isNotEmpty()) {
            val waterbendResult = com.wingedsheep.engine.mechanics.mana.AlternativePaymentHandler()
                .applyWaterbendForAbility(
                    currentState,
                    continuation.manaCost,
                    com.wingedsheep.sdk.scripting.AlternativePaymentChoice(
                        tapForGenericPermanents = response.waterbendPermanents
                    ),
                    playerId
                )
            currentState = waterbendResult.newState
            effectiveCost = waterbendResult.reducedCost
            events.addAll(waterbendResult.events)
        }

        val playerEntity = currentState.getEntity(playerId)
            ?: return ExecutionResult.error(state, "Paying player not found")

        val manaPoolComponent = playerEntity.get<ManaPoolComponent>()
            ?: return ExecutionResult.error(state, "Player has no mana pool")

        val manaPool = ManaPool(
            manaPoolComponent.white, manaPoolComponent.blue, manaPoolComponent.black,
            manaPoolComponent.red, manaPoolComponent.green, manaPoolComponent.colorless
        )

        val partialResult = manaPool.payPartial(effectiveCost)
        val remainingCost = partialResult.remainingCost
        var currentPool = manaPool

        if (!remainingCost.isEmpty()) {
            if (response.autoPay) {
                val manaSolver = ManaSolver(services.cardRegistry)
                val solution = manaSolver.solve(currentState, playerId, remainingCost)
                    ?: return ExecutionResult.error(state, "Cannot pay mana cost with auto-pay")

                for (source in solution.sources) {
                    val (tappedState, tapEvent) = tap(currentState, source.entityId)
                    currentState = tappedState
                    tapEvent?.let(events::add)
                }
                for ((_, production) in solution.manaProduced) {
                    currentPool = if (production.color != null) {
                        currentPool.add(production.color, production.amount)
                    } else {
                        currentPool.addColorless(production.colorless)
                    }
                }
            } else {
                // Split off sources that carry a tap-permanents sub-cost (Springleaf Drum) —
                // those require a follow-up creature-selection prompt before the source can
                // be tapped. All other selections (lands, treasures, etc.) are tapped now.
                val sourceMap = continuation.availableSources.associateBy { it.entityId }
                val (subCostSources, otherSources) = response.selectedSources.partition { id ->
                    sourceMap[id]?.requiresTappingAnotherPermanent == true
                }

                val manual = applyManualSourceSelection(
                    currentState,
                    currentPool,
                    continuation.availableSources,
                    otherSources,
                    fallbackControllerId = playerId
                ) ?: return ExecutionResult.error(state, "Selected source is not a valid mana source")
                currentState = manual.state
                currentPool = manual.pool
                events.addAll(manual.events)

                if (subCostSources.isNotEmpty()) {
                    // Persist the pool from the first-phase taps so the sub-cost
                    // continuation reads it off the player's mana pool component on resume.
                    currentState = currentState.updateEntity(playerId) { container ->
                        container.with(
                            ManaPoolComponent(
                                white = currentPool.white, blue = currentPool.blue, black = currentPool.black,
                                red = currentPool.red, green = currentPool.green, colorless = currentPool.colorless
                            )
                        )
                    }
                    return promptForTapPermanentsSubCost(
                        currentState,
                        events,
                        payingPlayerId = playerId,
                        spellEntityId = continuation.spellEntityId,
                        manaCost = effectiveCost,
                        counterDestination = continuation.counterDestination,
                        controllerId = continuation.controllerId,
                        pendingSubCostSources = subCostSources,
                        availableSources = continuation.availableSources,
                        onPaid = continuation.onPaid,
                        sourceId = continuation.sourceId,
                        remainingWardParts = continuation.remainingWardParts,
                        wardSourceId = continuation.wardSourceId
                    )
                }
            }
        }

        val newPool = currentPool.pay(effectiveCost)
        if (newPool == null) {
            // Payment failed — counter the spell
            return counterForUnpaidCost(
                state, continuation.spellEntityId, continuation.counterDestination,
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore
            )
        }

        currentState = currentState.updateEntity(playerId) { container ->
            container.with(
                ManaPoolComponent(
                    white = newPool.white, blue = newPool.blue, black = newPool.black,
                    red = newPool.red, green = newPool.green, colorless = newPool.colorless
                )
            )
        }

        // If this mana cost was one component of a composite ward cost, charge the next
        // component before the spell is allowed to resolve.
        chargeNextWardPartOrNull(
            currentState, events,
            continuation.remainingWardParts, continuation.spellEntityId,
            continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
            checkForMore
        )?.let { return it }

        // Spell resolves normally — don't counter it.
        return runOnPaidThenCheckForMore(
            currentState,
            events,
            continuation.onPaid,
            continuation.controllerId ?: continuation.payingPlayerId,
            continuation.sourceId,
            checkForMore
        )
    }

    /**
     * If [remainingWardParts] is non-empty, charge the next component of a composite ward cost
     * (CR 702.21a — "Ward—{2}, Pay 2 life") and return the resulting [ExecutionResult] (a new
     * pause for the next component's decision, or a resolved/countered result). Returns `null`
     * when there are no further ward components, so the caller proceeds with the spell resolving.
     *
     * [priorEvents] (e.g. the LifeChangedEvent / tap events from the just-paid component) are
     * prepended to the next component's events so nothing is dropped across the chain.
     */
    private fun chargeNextWardPartOrNull(
        state: GameState,
        priorEvents: List<GameEvent>,
        remainingWardParts: List<com.wingedsheep.sdk.scripting.effects.WardCost>,
        spellEntityId: EntityId,
        payingPlayerId: EntityId,
        wardSourceId: EntityId?,
        controllerId: EntityId?,
        checkForMore: CheckForMore
    ): ExecutionResult? {
        if (remainingWardParts.isEmpty()) return null

        // The spell/ability must still be on the stack; if it left, there's nothing left to pay for.
        val container = state.getEntity(spellEntityId)
        if (container == null || !state.stack.contains(spellEntityId)) {
            return checkForMore(state, priorEvents)
        }

        val next = com.wingedsheep.engine.handlers.effects.stack.WardCounterEffectExecutor
            .chargeWardCost(
                state = state,
                cardRegistry = services.cardRegistry,
                cost = remainingWardParts.first(),
                remainingParts = remainingWardParts.drop(1),
                spellEntityId = spellEntityId,
                container = container,
                payingPlayerId = payingPlayerId,
                wardSourceId = wardSourceId,
                controllerId = controllerId
            ).toExecutionResult()

        if (next.error != null) return next
        return if (next.isPaused) {
            ExecutionResult.propagatePause(next.state, priorEvents + next.events)
        } else {
            checkForMore(next.state, priorEvents + next.events)
        }
    }

    /**
     * Run the optional "If they do, …" rider that fires only when the spell's controller
     * paid the counter-unless cost, then continue the pipeline.
     *
     * The rider executes with [riderController] as `controllerId` (the controller of the
     * counter effect, i.e. "you" in "you create a Lander token"). If the rider pauses
     * for a sub-decision we surface that
     * pause directly; on error we also propagate it. Otherwise events from the prior
     * payment phase are concatenated with the rider's events.
     */
    private fun runOnPaidThenCheckForMore(
        state: GameState,
        priorEvents: List<GameEvent>,
        onPaid: com.wingedsheep.sdk.scripting.effects.Effect?,
        riderController: EntityId,
        sourceId: EntityId?,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (onPaid == null) return checkForMore(state, priorEvents)

        val riderContext = com.wingedsheep.engine.handlers.EffectContext(
            sourceId = sourceId,
            controllerId = riderController,
        )
        val riderResult = services.effectExecutorRegistry
            .execute(state, onPaid, riderContext)
            .toExecutionResult()
        if (riderResult.error != null) return riderResult
        if (riderResult.isPaused) {
            return ExecutionResult.propagatePause(
                riderResult.state,
                priorEvents + riderResult.events
            )
        }
        return checkForMore(riderResult.state, priorEvents + riderResult.events)
    }

    /**
     * Resume after the controller chooses a new target for a spell/ability.
     * Handles both creature (permanent) and player targets.
     */
    fun resumeChangeSpellTarget(
        state: GameState,
        continuation: ChangeSpellTargetContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for change spell target")
        }

        val selectedEntityId = response.selectedCards.singleOrNull()
            ?: return ExecutionResult.error(state, "Expected exactly one target for change spell target")
        val snapshot = continuation.retargetSnapshot ?: return checkForMore(state, emptyList())
        if (snapshot.stackRef.entityId != continuation.spellEntityId) return checkForMore(state, emptyList())
        val result = com.wingedsheep.engine.mechanics.targeting.GenericRetargeting.apply(state, snapshot, selectedEntityId)
        return checkForMore(result.state, result.events)
    }

    /**
     * Resume after the controller decides whether to pay a mana cost for "you may pay {cost}" effects.
     */
    fun resumeMayPayMana(
        state: GameState,
        continuation: MayPayManaContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for may pay mana")
        }

        if (!response.choice) {
            // Player declined to pay — nothing happens
            return checkForMore(state, emptyList())
        }

        // Player chose to pay — check if floating mana covers the cost
        val playerId = continuation.playerId
        val playerEntity = state.getEntity(playerId)
            ?: return ExecutionResult.error(state, "Paying player not found")

        val manaPoolComponent = playerEntity.get<ManaPoolComponent>()
            ?: return ExecutionResult.error(state, "Player has no mana pool")

        val manaPool = ManaPool(
            manaPoolComponent.white, manaPoolComponent.blue, manaPoolComponent.black,
            manaPoolComponent.red, manaPoolComponent.green, manaPoolComponent.colorless
        )
        val partialResult = manaPool.payPartial(continuation.manaCost)

        if (partialResult.remainingCost.isEmpty()) {
            // Floating mana covers the cost — pay immediately and execute inner effect
            val newPool = manaPool.pay(continuation.manaCost)
                ?: return ExecutionResult.error(state, "Cannot pay mana cost from floating mana")
            var currentState = state.updateEntity(playerId) { container ->
                container.with(
                    ManaPoolComponent(
                        white = newPool.white, blue = newPool.blue, black = newPool.black,
                        red = newPool.red, green = newPool.green, colorless = newPool.colorless
                    )
                )
            }

            val effectResult = services.effectExecutorRegistry.execute(currentState, continuation.effect, continuation.effectContext).toExecutionResult()
            if (effectResult.error != null) return effectResult
            if (effectResult.isPaused) return effectResult
            return checkForMore(effectResult.state, effectResult.events)
        }

        // Need to tap sources — show mana source selection UI
        val manaSolver = ManaSolver(services.cardRegistry)
        val sources = manaSolver.findAvailableManaSources(state, playerId)
        val sourceOptions = sources.map { source ->
            ManaSourceOption(
                entityId = source.entityId,
                name = source.name,
                producesColors = source.producesColors,
                producesColorless = source.producesColorless,
                requiresSacrifice = source.requiresSacrifice,
                manaAmount = source.manaAmount,
                requiresTappingAnotherPermanent = source.tapPermanentsSubCost != null
            )
        }

        val solution = manaSolver.solve(state, playerId, partialResult.remainingCost)
        val autoPaySuggestion = solution?.sources?.map { it.entityId } ?: emptyList()

        val question = { decisionId: String -> SelectManaSourcesDecision(
            id = decisionId,
            playerId = playerId,
            prompt = "Pay ${continuation.manaCost}",
            context = DecisionContext(
                sourceId = continuation.effectContext.sourceId,
                sourceName = continuation.sourceName ?: "You may pay",
                phase = DecisionPhase.RESOLUTION
            ),
            availableSources = sourceOptions,
            requiredCost = continuation.manaCost.toString(),
            autoPaySuggestion = autoPaySuggestion,
            canDecline = true
        ) }

        val manaSelectionContinuation = MayPayManaSelectionContinuation(
            playerId = playerId,
            sourceName = continuation.sourceName,
            manaCost = continuation.manaCost,
            effect = continuation.effect,
            effectContext = continuation.effectContext,
            availableSources = sourceOptions,
            autoPaySuggestion = autoPaySuggestion
        )

        return state.suspendForDecision(
            question = question,
            answer = manaSelectionContinuation,
            events = emptyList(),
        )
    }

    /**
     * Resume after the controller selects mana sources for a "you may pay" ability
     * (non-targeted). Taps sources, deducts mana, executes the inner effect.
     */
    fun resumeMayPayManaSelection(
        state: GameState,
        continuation: MayPayManaSelectionContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is ManaSourcesSelectedResponse) {
            return ExecutionResult.error(state, "Expected mana sources selected response")
        }

        val playerId = continuation.playerId

        // Declined — no mana sources, no auto-pay, (for a waterbend gate) no taps to help, and no
        // floating mana that already covers it. Run the "unless" branch (e.g. "discard a card") if
        // one is attached, otherwise nothing happens.
        if (response.isDecline(floatingCovers(state, playerId, continuation.manaCost))) {
            val otherwise = continuation.otherwise
                ?: return checkForMore(state, emptyList())
            val otherwiseResult = services.effectExecutorRegistry
                .execute(state, otherwise, continuation.effectContext).toExecutionResult()
            if (otherwiseResult.error != null || otherwiseResult.isPaused) return otherwiseResult
            return checkForMore(otherwiseResult.state, otherwiseResult.events)
        }

        var currentState = state
        val events = mutableListOf<GameEvent>()

        // Waterbend (Avatar: The Last Airbender): tap the chosen artifacts/creatures first, each
        // paying {1} of the generic through the shared waterbend machinery. The remaining (reduced)
        // cost is then paid with mana sources exactly as a plain payment.
        var effectiveCost = continuation.manaCost
        if (continuation.waterbend && response.waterbendPermanents.isNotEmpty()) {
            val waterbendResult = com.wingedsheep.engine.mechanics.mana.AlternativePaymentHandler()
                .applyWaterbendForAbility(
                    currentState,
                    continuation.manaCost,
                    com.wingedsheep.sdk.scripting.AlternativePaymentChoice(
                        tapForGenericPermanents = response.waterbendPermanents
                    ),
                    playerId
                )
            currentState = waterbendResult.newState
            effectiveCost = waterbendResult.reducedCost
            events.addAll(waterbendResult.events)
        }

        val playerEntity = currentState.getEntity(playerId)
            ?: return ExecutionResult.error(state, "Paying player not found")

        val manaPoolComponent = playerEntity.get<ManaPoolComponent>()
            ?: return ExecutionResult.error(state, "Player has no mana pool")

        val manaPool = ManaPool(
            manaPoolComponent.white, manaPoolComponent.blue, manaPoolComponent.black,
            manaPoolComponent.red, manaPoolComponent.green, manaPoolComponent.colorless
        )

        val partialResult = manaPool.payPartial(effectiveCost)
        val remainingCost = partialResult.remainingCost
        var currentPool = manaPool

        if (!remainingCost.isEmpty()) {
            if (response.autoPay) {
                val manaSolver = ManaSolver(services.cardRegistry)
                val solution = manaSolver.solve(currentState, playerId, remainingCost)
                    ?: return ExecutionResult.error(state, "Cannot pay mana cost with auto-pay")

                for (source in solution.sources) {
                    val (tappedState, tapEvent) = tap(currentState, source.entityId)
                    currentState = tappedState
                    tapEvent?.let(events::add)
                }
                for ((_, production) in solution.manaProduced) {
                    currentPool = if (production.color != null) {
                        currentPool.add(production.color, production.amount)
                    } else {
                        currentPool.addColorless(production.colorless)
                    }
                }
            } else {
                val manual = applyManualSourceSelection(
                    currentState,
                    currentPool,
                    continuation.availableSources,
                    response.selectedSources,
                    fallbackControllerId = playerId
                ) ?: return ExecutionResult.error(state, "Selected source is not a valid mana source")
                currentState = manual.state
                currentPool = manual.pool
                events.addAll(manual.events)
            }
        }

        val newPool = currentPool.pay(effectiveCost)
            ?: return ExecutionResult.error(state, "Cannot pay mana cost after tapping sources")

        currentState = currentState.updateEntity(playerId) { container ->
            container.with(
                ManaPoolComponent(
                    white = newPool.white, blue = newPool.blue, black = newPool.black,
                    red = newPool.red, green = newPool.green, colorless = newPool.colorless
                )
            )
        }

        // Execute the inner effect
        val effectResult = services.effectExecutorRegistry.execute(currentState, continuation.effect, continuation.effectContext).toExecutionResult()
        if (effectResult.error != null) return effectResult
        if (effectResult.isPaused) return effectResult

        val allEvents = events + effectResult.events
        return checkForMore(effectResult.state, allEvents)
    }

    /**
     * Resume after the controller decides whether to pay a mana cost for a triggered
     * ability that also requires targets (e.g., Lightning Rift).
     *
     * If the player says yes, shows mana source selection. If no, skips the trigger.
     */
    fun resumeMayPayManaTrigger(
        state: GameState,
        continuation: MayPayManaTriggerContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is YesNoResponse) {
            return ExecutionResult.error(state, "Expected yes/no response for may pay mana trigger")
        }

        if (!response.choice) {
            // Player declined to pay — skip the trigger entirely
            return checkForMore(state, emptyList())
        }

        // Player chose to pay — show mana source selection
        val playerId = continuation.trigger.controllerId
        val manaSolver = ManaSolver(services.cardRegistry)

        // Find available sources for the UI
        val sources = manaSolver.findAvailableManaSources(state, playerId)
        val sourceOptions = sources.map { source ->
            ManaSourceOption(
                entityId = source.entityId,
                name = source.name,
                producesColors = source.producesColors,
                producesColorless = source.producesColorless,
                requiresSacrifice = source.requiresSacrifice,
                manaAmount = source.manaAmount,
                requiresTappingAnotherPermanent = source.tapPermanentsSubCost != null
            )
        }

        // Get auto-pay suggestion
        val solution = manaSolver.solve(state, playerId, continuation.manaCost)
        val autoPaySuggestion = solution?.sources?.map { it.entityId } ?: emptyList()

        // Create mana source selection decision
        val question = { decisionId: String -> SelectManaSourcesDecision(
            id = decisionId,
            playerId = playerId,
            prompt = "Pay ${continuation.manaCost}",
            context = DecisionContext(
                sourceId = continuation.trigger.sourceId,
                sourceName = continuation.trigger.sourceName,
                phase = DecisionPhase.RESOLUTION
            ),
            availableSources = sourceOptions,
            requiredCost = continuation.manaCost.toString(),
            autoPaySuggestion = autoPaySuggestion
        ) }

        val manaSourceContinuation = ManaSourceSelectionContinuation(
            trigger = continuation.trigger,
            targetRequirement = continuation.targetRequirement,
            manaCost = continuation.manaCost,
            availableSources = sourceOptions,
            autoPaySuggestion = autoPaySuggestion
        )

        return state.suspendForDecision(
            question = question,
            answer = manaSourceContinuation,
            events = emptyList(),
        )
    }

    /**
     * Resume after the controller chooses an X value for "you may pay {X}" effects.
     * If X > 0, auto-tap X mana and execute the inner effect with the chosen X.
     */
    fun resumeMayPayX(
        state: GameState,
        continuation: MayPayXContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is NumberChosenResponse) {
            return ExecutionResult.error(state, "Expected number chosen response for may pay X")
        }

        val chosenX = response.number
        if (chosenX <= 0) {
            // Player declined to pay — nothing happens
            return checkForMore(state, emptyList())
        }

        // Player chose to pay X mana — auto-tap sources
        val playerId = continuation.playerId
        val playerEntity = state.getEntity(playerId)
            ?: return ExecutionResult.error(state, "Paying player not found")

        val manaPoolComponent = playerEntity.get<ManaPoolComponent>()
            ?: return ExecutionResult.error(state, "Player has no mana pool")

        val manaPool = ManaPool(
            manaPoolComponent.white,
            manaPoolComponent.blue,
            manaPoolComponent.black,
            manaPoolComponent.red,
            manaPoolComponent.green,
            manaPoolComponent.colorless
        )

        // Create a ManaCost of {X} generic mana
        val xCost = com.wingedsheep.sdk.core.ManaCost(
            List(chosenX) { com.wingedsheep.sdk.core.ManaSymbol.generic(1) }
        )

        // Try to pay from floating mana first, then tap sources for the rest
        val partialResult = manaPool.payPartial(xCost)
        val remainingCost = partialResult.remainingCost
        var currentPool = manaPool
        var currentState = state
        val events = mutableListOf<GameEvent>()

        if (!remainingCost.isEmpty()) {
            val manaSolver = ManaSolver(services.cardRegistry)
            val solution = manaSolver.solve(currentState, playerId, remainingCost)
                ?: return ExecutionResult.error(state, "Cannot pay mana cost")

            for (source in solution.sources) {
                val (tappedState, tapEvent) = tap(currentState, source.entityId)
                currentState = tappedState
                tapEvent?.let(events::add)
            }

            for ((_, production) in solution.manaProduced) {
                currentPool = if (production.color != null) {
                    currentPool.add(production.color)
                } else {
                    currentPool.addColorless(production.colorless)
                }
            }
        }

        // Deduct the cost from the pool
        val newPool = currentPool.pay(xCost)
            ?: return ExecutionResult.error(state, "Cannot pay mana cost after auto-tap")

        currentState = currentState.updateEntity(playerId) { container ->
            container.with(
                ManaPoolComponent(
                    white = newPool.white,
                    blue = newPool.blue,
                    black = newPool.black,
                    red = newPool.red,
                    green = newPool.green,
                    colorless = newPool.colorless
                )
            )
        }

        // Execute the inner effect with the chosen X value
        val context = continuation.effectContext.copy(xValue = chosenX)
        val effectResult = services.effectExecutorRegistry.execute(currentState, continuation.effect, context).toExecutionResult()

        if (effectResult.error != null) {
            return effectResult
        }
        if (effectResult.isPaused) return effectResult

        val allEvents = events + effectResult.events
        return checkForMore(effectResult.state, allEvents)
    }

    /**
     * Resume after the controller selects mana sources to pay a cost for a triggered
     * ability that also requires targets.
     *
     * Taps the selected sources, deducts mana, unwraps MayPayManaEffect, and proceeds
     * to target selection with the inner effect.
     */
    fun resumeManaSourceSelection(
        state: GameState,
        continuation: ManaSourceSelectionContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is ManaSourcesSelectedResponse) {
            return ExecutionResult.error(state, "Expected mana sources selected response")
        }

        val playerId = continuation.trigger.controllerId
        val playerEntity = state.getEntity(playerId)
            ?: return ExecutionResult.error(state, "Paying player not found")

        val manaPoolComponent = playerEntity.get<ManaPoolComponent>()
            ?: return ExecutionResult.error(state, "Player has no mana pool")

        val manaPool = ManaPool(
            manaPoolComponent.white,
            manaPoolComponent.blue,
            manaPoolComponent.black,
            manaPoolComponent.red,
            manaPoolComponent.green,
            manaPoolComponent.colorless
        )

        // Try to pay from floating mana first
        val partialResult = manaPool.payPartial(continuation.manaCost)
        val remainingCost = partialResult.remainingCost
        var currentPool = manaPool
        var currentState = state
        val events = mutableListOf<GameEvent>()

        if (!remainingCost.isEmpty()) {
            if (response.autoPay) {
                // Auto-tap: use ManaSolver
                val manaSolver = ManaSolver(services.cardRegistry)
                val solution = manaSolver.solve(currentState, playerId, remainingCost)
                    ?: return ExecutionResult.error(state, "Cannot pay mana cost with auto-pay")

                for (source in solution.sources) {
                    val (tappedState, tapEvent) = tap(currentState, source.entityId)
                    currentState = tappedState
                    tapEvent?.let(events::add)
                }

                for ((_, production) in solution.manaProduced) {
                    currentPool = if (production.color != null) {
                        currentPool.add(production.color, production.amount)
                    } else {
                        currentPool.addColorless(production.colorless)
                    }
                }
            } else {
                val manual = applyManualSourceSelection(
                    currentState,
                    currentPool,
                    continuation.availableSources,
                    response.selectedSources,
                    fallbackControllerId = playerId
                ) ?: return ExecutionResult.error(state, "Selected source is not a valid mana source")
                currentState = manual.state
                currentPool = manual.pool
                events.addAll(manual.events)
            }
        }

        // Deduct the cost from the pool
        val newPool = currentPool.pay(continuation.manaCost)
            ?: return ExecutionResult.error(state, "Cannot pay mana cost after tapping sources")

        currentState = currentState.updateEntity(playerId) { container ->
            container.with(
                ManaPoolComponent(
                    white = newPool.white,
                    blue = newPool.blue,
                    black = newPool.black,
                    red = newPool.red,
                    green = newPool.green,
                    colorless = newPool.colorless
                )
            )
        }

        // Unwrap the optional-mana-payment gate to get its inner effect (mana already paid).
        val trigger = continuation.trigger
        val innerEffect = trigger.ability.effect.asOptionalManaPayment()!!.then

        // Create a modified trigger with the inner effect (mana already paid)
        val unwrappedAbility = trigger.ability.copy(effect = innerEffect)
        val unwrappedTrigger = trigger.copy(ability = unwrappedAbility)

        // Proceed to target selection
        val result = services.triggerProcessor.processTargetedTrigger(currentState, unwrappedTrigger, continuation.targetRequirement)

        if (result.isPaused) {
            // Target selection is needed - return paused with accumulated events
            return ExecutionResult.propagatePause(
                result.state,
                events + result.events
            )
        }

        if (!result.isSuccess) {
            return result
        }

        // Target was auto-selected - check for more continuations
        return checkForMore(result.newState, events + result.events.toList())
    }

    /**
     * Applies a player's manual mana-source selection: taps each source (sacrificing
     * those with [ManaSourceOption.requiresSacrifice] — e.g. Treasure tokens) and
     * adds the produced mana to [pool]. For tap+sacrifice sources we route the zone
     * move through [ZoneTransitionService] so dies/leaves triggers and Food trackers
     * stay consistent with [com.wingedsheep.engine.handlers.CostHandler]'s payment of
     * the same cost.
     *
     * For "any color" producers (treasures' `AddAnyColorMana`) the resumer picks the
     * first listed color; for paying generic costs (ward {N}, may-pay {N}) any color
     * suffices.
     *
     * @return null when [selectedSourceIds] references a source not in [availableSources].
     */
    private data class ManualSourceTapResult(
        val state: GameState,
        val pool: ManaPool,
        val events: List<GameEvent>
    )

    private fun applyManualSourceSelection(
        state: GameState,
        pool: ManaPool,
        availableSources: List<ManaSourceOption>,
        selectedSourceIds: List<EntityId>,
        fallbackControllerId: EntityId
    ): ManualSourceTapResult? {
        val sourceMap = availableSources.associateBy { it.entityId }
        var currentState = state
        var currentPool = pool
        val events = mutableListOf<GameEvent>()

        for (sourceId in selectedSourceIds) {
            val source = sourceMap[sourceId] ?: return null

            if (source.requiresSacrifice) {
                val sourceController = currentState.getEntity(sourceId)
                    ?.get<ControllerComponent>()?.playerId
                    ?: fallbackControllerId
                // Emit a TappedEvent for parity with the tap sub-cost on the ability
                // (some triggers care about "becomes tapped"), then sacrifice. The
                // permanent is about to leave the battlefield so we skip setting
                // TappedComponent on it.
                events.add(
                    TappedEvent(
                        sourceId,
                        source.name,
                        firstThisTurn = isFirstTapThisTurn(currentState, sourceId)
                    )
                )
                val preState = ZoneTransitionService
                    .trackPermanentSacrifice(currentState, listOf(sourceId), sourceController)
                val transition = ZoneTransitionService.moveToZone(
                    preState, sourceId, Zone.GRAVEYARD
                )
                currentState = transition.state
                events.add(PermanentsSacrificedEvent(sourceController, listOf(sourceId)))
                events.addAll(transition.events)
            } else {
                val (tappedState, tapEvent) = tap(currentState, sourceId)
                currentState = tappedState
                tapEvent?.let(events::add)
            }

            if (source.producesColors.isNotEmpty()) {
                currentPool = currentPool.add(source.producesColors.first())
            } else if (source.producesColorless) {
                currentPool = currentPool.addColorless(1)
            }
        }

        return ManualSourceTapResult(currentState, currentPool, events)
    }

    /**
     * Resolves the [com.wingedsheep.engine.mechanics.mana.TapPermanentsSubCost] for [sourceId]
     * by re-querying the ManaSolver. Returns null when [sourceId] is no longer a sub-cost
     * source — this can happen if the source left the battlefield between menu render and
     * resume, in which case the resumer must counter the spell.
     */
    private fun lookupSubCost(
        state: GameState,
        playerId: EntityId,
        sourceId: EntityId
    ): com.wingedsheep.engine.mechanics.mana.TapPermanentsSubCost? {
        val manaSolver = ManaSolver(services.cardRegistry)
        return manaSolver.findAvailableManaSources(state, playerId)
            .firstOrNull { it.entityId == sourceId }
            ?.tapPermanentsSubCost
    }

    /**
     * Builds a [SelectCardsDecision] for the head of [pendingSubCostSources] and pauses
     * with a [WardTapPermanentsSubCostContinuation] queued for the response. The decision
     * lists every untapped permanent the [payingPlayerId] controls that matches the
     * sub-cost filter (and is not the source itself).
     */
    private fun promptForTapPermanentsSubCost(
        state: GameState,
        priorEvents: List<GameEvent>,
        payingPlayerId: EntityId,
        spellEntityId: EntityId,
        manaCost: com.wingedsheep.sdk.core.ManaCost,
        counterDestination: CounterDestination,
        controllerId: EntityId?,
        pendingSubCostSources: List<EntityId>,
        availableSources: List<ManaSourceOption>,
        onPaid: com.wingedsheep.sdk.scripting.effects.Effect? = null,
        sourceId: EntityId? = null,
        remainingWardParts: List<com.wingedsheep.sdk.scripting.effects.WardCost> = emptyList(),
        wardSourceId: EntityId? = null
    ): ExecutionResult {
        val headSourceId = pendingSubCostSources.first()
        val sourceName = availableSources.firstOrNull { it.entityId == headSourceId }?.name
            ?: state.getEntity(headSourceId)
                ?.get<com.wingedsheep.engine.state.components.identity.CardComponent>()?.name
            ?: "Mana source"

        val subCost = lookupSubCost(state, payingPlayerId, headSourceId)
            ?: return ExecutionResult.error(state, "Selected mana source is no longer available")

        val projected = state.projectedState
        val predicateEvaluator = PredicateEvaluator()
        val predicateContext = PredicateContext(controllerId = payingPlayerId)
        val options = projected.getBattlefieldControlledBy(payingPlayerId)
            .filter { candidate ->
                candidate != headSourceId &&
                    state.getEntity(candidate)?.has<TappedComponent>() == false &&
                    predicateEvaluator.matches(state, projected, candidate, subCost.filter, predicateContext)
            }

        if (options.size < subCost.count) {
            return ExecutionResult.error(state, "Not enough valid permanents to satisfy $sourceName's tap cost")
        }

        val question = { decisionId: String -> SelectCardsDecision(
            id = decisionId,
            playerId = payingPlayerId,
            prompt = "Tap an untapped ${subCost.filter.description} you control for $sourceName",
            context = DecisionContext(
                sourceId = headSourceId,
                sourceName = sourceName,
                phase = DecisionPhase.RESOLUTION
            ),
            options = options,
            minSelections = subCost.count,
            maxSelections = subCost.count,
            useTargetingUI = true
        ) }

        val continuation = WardTapPermanentsSubCostContinuation(
            payingPlayerId = payingPlayerId,
            spellEntityId = spellEntityId,
            manaCost = manaCost,
            counterDestination = counterDestination,
            controllerId = controllerId,
            pendingSubCostSources = pendingSubCostSources,
            availableSources = availableSources,
            onPaid = onPaid,
            sourceId = sourceId,
            remainingWardParts = remainingWardParts,
            wardSourceId = wardSourceId
        )

        return state.suspendForDecision(
            question = question,
            answer = continuation,
            events = priorEvents,
        )
    }

    /**
     * Resume after the player picks which permanent to tap for the secondary tap-permanents
     * sub-cost of the head [WardTapPermanentsSubCostContinuation.pendingSubCostSources].
     * Taps the source + the chosen permanent, adds the source's mana to the player's
     * pool, then either prompts for the next sub-cost or attempts to pay the ward cost.
     */
    fun resumeWardTapPermanentsSubCost(
        state: GameState,
        continuation: WardTapPermanentsSubCostContinuation,
        response: DecisionResponse,
        checkForMore: CheckForMore
    ): ExecutionResult {
        if (response !is CardsSelectedResponse) {
            return ExecutionResult.error(state, "Expected card selection response for tap-permanents sub-cost")
        }

        val headSourceId = continuation.pendingSubCostSources.first()
        val sourceOption = continuation.availableSources.firstOrNull { it.entityId == headSourceId }
            ?: return ExecutionResult.error(state, "Mana source not found in continuation availableSources")

        val subCost = lookupSubCost(state, continuation.payingPlayerId, headSourceId)
            ?: return ExecutionResult.error(state, "Selected mana source is no longer available")

        if (response.selectedCards.size != subCost.count) {
            return ExecutionResult.error(state, "Expected ${subCost.count} target(s) for ${sourceOption.name}'s tap cost")
        }

        // Validate each chosen permanent still matches the filter and is untapped.
        val projected = state.projectedState
        val predicateEvaluator = PredicateEvaluator()
        val predicateContext = PredicateContext(controllerId = continuation.payingPlayerId)
        for (chosen in response.selectedCards) {
            if (chosen == headSourceId) {
                return ExecutionResult.error(state, "Cannot use the source itself to pay its own tap-permanents sub-cost")
            }
            val container = state.getEntity(chosen)
                ?: return ExecutionResult.error(state, "Chosen permanent not found")
            if (container.has<TappedComponent>()) {
                return ExecutionResult.error(state, "Chosen permanent is already tapped")
            }
            if (!predicateEvaluator.matches(state, projected, chosen, subCost.filter, predicateContext)) {
                return ExecutionResult.error(state, "Chosen permanent does not match ${sourceOption.name}'s tap requirement")
            }
        }

        // Tap the source and each chosen permanent, then credit the source's mana to the pool.
        var currentState = state
        val events = mutableListOf<GameEvent>()
        val (headTappedState, headTapEvent) = tap(currentState, headSourceId)
        currentState = headTappedState
        headTapEvent?.let(events::add)
        for (chosen in response.selectedCards) {
            val (tappedState, tapEvent) = tap(currentState, chosen)
            currentState = tappedState
            tapEvent?.let(events::add)
        }

        // Read current pool, add the source's mana, persist.
        val playerEntity = currentState.getEntity(continuation.payingPlayerId)
            ?: return ExecutionResult.error(state, "Paying player not found")
        val poolComponent = playerEntity.get<ManaPoolComponent>()
            ?: return ExecutionResult.error(state, "Player has no mana pool")
        var pool = ManaPool(
            poolComponent.white, poolComponent.blue, poolComponent.black,
            poolComponent.red, poolComponent.green, poolComponent.colorless
        )
        pool = if (sourceOption.producesColors.isNotEmpty()) {
            pool.add(sourceOption.producesColors.first())
        } else if (sourceOption.producesColorless) {
            pool.addColorless(1)
        } else {
            pool
        }
        currentState = currentState.updateEntity(continuation.payingPlayerId) { container ->
            container.with(
                ManaPoolComponent(
                    white = pool.white, blue = pool.blue, black = pool.black,
                    red = pool.red, green = pool.green, colorless = pool.colorless
                )
            )
        }

        // If more sub-cost sources remain, prompt the next one.
        val remaining = continuation.pendingSubCostSources.drop(1)
        if (remaining.isNotEmpty()) {
            return promptForTapPermanentsSubCost(
                currentState,
                events,
                payingPlayerId = continuation.payingPlayerId,
                spellEntityId = continuation.spellEntityId,
                manaCost = continuation.manaCost,
                counterDestination = continuation.counterDestination,
                controllerId = continuation.controllerId,
                pendingSubCostSources = remaining,
                availableSources = continuation.availableSources,
                onPaid = continuation.onPaid,
                sourceId = continuation.sourceId,
                remainingWardParts = continuation.remainingWardParts,
                wardSourceId = continuation.wardSourceId
            )
        }

        // No more sub-costs — attempt to pay the ward cost. On failure, counter the spell.
        val newPool = pool.pay(continuation.manaCost)
        if (newPool == null) {
            return counterForUnpaidCost(
                currentState, continuation.spellEntityId, continuation.counterDestination,
                continuation.controllerId ?: continuation.payingPlayerId, checkForMore,
                precedingEvents = events
            )
        }
        currentState = currentState.updateEntity(continuation.payingPlayerId) { container ->
            container.with(
                ManaPoolComponent(
                    white = newPool.white, blue = newPool.blue, black = newPool.black,
                    red = newPool.red, green = newPool.green, colorless = newPool.colorless
                )
            )
        }
        // If this mana component was one part of a composite ward cost, charge the next
        // component before the spell is allowed to resolve.
        chargeNextWardPartOrNull(
            currentState, events,
            continuation.remainingWardParts, continuation.spellEntityId,
            continuation.payingPlayerId, continuation.wardSourceId, continuation.controllerId,
            checkForMore
        )?.let { return it }

        // Payment fully resolved through the sub-cost source — fire the "If they do, …"
        // rider (no-op when null), with the counter's controller as "you".
        return runOnPaidThenCheckForMore(
            currentState,
            events,
            continuation.onPaid,
            continuation.controllerId ?: continuation.payingPlayerId,
            continuation.sourceId,
            checkForMore
        )
    }

    /**
     * Whether [playerId]'s floating mana already covers [cost] — see
     * [ManaSourcesSelectedResponse.isDecline]. A player who taps their own sources during the
     * payment window (CR 605.3a) confirms with an empty selection, which must not read as a refusal.
     */
    private fun floatingCovers(state: GameState, playerId: EntityId, cost: ManaCost): Boolean =
        com.wingedsheep.engine.mechanics.mana.ManaPaymentWindow.floatingManaCovers(state, playerId, cost)
}
