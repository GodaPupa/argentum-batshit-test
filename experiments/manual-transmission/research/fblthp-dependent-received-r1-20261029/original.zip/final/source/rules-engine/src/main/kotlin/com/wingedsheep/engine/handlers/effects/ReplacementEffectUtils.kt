package com.wingedsheep.engine.handlers.effects

import com.wingedsheep.engine.handlers.PredicateContext
import com.wingedsheep.engine.handlers.PredicateEvaluator
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.battlefield.ReplacementEffectSourceComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.sdk.core.CounterType
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.DoubleCounterPlacement
import com.wingedsheep.sdk.scripting.ModifyCounterPlacement
import com.wingedsheep.sdk.scripting.PreventExtraTurns
import com.wingedsheep.sdk.scripting.events.CounterTypeFilter
import com.wingedsheep.sdk.scripting.events.RecipientFilter

/**
 * Utility functions for applying replacement effects that modify game actions
 * before they produce events (counter placement modifiers, extra turn prevention).
 */
object ReplacementEffectUtils {

    private val predicateEvaluator = PredicateEvaluator()

    /**
     * Check if extra turns are prevented by any PreventExtraTurns replacement effect
     * on the battlefield (e.g., Ugin's Nexus).
     */
    fun isExtraTurnPrevented(state: GameState): Boolean {
        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val replacementComponent = container.get<ReplacementEffectSourceComponent>() ?: continue
            for (effect in replacementComponent.replacementEffects) {
                if (effect is PreventExtraTurns) return true
            }
        }
        return false
    }

    /**
     * Apply ModifyCounterPlacement replacement effects (Hardened Scales, Winding Constrictor).
     *
     * Scans all battlefield entities for ReplacementEffectSourceComponent containing
     * ModifyCounterPlacement effects. If the counter type and recipient match, modifies
     * the counter count by the effect's modifier.
     *
     * @param state The current game state
     * @param targetId The entity receiving counters
     * @param counterType The type of counter being placed (as CounterType enum)
     * @param count The original number of counters
     * @param placerId The player placing the counters — used to gate effects that only
     *                 apply when "you" are the one placing them (e.g., Innkeeper's Talent
     *                 Level 3). When null, placer-gated effects do not apply.
     * @param entrySourceState For entry counters only, the state before the entry event. Other
     *                 replacement sources come from this boundary; the prepared entering object
     *                 also supplies exclusively self-affecting replacements, even while still on the stack.
     *                 Ordinary counter placement leaves this null and keeps its current-state scan.
     * @return The modified counter count
     */
    fun applyCounterPlacementModifiers(
        state: GameState,
        targetId: EntityId,
        counterType: CounterType,
        count: Int,
        placerId: EntityId? = null,
        entrySourceState: GameState? = null,
    ): Int {
        if (count <= 0) return count

        var modifiedCount = count

        // CR 614.12: simultaneous other entrants are not replacement sources. The entering
        // subject supplies only exclusively self-affecting replacements, not a general subset.
        val sourceState = entrySourceState ?: state
        val sourceIds = if (entrySourceState == null) sourceState.getBattlefield()
            else (sourceState.getBattlefield() + targetId).distinct()
        // 1. Static battlefield replacement effects (Hardened Scales, Doubling Season, …).
        for (entityId in sourceIds) {
            val container = if (entrySourceState != null && entityId == targetId)
                state.getEntity(entityId) else sourceState.getEntity(entityId)
            if (container == null) continue
            val replacementComponent = container.get<ReplacementEffectSourceComponent>() ?: continue
            val sourceControllerId = container.get<ControllerComponent>()?.playerId ?: continue

            for (effect in replacementComponent.replacementEffects) {
                val counterEvent = when (effect) {
                    is ModifyCounterPlacement -> effect.appliesTo
                    is DoubleCounterPlacement -> effect.appliesTo
                    else -> continue
                }
                if (counterEvent !is com.wingedsheep.sdk.scripting.EventPattern.CounterPlacementEvent) continue
                // A new source's general "creatures/permanents you control" effect does not
                // modify its own entry (CR 614.12). The explicit Self recipient is the SDK's
                // self-exclusive spelling; other existing sources retain their normal filters.
                if (entrySourceState != null && entityId == targetId &&
                    counterEvent.recipient != RecipientFilter.Self) continue

                // Gate on "If YOU would put..." — skip when an opponent is the placer.
                val placedByYouOnly = when (effect) {
                    is ModifyCounterPlacement -> effect.placedByYou
                    is DoubleCounterPlacement -> effect.placedByYou
                }
                if (placedByYouOnly && placerId != sourceControllerId) continue

                if (!matchesCounterTypeFilter(counterEvent.counterType, counterType)) continue

                // Check recipient filter
                val recipientMatches = matchesRecipientFilter(
                    counterEvent.recipient, state, targetId, entityId, sourceControllerId
                )
                if (!recipientMatches) continue

                when (effect) {
                    is ModifyCounterPlacement -> modifiedCount += effect.modifier
                    is DoubleCounterPlacement -> modifiedCount *= 2
                }
            }
        }

        // 2. Temporary, duration-scoped, controller-scoped modifiers
        //    (GrantCounterPlacementModifierEffect — e.g. Prairie Dog's {4}{W}).
        //    These have no battlefield source permanent: the effect's stored controllerId IS
        //    the "you" for both the recipient filter ("a creature you control") and the placer
        //    gate (only the controller's own counter placements get the bonus).
        for (modifier in sourceState.activeCounterPlacementModifiers) {
            if (placerId != modifier.controllerId) continue
            if (!matchesCounterTypeFilter(modifier.counterType, counterType)) continue
            // No battlefield source entity — pass the controller as the "source entity" so
            // RecipientFilter.Self can't spuriously match, and the controller as controllerId.
            val recipientMatches = matchesRecipientFilter(
                modifier.recipient, state, targetId, modifier.controllerId, modifier.controllerId
            )
            if (!recipientMatches) continue
            modifiedCount += modifier.modifier
        }

        return modifiedCount.coerceAtLeast(0)
    }

    /** Whether a [CounterTypeFilter] from a replacement/modifier matches the concrete [counterType] being placed. */
    private fun matchesCounterTypeFilter(filter: CounterTypeFilter, counterType: CounterType): Boolean =
        when (filter) {
            is CounterTypeFilter.Any -> true
            is CounterTypeFilter.PlusOnePlusOne -> counterType == CounterType.PLUS_ONE_PLUS_ONE
            is CounterTypeFilter.MinusOneMinusOne -> counterType == CounterType.MINUS_ONE_MINUS_ONE
            is CounterTypeFilter.PlusOnePlusZero -> counterType == CounterType.PLUS_ONE_PLUS_ZERO
            is CounterTypeFilter.PlusZeroPlusOne -> counterType == CounterType.PLUS_ZERO_PLUS_ONE
            is CounterTypeFilter.MinusOneMinusZero -> counterType == CounterType.MINUS_ONE_MINUS_ZERO
            is CounterTypeFilter.MinusZeroMinusOne -> counterType == CounterType.MINUS_ZERO_MINUS_ONE
            is CounterTypeFilter.Loyalty -> counterType == CounterType.LOYALTY
            is CounterTypeFilter.Named -> {
                try {
                    counterType == CounterType.valueOf(filter.name.uppercase().replace(' ', '_'))
                } catch (_: IllegalArgumentException) {
                    false
                }
            }
        }

    private fun matchesRecipientFilter(
        recipient: RecipientFilter,
        state: GameState,
        targetId: EntityId,
        sourceEntityId: EntityId,
        sourceControllerId: EntityId
    ): Boolean {
        val projected = state.projectedState
        // Entities still on the stack (about to enter the battlefield) are not in the
        // projected state yet, so fall back to base components for those. Battlefield
        // permanents go through projected state so control-changing effects (Annex,
        // Blatant Thievery) are honored.
        val projectedController = projected.getController(targetId)
        val effectiveController = projectedController
            ?: state.getEntity(targetId)?.get<ControllerComponent>()?.playerId
        return when (recipient) {
            is RecipientFilter.CreatureYouControl -> {
                val isCreature = if (projectedController != null) {
                    projected.isCreature(targetId)
                } else {
                    state.getEntity(targetId)?.get<CardComponent>()?.typeLine?.isCreature == true
                }
                val isControlled = effectiveController == sourceControllerId
                isCreature && isControlled
            }
            is RecipientFilter.Any -> true
            is RecipientFilter.Self -> targetId == sourceEntityId
            is RecipientFilter.PermanentYouControl -> {
                effectiveController == sourceControllerId
            }
            is RecipientFilter.You -> targetId == sourceControllerId
            is RecipientFilter.Matching -> {
                val context = PredicateContext(controllerId = sourceControllerId, sourceId = sourceEntityId)
                predicateEvaluator.matches(
                    state, projected, targetId, recipient.filter, context
                )
            }
            else -> false
        }
    }
}
