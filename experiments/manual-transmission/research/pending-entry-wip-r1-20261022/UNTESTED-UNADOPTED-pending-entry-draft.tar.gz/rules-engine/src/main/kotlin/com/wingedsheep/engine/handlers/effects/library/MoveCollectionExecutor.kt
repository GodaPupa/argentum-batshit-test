package com.wingedsheep.engine.handlers.effects.library

import com.wingedsheep.engine.core.*
import com.wingedsheep.engine.handlers.EffectContext
import com.wingedsheep.engine.handlers.TargetFinder
import com.wingedsheep.engine.handlers.effects.EffectExecutor
import com.wingedsheep.engine.handlers.effects.EntersWithReplacements
import com.wingedsheep.engine.handlers.effects.TargetResolutionUtils
import com.wingedsheep.engine.handlers.effects.ZoneMovementUtils
import com.wingedsheep.engine.registry.CardRegistry
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.ZoneKey
import com.wingedsheep.engine.state.components.battlefield.AttachedToComponent
import com.wingedsheep.engine.state.components.battlefield.AttachmentsComponent
import com.wingedsheep.engine.state.components.battlefield.CountersComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.engine.state.components.identity.FaceDownComponent
import com.wingedsheep.engine.state.components.identity.MayLookAtInExileComponent
import com.wingedsheep.engine.state.components.identity.OwnerComponent
import com.wingedsheep.engine.state.components.player.SacrificedFoodThisTurnComponent
import com.wingedsheep.sdk.core.Keyword
import com.wingedsheep.sdk.core.Zone
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.effects.CardDestination
import com.wingedsheep.sdk.scripting.effects.CardOrder
import com.wingedsheep.sdk.scripting.effects.FaceDownMode
import com.wingedsheep.sdk.scripting.effects.MoveCollectionEffect
import com.wingedsheep.engine.state.components.stack.captureEntitySnapshots
import com.wingedsheep.sdk.scripting.effects.MoveType
import com.wingedsheep.sdk.scripting.references.Player
import com.wingedsheep.sdk.scripting.effects.ZonePlacement
import kotlin.reflect.KClass

/**
 * Executor for MoveCollectionEffect.
 *
 * Reads cards from a named collection in [EffectContext.storedCollections]
 * and moves them to the specified destination zone.
 *
 * Cards are removed from their current zone (determined by looking at which zone
 * currently contains each card) and placed in the destination.
 */
class MoveCollectionExecutor(
    private val cardRegistry: CardRegistry,
    private val targetFinder: TargetFinder? = null,
    private val preparedEntries: Map<EntityId, PendingCardEntry>? = null,
    private val entryBoundary: GameState? = null,
) : EffectExecutor<MoveCollectionEffect> {

    override val effectType: KClass<MoveCollectionEffect> = MoveCollectionEffect::class

    override fun execute(
        state: GameState,
        effect: MoveCollectionEffect,
        context: EffectContext
    ): EffectResult {
        val allCards = preparedEntries?.keys?.toList() ?: context.pipeline.storedCollections[effect.from]
            ?: return EffectResult.error(state, "No collection named '${effect.from}' in storedCollections")

        // Optional per-card filter: only move cards matching it; the rest stay put. Lets a single
        // gathered pile be split by type across multiple MoveCollection steps.
        val cards = if (preparedEntries == null && effect.filter != null) {
            val predicateEvaluator = com.wingedsheep.engine.handlers.PredicateEvaluator()
            val predicateContext = com.wingedsheep.engine.handlers.PredicateContext(
                controllerId = context.controllerId,
                sourceId = context.sourceId
            )
            allCards.filter { cardId ->
                predicateEvaluator.matches(state, state.projectedState, cardId, effect.filter!!, predicateContext)
            }
        } else {
            allCards
        }

        val destination = effect.destination
        if (preparedEntries == null && destination is CardDestination.ToZone &&
            destination.zone == Zone.BATTLEFIELD && effect.faceDown == null && cards.any { id ->
                val card = state.getEntity(id)?.get<CardComponent>()
                card?.let { cardRegistry.getCard(it.cardDefinitionId)?.script?.replacementEffects }
                    .orEmpty().any { it is com.wingedsheep.sdk.scripting.EntersAsCopy || it is com.wingedsheep.sdk.scripting.EntersWithChoice }
            }
        ) {
            val destinationPlayer = resolvePlayer(destination.player, context, state) ?: context.controllerId
            val entrants = cards.map { id -> id to if (effect.underOwnersControl) {
                state.getEntity(id)?.get<OwnerComponent>()?.playerId ?: destinationPlayer
            } else destinationPlayer }
            return com.wingedsheep.engine.handlers.effects.PendingEntryChoices(cardRegistry).begin(
                state, effect, context, entrants,
            ) { ready, plan -> com.wingedsheep.engine.handlers.effects.PendingEntryCommitter.commit(
                ready, plan, cardRegistry, targetFinder ?: TargetFinder(),
                { _, _, _ -> error("Collection entry must not route through a single-card effect callback") },
            ) }
        }
        if (cards.isEmpty()) {
            // Nothing to move, but for library shuffles we still shuffle (e.g., ShuffleGraveyardIntoLibrary
            // shuffles even when the graveyard is empty, per the card's rules text).
            if (destination is CardDestination.ToZone &&
                destination.zone == Zone.LIBRARY &&
                destination.placement == ZonePlacement.Shuffled) {
                val destPlayerId = resolvePlayer(destination.player, context, state)
                if (destPlayerId != null) {
                    val destZoneKey = ZoneKey(destPlayerId, Zone.LIBRARY)
                    val (shuffledLibrary, shuffledState) = state.nextRandom { shuffle(state.getZone(destZoneKey)) }
                    val newState = shuffledState.reorderZone(destZoneKey, shuffledLibrary)
                    return EffectResult.success(newState, listOf(LibraryShuffledEvent(destPlayerId)))
                }
            }
            return EffectResult.success(state).copy(updatedCollections =
                effect.storeMovedAs?.let { mapOf(it to emptyList<EntityId>()) }.orEmpty())
        }

        var result = when (destination) {
            is CardDestination.ToZone ->
                moveToZone(state, context, cards, destination, effect.order, effect.revealed, effect.moveType, effect.faceDown, effect.noRegenerate, effect.storeMovedAs, effect.underOwnersControl, effect.revealToSelf)
            is CardDestination.ToZoneExiledFrom ->
                moveToZonesExiledFrom(state, context, cards, destination, effect)
        }
        if (effect.linkToSource && result.isSuccess) {
            result = linkCardsToSource(result, context, cards)
        }
        if (effect.unlinkFromSource && result.isSuccess) {
            result = unlinkCardsFromSource(result, context, cards)
        }
        val counterType = effect.addCounterType
        if (counterType != null && result.isSuccess) {
            var newState = result.state
            for (cardId in cards) {
                newState = newState.updateEntity(cardId) { c ->
                    val existing = c.get<CountersComponent>() ?: CountersComponent()
                    c.with(existing.withAdded(counterType, 1))
                }
            }
            result = EffectResult.success(newState, result.events).copy(updatedCollections = result.updatedCollections)
        }
        if (effect.lookableInExile && result.isSuccess) {
            result = grantLookAtInExile(result, context, cards)
        }
        val marksBattlefieldEntries = when (destination) {
            is CardDestination.ToZone -> destination.zone == Zone.BATTLEFIELD
            // Per-card destination: markEnteredViaSourceAbility already skips cards that didn't
            // land on the battlefield, so let it inspect the whole set.
            is CardDestination.ToZoneExiledFrom -> true
        }
        if (effect.markEnteredViaSourceAbility && marksBattlefieldEntries && result.isSuccess) {
            result = markEnteredViaSourceAbility(result, context, cards)
        }
        return result
    }

    /**
     * Stamp the "you may look at that card for as long as it remains exiled" grant
     * ([MoveCollectionEffect.lookableInExile]) on every card this move actually landed face down
     * in exile.
     *
     * Both halves of that guard matter. A card that never reached exile — a move that was
     * replaced, or a collection holding a card already gone — must not carry a grant keyed to a
     * zone it isn't in. And a card that reached exile *face up* needs no grant: it is public
     * information already, so stamping one would only make the component lie about why the card
     * is visible.
     */
    private fun grantLookAtInExile(
        result: EffectResult,
        context: EffectContext,
        cards: List<EntityId>,
    ): EffectResult {
        val viewerId = context.controllerId
        var newState = result.state
        for (cardId in cards) {
            val container = newState.getEntity(cardId) ?: continue
            if (!container.has<FaceDownComponent>()) continue
            val inExile = newState.turnOrder.any { pid -> cardId in newState.getZone(ZoneKey(pid, Zone.EXILE)) }
            if (!inExile) continue
            newState = newState.updateEntity(cardId) { c ->
                val existing = c.get<MayLookAtInExileComponent>()
                c.with(existing?.withPlayer(viewerId) ?: MayLookAtInExileComponent.to(viewerId))
            }
        }
        return EffectResult.success(newState, result.events).copy(updatedCollections = result.updatedCollections)
    }

    /**
     * Send each card back to the zone recorded on its
     * [com.wingedsheep.engine.state.components.identity.ExiledFromZoneComponent] — CR 610.3's
     * "return the object to its previous zone" for an exile-until whose exile half spanned several
     * zones.
     *
     * Cards are grouped by destination zone and each group is handed to the ordinary
     * [moveToZone] path, so aura-target selection, owner routing, library placement, reveals and
     * events all behave exactly as they do for a fixed [CardDestination.ToZone].
     *
     * The per-group [CardDestination.ToZone] is rebuilt with **only** the zone: no `player`, no
     * `placement`. That is load-bearing rather than an oversight — owner routing for a
     * non-battlefield zone comes from the zone transition itself (it routes to the card's owner),
     * and the battlefield case comes from `underOwnersControl` (CR 610.3c). One consequence worth
     * knowing: a card that was exiled from the *middle* of a library comes back at
     * `ZonePlacement.Default`, not at the index it left from. CR 610.3 names only "its previous
     * zone" and fixes no position, so that is legal, but it is not a round trip.
     *
     * **Group order matters.** `moveToZone` can pause for player input, and a pause abandons the
     * groups that haven't run yet. Only two destinations can pause: a library group under
     * [CardOrder.ControllerChooses] (the reorder decision) and a battlefield group containing an
     * Aura (its enchant target, CR 303.4f). Those two are therefore ordered last — every zone that
     * cannot pause runs first. With the shipped `Effects.ReturnLinkedExileToZoneExiledFrom` facade
     * (which uses [CardOrder.Preserve]) only the battlefield group can pause, so nothing is ever
     * stranded; a caller that opts into `ControllerChooses` *and* returns cards to both a library
     * and the battlefield could strand the battlefield group behind the library prompt.
     * TODO: resume the remaining groups from the continuation instead of abandoning them, so that
     *  combination stops being a hazard a caller has to know about.
     *
     * A card whose origin zone wasn't recorded, or was a zone an object can't be returned to
     * (the stack), falls back to [CardDestination.ToZoneExiledFrom.fallback]. A card recorded as
     * exiled *from exile* (CR 406.7) is left exactly where it is — see [originZoneOf].
     */
    private fun moveToZonesExiledFrom(
        state: GameState,
        context: EffectContext,
        cards: List<EntityId>,
        destination: CardDestination.ToZoneExiledFrom,
        effect: MoveCollectionEffect
    ): EffectResult {
        val byZone = cards.groupBy { cardId -> originZoneOf(state, cardId, destination.fallback) }
            // An object exiled from exile (CR 406.7) never changed zones, so "return it to its
            // previous zone" leaves it in exile. Skip the group outright rather than running an
            // exile → exile transition, which would emit a spurious ZoneChangeEvent and strip the
            // face-down / suspend / madness / paradigm markers off a card that went nowhere.
            .filterKeys { it != Zone.EXILE }
        // Zones that cannot pause first; library then battlefield last (see the doc comment).
        val orderedZones = byZone.keys.sortedBy { zone ->
            when (zone) {
                Zone.LIBRARY -> 1
                Zone.BATTLEFIELD -> 2
                else -> 0
            }
        }

        var runningState = state
        val events = mutableListOf<GameEvent>()
        val collections = mutableMapOf<String, List<EntityId>>()

        for (zone in orderedZones) {
            val group = byZone.getValue(zone)
            val groupResult = moveToZone(
                runningState, context, group,
                CardDestination.ToZone(zone),
                effect.order, effect.revealed, effect.moveType, effect.faceDown,
                effect.noRegenerate, effect.storeMovedAs, effect.underOwnersControl, effect.revealToSelf
            )
            runningState = groupResult.state
            events.addAll(groupResult.events)
            groupResult.updatedCollections.forEach { (key, ids) ->
                collections[key] = (collections[key] ?: emptyList()) + ids
            }
            if (!groupResult.isSuccess || groupResult.pendingDecision != null) {
                return groupResult.copy(
                    state = runningState,
                    events = events,
                    updatedCollections = collections
                )
            }
        }

        return EffectResult.success(runningState, events).copy(updatedCollections = collections)
    }

    /**
     * The zone [cardId] was exiled from, or [fallback] when nothing usable was recorded.
     *
     * Two recorded values are not returned as-is:
     *  - **`STACK`** takes [fallback]. A spell lifted off the stack and exiled has no stack object
     *    to go back to (CR 400.7 — it would be a new object, and the stack only holds spells and
     *    abilities that were *put* there).
     *  - **`EXILE`** is returned unchanged, and the caller ([moveToZonesExiledFrom]) drops that
     *    group: an object exiled from exile (CR 406.7) "doesn't change zones", so its previous
     *    zone *is* exile and the CR 610.3 return is a no-op.
     *
     * Every other `Zone` member — battlefield, hand, graveyard, library, command, sideboard — is
     * passed straight through, so this is a two-value exclusion list, not an allowlist.
     */
    private fun originZoneOf(state: GameState, cardId: EntityId, fallback: Zone): Zone {
        val recorded = state.getEntity(cardId)
            ?.get<com.wingedsheep.engine.state.components.identity.ExiledFromZoneComponent>()
            ?.zone
            ?: return fallback
        return if (recorded == Zone.STACK) fallback else recorded
    }

    /**
     * Stamp each card that just landed on the battlefield with an
     * [com.wingedsheep.engine.state.components.battlefield.EnteredViaAbilityComponent]
     * referencing the resolving ability's source permanent. Used by anti-loop guards
     * like Kodama of the East Tree's "if it wasn't put onto the battlefield with this
     * ability" intervening-if. Cards that ended up off the battlefield (e.g., redirected
     * by a replacement effect) are skipped — the component would not apply to them.
     */
    private fun markEnteredViaSourceAbility(
        result: EffectResult,
        context: EffectContext,
        cards: List<EntityId>
    ): EffectResult {
        val sourceId = context.sourceId ?: return result
        var newState = result.state
        for (cardId in cards) {
            val zone = findCurrentZone(newState, cardId, newState.getEntity(cardId)?.get<CardComponent>()?.ownerId ?: continue)
            if (zone != Zone.BATTLEFIELD) continue
            newState = newState.updateEntity(cardId) { c ->
                c.with(com.wingedsheep.engine.state.components.battlefield.EnteredViaAbilityComponent(sourceId))
            }
        }
        return EffectResult.success(newState, result.events).copy(updatedCollections = result.updatedCollections)
    }

    /**
     * Store the moved card IDs on the source permanent's LinkedExileComponent.
     * Used by Parallel Thoughts and similar cards that need to track exiled cards.
     */
    private fun linkCardsToSource(
        result: EffectResult,
        context: EffectContext,
        cards: List<EntityId>
    ): EffectResult {
        return result.copy(state = com.wingedsheep.engine.handlers.effects.linkedexile.LinkedExileLookup
            .link(result.state, context, cards))
    }

    /**
     * Remove the moved card IDs from the source permanent's LinkedExileComponent.
     * Inverse of [linkCardsToSource] — used when taking cards from a linked exile pile.
     */
    private fun unlinkCardsFromSource(
        result: EffectResult,
        context: EffectContext,
        cards: List<EntityId>
    ): EffectResult {
        val sourceId = context.sourceId ?: return result
        var newState = result.state
        val sourceContainer = newState.getEntity(sourceId) ?: return result
        val existingLinked = sourceContainer.get<com.wingedsheep.engine.state.components.battlefield.LinkedExileComponent>() ?: return result
        val movedSet = cards.toSet()
        val remaining = existingLinked.exiledIds.filter { it !in movedSet }
        newState = newState.updateEntity(sourceId) { c ->
            c.with(com.wingedsheep.engine.state.components.battlefield.LinkedExileComponent(remaining))
        }
        return EffectResult.success(newState, result.events)
    }

    private fun moveToZone(
        state: GameState,
        context: EffectContext,
        cards: List<EntityId>,
        destination: CardDestination.ToZone,
        order: CardOrder,
        revealed: Boolean = false,
        moveType: MoveType = MoveType.Default,
        faceDown: FaceDownMode? = null,
        noRegenerate: Boolean = false,
        storeMovedAs: String? = null,
        underOwnersControl: Boolean = false,
        revealToSelf: Boolean = true
    ): EffectResult {
        val destPlayerId = resolvePlayer(destination.player, context, state)
            ?: return EffectResult.error(state, "Could not resolve destination player for MoveCollection")

        val destZone = destination.zone

        // ControllerChooses ordering: pause for player to see/reorder cards going to library
        if (order == CardOrder.ControllerChooses && destZone == Zone.LIBRARY) {
            val isBottom = destination.placement == ZonePlacement.Bottom
            // For top placement: always pause (even for 1 card, so player can see it)
            // For bottom placement: only pause when there are multiple cards to order
            if (!isBottom || cards.size > 1) {
                return pauseForOrderDecision(state, context, cards, destZone, destPlayerId, destination.placement)
            }
        }

        // Random ordering: shuffle the cards before placing them (player has no knowledge of order)
        val (orderedCards, stateForMove) = if (order == CardOrder.Random) {
            state.nextRandom { shuffle(cards) }
        } else {
            cards to state
        }

        val result = moveCardsToZone(stateForMove, context, orderedCards, destination, destPlayerId, revealed, moveType, faceDown, noRegenerate, storeMovedAs, underOwnersControl, revealToSelf)

        // Random library placement: the mover doesn't know where the cards landed, so strip
        // their reveal markers. moveCardsToZone marks moved cards as revealed to the controller
        // (so the UI can show "you know this card"), but random ordering invalidates that.
        //
        // Note: this is intentionally per-card, *not* full-library — unlike ZonePlacement.Shuffled
        // which calls LibraryRevealUtils.clearLibraryReveals() to wipe the whole library. Random
        // bottom-placement only obscures the cards being moved; any other cards in the library
        // whose positions the player legitimately knows (e.g. from a prior Brainstorm) stay revealed.
        if (order == CardOrder.Random && destination.zone == Zone.LIBRARY && result.isSuccess) {
            return result.copy(state = LibraryRevealUtils.clearReveals(result.state, orderedCards))
        }

        return result
    }

    /**
     * Pause execution and present a ReorderLibraryDecision so the player
     * can choose the order of multiple cards going to the top of a library.
     */
    private fun pauseForOrderDecision(
        state: GameState,
        context: EffectContext,
        cards: List<EntityId>,
        destZone: Zone,
        destPlayerId: EntityId,
        placement: ZonePlacement = ZonePlacement.Top
    ): EffectResult {
        val playerId = context.controllerId

        // Build card info map for the UI
        val cardInfoMap = cards.associateWith { cardId ->
            val container = state.getEntity(cardId)
            val cardComponent = container?.get<CardComponent>()
            SearchCardInfo(
                name = cardComponent?.name ?: "Unknown",
                manaCost = cardComponent?.manaCost?.toString() ?: "",
                typeLine = cardComponent?.typeLine?.toString() ?: "",
                imageUri = null
            )
        }

        val sourceName = context.sourceId?.let { sourceId ->
            state.getEntity(sourceId)?.get<CardComponent>()?.name
        }

        val isOwnLibrary = destPlayerId == context.controllerId
        val libraryOwner = if (isOwnLibrary) "your" else "their"
        val promptText = when (placement) {
            ZonePlacement.Bottom -> "Put the revealed cards on the bottom of $libraryOwner library in any order."
            else -> if (cards.size == 1) "Look at the top card of $libraryOwner library."
                else "Look at the top ${cards.size} cards of $libraryOwner library. Put them back in any order."
        }

        val decision = { decisionId: String -> ReorderLibraryDecision(
            id = decisionId,
            playerId = playerId,
            prompt = promptText,
            context = DecisionContext(
                sourceId = context.sourceId,
                sourceName = sourceName,
                phase = DecisionPhase.RESOLUTION
            ),
            cards = cards,
            cardInfo = cardInfoMap
        ) }

        val continuation = MoveCollectionOrderContinuation(
            playerId = playerId,
            sourceId = context.sourceId,
            objectReferences = context.objectReferences,
            sourceName = sourceName,
            cards = cards,
            destinationZone = destZone,
            destinationPlayerId = destPlayerId,
            placement = placement
        )

        return EffectResult.from(state.suspendForDecision(decision, continuation))
    }

    /**
     * Actually move the cards to the destination zone. Used both for direct moves
     * and after the player has chosen an order via MoveCollectionOrderContinuation.
     */
    internal fun moveCardsToZone(
        state: GameState,
        context: EffectContext,
        cards: List<EntityId>,
        destination: CardDestination.ToZone,
        destPlayerId: EntityId,
        revealed: Boolean = false,
        moveType: MoveType = MoveType.Default,
        faceDown: FaceDownMode? = null,
        noRegenerate: Boolean = false,
        storeMovedAs: String? = null,
        underOwnersControl: Boolean = false,
        revealToSelf: Boolean = true
    ): EffectResult {
        val destZone = destination.zone

        // When moving to battlefield, detect auras that need target selection (Rule 303.4f)
        if (destZone == Zone.BATTLEFIELD && targetFinder != null) {
            val auraCards = mutableListOf<EntityId>()
            val nonAuraCards = mutableListOf<EntityId>()

            for (cardId in cards) {
                val container = state.getEntity(cardId)
                val cardComponent = container?.get<CardComponent>()
                if (cardComponent?.isAura == true) {
                    auraCards.add(cardId)
                } else {
                    nonAuraCards.add(cardId)
                }
            }

            if (auraCards.isNotEmpty()) {
                // Move non-auras first, then pause for aura target selection
                var newState = state
                val events = mutableListOf<GameEvent>()

                if (nonAuraCards.isNotEmpty()) {
                    val nonAuraResult = moveCardsToZoneInternal(
                        newState, context, nonAuraCards, destination, destPlayerId, revealed, moveType, faceDown, noRegenerate, storeMovedAs, underOwnersControl, revealToSelf
                    )
                    newState = nonAuraResult.state
                    events.addAll(nonAuraResult.events)
                }

                // Rule 303.4f: the player putting the Aura onto the battlefield chooses its enchant target.
                // When underOwnersControl=true the Aura returns to its owner, so the owner picks the target.
                val firstAuraId = auraCards.first()
                val actualControllerId = if (underOwnersControl) {
                    val e = newState.getEntity(firstAuraId)
                    e?.get<OwnerComponent>()?.playerId ?: e?.get<CardComponent>()?.ownerId ?: destPlayerId
                } else destPlayerId

                return askAuraTargetForMoveCollection(
                    state = newState,
                    events = events,
                    auraId = firstAuraId,
                    controllerId = actualControllerId,
                    destPlayerId = actualControllerId,
                    remainingAuras = auraCards.drop(1),
                    sourceId = context.sourceId,
                    sourceName = context.sourceId?.let { newState.getEntity(it)?.get<CardComponent>()?.name },
                    underOwnersControl = underOwnersControl
                )
            }
        }

        return moveCardsToZoneInternal(state, context, cards, destination, destPlayerId, revealed, moveType, faceDown, noRegenerate, storeMovedAs, underOwnersControl, revealToSelf)
    }

    /**
     * Ask the player to choose a target for an Aura entering the battlefield via MoveCollectionEffect.
     * Per Rule 303.4f, targeting restrictions (hexproof, shroud) do not apply.
     * If no legal target exists, the Aura stays in its current zone (Rule 303.4g).
     *
     * [underOwnersControl] — when true the aura returns under its owner's control; the owner
     * is the one choosing the enchant target and controlling the battlefield zone.
     */
    private fun askAuraTargetForMoveCollection(
        state: GameState,
        events: List<GameEvent>,
        auraId: EntityId,
        controllerId: EntityId,
        destPlayerId: EntityId,
        remainingAuras: List<EntityId>,
        sourceId: EntityId?,
        sourceName: String?,
        underOwnersControl: Boolean = false
    ): EffectResult {
        val cardComponent = state.getEntity(auraId)?.get<CardComponent>()
        val cardDef = cardComponent?.let { cardRegistry.getCard(it.cardDefinitionId) }
        val auraTarget = cardDef?.script?.auraTarget

        if (auraTarget == null) {
            // No aura target defined — skip this aura (leave in current zone)
            return continueAuraProcessingOrFinish(
                state, events, remainingAuras, controllerId, destPlayerId, sourceId, sourceName
            )
        }

        val legalTargets = targetFinder!!.findLegalTargets(
            state = state,
            requirement = auraTarget,
            controllerId = controllerId,
            sourceId = auraId,
            ignoreTargetingRestrictions = true
        )

        if (legalTargets.isEmpty()) {
            // No legal targets — Aura stays in current zone per Rule 303.4g
            return continueAuraProcessingOrFinish(
                state, events, remainingAuras, controllerId, destPlayerId, sourceId, sourceName, underOwnersControl
            )
        }

        val auraName = cardComponent.name
        val requirementInfo = TargetRequirementInfo(
            index = 0,
            description = auraTarget.description,
            minTargets = 1,
            maxTargets = 1
        )
        val decision = { decisionId: String -> ChooseTargetsDecision(
            id = decisionId,
            playerId = controllerId,
            prompt = "Choose what $auraName enchants",
            context = DecisionContext(
                sourceId = auraId,
                sourceName = auraName,
                phase = DecisionPhase.RESOLUTION
            ),
            targetRequirements = listOf(requirementInfo),
            legalTargets = mapOf(0 to legalTargets)
        ) }

        val continuation = MoveCollectionAuraTargetContinuation(
            auraId = auraId,
            controllerId = controllerId,
            destPlayerId = destPlayerId,
            remainingAuras = remainingAuras,
            sourceId = sourceId,
            sourceName = sourceName,
            underOwnersControl = underOwnersControl
        )

        return EffectResult.from(state.suspendForDecision(decision, continuation, emptyList()))
    }

    /**
     * Continue processing remaining auras, or finish if no more.
     */
    private fun continueAuraProcessingOrFinish(
        state: GameState,
        events: List<GameEvent>,
        remainingAuras: List<EntityId>,
        controllerId: EntityId,
        destPlayerId: EntityId,
        sourceId: EntityId?,
        sourceName: String?,
        underOwnersControl: Boolean = false
    ): EffectResult {
        if (remainingAuras.isNotEmpty()) {
            val nextAuraId = remainingAuras.first()
            val actualControllerId = if (underOwnersControl) {
                val e = state.getEntity(nextAuraId)
                e?.get<OwnerComponent>()?.playerId ?: e?.get<CardComponent>()?.ownerId ?: controllerId
            } else controllerId
            return askAuraTargetForMoveCollection(
                state = state,
                events = events,
                auraId = nextAuraId,
                controllerId = actualControllerId,
                destPlayerId = actualControllerId,
                remainingAuras = remainingAuras.drop(1),
                sourceId = sourceId,
                sourceName = sourceName,
                underOwnersControl = underOwnersControl
            )
        }
        return EffectResult.success(state, events)
    }

    /**
     * Move a single aura from its current zone to the battlefield with AttachedToComponent.
     */
    internal fun moveAuraToBattlefield(
        state: GameState,
        auraId: EntityId,
        targetId: EntityId,
        destPlayerId: EntityId
    ): Pair<GameState, List<GameEvent>> {
        val events = mutableListOf<GameEvent>()
        var newState = state

        val ownerId = newState.getEntity(auraId)?.get<OwnerComponent>()?.playerId ?: destPlayerId
        val cardName = newState.getEntity(auraId)?.get<CardComponent>()?.name ?: "Unknown"

        // Find and remove from current zone
        val fromZone = findCurrentZone(newState, auraId, ownerId)
        if (fromZone != null) {
            newState = newState.removeFromZone(ZoneKey(ownerId, fromZone), auraId)
        }

        // Add to battlefield
        newState = com.wingedsheep.engine.handlers.effects.BattlefieldEntry
            .place(newState, destPlayerId, auraId)

        // Apply battlefield components + AttachedToComponent on aura
        val container = newState.getEntity(auraId)
        if (container != null) {
            val cardDef = container.get<CardComponent>()
                ?.let { cardRegistry.getCard(it.cardDefinitionId) }
            var newContainer = container
                .with(ControllerComponent(destPlayerId))
                .with(AttachedToComponent(targetId))
            // Wire up static/replacement abilities from the card definition
            if (cardDef != null) {
                val staticHandler = com.wingedsheep.engine.mechanics.layers.StaticAbilityHandler(cardRegistry)
                newContainer = staticHandler.addContinuousEffectComponent(newContainer, cardDef)
                newContainer = staticHandler.addReplacementEffectComponent(newContainer, cardDef)
            }
            newState = newState.copy(entities = newState.entities + (auraId to newContainer))
        }

        // Update target's AttachmentsComponent to include this aura
        newState = newState.updateEntity(targetId) { targetContainer ->
            val existing = targetContainer.get<AttachmentsComponent>()
            val updatedIds = (existing?.attachedIds ?: emptyList()) + auraId
            targetContainer.with(AttachmentsComponent(updatedIds))
        }

        if (fromZone != null) {
            events.add(
                ZoneChangeEvent(
                    entityId = auraId,
                    entityName = cardName,
                    fromZone = fromZone,
                    toZone = Zone.BATTLEFIELD,
                    ownerId = ownerId,
                    oldObject = state.objectRef(auraId),
                    newObject = newState.objectRef(auraId)
                )
            )
        }

        // CR 603.2e — the Aura "becomes attached" as it enters attached by this effect; emit so
        // attachment triggers (Eriette, the Beguiler) fire on the effect-driven attach path too.
        events.add(
            com.wingedsheep.engine.core.PermanentAttachedEvent(
                attachmentId = auraId,
                attachmentName = cardName,
                attachedToId = targetId,
                controllerId = destPlayerId,
            )
        )

        return Pair(newState, events)
    }

    private fun moveCardsToZoneInternal(
        state: GameState,
        context: EffectContext,
        cards: List<EntityId>,
        destination: CardDestination.ToZone,
        destPlayerId: EntityId,
        revealed: Boolean = false,
        moveType: MoveType = MoveType.Default,
        faceDown: FaceDownMode? = null,
        noRegenerate: Boolean = false,
        storeMovedAs: String? = null,
        underOwnersControl: Boolean = false,
        revealToSelf: Boolean = true
    ): EffectResult {
        val destZone = destination.zone
        val events = mutableListOf<GameEvent>()
        // Record the resolving spell/ability as the *cause* of a discard before anything moves, so
        // a card's own zone-change replacement can key off it (Wilt-Leaf Liege: "if a spell or
        // ability an opponent controls causes you to discard this card…"). Consumed per card by
        // ZoneTransitionService.moveToZone.
        var newState = if (moveType == MoveType.Discard) {
            com.wingedsheep.engine.handlers.effects.ZoneTransitionService
                .markDiscardCause(state, cards, context.controllerId)
        } else {
            state
        }

        val movedIds = mutableListOf<EntityId>()
        // Track every library that received at least one card so per-card owner routing
        // (e.g., a permanent owned by another player going to its owner's library) shuffles
        // and reveal-marks every affected library, not just the destination's nominal owner.
        val librariesReceivingCards = linkedSetOf<EntityId>()

        // Determine library placement for ZoneTransitionService
        val libraryPlacement = when (destination.placement) {
            ZonePlacement.Top, ZonePlacement.Default -> com.wingedsheep.engine.handlers.effects.LibraryPlacement.Top
            ZonePlacement.Bottom -> com.wingedsheep.engine.handlers.effects.LibraryPlacement.Bottom
            ZonePlacement.Shuffled -> com.wingedsheep.engine.handlers.effects.LibraryPlacement.Bottom // shuffle at end
            else -> com.wingedsheep.engine.handlers.effects.LibraryPlacement.Top
        }

        for (cardId in cards) {
            val ownerId = newState.getEntity(cardId)?.get<OwnerComponent>()?.playerId ?: destPlayerId

            // For MoveType.Destroy, check indestructible and regeneration before moving
            if (moveType == MoveType.Destroy) {
                if (newState.projectedState.hasKeyword(cardId, Keyword.INDESTRUCTIBLE)) {
                    continue
                }
                // CR 122.1c — a shield counter replaces destruction by an effect, one counter per
                // destruction. A board wipe destroys each permanent as a separate destruction event,
                // so each shielded permanent spends exactly one counter and survives. Ordered ahead
                // of regeneration for the reason given in `ZoneMovementUtils.destroyPermanent`.
                val shielded = consumeShieldCounter(newState, cardId)
                if (shielded != null) {
                    newState = shielded.first
                    events.add(shielded.second)
                    continue
                }
                if (!noRegenerate) {
                    val (shieldState, wasRegenerated) = ZoneMovementUtils.applyRegenerationShields(newState, cardId)
                    if (wasRegenerated) {
                        // Regeneration's tap emits a TappedEvent (CR 701.19a); fold it in so
                        // "becomes tapped" triggers fire on this path too, not just the SBA one.
                        val regenResult = ZoneMovementUtils.applyRegenerationReplacement(shieldState, cardId)
                        newState = regenResult.state
                        events.addAll(regenResult.events)
                        continue
                    }
                }
            }

            // Find current zone for controller override logic
            val fromZone = findCurrentZone(newState, cardId, ownerId)

            // Determine actual destination player based on moveType and zones.
            // A permanent leaving the battlefield always goes to its owner's hand/library/exile/
            // graveyard — never to a "destination player" chosen by the effect — so routing
            // collapses to ownerId for those cases regardless of the destination's nominal player.
            val actualDestPlayerId = when {
                (moveType == MoveType.Sacrifice || moveType == MoveType.Destroy) && destZone == Zone.GRAVEYARD -> ownerId
                destZone == Zone.HAND && fromZone == Zone.BATTLEFIELD -> ownerId
                destZone == Zone.EXILE && fromZone == Zone.BATTLEFIELD -> ownerId
                destZone == Zone.LIBRARY && fromZone == Zone.BATTLEFIELD -> ownerId
                underOwnersControl && destZone == Zone.BATTLEFIELD -> ownerId
                else -> destPlayerId
            }

            // Face-down battlefield entry (morph/manifest/disguise/cloak): derive each card's
            // turn-up data from its identity and the mode. Per-card because manifested and cloaked
            // cards turn up for their own (differing) mana costs. Exile face-down (Hideaway) is
            // just hidden — no turn-up data.
            val isBattlefieldFaceDown = faceDown != null && destZone == Zone.BATTLEFIELD
            val morphData = if (isBattlefieldFaceDown) {
                val cardDefinitionId = newState.getEntity(cardId)?.get<CardComponent>()?.cardDefinitionId
                if (cardDefinitionId != null) {
                    com.wingedsheep.engine.handlers.effects.FaceDownTurnUp.dataFor(
                        cardRegistry.getCard(cardDefinitionId), cardDefinitionId, faceDown
                    )
                } else null
            } else null

            val entryOptions = com.wingedsheep.engine.handlers.effects.ZoneEntryOptions(
                controllerId = actualDestPlayerId,
                libraryPlacement = libraryPlacement,
                tapped = destination.placement == ZonePlacement.Tapped || destination.placement == ZonePlacement.TappedAndAttacking,
                tappedAndAttacking = destination.placement == ZonePlacement.TappedAndAttacking,
                faceDown = isBattlefieldFaceDown,
                morphData = morphData,
                faceDownMode = if (isBattlefieldFaceDown) faceDown else null,
                faceDownExile = faceDown != null && destZone == Zone.EXILE,
                // Who may keep seeing this card once it is in the library. The policy lives in
                // LibraryRevealUtils.placementAudience — this only names the mover and whether the
                // move was public.
                libraryMoverId = context.controllerId,
                libraryMovePublic = revealed,
                preparedEntry = preparedEntries?.get(cardId),
                entryBoundary = entryBoundary,
            )

            // Delegate to ZoneTransitionService for full cleanup + entry
            val fromZoneKey = if (fromZone != null) ZoneKey(ownerId, fromZone) else null
            val transitionResult = com.wingedsheep.engine.handlers.effects.ZoneTransitionService.moveToZone(
                newState, cardId, destZone, entryOptions, fromZoneKey
            )
            newState = transitionResult.state
            events.addAll(transitionResult.events)

            // Apply "enters with counters" replacement effects when a permanent enters the
            // battlefield from a non-stack zone (e.g., Celestial Reunion tutoring directly to
            // play, Hideaway's free-cast pile). Face-down entries skip this — morphed creatures
            // enter as 2/2 nameless with no replacement effects from their face-up identity.
            //
            // KNOWN GAP: the single-card sibling of this path (MoveToZoneEffectExecutor) also runs
            // PermanentEntryReplacements.runOnEnterRunEffect here; this one does not, so a card
            // with an "as ~ enters, run [effect]" replacement (Multiversal Passage, Game Trail)
            // tutored onto the battlefield still enters with its clause never run. Closing it
            // needs more than the two-line call: this is a loop, the replacement can pause for a
            // decision, and pausing mid-loop requires a continuation that resumes the remaining
            // cards. See docs/card-sdk-language-reference.md, OnEnterRunEffect "Scope today".
            if (destZone == Zone.BATTLEFIELD && faceDown == null) {
                val (counterState, counterEvents) = EntersWithReplacements.applyOnEntry(
                    newState, cardId, actualDestPlayerId, cardRegistry
                )
                newState = counterState
                events.addAll(counterEvents)
            }

            movedIds.add(cardId)
            if (destZone == Zone.LIBRARY) {
                librariesReceivingCards.add(actualDestPlayerId)
            }
        }

        // Handle shuffled placement — shuffle every affected library once after all cards are placed.
        // Per-card owner routing means a single MoveCollection can deposit cards in multiple libraries
        // (e.g., target opponent shuffles permanents they control but don't own).
        if (destination.placement == ZonePlacement.Shuffled && destZone == Zone.LIBRARY) {
            val toShuffle = if (librariesReceivingCards.isNotEmpty()) librariesReceivingCards else linkedSetOf(destPlayerId)
            for (libraryOwnerId in toShuffle) {
                val destZoneKey = ZoneKey(libraryOwnerId, Zone.LIBRARY)
                // Strip reveals before shuffling — once shuffled, no one knows positions any more
                newState = LibraryRevealUtils.clearLibraryReveals(newState, libraryOwnerId)
                val (shuffledLibrary, shuffledState) = newState.nextRandom { shuffle(newState.getZone(destZoneKey)) }
                newState = shuffledState.reorderZone(destZoneKey, shuffledLibrary)
                events.add(LibraryShuffledEvent(libraryOwnerId))
            }
        }

        // Emit discard event if configured
        if (moveType == MoveType.Discard && cards.isNotEmpty()) {
            val discardNames = cards.map { state.getEntity(it)?.get<CardComponent>()?.name ?: "Card" }
            events.add(CardsDiscardedEvent(destPlayerId, cards, discardNames))
            newState = com.wingedsheep.engine.handlers.effects.ZoneTransitionService
                .trackDiscard(newState, destPlayerId, cards)
        }

        // Emit sacrifice event if configured. Track the per-turn sacrifice count + Food
        // sacrifice off the *pre-move* state, where the sacrificed permanents (and their
        // projected subtypes) still exist on the battlefield.
        if (moveType == MoveType.Sacrifice && cards.isNotEmpty()) {
            val sacrificeNames = cards.map { cardId ->
                state.getEntity(cardId)?.get<CardComponent>()?.name ?: "Unknown"
            }
            val tracked = com.wingedsheep.engine.handlers.effects.ZoneTransitionService
                .trackPermanentSacrifice(state, cards, context.controllerId)
            newState = newState.copy(
                permanentsSacrificedThisTurn = tracked.permanentsSacrificedThisTurn,
            )
            // trackPermanentSacrifice also tags the controller with SacrificedFoodThisTurnComponent
            // when a sacrificed permanent was a Food. That tag lives on the controller entity (which
            // the move above leaves untouched), so carry it over too — otherwise "whenever you
            // sacrifice a Food" triggers never fire for Foods sacrificed through this path.
            if (tracked.getEntity(context.controllerId)?.has<SacrificedFoodThisTurnComponent>() == true) {
                newState = newState.updateEntity(context.controllerId) { it.with(SacrificedFoodThisTurnComponent) }
            }
            events.add(0, PermanentsSacrificedEvent(context.controllerId, cards, sacrificeNames))
        }

        // Emit reveal event if configured
        if (revealed && cards.isNotEmpty()) {
            val cardNames = cards.map { cardId ->
                newState.getEntity(cardId)?.get<CardComponent>()?.name ?: "Unknown"
            }
            val imageUris = cards.map { cardId ->
                newState.getEntity(cardId)?.get<CardComponent>()?.imageUri
            }
            val sourceName = context.sourceId?.let { sourceId ->
                newState.getEntity(sourceId)?.get<CardComponent>()?.name
            }
            // Look up each card's pre-move zone from the *original* state so the client can
            // distinguish a zone-transition reveal (Cultivate puts a basic land onto the
            // battlefield) from a hidden-zone reveal (Behold reveals a card in hand). Without
            // these zones the client treats the reveal as in-place and flashes a "Beheld"
            // pulse on whatever permanent the card became — wrong for tutor-and-play effects.
            val sourceZones = cards.mapNotNull { cardId ->
                val ownerId = state.getEntity(cardId)?.get<OwnerComponent>()?.playerId
                if (ownerId != null) findCurrentZone(state, cardId, ownerId) else null
            }
            val sharedFromZone = sourceZones.distinct().singleOrNull()
            events.add(
                CardsRevealedEvent(
                    revealingPlayerId = context.controllerId,
                    cardIds = cards,
                    cardNames = cardNames,
                    imageUris = imageUris,
                    source = sourceName,
                    revealToSelf = revealToSelf,
                    fromZone = sharedFromZone,
                    toZone = destZone,
                )
            )
        }

        val updatedCollections = if (storeMovedAs != null) {
            mapOf(storeMovedAs to movedIds.toList())
        } else {
            emptyMap()
        }

        // Capture LKI snapshots of permanents sacrificed by this *effect* (Rule 608.2h) so a
        // following pipeline/composite sibling can read the sacrificed permanent's P/T as it last
        // existed — e.g. The Gitrog, Ravenous Ride: "draw X cards … where X is the sacrificed
        // creature's power." Snapshots are taken from the pre-move projected state since the
        // permanents have already left the battlefield by now. Mirrors the cost-sacrifice path.
        val sacrificedSnapshots = if (moveType == MoveType.Sacrifice && cards.isNotEmpty()) {
            captureEntitySnapshots(cards, state.projectedState)
        } else {
            emptyList()
        }

        return EffectResult.success(newState, events).copy(
            updatedCollections = updatedCollections,
            updatedSacrificedPermanents = sacrificedSnapshots,
        )
    }

    /**
     * Find which zone a card currently lives in.
     */
    private fun findCurrentZone(state: GameState, cardId: EntityId, ownerId: EntityId): Zone? {
        for (zone in Zone.entries) {
            val zoneKey = ZoneKey(ownerId, zone)
            if (cardId in state.getZone(zoneKey)) {
                return zone
            }
        }
        return null
    }

    private fun resolvePlayer(player: Player, context: EffectContext, state: GameState): EntityId? =
        TargetResolutionUtils.resolvePlayerRef(player, context, state) ?: context.controllerId
}
