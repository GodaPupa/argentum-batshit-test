package com.wingedsheep.engine.handlers

import com.wingedsheep.engine.handlers.ConditionEvaluationContext.Projection
import com.wingedsheep.engine.handlers.ConditionEvaluationContext.Resolution
import com.wingedsheep.engine.handlers.effects.linkedexile.LinkedExileLookup
import com.wingedsheep.engine.state.CastSpellRecord
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.ZoneKey
import com.wingedsheep.sdk.scripting.references.Player
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.engine.state.components.battlefield.AbilityActivatedThisTurnComponent
import com.wingedsheep.engine.state.components.battlefield.AttachedToComponent
import com.wingedsheep.engine.state.components.battlefield.CastFromHandComponent
import com.wingedsheep.engine.state.components.battlefield.CountersComponent
import com.wingedsheep.engine.state.components.battlefield.EnteredThisTurnComponent
import com.wingedsheep.engine.state.components.battlefield.LastKnownPermanentComponent
import com.wingedsheep.engine.state.components.battlefield.EnteredViaAbilityComponent
import com.wingedsheep.engine.state.components.battlefield.chosenOpponent
import com.wingedsheep.engine.state.components.battlefield.HasDealtCombatDamageToPlayerComponent
import com.wingedsheep.engine.state.components.battlefield.CastRecordComponent
import com.wingedsheep.engine.state.components.battlefield.TappedComponent
import com.wingedsheep.engine.state.components.battlefield.ChoiceValue
import com.wingedsheep.engine.state.components.battlefield.CastChoicesComponent
import com.wingedsheep.engine.state.components.battlefield.chosenColor
import com.wingedsheep.engine.state.components.battlefield.chosenCreatureType
import com.wingedsheep.engine.state.components.battlefield.chosenLandType
import com.wingedsheep.engine.state.components.battlefield.chosenModeId
import com.wingedsheep.engine.state.components.battlefield.wasKickedChoice
import com.wingedsheep.engine.state.components.combat.AttackingComponent
import com.wingedsheep.engine.state.components.combat.BlockedComponent
import com.wingedsheep.engine.state.components.combat.BlockingComponent
import com.wingedsheep.engine.state.components.combat.PlayerAttackedThisTurnComponent
import com.wingedsheep.engine.state.components.combat.PlayerAttackersThisTurnComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.engine.state.components.identity.FaceDownComponent
import com.wingedsheep.engine.state.components.identity.LifeTotalComponent
import com.wingedsheep.engine.state.components.identity.RingBearerComponent
import com.wingedsheep.engine.state.components.player.InAdditionalCombatPhaseComponent
import com.wingedsheep.engine.state.components.player.InAdditionalEndStepComponent
import com.wingedsheep.engine.state.components.player.LandDropsComponent
import com.wingedsheep.engine.state.components.player.PlayerTurnsTakenComponent
import com.wingedsheep.engine.state.components.player.CombatDamageReceivedThisTurnComponent
import com.wingedsheep.engine.state.components.player.WasDealtCombatDamageThisTurnComponent
import com.wingedsheep.sdk.core.CounterType
import com.wingedsheep.sdk.core.Keyword
import com.wingedsheep.sdk.core.Subtype
import com.wingedsheep.sdk.core.Phase
import com.wingedsheep.sdk.core.Step
import com.wingedsheep.sdk.core.Zone
import com.wingedsheep.sdk.scripting.*
import com.wingedsheep.sdk.scripting.events.CounterTypeFilter
import com.wingedsheep.sdk.scripting.conditions.APlayerControlsMostOfSubtype
import com.wingedsheep.sdk.scripting.conditions.YouControlMostOfChosenType
import com.wingedsheep.sdk.scripting.conditions.AllConditions
import com.wingedsheep.sdk.scripting.conditions.AnyCondition
import com.wingedsheep.sdk.scripting.conditions.ExiledAsCostHadSubtype
import com.wingedsheep.sdk.scripting.conditions.ThisAbilityActivatedThisTurnAtLeast
import com.wingedsheep.sdk.scripting.conditions.APlayerLifeAtMost
import com.wingedsheep.sdk.scripting.conditions.EachPlayerLifeAtMost
import com.wingedsheep.sdk.scripting.conditions.AnyPlayerDealtCombatDamageThisTurnAtLeast
import com.wingedsheep.sdk.scripting.conditions.Compare
import com.wingedsheep.sdk.scripting.conditions.NumberMatches
import com.wingedsheep.sdk.scripting.conditions.NumberProperty
import com.wingedsheep.sdk.scripting.conditions.ComparisonOperator
import com.wingedsheep.sdk.scripting.conditions.Condition
import com.wingedsheep.sdk.scripting.conditions.EnchantedCreatureHasSubtype
import com.wingedsheep.sdk.scripting.conditions.SourceIsBlockingOrBlockedBySubtype
import com.wingedsheep.sdk.scripting.conditions.EnchantedCreatureIsLegendary
import com.wingedsheep.sdk.scripting.conditions.EntityMatches
import com.wingedsheep.sdk.scripting.targets.EffectTarget
import com.wingedsheep.sdk.scripting.GameObjectFilter
import com.wingedsheep.sdk.scripting.conditions.Exists
import com.wingedsheep.sdk.scripting.conditions.IsInPhase
import com.wingedsheep.sdk.scripting.conditions.IsInStep
import com.wingedsheep.sdk.scripting.conditions.IsFirstCombatPhaseOfTurn
import com.wingedsheep.sdk.scripting.conditions.IsFirstEndStepOfTurn
import com.wingedsheep.sdk.scripting.conditions.IsNotYourTurn
import com.wingedsheep.sdk.scripting.conditions.IsPlayersTurn
import com.wingedsheep.sdk.scripting.conditions.IsYourTurn
import com.wingedsheep.sdk.scripting.conditions.NotCondition
import com.wingedsheep.sdk.scripting.conditions.OpponentSpellOnStack
import com.wingedsheep.sdk.scripting.conditions.ControllerTurnsTakenAtMost
import com.wingedsheep.sdk.scripting.conditions.SourceCastForImpending
import com.wingedsheep.sdk.scripting.conditions.SourceReturnedAsEnchantment
import com.wingedsheep.sdk.scripting.conditions.SourceIsModified
import com.wingedsheep.sdk.scripting.conditions.SourceChosenModeIs
import com.wingedsheep.sdk.scripting.conditions.CastChoiceMade
import com.wingedsheep.sdk.scripting.conditions.CastChoiceIs
import com.wingedsheep.sdk.scripting.conditions.CastTimeFlagSet
import com.wingedsheep.engine.state.components.battlefield.CastForImpendingComponent
import com.wingedsheep.sdk.scripting.ChoiceSlot
import com.wingedsheep.sdk.scripting.conditions.WasCast
import com.wingedsheep.sdk.scripting.conditions.WasCastFromHand
import com.wingedsheep.sdk.scripting.conditions.SourceInZone
import com.wingedsheep.sdk.scripting.conditions.WasCastFromZone
import com.wingedsheep.engine.state.components.battlefield.CastFromGraveyardComponent
import com.wingedsheep.engine.state.components.battlefield.CastFromLibraryComponent
import com.wingedsheep.sdk.scripting.conditions.SacrificedPermanentHadSubtype
import com.wingedsheep.sdk.scripting.conditions.SacrificedPermanentWasLegendary
import com.wingedsheep.sdk.scripting.conditions.SacrificedPermanentWasSuspected
import com.wingedsheep.sdk.scripting.conditions.YouSacrificedPermanentThisWay
import com.wingedsheep.sdk.scripting.conditions.AnotherPermanentWithSameNameAsTarget
import com.wingedsheep.sdk.scripting.conditions.TargetMarkedDamageExceedsToughness
import com.wingedsheep.sdk.scripting.conditions.TargetIsPlayer
import com.wingedsheep.sdk.scripting.conditions.TargetIsCreatureCard
import com.wingedsheep.sdk.scripting.conditions.TargetIsSpellOnStack
import com.wingedsheep.sdk.scripting.conditions.TargetIsTapped
import com.wingedsheep.sdk.scripting.conditions.TargetIsSource
import com.wingedsheep.sdk.scripting.conditions.TargetSharesMostCommonColor
import com.wingedsheep.sdk.scripting.conditions.ColorIsMostCommon
import com.wingedsheep.engine.mechanics.layers.ProjectedState
import com.wingedsheep.sdk.scripting.conditions.TriggeringEntityEnteredOrWasCastFromGraveyard
import com.wingedsheep.sdk.scripting.conditions.TriggeringEntityHadCounters
import com.wingedsheep.sdk.scripting.conditions.TriggeringEntityHadMinusOneMinusOneCounter
import com.wingedsheep.sdk.scripting.conditions.TriggeringEntityWasHistoric
import com.wingedsheep.sdk.scripting.conditions.TriggeringEntityWasCast
import com.wingedsheep.sdk.scripting.conditions.TriggeringEntityWasNotPutByThisSource
import com.wingedsheep.sdk.scripting.conditions.TriggeringSpellHasSingleTarget
import com.wingedsheep.sdk.scripting.conditions.CollectionContainsMatch
import com.wingedsheep.sdk.scripting.conditions.CollectionSharesCardType
import com.wingedsheep.sdk.scripting.conditions.IsFirstSpellPaidWithTreasureManaCastThisTurn
import com.wingedsheep.sdk.scripting.conditions.SourceAbilityResolvedNTimesThisTurn
import com.wingedsheep.sdk.scripting.conditions.ManaSpentToCastIncludes
import com.wingedsheep.sdk.scripting.conditions.NoManaSpentToCast
import com.wingedsheep.sdk.scripting.conditions.AnyEnteredOrWasCastFromExile
import com.wingedsheep.sdk.scripting.conditions.NoManaSpentToCastEntered
import com.wingedsheep.sdk.scripting.conditions.WasKicked
import com.wingedsheep.sdk.scripting.conditions.BlightWasPaid
import com.wingedsheep.sdk.scripting.conditions.SneakCostWasPaid
import com.wingedsheep.sdk.scripting.conditions.WebSlungCostWasPaid
import com.wingedsheep.sdk.scripting.conditions.MayhemCostWasPaid
import com.wingedsheep.sdk.scripting.conditions.WaterbendWasPaid
import com.wingedsheep.sdk.scripting.conditions.SourceIsRingBearer
import com.wingedsheep.sdk.scripting.conditions.YouChoseOtherCreatureAsRingBearer
import com.wingedsheep.sdk.scripting.conditions.YouControlSource
import com.wingedsheep.sdk.scripting.conditions.PlayerAttackedWithCreaturesThisTurn
import com.wingedsheep.sdk.scripting.conditions.PermanentLeftBattlefieldThisTurn
import com.wingedsheep.sdk.scripting.conditions.PermanentTypeEnteredBattlefieldThisTurn
import com.wingedsheep.sdk.scripting.conditions.PlayerCastSpellsThisTurn
import com.wingedsheep.sdk.scripting.conditions.PlayerCommittedCrimeThisTurn
import com.wingedsheep.sdk.scripting.conditions.PlayerHasCitysBlessing
import com.wingedsheep.sdk.scripting.conditions.PlayerHasEnduringStory
import com.wingedsheep.sdk.scripting.conditions.PlayerControlsMostPermanents
import com.wingedsheep.sdk.scripting.conditions.PlayerHasMostLife
import com.wingedsheep.sdk.scripting.conditions.TriggeringPlayerIs
import com.wingedsheep.sdk.scripting.conditions.RingHasTemptedPlayerAtLeast
import com.wingedsheep.sdk.scripting.conditions.CreatureDiedThisTurnCondition
import com.wingedsheep.sdk.scripting.conditions.ControlledCreatureDiedThisTurnCondition
import com.wingedsheep.sdk.scripting.conditions.CreatureWithSubtypeDiedThisTurn
import com.wingedsheep.engine.state.components.player.CreatureSubtypesDiedThisTurnComponent
import com.wingedsheep.sdk.scripting.conditions.SourcePlottedOnPriorTurn
import com.wingedsheep.sdk.scripting.conditions.SourceForetoldOnPriorTurn
import com.wingedsheep.sdk.scripting.conditions.YouDiscardedThisCardThisTurn
import com.wingedsheep.engine.handlers.triggers.CreatureDiedThisTurnConditionEvaluator
import com.wingedsheep.engine.state.components.identity.PlottedComponent
import com.wingedsheep.engine.state.components.identity.ForetoldComponent
import com.wingedsheep.sdk.scripting.conditions.YouWereAttackedThisStep
import com.wingedsheep.sdk.scripting.conditions.VoidCondition
import com.wingedsheep.engine.mechanics.citysblessing.CitysBlessingService
import com.wingedsheep.engine.mechanics.enduringstory.EnduringStoryService
import com.wingedsheep.engine.state.components.player.TheRingComponent

/**
 * How far along a count-shaped condition is: [current] things counted against the [required] many
 * it wants, related by [operator] ("three or more sources dealt damage" is `GTE 3`, "no cards in
 * hand" is `LTE 0`).
 *
 * Produced by [ConditionEvaluator.countProgress] for the client's progress badges. [met] is the
 * same comparison the condition itself performs, so "0/3" is grey and "3/3" is green for the same
 * reason the trigger does or doesn't go on the stack.
 */
data class CountProgress(
    val current: Int,
    val required: Int,
    val operator: ComparisonOperator
) {
    val met: Boolean get() = compareAmounts(current, operator, required)
}

/** The one place [ComparisonOperator] is turned into an actual comparison. */
internal fun compareAmounts(left: Int, operator: ComparisonOperator, right: Int): Boolean =
    when (operator) {
        ComparisonOperator.LT -> left < right
        ComparisonOperator.LTE -> left <= right
        ComparisonOperator.EQ -> left == right
        ComparisonOperator.NEQ -> left != right
        ComparisonOperator.GT -> left > right
        ComparisonOperator.GTE -> left >= right
    }

/**
 * Evaluates conditions from the SDK against the game state.
 *
 * [defaultProjection] is forwarded to this evaluator's [DynamicAmountEvaluator] for battlefield
 * reads when a caller doesn't thread a projection. Resolution-time callers leave the default
 * (the canonical lazy [GameState.projectedState]). A mid-projection caller — the
 * [com.wingedsheep.engine.mechanics.layers.EffectApplicator] evaluating a source condition while
 * the projection is still being computed — must swap in a non-reentrant projection, otherwise an
 * aggregate `Compare` (e.g. "while you control N+ creatures") re-enters the lazy `projectedState`
 * initializer and recurses until the stack overflows.
 */
class ConditionEvaluator(
    defaultProjection: (GameState) -> ProjectedState = { it.projectedState }
) {

    private val dynamicAmountEvaluator = DynamicAmountEvaluator(this, defaultProjection)

    /**
     * Evaluate a condition at resolution time, when a full [EffectContext] is available.
     * Thin wrapper over the dual-mode [evaluate] below.
     */
    fun evaluate(
        state: GameState,
        condition: Condition,
        context: EffectContext
    ): Boolean = evaluate(state, condition, Resolution(context))

    /**
     * The count-shaped reading of [condition] — how many things it counts right now against how
     * many it needs — or `null` when the condition isn't count-shaped ("it's your turn", "this
     * permanent is attacking", a composite; a caller that wants the parts of a composite splits it
     * itself).
     *
     * This is display vocabulary: it feeds the client's "2/4" progress badge, so a player can see
     * how close an intervening-if — a Case's "to solve" line above all — is to being satisfied. It
     * deliberately reuses the same counting code the boolean [evaluate] runs on, so a badge can
     * never claim progress the trigger itself disagrees with.
     */
    fun countProgress(
        state: GameState,
        condition: Condition,
        context: EffectContext
    ): CountProgress? {
        val ctx = Resolution(context)
        return when (condition) {
            is Compare -> CountProgress(
                current = dynamicAmountEvaluator.evaluate(state, condition.left, context),
                required = dynamicAmountEvaluator.evaluate(state, condition.right, context),
                operator = condition.operator
            )

            is PlayerCastSpellsThisTurn -> CountProgress(
                current = countCastSpellsThisTurnCtx(state, condition, ctx, cap = Int.MAX_VALUE),
                required = condition.atLeast,
                operator = ComparisonOperator.GTE
            )

            is PlayerAttackedWithCreaturesThisTurn -> CountProgress(
                current = countAttackedWithCreaturesCtx(state, condition, ctx, cap = Int.MAX_VALUE),
                required = condition.atLeast,
                operator = ComparisonOperator.GTE
            )

            // "There are no suspected Skeletons you control" reads as a count against zero rather
            // than a bare unmet flag, which is what makes Case of the Stashed Skeleton's progress
            // legible: 1/0 while one is still suspected, 0/0 once it isn't.
            is Exists -> CountProgress(
                current = countExistsCtx(state, condition, ctx, cap = Int.MAX_VALUE),
                required = if (condition.negate) 0 else 1,
                operator = if (condition.negate) ComparisonOperator.LTE else ComparisonOperator.GTE
            )

            else -> null
        }
    }

    /**
     * Evaluate a condition in either resolution or projection mode.
     *
     * Conditions that need resolution-time facts (targets, triggering entity, cast-from
     * zone, kicker state, etc.) return `false` in projection mode — a static-ability gate
     * never sees those facts.
     */
    internal fun evaluate(
        state: GameState,
        condition: Condition,
        ctx: ConditionEvaluationContext
    ): Boolean {
        // Helper: dispatch a resolution-only branch, returning false when running under projection.
        fun ifResolution(fn: (EffectContext) -> Boolean): Boolean =
            (ctx as? Resolution)?.let { fn(it.effectContext) } ?: false

        return when (condition) {
            // ============================================================
            // Dual-mode primitives (work in both resolution and projection)
            // ============================================================
            is Compare -> evaluateCompareCtx(state, condition, ctx)
            is NumberMatches -> evaluateNumberMatchesCtx(state, condition, ctx)
            is Exists -> evaluateExistsCtx(state, condition, ctx)

            // Pure zone-membership lookup, so it reads the same in both modes.
            is SourceInZone -> evaluateSourceInZone(state, condition, ctx)

            // CR 805 — "your turn" is the active team's turn for every member of that team.
            is IsYourTurn -> ctx.controllerId?.let { state.isActiveTurnFor(it) } ?: false
            is IsNotYourTurn -> ctx.controllerId?.let { !state.isActiveTurnFor(it) } ?: false
            // The Player-parametric turn check (Scytheclaw Raptor via TriggeringPlayer). Resolves the
            // referenced player, then asks whether it's their active turn (CR 805 team-aware).
            is IsPlayersTurn ->
                resolvePlayer(state, condition.player, ctx)?.let { state.isActiveTurnFor(it) } ?: false

            // Existential over all players: does some single player's combat-damage-received running
            // total reach the threshold? Board-derived (reads a per-player accumulator), so it works
            // identically at resolution and under projection. Not the summing TurnTracking path.
            is AnyPlayerDealtCombatDamageThisTurnAtLeast -> state.turnOrder.any { playerId ->
                (state.getEntity(playerId)?.get<CombatDamageReceivedThisTurnComponent>()?.amount ?: 0) >= condition.amount
            }

            // Board-derived (current step + active player), so it works identically at resolution
            // and under projection — used as a ConditionalStaticAbility gate (Zurgo's end step).
            is IsInStep -> {
                val cid = ctx.controllerId
                val notYourTurn = cid == null || !state.isActiveTurnFor(cid)
                if (condition.yoursOnly && notYourTurn) false
                else state.step in condition.steps
            }

            // True while we're in the turn's *natural* end step — i.e. an end step the active player
            // hasn't yet marked as an inserted extra (AddAdditionalEndStepsEffect). Board-derived, so
            // it reads the same at resolution and under projection. The loop guard for Y'shtola Rhul.
            is IsFirstEndStepOfTurn -> {
                state.step == Step.END &&
                    state.activePlayerId?.let {
                        state.getEntity(it)?.has<InAdditionalEndStepComponent>()
                    } != true
            }

            // True while we're in the turn's *natural* combat phase — i.e. a combat phase the active
            // player hasn't yet marked as an inserted extra (AddCombatPhaseEffect). Board-derived, so
            // it reads the same at resolution and under projection. The loop guard for the
            // "additional combat phase" riders (Balthier and Fran, Genji Glove, Raph & Leo).
            is IsFirstCombatPhaseOfTurn -> {
                state.phase == Phase.COMBAT &&
                    state.activePlayerId?.let {
                        state.getEntity(it)?.has<InAdditionalCombatPhaseComponent>()
                    } != true
            }

            // Reads the controller's PlayerTurnsTakenComponent (incremented in
            // TurnManager.startTurn). Returns false when there's no controller
            // (e.g. some projection-time evaluations) — the unless-branch then
            // falls through, which matches "enters tapped" for the default case.
            is ControllerTurnsTakenAtMost -> {
                val controllerId = ctx.controllerId
                val taken = controllerId?.let {
                    state.getEntity(it)?.get<PlayerTurnsTakenComponent>()?.count
                }
                taken != null && taken <= condition.threshold
            }

            is SourcePlottedOnPriorTurn -> {
                val sourceId = ctx.sourceId
                val plotted = sourceId?.let { state.getEntity(it)?.get<PlottedComponent>() }
                plotted != null && plotted.turnPlotted < state.turnNumber
            }

            is SourceForetoldOnPriorTurn -> {
                val sourceId = ctx.sourceId
                val foretold = sourceId?.let { state.getEntity(it)?.get<ForetoldComponent>() }
                foretold != null && foretold.turnForetold < state.turnNumber
            }

            is YouDiscardedThisCardThisTurn -> {
                // The Mayhem gate (CR 702.187b). A discarded card lives only in its owner's
                // graveyard and entity ids are unique, so "recorded in any player's discard list"
                // is equivalent to "this card's owner discarded it this turn".
                val sourceId = ctx.sourceId
                sourceId != null && state.turnOrder.any { pid ->
                    state.getEntity(pid)
                        ?.get<com.wingedsheep.engine.state.components.player.CardsDiscardedThisTurnComponent>()
                        ?.cardIds?.contains(sourceId) == true
                }
            }

            is SourceCastForImpending -> {
                val sourceId = ctx.sourceId
                sourceId != null && state.getEntity(sourceId)?.has<CastForImpendingComponent>() == true
            }

            is SourceReturnedAsEnchantment -> {
                val sourceId = ctx.sourceId
                sourceId != null &&
                    state.getEntity(sourceId)
                        ?.has<com.wingedsheep.engine.state.components.battlefield.EnduringReturnComponent>() == true
            }

            // The unified "an entity matches a filter" primitive. Dispatches on the entity role:
            // Self / enchanted-or-equipped are dual-mode (resolution + projection); a chosen target
            // or the triggering spell are resolution-only.
            is EntityMatches -> evaluateEntityMatches(state, condition, ctx)

            // CR 701.54e: the source is your Ring-bearer — it carries your Ring-bearer designation
            // and you still control it. The control half reads the projected controller so a
            // control-changing effect correctly ends the designation.
            is SourceIsRingBearer -> {
                val sourceId = ctx.sourceId
                val controllerId = ctx.controllerId
                val bearer = sourceId?.let { state.getEntity(it)?.get<RingBearerComponent>() }
                bearer != null && controllerId != null &&
                    bearer.ownerId == controllerId &&
                    state.projectedState.getController(sourceId) == controllerId
            }

            // CR 701.54a: intervening-if for "Whenever the Ring tempts you" payoffs that only
            // fire when the player chose someone other than the source. True iff the controller
            // currently has a Ring-bearer AND that bearer isn't the source. Reads the same
            // controller/projected-controller pair as SourceIsRingBearer so a designation that's
            // been suspended by a control change correctly fails to count as "a bearer".
            is YouChoseOtherCreatureAsRingBearer -> {
                val sourceId = ctx.sourceId
                val controllerId = ctx.controllerId
                if (sourceId == null || controllerId == null) {
                    false
                } else {
                    val bearerId = state.getBattlefield().firstOrNull { id ->
                        val bearer = state.getEntity(id)?.get<RingBearerComponent>() ?: return@firstOrNull false
                        bearer.ownerId == controllerId &&
                            state.projectedState.getController(id) == controllerId
                    }
                    bearerId != null && bearerId != sourceId
                }
            }

            // Aura-controller-aware modified check (CR 700.4) — distinct enough from the
            // generic StatePredicate.IsModified to warrant its own branch.
            is SourceIsModified -> evaluateSourceIsModifiedCtx(state, ctx)

            is SourceIsBlockingOrBlockedBySubtype -> evaluateSourceIsBlockingOrBlockedBySubtypeCtx(state, condition, ctx)

            is EnchantedCreatureHasSubtype -> evaluateEnchantedCreatureHasSubtypeCtx(state, condition, ctx)
            is EnchantedCreatureIsLegendary -> evaluateEnchantedCreatureIsLegendaryCtx(state, ctx)

            // Player-relative trackers (resolve [Player] against the current context).
            is PlayerAttackedWithCreaturesThisTurn -> evaluateAttackedWithCreaturesCtx(state, condition, ctx)
            is com.wingedsheep.sdk.scripting.conditions.PlayerAttackedPlayerThisTurn ->
                evaluateAttackedPlayerThisTurnCtx(state, condition, ctx)
            is PlayerCastSpellsThisTurn -> evaluateCastSpellsThisTurnCtx(state, condition, ctx)
            is com.wingedsheep.sdk.scripting.conditions.PlayerDrewCardsThisTurn -> {
                if (condition.atLeast <= 0) true
                else {
                    val playerId = resolvePlayer(state, condition.player, ctx)
                    val drawn = playerId?.let {
                        state.getEntity(it)
                            ?.get<com.wingedsheep.engine.state.components.player.CardsDrawnThisTurnComponent>()
                            ?.count
                    } ?: 0
                    drawn >= condition.atLeast
                }
            }
            is com.wingedsheep.sdk.scripting.conditions.PlayerActivatedExhaustAbilitiesThisTurn -> {
                if (condition.atLeast <= 0) true
                else {
                    val playerId = resolvePlayer(state, condition.player, ctx)
                    val activated = playerId?.let {
                        state.getEntity(it)
                            ?.get<com.wingedsheep.engine.state.components.player.ExhaustAbilitiesActivatedThisTurnComponent>()
                            ?.count
                    } ?: 0
                    activated >= condition.atLeast
                }
            }
            is PlayerCommittedCrimeThisTurn -> {
                val playerId = resolvePlayer(state, condition.player, ctx)
                playerId != null && playerId in state.playersWhoCommittedCrimeThisTurn
            }
            is com.wingedsheep.sdk.scripting.conditions.PlayerPlayedLandThisTurn -> {
                val playerId = resolvePlayer(state, condition.player, ctx)
                val zones = playerId?.let {
                    state.getEntity(it)
                        ?.get<com.wingedsheep.engine.state.components.player.LandsPlayedThisTurnComponent>()
                        ?.fromZones
                } ?: emptyList()
                when {
                    condition.fromZone != null -> zones.any { it == condition.fromZone }
                    condition.fromZoneOtherThan != null -> zones.any { it != condition.fromZoneOtherThan }
                    else -> zones.isNotEmpty()
                }
            }
            // "you've put one or more <kind> counters on a creature this turn" — turn history off
            // the placing player, never a board scan: the counters, the creature, and even its
            // creature-ness may all be gone by now and the answer is still yes.
            is com.wingedsheep.sdk.scripting.conditions.PutCounterKindOnCreatureThisTurn -> {
                val playerId = resolvePlayer(state, condition.player, ctx)
                val record = playerId?.let {
                    state.getEntity(it)
                        ?.get<com.wingedsheep.engine.state.components.player.PutCounterOnCreatureThisTurnComponent>()
                }
                when {
                    record == null -> false
                    condition.counterType == null -> true
                    else -> condition.counterType in record.kinds
                }
            }
            is com.wingedsheep.sdk.scripting.conditions.PermanentEnteredFaceDownThisTurn -> {
                val playerId = resolvePlayer(state, condition.player, ctx)
                val count = playerId?.let {
                    state.getEntity(it)
                        ?.get<com.wingedsheep.engine.state.components.player.PermanentEnteredFaceDownThisTurnComponent>()
                        ?.count
                } ?: 0
                count > 0
            }
            is com.wingedsheep.sdk.scripting.conditions.PlayerTurnedPermanentFaceUpThisTurn -> {
                val playerId = resolvePlayer(state, condition.player, ctx)
                val count = playerId?.let {
                    state.getEntity(it)
                        ?.get<com.wingedsheep.engine.state.components.player.TurnedPermanentFaceUpThisTurnComponent>()
                        ?.count
                } ?: 0
                count > 0
            }
            is PlayerHasCitysBlessing -> evaluateHasCitysBlessingCtx(state, condition, ctx)
            is PlayerHasEnduringStory -> evaluateHasEnduringStoryCtx(state, condition, ctx)

            is TriggeringPlayerIs -> {
                val triggeringPlayer = resolvePlayer(state, Player.TriggeringPlayer, ctx)
                val expected = resolvePlayer(state, condition.player, ctx)
                triggeringPlayer != null && expected != null && triggeringPlayer == expected
            }

            is PlayerHasMostLife -> {
                val playerId = resolvePlayer(state, condition.player, ctx)
                if (playerId == null) false else {
                    val life = state.lifeTotal(playerId)
                    // Most life or tied for most: no player has strictly more.
                    state.turnOrder.all { state.lifeTotal(it) <= life }
                }
            }

            is PlayerControlsMostPermanents ->
                evaluatePlayerControlsMostPermanentsCtx(state, condition, ctx)

            is RingHasTemptedPlayerAtLeast -> {
                val playerId = resolvePlayer(state, condition.player, ctx)
                val tempted = playerId?.let {
                    state.getEntity(it)?.get<TheRingComponent>()?.temptCount
                } ?: 0
                tempted >= condition.times
            }
            is PermanentTypeEnteredBattlefieldThisTurn ->
                evaluatePermanentTypeEnteredBattlefieldThisTurnCtx(state, condition, ctx)
            is PermanentLeftBattlefieldThisTurn ->
                evaluatePermanentLeftBattlefieldThisTurnCtx(state, condition, ctx)

            // Global facts (no controller/source needed).
            is VoidCondition ->
                state.nonlandPermanentLeftBattlefieldThisTurn || state.spellWarpedThisTurn

            // Day/night designation (CR 731). Global game state read straight off GameState.dayNight;
            // works identically in resolution and projection. Neither designation (null) satisfies
            // neither condition — the game starts neither day nor night (CR 731.1).
            is com.wingedsheep.sdk.scripting.conditions.IsDay ->
                state.dayNight == com.wingedsheep.sdk.core.DayNight.DAY
            is com.wingedsheep.sdk.scripting.conditions.IsNight ->
                state.dayNight == com.wingedsheep.sdk.core.DayNight.NIGHT

            // Global, subtype-filtered death tracker — matched against each dying creature's
            // last-known subtypes recorded across every player. present=true: some dead creature
            // had the subtype; present=false: some dead creature lacked it ("a non-Zombie died").
            is CreatureWithSubtypeDiedThisTurn -> state.turnOrder.any { playerId ->
                val died = state.getEntity(playerId)
                    ?.get<CreatureSubtypesDiedThisTurnComponent>()
                    ?.diedSubtypeSets.orEmpty()
                died.any { subtypes -> (condition.subtype in subtypes) == condition.present }
            }

            // Existential over all players: some player has at most [threshold] life.
            // Reads each player's LifeTotalComponent from state.turnOrder.
            is APlayerLifeAtMost -> state.turnOrder.any { playerId ->
                // CR 810.9a — read the team's shared total; existential so teams don't double-count.
                state.lifeTotal(playerId) <= condition.threshold
            }

            is EachPlayerLifeAtMost -> state.turnOrder.all { playerId ->
                state.lifeTotal(playerId) <= condition.threshold
            }

            // Existential over the controller's opponents. The controller's own low life total must
            // not satisfy cards such as Bloodghast; team games use the shared team life total.
            is com.wingedsheep.sdk.scripting.conditions.AnOpponentLifeAtMost ->
                ctx.controllerId?.let { controllerId ->
                    state.getOpponents(controllerId).any { opponentId ->
                        state.lifeTotal(opponentId) <= condition.threshold
                    }
                } ?: false

            // Board-derived only — no targets/triggering/kicker — so it works identically in
            // resolution and projection (required for the djinn `ConditionalStaticAbility` gate).
            is ColorIsMostCommon ->
                condition.color.name in mostCommonColors(state, ctx.projectedStateFor(state))

            // Composites recurse with the same ctx.
            is AllConditions -> condition.conditions.all { evaluate(state, it, ctx) }
            is AnyCondition -> condition.conditions.any { evaluate(state, it, ctx) }
            is NotCondition -> !evaluate(state, condition.condition, ctx)

            // ============================================================
            // Resolution-only conditions — false under projection.
            // ============================================================
            is APlayerControlsMostOfSubtype -> ifResolution { evaluateAPlayerControlsMostOfSubtype(state, condition) }
            is YouControlMostOfChosenType -> ifResolution { evaluateYouControlMostOfChosenType(state, condition, it) }
            is YouControlSource -> ifResolution { evaluateYouControlSource(state, it) }
            is WasCast -> ifResolution { evaluateWasCast(state, it) }
            is WasCastFromHand -> ifResolution { evaluateWasCastFromHand(state, it) }
            is WasCastFromZone -> ifResolution { evaluateWasCastFromZone(state, condition, it) }
            is WasKicked -> ifResolution { evaluateWasKicked(state, it) }
            is SneakCostWasPaid -> ifResolution { evaluateSneakCostWasPaid(state, it) }
            is WebSlungCostWasPaid -> ifResolution { evaluateWebSlungCostWasPaid(state, it) }
            is MayhemCostWasPaid -> ifResolution { evaluateMayhemCostWasPaid(state, it) }
            is BlightWasPaid -> ifResolution { it.wasBlightPaid }
            is WaterbendWasPaid -> ifResolution { evaluateWaterbendWasPaid(state, it) }
            is ManaSpentToCastIncludes -> ifResolution { evaluateManaSpentToCastIncludes(state, condition, it) }
            is NoManaSpentToCast -> ifResolution { evaluateNoManaSpentToCast(state, it) }
            is NoManaSpentToCastEntered -> ifResolution { evaluateNoManaSpentToCastEntered(state, it) }
            is AnyEnteredOrWasCastFromExile -> ifResolution { evaluateAnyEnteredOrWasCastFromExile(state, it) }
            is SourceChosenModeIs -> {
                // Dual-mode: the chosen mode is stored in the durable cast-choices bag on the
                // source permanent, readable both at resolution (gating triggered abilities) and
                // during projection (gating mode-dependent continuous static abilities, e.g.
                // Frostcliff/Windcrag Sieges' lord and static modes).
                val sourceId = ctx.sourceId
                sourceId != null &&
                    state.getEntity(sourceId)?.chosenModeId() == condition.modeId
            }
            is CastChoiceMade -> {
                // Generic "was this choice made" guard over the durable cast-choices bag; works at
                // both resolution and projection. An optional-additional-cost declaration
                // (kicker/bargain) also answers from the context, so a still-on-the-stack spell's
                // own rider ("If this spell was bargained, …") and a cost gate priced before the
                // spell exists both read true — the bag only exists once it resolves.
                val sourceId = ctx.sourceId
                val declaredThisCast = (ctx as? Resolution)?.effectContext?.declaredCostSlot
                if (declaredThisCast == condition.slot) {
                    true
                } else {
                    sourceId != null &&
                        state.getEntity(sourceId)?.get<CastChoicesComponent>()
                            ?.chosen?.containsKey(condition.slot) == true
                }
            }
            is CastChoiceIs -> {
                val sourceId = ctx.sourceId
                sourceId != null &&
                    castChoiceMatches(state.getEntity(sourceId), condition.slot, condition.value)
            }
            is CastTimeFlagSet -> {
                // The "as you cast this spell" capture, frozen onto the spell on the stack at cast
                // (CR 601.2i). Read here at resolution so the answer reflects the cast-time board
                // even after a later change (Steer Clear). The spell entity keeps its id across the
                // hand→stack boundary, so the resolving effect's sourceId locates it.
                val sourceId = ctx.sourceId
                sourceId != null &&
                    state.getEntity(sourceId)
                        ?.get<com.wingedsheep.engine.state.components.stack.SpellOnStackComponent>()
                        ?.castTimeFlags?.contains(condition.flag) == true
            }
            is SacrificedPermanentHadSubtype -> ifResolution { evaluateSacrificedPermanentHadSubtype(condition, it) }
            is ExiledAsCostHadSubtype -> ifResolution { evaluateExiledAsCostHadSubtype(state, condition, it) }
            is ThisAbilityActivatedThisTurnAtLeast ->
                ifResolution { evaluateThisAbilityActivatedThisTurnAtLeast(state, condition, it) }
            is SacrificedPermanentWasLegendary -> ifResolution { evaluateSacrificedPermanentWasLegendary(it) }
            is SacrificedPermanentWasSuspected -> ifResolution { evaluateSacrificedPermanentWasSuspected(it) }
            is YouSacrificedPermanentThisWay -> ifResolution { evaluateYouSacrificedPermanentThisWay(it) }
            is TriggeringEntityWasHistoric -> ifResolution { evaluateTriggeringEntityWasHistoric(state, it) }
            is TriggeringEntityWasCast -> ifResolution { evaluateTriggeringEntityWasCast(state, it) }
            is com.wingedsheep.sdk.scripting.conditions.TriggeringSpellCastWithoutPayingMana ->
                ifResolution { evaluateTriggeringSpellCastWithoutPayingMana(state, it) }
            is com.wingedsheep.sdk.scripting.conditions.TriggeringSpellManaSpentAtLeast ->
                ifResolution { evaluateTriggeringSpellManaSpentAtLeast(state, condition.amount, it) }
            is TriggeringEntityEnteredOrWasCastFromGraveyard ->
                ifResolution { evaluateTriggeringEntityEnteredOrWasCastFromGraveyard(state, it) }
            is TriggeringEntityHadMinusOneMinusOneCounter ->
                ifResolution { (it.triggerMinusOneMinusOneCounterCount ?: 0) > 0 }
            is TriggeringEntityHadCounters ->
                ifResolution { (it.triggerTotalCounterCount ?: 0) > 0 }
            is com.wingedsheep.sdk.scripting.conditions.TriggeringEntityHadSubtype ->
                // Subtype names are captured in projected form (e.g. "Demon"); compare
                // case-insensitively so card authors can pass either Subtype.X.value or a literal.
                ifResolution { ctx ->
                    ctx.triggerLastKnownSubtypes.orEmpty().any { it.equals(condition.subtype, ignoreCase = true) }
                }
            is com.wingedsheep.sdk.scripting.conditions.TriggeringEntityHadCardType ->
                // Card-type names are captured from the projected TypeLine's enum names (e.g.
                // "CREATURE"); compare case-insensitively so card authors can pass either
                // CardType.X.name or a literal.
                ifResolution { ctx ->
                    ctx.triggerLastKnownCardTypes.orEmpty().any { it.equals(condition.cardType, ignoreCase = true) }
                }
            // CR 701.30d — "if you won" on a "Whenever you clash" trigger. The clash is over by the
            // time the ability resolves, so the outcome travels as trigger context; a null (this
            // trigger was not fired by a clash) reads as "did not win".
            is com.wingedsheep.sdk.scripting.conditions.YouWonTheClash ->
                ifResolution { it.triggerClashWon == true }
            is TriggeringEntityWasNotPutByThisSource ->
                ifResolution { evaluateTriggeringEntityWasNotPutByThisSource(state, it) }
            is TriggeringSpellHasSingleTarget -> ifResolution { evaluateTriggeringSpellHasSingleTarget(state, it) }
            is TargetIsPlayer -> ifResolution { evaluateTargetIsPlayer(condition, it) }
            is TargetIsCreatureCard -> ifResolution { evaluateTargetIsCreatureCard(state, condition, it) }
            is TargetIsSpellOnStack -> ifResolution { evaluateTargetIsSpellOnStack(condition, it) }
            is TargetIsTapped -> ifResolution { evaluateTargetIsTapped(state, condition, it) }
            is TargetIsSource -> ifResolution { evaluateTargetIsSource(condition, it) }
            is TargetMarkedDamageExceedsToughness ->
                ifResolution { evaluateTargetMarkedDamageExceedsToughness(state, condition, it) }
            is TargetSharesMostCommonColor -> ifResolution { evaluateTargetSharesMostCommonColor(state, condition, it) }
            is AnotherPermanentWithSameNameAsTarget ->
                ifResolution { evaluateAnotherPermanentWithSameNameAsTarget(state, condition, it) }
            is IsInPhase -> ifResolution { evaluateIsInPhase(state, condition, it) }
            is YouWereAttackedThisStep -> ifResolution { evaluateYouWereAttackedThisStep(state, it) }
            is IsFirstSpellPaidWithTreasureManaCastThisTurn ->
                ifResolution { evaluateFirstSpellPaidWithTreasureMana(state, it) }
            is SourceAbilityResolvedNTimesThisTurn -> ifResolution { evaluateSourceAbilityResolvedNTimes(state, condition, it) }
            is OpponentSpellOnStack -> ifResolution { evaluateOpponentSpellOnStack(state, it) }
            is CollectionContainsMatch -> ifResolution { evaluateCollectionContainsMatch(state, condition, it) }
            is CollectionSharesCardType -> ifResolution { evaluateCollectionSharesCardType(state, condition, it) }
            is CreatureDiedThisTurnCondition ->
                ifResolution { CreatureDiedThisTurnConditionEvaluator().evaluate(state, condition, it) }
            is ControlledCreatureDiedThisTurnCondition ->
                ifResolution { CreatureDiedThisTurnConditionEvaluator().evaluateControlled(state, it) }
        }
    }

    // ================================================================================
    // Dual-mode evaluators (resolve via [ConditionEvaluationContext]).
    // ================================================================================

    private fun syntheticEffectContext(state: GameState, ctx: ConditionEvaluationContext): EffectContext? {
        val controllerId = ctx.controllerId ?: return null
        return EffectContext(
            sourceId = ctx.sourceId,
            controllerId = controllerId,
        )
    }

    private fun evaluateCompareCtx(
        state: GameState,
        condition: Compare,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val effectCtx = when (ctx) {
            is Resolution -> ctx.effectContext
            is Projection -> syntheticEffectContext(state, ctx) ?: return false
        }
        // Earlier layers (especially control changes) are already present in this snapshot.
        // Keep resolution lazy: callers evaluating during projection supply a non-reentrant
        // default, and fixed amounts do not need to initialize a projection at all.
        val projected = if (ctx is Projection) ctx.projectedStateFor(state) else null
        val left = dynamicAmountEvaluator.evaluate(state, condition.left, effectCtx, projected)
        val right = dynamicAmountEvaluator.evaluate(state, condition.right, effectCtx, projected)
        return compareAmounts(left, condition.operator, right)
    }

    /**
     * Evaluates [NumberMatches] in both resolution and projection: resolves the amount via the
     * same effect-context plumbing as [evaluateCompareCtx], then applies the unary numeric
     * predicate. The arithmetic lives here (not on the SDK type) so [NumberProperty] stays pure
     * data, mirroring how [ComparisonOperator]'s comparison logic lives in [evaluateCompareCtx].
     */
    private fun evaluateNumberMatchesCtx(
        state: GameState,
        condition: NumberMatches,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val effectCtx = when (ctx) {
            is Resolution -> ctx.effectContext
            is Projection -> syntheticEffectContext(state, ctx) ?: return false
        }
        val projected = if (ctx is Projection) ctx.projectedStateFor(state) else null
        val value = dynamicAmountEvaluator.evaluate(state, condition.amount, effectCtx, projected)
        return when (val property = condition.property) {
            NumberProperty.Prime -> isPrime(value)
            NumberProperty.Even -> value % 2 == 0
            NumberProperty.Odd -> value % 2 != 0
            is NumberProperty.MultipleOf -> property.divisor != 0 && value % property.divisor == 0
        }
    }

    /** Standard primality test: 0 and 1 are not prime; 2 is the only even prime (CR-agnostic). */
    private fun isPrime(n: Int): Boolean {
        if (n < 2) return false
        if (n < 4) return true
        if (n % 2 == 0) return false
        var d = 3
        while (d.toLong() * d <= n) {
            if (n % d == 0) return false
            d += 2
        }
        return true
    }

    /**
     * The unified `EntityMatches(entity, filter)` evaluator. Resolves [EntityMatches.entity] and
     * matches it against [EntityMatches.filter], routing to the matching strategy each entity role
     * requires:
     * - [EffectTarget.Self]: live predicate match against the source; dual-mode (resolution +
     *   static-ability projection).
     * - [EffectTarget.EnchantedPermanent] / [EffectTarget.EnchantedCreature] /
     *   [EffectTarget.EquippedCreature]: live match against the source's attachment; dual-mode.
     * - [EffectTarget.ContextTarget]: resolution-only; resolve the chosen target to a game object
     *   (false for a player target) and match live.
     * - [EffectTarget.TriggeringEntity]: resolution-only; match the triggering spell by its static
     *   cast characteristics so the answer survives the spell leaving the stack (CR 603.4).
     *
     * Other entity roles are unsupported: the `CardLinter` rejects them at card load
     * (`UnsupportedEntityMatchesRole` — its supported-role set must extend in lockstep with this
     * dispatch), and the `else` here is the defense-in-depth backstop, not a contract.
     */
    private fun evaluateEntityMatches(
        state: GameState,
        condition: EntityMatches,
        ctx: ConditionEvaluationContext
    ): Boolean = when (val entity = condition.entity) {
        is EffectTarget.Self ->
            evaluateSourceFilterMatch(state, condition.filter, ctx)
        is EffectTarget.EnchantedPermanent,
        is EffectTarget.EnchantedCreature,
        is EffectTarget.EquippedCreature ->
            evaluateAttachmentFilterMatch(state, condition.filter, ctx)
        is EffectTarget.ContextTarget ->
            (ctx as? Resolution)?.let {
                evaluateTargetFilterMatch(state, condition.filter, entity.index, it.effectContext)
            } ?: false
        is EffectTarget.TriggeringEntity ->
            (ctx as? Resolution)?.let {
                val triggeringId = it.effectContext.triggeringEntityId
                if (triggeringId != null && state.getBattlefield().contains(triggeringId)) {
                    // The triggering object is a battlefield permanent (e.g. a delayed trigger
                    // watching "that Equipment"). Match against projected state so state predicates
                    // (attachment) and the controller predicate ("a creature you control") resolve;
                    // "you" is the ability's controller carried in the effect context.
                    PredicateEvaluator().matches(
                        state,
                        state.projectedState,
                        triggeringId,
                        condition.filter,
                        PredicateContext.fromEffectContext(it.effectContext)
                    )
                } else if (triggeringId != null &&
                    state.getEntity(triggeringId)?.has<LastKnownPermanentComponent>() == true
                ) {
                    // The triggering object is a permanent that has *left* the battlefield — the
                    // dies/leaves-trigger case. "It" still means the permanent as it last existed
                    // (CR 608.2h), so run the real predicate evaluator: the LKI-aware predicates
                    // (e.g. IsAttacking, which reads the battlefield-exit snapshot) resolve there,
                    // whereas the static-card-characteristics path below can't see them at all and
                    // would vacuously match. Garna, Bloodfist of Keld's "if it was attacking".
                    PredicateEvaluator().matches(
                        state,
                        state.projectedState,
                        triggeringId,
                        condition.filter,
                        PredicateContext.fromEffectContext(it.effectContext)
                    )
                } else {
                    // Stack / non-battlefield triggering object (the spell-cast case): match the
                    // spell's static card characteristics.
                    evaluateTriggeringSpellFilterMatch(state, condition.filter, it.effectContext)
                }
            } ?: false
        is EffectTarget.DiscardedAsCost ->
            (ctx as? Resolution)?.let {
                evaluateDiscardedCardFilterMatch(state, condition.filter, entity.index, it.effectContext)
            } ?: false
        is EffectTarget.LinkedExiledCard ->
            evaluateLinkedExiledCardFilterMatch(state, condition.filter, entity.index, ctx)
        else -> false
    }

    /**
     * Match the [index]-th card exiled with the source ([EffectTarget.LinkedExiledCard]) against
     * [filter]. **Dual-mode**: the pile hangs off the source permanent, so this answers identically
     * at resolution and during static-ability projection — which is what lets a
     * `ConditionalStaticAbility` be gated on the imprinted card (Duplicant's "as long as a card
     * exiled with this creature is a creature card").
     *
     * The card is in exile, so it has no projection entry and `matches` falls through to its
     * printed `CardComponent` characteristics — the right read for "is a creature card". Returns
     * false when the pile is empty at that index (imprint declined, or the card has left exile),
     * via [LinkedExileLookup]'s still-in-exile guard.
     */
    private fun evaluateLinkedExiledCardFilterMatch(
        state: GameState,
        filter: GameObjectFilter,
        index: Int,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val sourceId = ctx.sourceId ?: return false
        val exiledId = LinkedExileLookup.exiledCard(state, sourceId, index) ?: return false
        val predicateContext = when (ctx) {
            is Resolution -> PredicateContext.fromEffectContext(ctx.effectContext)
            is Projection -> ctx.controllerId?.let { PredicateContext(controllerId = it, sourceId = sourceId) }
                ?: PredicateContext(controllerId = sourceId, sourceId = sourceId)
        }
        return PredicateEvaluator().matches(
            state, ctx.projectedStateFor(state), exiledId, filter, predicateContext
        )
    }

    /**
     * Match the card discarded to pay this spell's additional discard cost
     * ([EffectTarget.DiscardedAsCost]) against [filter]. The discarded card is in its owner's
     * graveyard by resolution (CR 608.2), so this reads its graveyard characteristics — exactly
     * the right "land vs nonland" answer for Grab the Prize. Resolution-only; returns false when
     * no card was discarded at that index (e.g. the spell carried no discard cost).
     */
    private fun evaluateDiscardedCardFilterMatch(
        state: GameState,
        filter: GameObjectFilter,
        index: Int,
        context: EffectContext
    ): Boolean {
        val cardId = context.discardedAsCostCards.getOrNull(index) ?: return false
        val predicateEvaluator = PredicateEvaluator()
        val predicateContext = PredicateContext.fromEffectContext(context)
        return predicateEvaluator.matches(state, state.projectedState, cardId, filter, predicateContext)
    }

    private fun evaluateSourceFilterMatch(
        state: GameState,
        filter: GameObjectFilter,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val sourceId = ctx.sourceId ?: return false
        val projected = ctx.projectedStateFor(state)
        val predicateContext = when (ctx) {
            is Resolution -> PredicateContext.fromEffectContext(ctx.effectContext)
            is Projection -> ctx.controllerId?.let { PredicateContext(controllerId = it) }
                ?: PredicateContext(controllerId = sourceId)
        }
        return PredicateEvaluator().matches(state, projected, sourceId, filter, predicateContext)
    }

    private fun evaluateExistsCtx(
        state: GameState,
        condition: Exists,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val found = countExistsCtx(state, condition, ctx, cap = 1) > 0
        return if (condition.negate) !found else found
    }

    /**
     * How many objects match [condition]'s zone + filter, stopping once [cap] of them are found.
     * The boolean evaluation above is `count > 0` (negated for "there are no…"); the progress
     * badge ([countProgress]) is the same count uncapped, which is what makes a "you control no
     * suspected Skeletons" gate readable as "1/0" rather than a bare unmet flag.
     */
    private fun countExistsCtx(
        state: GameState,
        condition: Exists,
        ctx: ConditionEvaluationContext,
        cap: Int
    ): Int {
        if (cap <= 0) return 0
        val predicateEvaluator = PredicateEvaluator()
        val controllerId = ctx.controllerId
        val projected = ctx.projectedStateFor(state)
        val predicateContext = when (ctx) {
            is Resolution -> PredicateContext.fromEffectContext(ctx.effectContext)
            is Projection -> controllerId?.let {
                // Pass `sourceId` through so source-reading predicates (e.g.
                // `sharingChosenColorWithSource`) can find the source's
                // `CastChoicesComponent` during static-ability gating.
                PredicateContext(controllerId = it, sourceId = ctx.sourceId)
            } ?: return 0
        }

        val playerIds: List<EntityId> = when (condition.player) {
            is Player.You -> controllerId?.let { listOf(it) } ?: emptyList()
            is Player.EachOpponent -> controllerId?.let { state.getOpponents(it) } ?: emptyList()
            is Player.Each -> state.activePlayers
            is Player.Any -> state.activePlayers
            is Player.Candidate -> listOfNotNull((ctx as? Resolution)?.effectContext?.candidatePlayerId)
            is Player.ChosenOpponent -> listOfNotNull(
                ctx.sourceId?.let { state.getEntity(it)?.chosenOpponent() }
            )
            // Defender-relative conditions (CantAttackUnless "defending player controls…"):
            // the defender is bound into the EffectContext by the attack legality check, or
            // read from the source's attack assignment once combat is underway. No defender
            // in scope -> empty (the condition fails rather than leaking to other players).
            is Player.DefendingPlayer -> listOfNotNull(
                (ctx as? Resolution)?.effectContext?.let {
                    com.wingedsheep.engine.handlers.effects.TargetResolutionUtils.resolveDefendingPlayer(it, state)
                }
            )
            else -> controllerId?.let { listOf(it) } ?: emptyList()
        }

        var matches = 0
        for (playerId in playerIds) {
            var entities = if (condition.zone == Zone.BATTLEFIELD) {
                state.getBattlefield().filter { entityId -> projected.getController(entityId) == playerId }
            } else {
                state.getZone(ZoneKey(playerId, condition.zone))
            }
            if (condition.excludeSelf) {
                entities = entities.filter { it != ctx.sourceId }
            }
            for (entityId in entities) {
                if (condition.filter == GameObjectFilter.Any ||
                    predicateEvaluator.matches(state, projected, entityId, condition.filter, predicateContext)
                ) {
                    matches++
                    if (matches >= cap) return matches
                }
            }
        }
        return matches
    }

    /**
     * "Controls the most [filter], or is tied for the most" — the board-count sibling of
     * [PlayerHasMostLife]. Counts every player's matching permanents off the *projected*
     * battlefield (so an animated land counts as a creature) and returns true when nobody has
     * strictly more than the named player. `state.turnOrder` is the comparison set, matching
     * [PlayerHasMostLife]; a player with zero matches still qualifies when everyone has zero,
     * exactly as "the most" reads with an empty board.
     */
    private fun evaluatePlayerControlsMostPermanentsCtx(
        state: GameState,
        condition: PlayerControlsMostPermanents,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val playerId = resolvePlayer(state, condition.player, ctx) ?: return false
        val projected = ctx.projectedStateFor(state)
        val predicateEvaluator = PredicateEvaluator()
        val predicateContext = when (ctx) {
            is Resolution -> PredicateContext.fromEffectContext(ctx.effectContext)
            is Projection -> PredicateContext(controllerId = playerId, sourceId = ctx.sourceId)
        }

        val counts = state.getBattlefield()
            .filter { entityId ->
                predicateEvaluator.matches(state, projected, entityId, condition.filter, predicateContext)
            }
            .groupingBy { entityId -> projected.getController(entityId) }
            .eachCount()

        val mine = counts[playerId] ?: 0
        return state.turnOrder.all { (counts[it] ?: 0) <= mine }
    }

    private fun evaluateSourceIsModifiedCtx(state: GameState, ctx: ConditionEvaluationContext): Boolean {
        val sourceId = ctx.sourceId ?: return false
        val entity = state.getEntity(sourceId) ?: return false
        val controllerId = ctx.controllerId

        val counters = entity.get<com.wingedsheep.engine.state.components.battlefield.CountersComponent>()
        if (counters != null && counters.counters.values.any { it > 0 }) return true

        for (permanentId in state.getBattlefield()) {
            if (permanentId == sourceId) continue
            val container = state.getEntity(permanentId) ?: continue
            val attachedTo = container.get<AttachedToComponent>()?.targetId ?: continue
            if (attachedTo != sourceId) continue
            val card = container.get<CardComponent>() ?: continue

            if (card.typeLine.hasSubtype(Subtype.EQUIPMENT)) return true

            if (card.typeLine.hasSubtype(Subtype.AURA)) {
                val auraController = when (ctx) {
                    is Resolution -> container.get<ControllerComponent>()?.playerId
                    is Projection -> ctx.projectedValues[permanentId]?.controllerId
                        ?: container.get<ControllerComponent>()?.playerId
                }
                if (auraController == controllerId) return true
            }
        }
        return false
    }

    /**
     * "as long as it's blocking or blocked by a creature of one of [subtypes]".
     *
     * Resolves "it" through the source: an Equipment/Aura points at its attached creature (so the
     * static is gated for the equipped creature); a creature source uses itself. Then checks both
     * combat directions on that creature — the attackers it is blocking ([BlockingComponent]) and
     * the creatures blocking it ([BlockedComponent]) — and matches any partner whose projected
     * subtypes include one of [subtypes]. Subtypes use projected state so type-changing effects on
     * the partner are respected.
     */
    private fun evaluateSourceIsBlockingOrBlockedBySubtypeCtx(
        state: GameState,
        condition: SourceIsBlockingOrBlockedBySubtype,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val sourceId = ctx.sourceId ?: return false
        val attached = state.getEntity(sourceId)?.get<AttachedToComponent>()?.targetId
        val creatureId = attached ?: when (ctx) {
            is Resolution -> sourceId  // granted-ability / creature-source scope
            is Projection -> sourceId
        }
        val creature = state.getEntity(creatureId) ?: return false

        val partners = buildSet {
            creature.get<BlockingComponent>()?.blockedAttackerIds?.let { addAll(it) }
            creature.get<BlockedComponent>()?.blockerIds?.let { addAll(it) }
        }
        if (partners.isEmpty()) return false

        val projected = ctx.projectedStateFor(state)
        return partners.any { partnerId ->
            condition.subtypes.any { projected.hasSubtype(partnerId, it) }
        }
    }

    private fun evaluateEnchantedCreatureHasSubtypeCtx(
        state: GameState,
        condition: EnchantedCreatureHasSubtype,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val sourceId = ctx.sourceId ?: return false
        val attached = state.getEntity(sourceId)?.get<AttachedToComponent>()?.targetId
        val creatureId = attached ?: when (ctx) {
            is Resolution -> sourceId  // resolution-mode fallback (granted-ability scope)
            is Projection -> return false
        }
        return ctx.projectedStateFor(state).hasSubtype(creatureId, condition.subtype.value)
    }

    private fun evaluateEnchantedCreatureIsLegendaryCtx(
        state: GameState,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val sourceId = ctx.sourceId ?: return false
        val attached = state.getEntity(sourceId)?.get<AttachedToComponent>()?.targetId
        val creatureId = attached ?: when (ctx) {
            is Resolution -> sourceId
            is Projection -> return false
        }
        return "LEGENDARY" in ctx.projectedStateFor(state).getTypes(creatureId)
    }

    private fun evaluateAttachmentFilterMatch(
        state: GameState,
        filter: GameObjectFilter,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val sourceId = ctx.sourceId ?: return false
        val attached = state.getEntity(sourceId)?.get<AttachedToComponent>()?.targetId
        val permanentId = attached ?: when (ctx) {
            is Resolution -> sourceId  // resolution-mode fallback (granted-ability scope)
            is Projection -> return false
        }
        val projected = ctx.projectedStateFor(state)
        val predicateContext = when (ctx) {
            is Resolution -> PredicateContext.fromEffectContext(ctx.effectContext)
            is Projection -> {
                // "You" (for any controller predicate in [filter]) is the Aura's controller.
                // Fall back to the source's projected controller rather than miscasting the
                // source entity id as a player id; if even that is unknown, we can't evaluate.
                val controller = ctx.controllerId ?: projected.getController(sourceId) ?: return false
                PredicateContext(controllerId = controller)
            }
        }
        return PredicateEvaluator().matches(state, projected, permanentId, filter, predicateContext)
    }

    /**
     * Resolve a [Player] reference against the current evaluation context.
     *
     * - [Player.You]: controller-of-source (resolution: effectContext.controllerId;
     *   projection: source's projected controller).
     * - [Player.AnOpponent]: a non-targeted opponent of the controller. Returns the first opponent
     *   in turn order — sufficient for per-player tracker reads where each player has
     *   its own bucket.
     * - [Player.TriggeringPlayer]: only resolvable in resolution mode.
     * - Other relational forms are not currently supported by the player-relative
     *   conditions and return `null`.
     */
    private fun resolvePlayer(state: GameState, player: Player, ctx: ConditionEvaluationContext): EntityId? {
        return when (player) {
            is Player.You -> ctx.controllerId
                ?: ctx.sourceId?.let { state.getEntity(it)?.get<ControllerComponent>()?.playerId }
            is Player.AnOpponent -> {
                val c = ctx.controllerId ?: return null
                state.getOpponents(c).firstOrNull()
            }
            is Player.TriggeringPlayer -> (ctx as? Resolution)?.effectContext?.triggeringPlayerId
            // The attacked player for the source's attack assignment (read from its
            // AttackingComponent by resolveDefendingPlayer) — Preacher of the Schism's "attacks the
            // player with the most life".
            is Player.DefendingPlayer -> (ctx as? Resolution)?.effectContext?.let {
                com.wingedsheep.engine.handlers.effects.TargetResolutionUtils.resolveDefendingPlayer(it, state)
            }
            is Player.Candidate -> (ctx as? Resolution)?.effectContext?.candidatePlayerId
            is Player.ChosenOpponent -> ctx.sourceId?.let { sourceId ->
                state.getEntity(sourceId)?.chosenOpponent()
            }
            else -> null
        }
    }

    private fun evaluateAttackedWithCreaturesCtx(
        state: GameState,
        condition: PlayerAttackedWithCreaturesThisTurn,
        ctx: ConditionEvaluationContext
    ): Boolean =
        condition.atLeast <= 0 ||
            countAttackedWithCreaturesCtx(state, condition, ctx, cap = condition.atLeast) >= condition.atLeast

    /**
     * How many creatures matching [condition] have attacked this turn, stopping once [cap] of them
     * are found. The boolean evaluation above is this count against `atLeast`; the progress badge
     * ([countProgress]) is the same count uncapped, so the two can't disagree.
     */
    private fun countAttackedWithCreaturesCtx(
        state: GameState,
        condition: PlayerAttackedWithCreaturesThisTurn,
        ctx: ConditionEvaluationContext,
        cap: Int
    ): Int {
        if (cap <= 0) return 0
        // Player.Each / Player.Any make this the *player-agnostic* count — "three or more creatures
        // attacked this turn" (Case of the Gateway Express) rather than "you attacked with three or
        // more". Every other scope resolves to the single player it names, so Player.You behaves
        // exactly as before.
        val playerIds = when (condition.player) {
            is Player.Each, is Player.Any -> state.activePlayers
            is Player.EachOpponent -> {
                val controller = resolvePlayer(state, Player.You, ctx) ?: return 0
                state.getOpponents(controller)
            }
            else -> listOfNotNull(resolvePlayer(state, condition.player, ctx))
        }
        if (playerIds.isEmpty()) return 0
        // Attackers are recorded per declaring player, so the union is the set of creatures that
        // attacked at all this turn — a creature counts once even if two scopes both name it.
        val attackerIds = playerIds.flatMapTo(mutableSetOf()) { playerId ->
            state.getEntity(playerId)
                ?.get<PlayerAttackersThisTurnComponent>()
                ?.attackerIds
                ?: emptySet()
        }
        if (attackerIds.isEmpty()) return 0
        val predicateEvaluator = PredicateEvaluator()
        val predicateContext = when (ctx) {
            is Resolution -> PredicateContext.fromEffectContext(ctx.effectContext)
            // The filter's own "you control" clauses are relative to the ability's controller,
            // not to whichever player's attack record is being scanned.
            is Projection -> PredicateContext(
                controllerId = resolvePlayer(state, Player.You, ctx) ?: playerIds.first()
            )
        }
        val projected = ctx.projectedStateFor(state)
        var matches = 0
        for (id in attackerIds) {
            if (predicateEvaluator.matches(state, projected, id, condition.filter, predicateContext)) {
                matches++
                if (matches >= cap) return matches
            }
        }
        return matches
    }

    private fun evaluateAttackedPlayerThisTurnCtx(
        state: GameState,
        condition: com.wingedsheep.sdk.scripting.conditions.PlayerAttackedPlayerThisTurn,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val attackerId = resolvePlayer(state, condition.attacker, ctx) ?: return false
        val defenderId = resolvePlayer(state, condition.defender, ctx) ?: return false
        val attackedPlayers = state.getEntity(attackerId)
            ?.get<com.wingedsheep.engine.state.components.combat.PlayerAttackedPlayersThisTurnComponent>()
            ?.defendingPlayerIds
            ?: emptySet()
        return defenderId in attackedPlayers
    }

    private fun evaluateCastSpellsThisTurnCtx(
        state: GameState,
        condition: PlayerCastSpellsThisTurn,
        ctx: ConditionEvaluationContext
    ): Boolean =
        condition.atLeast <= 0 ||
            countCastSpellsThisTurnCtx(state, condition, ctx, cap = condition.atLeast) >= condition.atLeast

    /**
     * How many spells matching [condition] the player has cast this turn, stopping once [cap] of
     * them are found. Counterpart of [countAttackedWithCreaturesCtx]: the boolean evaluation is
     * this count against `atLeast`, the progress badge is the same count uncapped.
     */
    private fun countCastSpellsThisTurnCtx(
        state: GameState,
        condition: PlayerCastSpellsThisTurn,
        ctx: ConditionEvaluationContext,
        cap: Int
    ): Int {
        if (cap <= 0) return 0
        val playerId = resolvePlayer(state, condition.player, ctx) ?: return 0
        val records = state.spellsCastThisTurnByPlayer[playerId] ?: return 0
        val evaluator = PredicateEvaluator()
        // Cast-history filters can reference a name captured earlier in this same resolution
        // (`GameObjectFilter.namedFromVariable`), so the record matcher needs the pipeline's
        // chosen values. Only a Resolution context has a pipeline; a static/projection evaluation
        // passes null and those predicates match nothing, as before.
        val predicateContext = (ctx as? Resolution)
            ?.let { PredicateContext.fromEffectContext(it.effectContext) }
        var matches = 0
        for (record in records) {
            // The zone qualifier is checked independently of the filter: a face-down (morph) spell
            // cast from hand still counts as "cast a spell from your hand" even though matchesFilter
            // bails on face-down characteristics (CR 708.2).
            if (condition.fromZone != null && record.castFromZone != condition.fromZone) continue
            // "…from anywhere other than your hand" (Spider-Man 2099): exclude that one zone.
            if (condition.fromZoneOtherThan != null && record.castFromZone == condition.fromZoneOtherThan) continue
            if (condition.filter != GameObjectFilter.Any &&
                !evaluator.matchesFilter(record, condition.filter, predicateContext)
            ) continue
            matches++
            if (matches >= cap) return matches
        }
        return matches
    }

    private fun evaluateHasCitysBlessingCtx(
        state: GameState,
        condition: PlayerHasCitysBlessing,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val playerId = resolvePlayer(state, condition.player, ctx) ?: return false
        // Not a bare component read: CR 702.131b's ascend is continuous, so a player who has just
        // crossed ten permanents mid-resolution already has the blessing, before the state-based
        // action writes the marker. The ctx projection (not state.projectedState) is what keeps the
        // projection-mode caller — Tendershoot Dryad's city's-blessing static gate — from
        // re-entering the lazy projection initializer. See CitysBlessingService.
        return CitysBlessingService.has(state, playerId, ctx.projectedStateFor(state))
    }

    private fun evaluateHasEnduringStoryCtx(
        state: GameState,
        condition: PlayerHasEnduringStory,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val playerId = resolvePlayer(state, condition.player, ctx) ?: return false
        // Same shape and same two reasons as the city's blessing read above: CR 702.195a's storied is
        // continuous, so a player who has just crossed three qualifying permanents mid-resolution
        // already has the enduring story before the state-based action writes the marker; and the ctx
        // projection (not state.projectedState) is what keeps the projection-mode callers — every
        // storied card's "as long as you have an enduring story" static gate — from re-entering the
        // lazy projection initializer. See EnduringStoryService.
        return EnduringStoryService.has(state, playerId, ctx.projectedStateFor(state))
    }

    private fun evaluatePermanentTypeEnteredBattlefieldThisTurnCtx(
        state: GameState,
        condition: PermanentTypeEnteredBattlefieldThisTurn,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val playerId = resolvePlayer(state, condition.player, ctx) ?: return false
        val log = state.getEntity(playerId)
            ?.get<com.wingedsheep.engine.state.components.player.PermanentsEnteredUnderControlThisTurnComponent>()
            ?: return false
        return log.countOfType(condition.cardType) > 0
    }

    private fun evaluatePermanentLeftBattlefieldThisTurnCtx(
        state: GameState,
        condition: PermanentLeftBattlefieldThisTurn,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val playerId = resolvePlayer(state, condition.player, ctx) ?: return false
        val count = state.getEntity(playerId)
            ?.get<com.wingedsheep.engine.state.components.player.PermanentLeftBattlefieldThisTurnComponent>()
            ?.count ?: 0
        return count > 0
    }

    private fun evaluateYouControlSource(state: GameState, context: EffectContext): Boolean {
        val sourceId = context.sourceId ?: return false
        val sourceController = state.getEntity(sourceId)?.get<ControllerComponent>()?.playerId ?: return false
        return context.controllerId == sourceController
    }

    private fun evaluateWasCast(state: GameState, context: EffectContext): Boolean {
        // For spells resolving, any non-null castFromZone means the spell is being cast
        if (context.castFromZone != null) return true
        // For permanents (e.g., ETB triggers), check the cast-from-zone markers added
        // when the spell resolved. Reanimated, token, and "put onto battlefield"
        // permanents lack these markers and are correctly excluded.
        val sourceId = context.sourceId ?: return false
        val container = state.getEntity(sourceId) ?: return false
        return container.has<CastFromHandComponent>() || container.has<CastFromGraveyardComponent>()
    }

    private fun evaluateWasCastFromHand(state: GameState, context: EffectContext): Boolean {
        // For spells resolving, check context.castFromZone (set from SpellOnStackComponent)
        if (context.castFromZone == Zone.HAND) return true
        // For permanents (triggered abilities), fall back to battlefield component
        val sourceId = context.sourceId ?: return false
        return state.getEntity(sourceId)?.has<CastFromHandComponent>() == true
    }

    /**
     * Where the source object sits *now* (CR 113.6b's zone test, and the resolution-time half of an
     * eminence ability's intervening-"if" per CR 603.4).
     *
     * Scans the zone map by zone *type* rather than reaching for per-zone accessors, because the
     * shared zones (battlefield, stack, exile) and the per-player ones (command zone, graveyard,
     * hand) are keyed differently and the condition is parameterized over both.
     */
    private fun evaluateSourceInZone(
        state: GameState,
        condition: SourceInZone,
        ctx: ConditionEvaluationContext
    ): Boolean {
        val sourceId = ctx.sourceId ?: return false
        return state.zones.any { (key, ids) -> key.zoneType in condition.zones && sourceId in ids }
    }

    private fun evaluateWasCastFromZone(state: GameState, condition: WasCastFromZone, context: EffectContext): Boolean {
        // For spells resolving, check context.castFromZone (set from SpellOnStackComponent)
        if (context.castFromZone == condition.zone) return true
        // For permanents (e.g. an entering creature's own "enters with a counter if cast from
        // graveyard" replacement, or a triggered ability), fall back to the cast-origin marker
        // component stamped on the permanent as it resolved onto the battlefield.
        val sourceId = context.sourceId ?: return false
        val entity = state.getEntity(sourceId) ?: return false
        return when (condition.zone) {
            Zone.HAND -> entity.has<CastFromHandComponent>()
            Zone.GRAVEYARD -> entity.has<CastFromGraveyardComponent>()
            Zone.LIBRARY -> entity.has<CastFromLibraryComponent>()
            Zone.EXILE -> entity.has<
                com.wingedsheep.engine.state.components.battlefield.CastFromExileComponent
                >()
            else -> false
        }
    }

    /**
     * "if it wasn't cast or no mana was spent to cast it." The engine stamps a
     * [CastRecordComponent] on a resolving permanent only when the total mana spent to
     * cast it was greater than zero (see StackResolver.resolvePermanentSpell). So the
     * source has no cast record — or a record summing to zero — exactly when no mana was
     * spent: a free / {0} cast, or a permanent put onto the battlefield without being cast.
     * Mana paid for additional costs or cost increases on an otherwise-free cast does land
     * in the record, so such a permanent correctly fails this condition.
     */
    private fun evaluateNoManaSpentToCast(state: GameState, context: EffectContext): Boolean {
        val sourceId = context.sourceId ?: return false
        return noManaSpentToCast(state, sourceId)
    }

    /** True iff no mana at all was spent to cast [entityId] (absent record or zero total). */
    private fun noManaSpentToCast(state: GameState, entityId: EntityId): Boolean {
        val record = state.getEntity(entityId)?.get<CastRecordComponent>() ?: return true
        return record.whiteSpent + record.blueSpent + record.blackSpent +
            record.redSpent + record.greenSpent + record.colorlessSpent == 0
    }

    /**
     * Satoru-shaped batch gate: every permanent captured by the batch-enters trigger (exposed at
     * resolution under [PipelineState.TRIGGER_CAPTURED_COLLECTION]) had no mana spent to cast it.
     * An empty capture is vacuously true.
     */
    private fun evaluateNoManaSpentToCastEntered(state: GameState, context: EffectContext): Boolean {
        val captured = context.pipeline.storedCollections[PipelineState.TRIGGER_CAPTURED_COLLECTION].orEmpty()
        return captured.all { noManaSpentToCast(state, it) }
    }

    /**
     * "If one or more of them entered from exile or was cast from exile" — an *any* over the
     * batch-enters capture, the exile twin of
     * [evaluateTriggeringEntityEnteredOrWasCastFromGraveyard]. An empty capture is false: nothing
     * entered from exile.
     */
    private fun evaluateAnyEnteredOrWasCastFromExile(state: GameState, context: EffectContext): Boolean {
        val captured = context.pipeline.storedCollections[PipelineState.TRIGGER_CAPTURED_COLLECTION].orEmpty()
        return captured.any { entityId ->
            val entity = state.getEntity(entityId) ?: return@any false
            entity.has<com.wingedsheep.engine.state.components.battlefield.CastFromExileComponent>() ||
                entity.has<com.wingedsheep.engine.state.components.battlefield.EnteredFromExileComponent>()
        }
    }

    /**
     * Triggering-entity counterpart of [evaluateNoManaSpentToCast] for a spell still on the stack
     * (Boromir, Warden of the Tower). The intervening-if runs before the spell resolves, so the
     * post-resolution `CastRecordComponent` isn't stamped yet — read the cast-time mana-spent totals
     * recorded on the [SpellOnStackComponent] instead. False (mana was spent) when the spell isn't
     * found / not a spell on the stack.
     */
    private fun evaluateTriggeringSpellCastWithoutPayingMana(state: GameState, context: EffectContext): Boolean {
        val entityId = context.triggeringEntityId ?: return false
        val spell = state.getEntity(entityId)
            ?.get<com.wingedsheep.engine.state.components.stack.SpellOnStackComponent>() ?: return false
        return spell.manaSpentWhite + spell.manaSpentBlue + spell.manaSpentBlack +
            spell.manaSpentRed + spell.manaSpentGreen + spell.manaSpentColorless == 0
    }

    /**
     * Threshold counterpart of [evaluateTriggeringSpellCastWithoutPayingMana]: true when the
     * total mana spent on the triggering spell (summed across colors + colorless on the
     * [SpellOnStackComponent]) is at least [amount]. False when the triggering entity isn't a
     * spell on the stack.
     */
    private fun evaluateTriggeringSpellManaSpentAtLeast(
        state: GameState,
        amount: Int,
        context: EffectContext
    ): Boolean {
        val entityId = context.triggeringEntityId ?: return false
        val spell = state.getEntity(entityId)
            ?.get<com.wingedsheep.engine.state.components.stack.SpellOnStackComponent>() ?: return false
        val total = spell.manaSpentWhite + spell.manaSpentBlue + spell.manaSpentBlack +
            spell.manaSpentRed + spell.manaSpentGreen + spell.manaSpentColorless
        return total >= amount
    }

    private fun evaluateWasKicked(state: GameState, context: EffectContext): Boolean {
        // Kicker specifically (ChoiceSlot.KICKED) — a spell that declared a *different*
        // optional additional cost on the same rail (bargain) is not kicked.
        val kicked = context.declaredCostSlot == ChoiceSlot.KICKED
        // Check the durable cast-choices bag on the permanent first (for triggered abilities)
        val sourceId = context.sourceId ?: return kicked
        if (state.getEntity(sourceId)?.wasKickedChoice() == true) return true
        // Fall back to context (for spell resolution, e.g. kicker additional effects)
        return kicked
    }

    private fun evaluateSneakCostWasPaid(state: GameState, context: EffectContext): Boolean {
        // Durable bag on the resolved permanent first (ETB / ongoing triggered & activated reads).
        val sourceId = context.sourceId ?: return context.wasSneaked
        val flagged = state.getEntity(sourceId)
            ?.get<CastChoicesComponent>()
            ?.chosen
            ?.containsKey(ChoiceSlot.SNEAK) == true
        if (flagged) return true
        // Fall back to the resolution context (a non-permanent spell's own resolving effect,
        // e.g. The Last Ronin's Technique reading "if this spell's sneak cost was paid").
        return context.wasSneaked
    }

    private fun evaluateWebSlungCostWasPaid(state: GameState, context: EffectContext): Boolean {
        // Durable bag on the resolved permanent first (ETB / ongoing reads, e.g. Spiders-Man's
        // "if they were cast using web-slinging" enters trigger).
        val sourceId = context.sourceId ?: return context.wasWebSlung
        val flagged = state.getEntity(sourceId)
            ?.get<CastChoicesComponent>()
            ?.chosen
            ?.containsKey(ChoiceSlot.WEB_SLUNG) == true
        if (flagged) return true
        // Fall back to the resolution context for a non-permanent spell's own resolving effect.
        return context.wasWebSlung
    }

    private fun evaluateMayhemCostWasPaid(state: GameState, context: EffectContext): Boolean {
        // Durable bag on the resolved permanent first (ETB / ongoing reads); fall back to the
        // resolution context for a non-permanent spell's own resolving effect (Sandman's Quicksand).
        val sourceId = context.sourceId ?: return context.wasMayhem
        val flagged = state.getEntity(sourceId)
            ?.get<CastChoicesComponent>()
            ?.chosen
            ?.containsKey(ChoiceSlot.MAYHEM_CAST) == true
        if (flagged) return true
        return context.wasMayhem
    }

    private fun evaluateWaterbendWasPaid(state: GameState, context: EffectContext): Boolean {
        // Durable bag on the resolved permanent first (e.g. a creature cast with optional
        // waterbend whose ongoing ability reads the flag); fall back to the resolution context for
        // a non-permanent spell's own resolving effect (Ruinous Waterbending, Spirit Water Revival).
        val sourceId = context.sourceId ?: return context.wasWaterbendPaid
        val flagged = state.getEntity(sourceId)
            ?.get<CastChoicesComponent>()
            ?.chosen
            ?.containsKey(ChoiceSlot.WATERBEND_PAID) == true
        if (flagged) return true
        return context.wasWaterbendPaid
    }

    /** Compare the value locked into [slot] on [entity]'s cast-choices bag to [value] as text. */
    private fun castChoiceMatches(
        entity: com.wingedsheep.engine.state.ComponentContainer?,
        slot: ChoiceSlot,
        value: String
    ): Boolean {
        val cv = entity?.get<CastChoicesComponent>()?.chosen?.get(slot) ?: return false
        val actual = when (cv) {
            is ChoiceValue.ColorChoice -> cv.color.name
            is ChoiceValue.TextChoice -> cv.text
            is ChoiceValue.NumberChoice -> cv.amount.toString()
            is ChoiceValue.EntityChoice -> cv.entityId.toString()
            ChoiceValue.Flag -> "true"
        }
        return actual.equals(value, ignoreCase = true)
    }

    private fun evaluateManaSpentToCastIncludes(
        state: GameState,
        condition: ManaSpentToCastIncludes,
        context: EffectContext
    ): Boolean {
        val sourceId = context.sourceId ?: return false
        // Read through ManaSpentReader rather than CastRecordComponent directly: that snapshot is
        // only stamped when a *permanent* spell resolves onto the battlefield, so reading it alone
        // made the condition permanently false for an instant or sorcery whose own resolution asks
        // the question ("If {U} was spent to cast this spell", the Ravnica hybrid-rider cycle) —
        // there the source is still a spell on the stack and its payment lives in
        // SpellOnStackComponent. The reader covers both zones.
        val spent = ManaSpentReader.coloredBuckets(state, sourceId)
        return spent[0] >= condition.requiredWhite &&
            spent[1] >= condition.requiredBlue &&
            spent[2] >= condition.requiredBlack &&
            spent[3] >= condition.requiredRed &&
            spent[4] >= condition.requiredGreen
    }

    private fun evaluateIsInPhase(state: GameState, condition: IsInPhase, context: EffectContext): Boolean {
        if (condition.yoursOnly && !state.isActiveTurnFor(context.controllerId)) return false
        return state.phase in condition.phases
    }

    private fun evaluateSacrificedPermanentHadSubtype(
        condition: SacrificedPermanentHadSubtype,
        context: EffectContext
    ): Boolean {
        return context.sacrificedPermanents.any { snapshot ->
            snapshot.subtypes.contains(condition.subtype)
        }
    }

    /**
     * Soul Exchange's "if the exiled creature was a Thrull". The additional cost is fully paid
     * before the spell resolves (CR 601.2h), so by resolution the exiled object is either a card
     * sitting in exile or — when the cost exiled a *permanent* — possibly gone entirely, a token
     * having ceased to exist. Prefer the cost-time snapshot when one was captured, because it is
     * both the only reading that survives a token and the one Rule 113.7a asks for: what the
     * permanent last was on the battlefield, continuous effects included. Fall back to the card's
     * printed subtypes for exile costs paid from a non-battlefield zone, where the card is still
     * there to read and its printed line is the right answer.
     */
    private fun evaluateExiledAsCostHadSubtype(
        state: GameState,
        condition: ExiledAsCostHadSubtype,
        context: EffectContext
    ): Boolean {
        val snapshots = context.exiledAsCostSnapshots.associateBy { it.entityId }
        return context.exiledAsCostCards.any { exiledId ->
            val snapshot = snapshots[exiledId]
            if (snapshot != null) {
                snapshot.subtypes.any { it.equals(condition.subtype, ignoreCase = true) }
            } else {
                state.getEntity(exiledId)
                    ?.get<CardComponent>()
                    ?.typeLine?.subtypes
                    ?.any { it.value.equals(condition.subtype, ignoreCase = true) } == true
            }
        }
    }

    /**
     * Farrelite Priest's "if this ability has been activated four or more times this turn". The
     * tally lives on the source permanent, keyed by ability id, and the handler increments it
     * before the effect runs — so the fourth activation reads four. A modern stack object carries
     * its concrete id whether or not it tracks activations; an untracked ability still reads false
     * because its source has no tally for that id. Contexts with no concrete activated ability id
     * also read false.
     */
    private fun evaluateThisAbilityActivatedThisTurnAtLeast(
        state: GameState,
        condition: ThisAbilityActivatedThisTurnAtLeast,
        context: EffectContext
    ): Boolean {
        val abilityId = context.activatedAbilityId ?: return false
        val sourceId = context.sourceId ?: return false
        val tracker = state.getEntity(sourceId)
            ?.get<AbilityActivatedThisTurnComponent>()
            ?: return false
        return tracker.activationCount(abilityId) >= condition.count
    }

    private fun evaluateSacrificedPermanentWasLegendary(context: EffectContext): Boolean {
        return context.sacrificedPermanents.any { snapshot ->
            "LEGENDARY" in snapshot.supertypes
        }
    }

    private fun evaluateSacrificedPermanentWasSuspected(context: EffectContext): Boolean {
        return context.sacrificedPermanents.any { snapshot -> snapshot.wasSuspected }
    }

    private fun evaluateYouSacrificedPermanentThisWay(context: EffectContext): Boolean {
        return context.sacrificedPermanents.any { snapshot ->
            snapshot.controllerId == context.controllerId
        }
    }

    private fun evaluateYouWereAttackedThisStep(state: GameState, context: EffectContext): Boolean {
        return state.entities.any { (_, container) ->
            val attacking = container.get<AttackingComponent>()
            attacking != null && attacking.defenderId == context.controllerId
        }
    }

    private fun evaluateOpponentSpellOnStack(state: GameState, context: EffectContext): Boolean {
        val opponents = state.getOpponents(context.controllerId)
        return state.stack.any { entityId ->
            val container = state.getEntity(entityId) ?: return@any false
            container.get<com.wingedsheep.engine.state.components.stack.SpellOnStackComponent>()?.casterId in opponents
        }
    }

    private fun evaluateAPlayerControlsMostOfSubtype(
        state: GameState,
        condition: APlayerControlsMostOfSubtype
    ): Boolean {
        val counts = state.turnOrder.associateWith { playerId ->
            state.entities.count { (_, container) ->
                container.get<ControllerComponent>()?.playerId == playerId &&
                container.get<CardComponent>()?.typeLine?.hasSubtype(condition.subtype) == true
            }
        }
        val maxCount = counts.values.maxOrNull() ?: return false
        if (maxCount == 0) return false
        val playersWithMax = counts.count { it.value == maxCount }
        return playersWithMax == 1
    }

    private fun evaluateYouControlMostOfChosenType(
        state: GameState,
        condition: YouControlMostOfChosenType,
        context: EffectContext
    ): Boolean {
        val chosenType = context.pipeline.chosenValues[condition.chosenValueKey] ?: return false
        val projected = state.projectedState
        val controllerId = context.controllerId

        val counts = state.turnOrder.associateWith { playerId ->
            state.getBattlefield().count { entityId ->
                val controller = projected.getController(entityId)
                controller == playerId && projected.hasSubtype(entityId, chosenType) &&
                    projected.isCreature(entityId)
            }
        }

        val controllerCount = counts[controllerId] ?: 0
        if (controllerCount == 0) return false

        return counts.filter { it.key != controllerId }.all { controllerCount > it.value }
    }

    private fun evaluateTriggeringEntityWasHistoric(state: GameState, context: EffectContext): Boolean {
        val entityId = context.triggeringEntityId ?: return false
        val card = state.getEntity(entityId)?.get<CardComponent>() ?: return false
        return card.typeLine.isHistoric
    }

    /**
     * "if you cast it" referring to the triggering (entering) permanent. Mirrors
     * [evaluateWasCast] but reads the cast-origin markers off the triggering entity rather than
     * the ability's source, so it works for "whenever a creature you control enters, if you cast
     * it" triggers where the source is a separate permanent. Tokens, reanimated, and
     * "put onto the battlefield" permanents lack these markers and are correctly excluded.
     */
    private fun evaluateTriggeringEntityWasCast(state: GameState, context: EffectContext): Boolean {
        val entityId = context.triggeringEntityId ?: return false
        val entity = state.getEntity(entityId) ?: return false
        return entity.has<CastFromHandComponent>() || entity.has<CastFromGraveyardComponent>()
    }

    private fun evaluateTriggeringEntityEnteredOrWasCastFromGraveyard(
        state: GameState,
        context: EffectContext
    ): Boolean {
        val entityId = context.triggeringEntityId ?: return false
        val entity = state.getEntity(entityId) ?: return false
        return entity.has<com.wingedsheep.engine.state.components.battlefield.CastFromGraveyardComponent>() ||
            entity.has<com.wingedsheep.engine.state.components.battlefield.EnteredFromGraveyardComponent>()
    }

    private fun evaluateTriggeringEntityWasNotPutByThisSource(
        state: GameState,
        context: EffectContext
    ): Boolean {
        val triggeringId = context.triggeringEntityId ?: return true
        val sourceId = context.sourceId ?: return true
        val marker = state.getEntity(triggeringId)?.get<EnteredViaAbilityComponent>()
        return marker?.sourceId != sourceId
    }

    private fun evaluateTriggeringSpellHasSingleTarget(
        state: GameState,
        context: EffectContext
    ): Boolean {
        val entityId = context.triggeringEntityId ?: return false
        val targets = state.getEntity(entityId)
            ?.get<com.wingedsheep.engine.state.components.stack.TargetsComponent>()
            ?.targets
            ?: return false
        return targets.size == 1
    }

    private fun evaluateTargetFilterMatch(
        state: GameState,
        filter: GameObjectFilter,
        targetIndex: Int,
        context: EffectContext
    ): Boolean {
        val target = context.positionalTarget(targetIndex) ?: return false
        val entityId = when (target) {
            is com.wingedsheep.engine.state.components.stack.ChosenTarget.Permanent -> target.entityId
            is com.wingedsheep.engine.state.components.stack.ChosenTarget.Player -> return false
            is com.wingedsheep.engine.state.components.stack.ChosenTarget.Spell -> target.spellEntityId
            is com.wingedsheep.engine.state.components.stack.ChosenTarget.Card -> target.cardId
        }
        val predicateEvaluator = PredicateEvaluator()
        val predicateContext = PredicateContext.fromEffectContext(context)
        val projected = state.projectedState
        return predicateEvaluator.matches(state, projected, entityId, filter, predicateContext)
    }

    /**
     * Evaluate "if a player is dealt damage this way" — true when the context target at the given
     * index is a player target. Used by Sonic Shrieker to gate its discard follow-up on the
     * damaged "any target" having been a player. Permanent/spell/card targets return false.
     */
    private fun evaluateTargetIsPlayer(
        condition: TargetIsPlayer,
        context: EffectContext
    ): Boolean {
        val target = context.positionalTarget(condition.targetIndex) ?: return false
        return target is com.wingedsheep.engine.state.components.stack.ChosenTarget.Player
    }

    /**
     * Evaluate "if excess damage was dealt this way" — true when the target creature's
     * marked damage strictly exceeds its (projected) toughness. Chained after a `DealDamage`
     * step in a composite, so the marked-damage component reflects damage just dealt by
     * the preceding step (Composite doesn't interleave SBA or fire other triggers between
     * its sub-effects, so for the canonical pipeline no other source contributes marked
     * damage in scope).
     *
     * The non-creature and not-on-battlefield branches return false defensively — under
     * `Targets.Creature` + Composite they can't fire, but they keep this condition safe
     * if a future caller wraps it in a longer chain that crosses SBA or re-targets.
     */
    /**
     * "If the target is tapped": resolve the context target to a battlefield permanent and read its
     * [TappedComponent]. Non-permanent targets and permanents no longer on the battlefield return
     * false. Used by Shackle Slinger to branch between stunning a tapped target and tapping an
     * untapped one.
     */
    /**
     * "If [the target] is a creature card": resolve the chosen target and test its *underlying
     * card's* printed type, not projected state. This is the correct test for a face-down permanent
     * — while face down it projects as a typeless 2/2 Creature regardless of what it really is, so
     * "creature card" must read the hidden card itself (CR 708.2). Non-permanent / player targets
     * return false.
     */
    private fun evaluateTargetIsCreatureCard(
        state: GameState,
        condition: TargetIsCreatureCard,
        context: EffectContext
    ): Boolean {
        val target = context.positionalTarget(condition.index) ?: return false
        // Works whether the target is a battlefield permanent (face-down reveal) or a card in another
        // zone — a graveyard card exiled by Agatha's Soul Cauldron is a ChosenTarget.Card. Both expose
        // the underlying entity, whose CardComponent still carries the printed type after it moves.
        val entityId = when (target) {
            is com.wingedsheep.engine.state.components.stack.ChosenTarget.Permanent -> target.entityId
            is com.wingedsheep.engine.state.components.stack.ChosenTarget.Card -> target.cardId
            else -> return false
        }
        return state.getEntity(entityId)?.get<CardComponent>()?.typeLine?.isCreature == true
    }

    private fun evaluateTargetIsSpellOnStack(
        condition: TargetIsSpellOnStack,
        context: EffectContext
    ): Boolean =
        context.positionalTarget(condition.index) is
            com.wingedsheep.engine.state.components.stack.ChosenTarget.Spell

    private fun evaluateTargetIsTapped(
        state: GameState,
        condition: TargetIsTapped,
        context: EffectContext
    ): Boolean {
        val target = context.positionalTarget(condition.targetIndex) ?: return false
        val entityId = (target as? com.wingedsheep.engine.state.components.stack.ChosenTarget.Permanent)
            ?.entityId ?: return false
        if (entityId !in state.getBattlefield()) return false
        return state.getEntity(entityId)?.has<TappedComponent>() == true
    }

    /**
     * "If the target is this permanent (the source)": resolve the context target and compare its
     * entity id to the ability's source. Non-permanent targets and a missing source return false.
     * Wrapped in `Not` by Arid Archway to express "another" (a returned land that isn't itself).
     */
    private fun evaluateTargetIsSource(
        condition: TargetIsSource,
        context: EffectContext
    ): Boolean {
        val sourceId = context.sourceId ?: return false
        val target = context.positionalTarget(condition.targetIndex) ?: return false
        val entityId = (target as? com.wingedsheep.engine.state.components.stack.ChosenTarget.Permanent)
            ?.entityId ?: return false
        return entityId == sourceId
    }

    private fun evaluateTargetMarkedDamageExceedsToughness(
        state: GameState,
        condition: TargetMarkedDamageExceedsToughness,
        context: EffectContext
    ): Boolean {
        val target = context.positionalTarget(condition.targetIndex) ?: return false
        val entityId = (target as? com.wingedsheep.engine.state.components.stack.ChosenTarget.Permanent)
            ?.entityId ?: return false
        if (entityId !in state.getBattlefield()) return false
        val projected = state.projectedState
        if (!projected.isCreature(entityId)) return false
        val marked = state.getEntity(entityId)
            ?.get<com.wingedsheep.engine.state.components.battlefield.DamageComponent>()
            ?.amount ?: 0
        val toughness = projected.getToughness(entityId) ?: return false
        return marked > toughness
    }

    /**
     * CR-style "most common color among all permanents": tally each of the five colors across
     * every battlefield permanent (multicolored permanents count once per color), find the
     * highest tally, and check whether the targeted permanent shares any color tied for that
     * highest tally. Uses projected colors so color-changing continuous effects are respected.
     */
    private fun evaluateTargetSharesMostCommonColor(
        state: GameState,
        condition: TargetSharesMostCommonColor,
        context: EffectContext
    ): Boolean {
        val target = context.positionalTarget(condition.targetIndex) ?: return false
        val entityId = (target as? com.wingedsheep.engine.state.components.stack.ChosenTarget.Permanent)
            ?.entityId ?: return false
        val projected = state.projectedState
        return projected.getColors(entityId).any { it in mostCommonColors(state, projected) }
    }

    /**
     * "If another permanent with the same name as the target is on the battlefield": resolve the
     * target permanent, read its card name, and return true when at least one *other* battlefield
     * permanent shares that exact name. The target itself is excluded so a single copy never
     * satisfies its own check.
     *
     * A face-down permanent has no name (CR 708.2), so it neither matches anything (as the target)
     * nor counts as a same-named permanent (as a candidate) — face-down entities are skipped on
     * both sides even though they retain a hidden [CardComponent.name].
     */
    private fun evaluateAnotherPermanentWithSameNameAsTarget(
        state: GameState,
        condition: AnotherPermanentWithSameNameAsTarget,
        context: EffectContext
    ): Boolean {
        val target = context.positionalTarget(condition.targetIndex) ?: return false
        val entityId = (target as? com.wingedsheep.engine.state.components.stack.ChosenTarget.Permanent)
            ?.entityId ?: return false
        val targetEntity = state.getEntity(entityId) ?: return false
        if (targetEntity.has<FaceDownComponent>()) return false
        val targetName = targetEntity.get<CardComponent>()?.name ?: return false
        return state.getBattlefield().any { otherId ->
            if (otherId == entityId) return@any false
            val other = state.getEntity(otherId) ?: return@any false
            !other.has<FaceDownComponent>() && other.get<CardComponent>()?.name == targetName
        }
    }

    /**
     * The set of colors tied for most common among all battlefield permanents. Colors are the
     * projected-state color strings (`Color.name`); a multicolored permanent contributes to each
     * of its colors. Empty when no permanent has a color.
     */
    private fun mostCommonColors(state: GameState, projected: ProjectedState): Set<String> {
        val colorCounts = mutableMapOf<String, Int>()
        for (permanentId in state.getBattlefield()) {
            for (color in projected.getColors(permanentId)) {
                colorCounts[color] = (colorCounts[color] ?: 0) + 1
            }
        }
        val maxCount = colorCounts.values.maxOrNull() ?: return emptySet()
        if (maxCount == 0) return emptySet()
        return colorCounts.filterValues { it == maxCount }.keys
    }

    private fun evaluateTriggeringSpellFilterMatch(
        state: GameState,
        filter: GameObjectFilter,
        context: EffectContext
    ): Boolean {
        // Match the triggering spell by its static card characteristics so the check stays correct
        // even after the spell has left the stack. Composes with PlayerCastSpellsThisTurn (via
        // Conditions.YouCastFirstSpellOfTypeThisTurn) to express "first X spell this turn" — this
        // guard is what stops a non-matching cast from satisfying that count-based payoff.
        val triggeringId = context.triggeringEntityId ?: return false
        val entity = state.getEntity(triggeringId) ?: return false
        val card = entity.get<CardComponent>() ?: return false
        val triggeringRecord = CastSpellRecord(
            typeLine = card.typeLine,
            manaValue = card.manaValue,
            colors = card.colors,
            isFaceDown = entity.has<com.wingedsheep.engine.state.components.identity.FaceDownComponent>(),
            name = card.name
        )
        return PredicateEvaluator().matchesFilter(triggeringRecord, filter)
    }

    private fun evaluateFirstSpellPaidWithTreasureMana(
        state: GameState,
        context: EffectContext
    ): Boolean {
        val records = state.spellsCastThisTurnByPlayer[context.controllerId] ?: return false
        return records.count { com.wingedsheep.sdk.core.Subtype.TREASURE in it.spentManaSubtypes } == 1 &&
            records.lastOrNull()?.spentManaSubtypes?.contains(com.wingedsheep.sdk.core.Subtype.TREASURE) == true
    }

    private fun evaluateSourceAbilityResolvedNTimes(
        state: GameState,
        condition: SourceAbilityResolvedNTimesThisTurn,
        context: EffectContext
    ): Boolean {
        val sourceId = context.sourceId ?: return false
        val component = state.getEntity(sourceId)
            ?.get<com.wingedsheep.engine.state.components.battlefield.AbilityResolutionCountThisTurnComponent>()
            ?: return false
        return component.count == condition.count
    }

    private fun evaluateCollectionContainsMatch(
        state: GameState,
        condition: CollectionContainsMatch,
        context: EffectContext
    ): Boolean {
        val collection = context.pipeline.storedCollections[condition.collection] ?: return false
        if (collection.isEmpty()) return false
        if (condition.filter == GameObjectFilter.Any) return true
        val predicateEvaluator = PredicateEvaluator()
        val predicateContext = PredicateContext.fromEffectContext(context)
        return collection.any { entityId ->
            predicateEvaluator.matches(state, state.projectedState, entityId, condition.filter, predicateContext)
        }
    }

    /**
     * CR 205.2a — two cards "share a card type" when their printed card-type sets intersect.
     * True iff some card type appears on at least two distinct cards in the collection. Reads the
     * cards' printed [com.wingedsheep.sdk.core.CardType]s (the cards are off the battlefield — in
     * the graveyard after a mill — so base characteristics are the right source).
     */
    private fun evaluateCollectionSharesCardType(
        state: GameState,
        condition: CollectionSharesCardType,
        context: EffectContext
    ): Boolean {
        val collection = context.pipeline.storedCollections[condition.collection] ?: return false
        if (collection.size < 2) return false
        val seenTypes = mutableSetOf<com.wingedsheep.sdk.core.CardType>()
        for (entityId in collection) {
            val cardTypes = state.getEntity(entityId)?.get<CardComponent>()?.typeLine?.cardTypes ?: continue
            if (cardTypes.any { it in seenTypes }) return true
            seenTypes += cardTypes
        }
        return false
    }
}
