package com.wingedsheep.engine.mechanics.layers

import com.wingedsheep.engine.handlers.DynamicAmountEvaluator
import com.wingedsheep.engine.handlers.EffectContext
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.battlefield.CantBeBlockedWhilePropertyAtMostComponent
import com.wingedsheep.engine.state.components.battlefield.CountersComponent
import com.wingedsheep.engine.state.components.battlefield.DashedComponent
import com.wingedsheep.engine.state.components.battlefield.TappedComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.battlefield.chosenCreatureType
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.engine.state.components.identity.FaceDownComponent
import com.wingedsheep.engine.state.components.identity.FaceDownModeComponent
import com.wingedsheep.engine.state.components.identity.HexproofFromComponent
import com.wingedsheep.engine.state.components.identity.ProtectionComponent
import com.wingedsheep.engine.state.components.identity.RingBearerComponent
import com.wingedsheep.engine.state.components.identity.ToxicComponent
import com.wingedsheep.engine.state.components.identity.TextReplacementComponent
import com.wingedsheep.sdk.core.AbilityFlag
import com.wingedsheep.sdk.core.CounterType
import com.wingedsheep.sdk.scripting.Duration
import com.wingedsheep.sdk.core.Keyword
import com.wingedsheep.sdk.core.Subtype
import com.wingedsheep.sdk.model.CharacteristicValue
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.values.DynamicAmount

/**
 * Projects the game state by applying continuous effects in layer order (Rule 613).
 *
 * The StateProjector transforms "base state" (stored components) into
 * "projected state" (what the game sees after all effects are applied).
 *
 * Layer Order:
 * 1. Copy effects
 * 2. Control-changing effects
 * 3. Text-changing effects
 * 4. Type-changing effects
 * 5. Color-changing effects
 * 6. Ability-adding/removing effects
 * 7. Power/toughness modifications
 *    a. Characteristic-defining abilities
 *    b. Setting P/T to specific values
 *    c. Modifications from +N/+N effects
 *    d. Counters (+1/+1, -1/-1)
 *    e. Effects that switch P/T
 */
/**
 * Mapping from keyword counter types to the keyword name they grant (Rule 122.1b).
 */
private val KEYWORD_COUNTER_MAP = mapOf(
    CounterType.FLYING to Keyword.FLYING.name,
    CounterType.FIRST_STRIKE to Keyword.FIRST_STRIKE.name,
    CounterType.DOUBLE_STRIKE to Keyword.DOUBLE_STRIKE.name,
    CounterType.VIGILANCE to Keyword.VIGILANCE.name,
    CounterType.LIFELINK to Keyword.LIFELINK.name,
    CounterType.INDESTRUCTIBLE to Keyword.INDESTRUCTIBLE.name,
    CounterType.DEATHTOUCH to Keyword.DEATHTOUCH.name,
    CounterType.TRAMPLE to Keyword.TRAMPLE.name,
    CounterType.HEXPROOF to Keyword.HEXPROOF.name,
    CounterType.REACH to Keyword.REACH.name,
    CounterType.HASTE to Keyword.HASTE.name,
    CounterType.MENACE to Keyword.MENACE.name
)

class StateProjector(
    // Inject an empty projection as the supplier — reaching for [GameState.projectedState]
    // here would re-enter our own lazy initializer. Mid-layer callers thread their
    // intermediate snapshot through the `projectedState` parameter explicitly; the empty
    // supplier is the safety net for paths that don't carry one (predicate matching falls
    // back to base CardComponent for missing entries).
    private val dynamicAmountEvaluator: DynamicAmountEvaluator = DynamicAmountEvaluator(
        defaultProjection = { ProjectedState(it, emptyMap()) }
    )
) {
    private val filterResolver = AffectsFilterResolver()
    private val effectApplicator = EffectApplicator(dynamicAmountEvaluator)
    private val effectSorter = EffectSorter()

    /**
     * Project the full game state with all continuous effects applied.
     */
    fun project(state: GameState): ProjectedState = project(state, state, null)

    /**
     * CR 614.12: inspect an entering permanent as it would exist, before its entry happens.
     * Existing continuous effects and its own self-applicable static effects determine its
     * characteristics. Battlefield aggregates and history still read [beforeEntry], so the
     * entering object does not contribute devotion or an entry event to its own replacement.
     * [prepared] supplies only the entering object's chosen face and prepared components.
     * The hypothetical zone insertion is immutable and emits no event or entry record.
     */
    fun projectForEntry(
        beforeEntry: GameState,
        prepared: GameState,
        enteringId: EntityId,
        controllerId: EntityId,
    ): ProjectedState {
        require(enteringId !in beforeEntry.allBattlefieldEntities()) {
            "Entry projection requires the state captured before battlefield placement"
        }
        val entering = requireNotNull(prepared.getEntity(enteringId))
        val evaluationState = beforeEntry.withEntity(enteringId, entering)
        val subjectState = evaluationState.addToZone(
            com.wingedsheep.engine.state.ZoneKey(controllerId, com.wingedsheep.sdk.core.Zone.BATTLEFIELD),
            enteringId,
        )
        return project(subjectState, evaluationState, enteringId)
    }

    private fun project(state: GameState, evaluationState: GameState, enteringId: EntityId?): ProjectedState {
        val projectedValues = mutableMapOf<EntityId, MutableProjectedValues>()
        val dynamicStatEntities = mutableListOf<Pair<EntityId, CardComponent>>()

        // Initialize all permanents with their base values
        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val cardComponent = container.get<CardComponent>() ?: continue

            if (container.has<FaceDownComponent>()) {
                // CR 708.2 / 708.2a: a face-down permanent has no characteristics beyond those the
                // rules that made it face down list — 2/2 creature, no name, subtypes or mana cost.
                // Disguise (CR 702.168a) and cloak (CR 701.58a) list one more: ward {2}. It is part
                // of this characteristic-defining effect, not an ability of the card underneath,
                // so it lives on the mode and ends the moment the permanent is turned face up.
                val faceDownWard = container.get<FaceDownModeComponent>()?.mode?.faceDownWard
                projectedValues[entityId] = MutableProjectedValues(
                    power = 2,
                    toughness = 2,
                    keywords = if (faceDownWard != null) {
                        mutableSetOf(Keyword.WARD.name)
                    } else {
                        mutableSetOf()
                    },
                    colors = mutableSetOf(),
                    types = mutableSetOf("CREATURE"),
                    subtypes = mutableSetOf(),
                    controllerId = container.get<ControllerComponent>()?.playerId,
                    isFaceDown = true
                )
            } else {
                val baseStats = cardComponent.baseStats
                projectedValues[entityId] = MutableProjectedValues(
                    power = baseStats?.basePower,
                    toughness = baseStats?.baseToughness,
                    keywords = linkedSetOf<String>().apply {
                        cardComponent.baseKeywords.forEach { add(it.name) }
                        cardComponent.baseFlags.forEach { add(it.name) }
                        container.get<ProtectionComponent>()?.let { protection ->
                            protection.colors.forEach { add("PROTECTION_FROM_${it.name}") }
                            protection.subtypes.forEach { add("PROTECTION_FROM_SUBTYPE_${it.uppercase()}") }
                            protection.supertypes.forEach { add("PROTECTION_FROM_SUPERTYPE_${it.uppercase()}") }
                            protection.cardTypes.forEach { add("PROTECTION_FROM_CARDTYPE_$it") }
                        }
                        container.get<HexproofFromComponent>()?.let { hexproof ->
                            hexproof.colors.forEach { add("HEXPROOF_FROM_${it.name}") }
                            hexproof.cardTypes.forEach { add("HEXPROOF_FROM_CARDTYPE_$it") }
                        }
                        container.get<ToxicComponent>()?.let { add("TOXIC_${it.amount}") }
                        // Dash supplies haste from the live marker on every projection.
                        if (container.has<DashedComponent>()) add(Keyword.HASTE.name)
                    },
                    colors = cardComponent.colors.mapTo(linkedSetOf()) { it.name },
                    types = extractTypes(cardComponent),
                    subtypes = cardComponent.typeLine.subtypes.mapTo(linkedSetOf()) { it.value },
                    controllerId = container.get<ControllerComponent>()?.playerId,
                    isFaceDown = false
                )

                // Rule 122.1b: Keyword counters grant their keyword
                val countersComponent = container.get<CountersComponent>()
                if (countersComponent != null) {
                    KEYWORD_COUNTER_MAP.forEach { (counterType, keywordName) ->
                        if (countersComponent.getCount(counterType) > 0) {
                            projectedValues[entityId]?.keywords?.add(keywordName)
                        }
                    }
                    // CR 702.147a: a decayed counter grants the Decayed keyword ability — the
                    // "can't block" static half is realized here (the attack-triggered "sacrifice
                    // at end of combat" half is detected by TriggerDetector off the counter).
                    if (countersComponent.getCount(CounterType.DECAYED) > 0) {
                        projectedValues[entityId]?.let {
                            it.keywords.add(Keyword.DECAYED.name)
                            it.cantBlock = true
                        }
                    }
                }

                if (Keyword.CHANGELING in cardComponent.baseKeywords) {
                    projectedValues[entityId]?.subtypes?.addAll(Subtype.ALL_CREATURE_TYPES)
                }

                if (baseStats?.isDynamic == true) {
                    dynamicStatEntities.add(entityId to cardComponent)
                }
            }
        }

        // Apply Layer 3 text-changing effects (TextReplacementComponent)
        applyTextReplacements(state, projectedValues)

        // Collect all active continuous effects
        val effects = collectContinuousEffects(state, projectedValues)

        // Sort effects by layer and dependency
        val sortedEffects = effectSorter.sortByLayerAndDependency(effects, state)

        // CR 613.6 group locking. A single multi-layer static ability lowers to several effects
        // that share a groupId (within one source permanent). Such an effect must affect the *same
        // set of objects* in every layer it applies in, with that set locked in when it first
        // starts to apply. [lockAffected] records the affected set the first time a group is
        // resolved (bands run in ascending layer order, so that's the group's earliest layer) and
        // returns that frozen set for every later layer, ignoring per-layer re-resolution. Keyed by
        // (sourceId, groupId) so the same groupId on two permanents never merges. A no-op (returns
        // the freshly-resolved set) for ungrouped single-layer effects.
        val lockedGroups = HashMap<Pair<EntityId, String>, Set<EntityId>>()
        fun lockAffected(effect: ContinuousEffect, resolved: Set<EntityId>): Set<EntityId> {
            // A not-yet-entered source may apply its static ability to itself, but cannot
            // change other permanents before entering. Resolved floating effects are separate.
            val eligible = if (enteringId != null && effect.fromStaticAbility && effect.sourceId == enteringId) {
                resolved.intersect(setOf(enteringId))
            } else resolved
            val groupId = effect.groupId ?: return eligible
            return lockedGroups.getOrPut(effect.sourceId to groupId) { eligible }
        }

        // Earliest layer each group starts to apply. Per CR 613.6, a group that started applying
        // before Layer 6 keeps applying its later-layer parts "even if the ability generating the
        // effect is removed during this process" — used below to exempt such groups from the
        // Layer-7 lose-all-abilities suppression.
        val groupFirstLayer = HashMap<Pair<EntityId, String>, Layer>()
        for (effect in sortedEffects) {
            val groupId = effect.groupId ?: continue
            val key = effect.sourceId to groupId
            val existing = groupFirstLayer[key]
            if (existing == null || effect.layer.ordinal < existing.ordinal) {
                groupFirstLayer[key] = effect.layer
            }
        }

        // === Layer 2 (Control) ===
        // The controller gates are applied *inside* the loop rather than to the whole list first,
        // so each control effect is judged against the control state as it stands at its own
        // timestamp (CR 613.1b) — an earlier steal of the source is visible to a later effect's
        // "for as long as you control this permanent" gate. Seasinger's
        // [Duration.WhileYouControlSourceAndSourceTapped] is the case that needs it: losing
        // Seasinger has to hand the borrowed creature back, and its own effect lives in this layer.
        val controlEffects = sortedEffects.filter { it.layer == Layer.CONTROL }
        for (rawEffect in controlEffects) {
            val effect = applyControllerGate(rawEffect, projectedValues)
            effectApplicator.applyEffect(effect.copy(affectedEntities = lockAffected(effect, effect.affectedEntities)), evaluationState, projectedValues)
        }

        // Re-resolve controller-dependent filters for layers 3-6 now that control is established
        val nonControlNonPTEffects = sortedEffects.filter { it.layer != Layer.CONTROL && it.layer != Layer.POWER_TOUGHNESS }
            .map { effect -> applyControllerGate(effect, projectedValues) }
            .map { effect ->
                val resolved = if (effect.affectsFilter != null && filterResolver.isControllerDependentFilter(effect.affectsFilter)) {
                    filterResolver.resolveAffectedEntities(state, effect.sourceId, effect.affectsFilter, projectedValues)
                } else {
                    effect.affectedEntities
                }
                effect.copy(affectedEntities = lockAffected(effect, resolved))
            }

        // === Layers 3-4 (Text + Type) ===
        // Apply type-changing effects first so creature-dependent filters in layers 5-6
        // see permanents that became creatures (e.g., Opalescence making enchantments creatures).
        //
        // Layer 4 is not one flat pass, because CR 613.8a dependencies exist *inside* it: an effect
        // whose affected set reads creature status ("Vehicle creatures you control" — Lifecraft
        // Engine) depends on the Layer-4 effects that grant or remove the CREATURE type (crew's
        // animation, Opalescence), since applying those changes which permanents it applies to. Such
        // an effect therefore applies after them whatever its timestamp, with its filter re-resolved
        // once they have landed — the same two-phase trick this method already uses between layer
        // bands. Effects whose filters don't read creature status keep plain timestamp order among
        // themselves, and a locked CR 613.6 group keeps its frozen set through the re-resolve.
        val typeLayerEffects = nonControlNonPTEffects.filter { it.layer == Layer.TEXT || it.layer == Layer.TYPE }
        val (creatureDependentTypeEffects, plainTypeEffects) = typeLayerEffects.partition { effect ->
            val filter = effect.affectsFilter
            filter != null && filterResolver.isCreatureDependentFilter(filter)
        }
        for (effect in plainTypeEffects) {
            effectApplicator.applyEffect(effect, evaluationState, projectedValues)
        }
        for (effect in creatureDependentTypeEffects) {
            val resolved = effect.affectsFilter
                ?.let { filterResolver.resolveAffectedEntities(state, effect.sourceId, it, projectedValues) }
                ?: effect.affectedEntities
            effectApplicator.applyEffect(
                effect.copy(affectedEntities = lockAffected(effect, resolved)),
                evaluationState,
                projectedValues
            )
        }

        // CR 701.54c: a player's Ring-bearer is legendary (the Ring emblem's first ability).
        // Applied here as a type-changing (Layer 4) effect, after Layer 2 control is established, so
        // it reads the *projected* controller: "is your Ring-bearer" requires the creature to still
        // be under its designator's control (CR 701.54e), so a Ring-bearer stolen by a control-
        // changing effect stops being legendary. isLegendary() reads the projected type set, so
        // adding "LEGENDARY" suffices, and it follows whichever creature currently holds the
        // designation.
        for (entityId in state.getBattlefield()) {
            val bearer = state.getEntity(entityId)?.get<RingBearerComponent>() ?: continue
            if (projectedValues[entityId]?.controllerId == bearer.ownerId) {
                projectedValues[entityId]?.types?.add("LEGENDARY")
            }
        }

        // Re-resolve creature-dependent filters for layers 5-6 now that type changes are applied.
        // A grouped effect keeps its locked set (CR 613.6) — [lockAffected] ignores this re-resolve
        // for any group already frozen at an earlier layer.
        val postTypeEffects = nonControlNonPTEffects.filter { it.layer != Layer.TEXT && it.layer != Layer.TYPE }
            .map { effect ->
                val resolved = if (effect.affectsFilter != null && filterResolver.isCreatureDependentFilter(effect.affectsFilter)) {
                    filterResolver.resolveAffectedEntities(state, effect.sourceId, effect.affectsFilter, projectedValues)
                } else {
                    effect.affectedEntities
                }
                effect.copy(affectedEntities = lockAffected(effect, resolved))
            }

        // === Layers 5-6 (Color + Ability) ===
        for (effect in postTypeEffects) {
            effectApplicator.applyEffect(effect, evaluationState, projectedValues)
        }

        // Rule 122.1b: re-apply keyword counters after Layer 6.
        // Counters that grant a keyword are themselves abilities of the object. When a "loses
        // all abilities" effect (Layer 6) was applied above, those counter-granted keywords
        // were wiped. Counter placement is generally later than (or part of the same effect as)
        // the lose-all-abilities effect (e.g., Abigale, Eloquent First-Year), so the counter
        // grant must win. Re-applying here is a pragmatic stand-in for proper Layer 6
        // timestamp ordering of counter-granted keywords.
        for ((entityId, values) in projectedValues) {
            val countersComponent = state.getEntity(entityId)?.get<CountersComponent>() ?: continue
            KEYWORD_COUNTER_MAP.forEach { (counterType, keywordName) ->
                if (countersComponent.getCount(counterType) > 0) {
                    values.keywords.add(keywordName)
                }
            }
            // Re-apply the decayed counter's Decayed grant after Layer 6 for the same reason
            // (a "loses all abilities" effect must not wipe a counter-granted ability).
            if (countersComponent.getCount(CounterType.DECAYED) > 0) {
                values.keywords.add(Keyword.DECAYED.name)
                values.cantBlock = true
            }
        }

        // Resolve CDAs (Layer 7a) - evaluate dynamic power/toughness
        resolveCDAs(evaluationState, projectedValues, dynamicStatEntities)

        // Collect sources that generate RemoveAllAbilities effects. These sources (e.g., Humility)
        // should not have their own effects suppressed even when they themselves lose abilities,
        // because their continuous effects are self-sustaining (removing the ability that removes
        // abilities would create a paradox).
        val removeAllAbilitiesSources = sortedEffects
            .filter { it.modification is Modification.RemoveAllAbilities }
            .map { it.sourceId }
            .toSet()

        // Re-resolve affected entities for Layer 7 effects that depend on subtypes, controller, or creature type.
        // Also suppress effects from sources that lost all abilities in Layer 6 (Rule 613: Humility
        // removing a lord's abilities means its continuous effects no longer apply in Layer 7).
        // Exception: sources that themselves generate RemoveAllAbilities are exempt — their effects
        // are self-sustaining (e.g., Humility's own P/T-setting effect persists).
        val resolvedLayer7Effects = sortedEffects.mapNotNull { rawEffect ->
            val effect = applyControllerGate(rawEffect, projectedValues)
            if (effect.layer != Layer.POWER_TOUGHNESS) return@mapNotNull effect

            // CR 613.6: a grouped effect that started applying before Layer 6 keeps applying its
            // Layer-7 part "even if the ability generating the effect is removed during this
            // process" (e.g. Bello's 4/4 set survives Bello losing all abilities). Only such
            // groups are exempt — a standalone P/T static (a lord anthem removed by Humility) has
            // no earlier-layer part and is still suppressed below.
            val startedBeforeAbility = effect.groupId?.let { groupId ->
                (groupFirstLayer[effect.sourceId to groupId]?.ordinal ?: Int.MAX_VALUE) < Layer.ABILITY.ordinal
            } ?: false

            // Suppress effects from sources that lost all abilities (e.g., a lord under Humility),
            // but NOT from sources that are themselves the source of a RemoveAllAbilities effect,
            // nor from a multi-layer group that already started applying before Layer 6.
            //
            // Only *static* abilities are suppressed (CR 611.3b — a static ability generates its
            // effect only for as long as the object has that ability). A continuous effect created
            // by a resolved spell or ability lasts as long as it says it does (CR 611.2a) and is
            // independent of the source's abilities: a Timid Shieldbearer that pumped your team
            // and then lost all its abilities to Curious Colossus keeps the +1/+1 it already gave,
            // exactly as Humility never undoes a Giant Growth that already resolved.
            val sourceProjected = projectedValues[effect.sourceId]
            if (effect.fromStaticAbility && sourceProjected != null && sourceProjected.lostAllAbilities &&
                effect.sourceId !in removeAllAbilitiesSources && !startedBeforeAbility) {
                return@mapNotNull null
            }

            val resolved = if (effect.affectsFilter != null &&
                (filterResolver.isSubtypeDependentFilter(effect.affectsFilter) ||
                    filterResolver.isControllerDependentFilter(effect.affectsFilter) ||
                    filterResolver.isCreatureDependentFilter(effect.affectsFilter))) {
                filterResolver.resolveAffectedEntities(state, effect.sourceId, effect.affectsFilter, projectedValues)
            } else {
                effect.affectedEntities
            }
            effect.copy(affectedEntities = lockAffected(effect, resolved))
        }

        // Apply layer 7 continuous effects
        for (effect in resolvedLayer7Effects) {
            if (effect.layer == Layer.POWER_TOUGHNESS) {
                effectApplicator.applyEffect(effect, evaluationState, projectedValues)
            }
        }

        // Apply counters (layer 7d)
        effectApplicator.applyCounters(state, projectedValues)

        // Post-layer pass: grant CANT_BE_BLOCKED to creatures qualifying via
        // CantBeBlockedWhilePropertyAtMost (Tetsuko Umezawa, Fugitive; Stature, Size Shifter).
        // Must happen after all P/T layers so projected power/toughness is final.
        applyCantBeBlockedWhilePropertyAtMost(state, projectedValues, enteringId)

        // Post-layer pass: enforce the affected-power half of
        // [Duration.WhileSourceTappedAndAffectedPowerAtMostSource] (Old Man of the Sea).
        // We could only apply the source-tapped half during Layer 2 collection because Layer 7
        // hadn't projected power yet. Now that final projected power is known, walk the floating
        // effects with this Duration and revert the controller change for any affected entity
        // whose projected power exceeds the source's projected power. This catches every pump
        // source — base printed power, +1/+1 / -1/-1 counters, Layer-7 floating pumps (Giant
        // Growth, Aggressive Urge), and lord-style anthems alike.
        applyAffectedPowerAtMostSourceGate(state, projectedValues)

        // Transfer the locally owned sets into the final projection. No later step mutates them;
        // intermediate projections still copy their sets because subsequent layers can change them.
        val finalValues = projectedValues.mapValues { (_, v) ->
            ProjectedValues(
                power = v.power,
                toughness = v.toughness,
                name = v.name,
                keywords = v.keywords,
                colors = v.colors,
                types = v.types,
                subtypes = v.subtypes,
                controllerId = v.controllerId,
                isFaceDown = v.isFaceDown,
                isSuspected = v.isSuspected,
                cantAttack = v.cantAttack,
                cantBlock = v.cantBlock,
                cantBeTurnedFaceUp = v.cantBeTurnedFaceUp,
                mustAttack = v.mustAttack,
                mustBlock = v.mustBlock,
                cantBeBlockedExceptByFilters = v.cantBeBlockedExceptByFilters.toList(),
                canOnlyBlockCreaturesWithFilters = v.canOnlyBlockCreaturesWithFilters.toList(),
                additionalBlockCount = v.additionalBlockCount,
                lostAllAbilities = v.lostAllAbilities,
                basicLandTypesSetByEffect = v.basicLandTypesSetByEffect
            )
        }

        // Collect cross-zone "is the chosen type" grants (Conspiracy / Leyline of Transformation).
        // A GrantChosenSubtype with cross-zone flags lowers to a Modification.AddChosenSubtype whose
        // Layer 4 application above only touched battlefield permanents; here we additionally record
        // an overlay entry so the non-battlefield subtype read-sites (spells on the stack, cards in
        // hand/library/graveyard/exile) can honor it. Reads the source's *projected* controller (so
        // it follows control changes) and the creature type it was made with.
        val crossZoneGrants = sortedEffects.mapNotNull { effect ->
            if (effect.fromStaticAbility && effect.sourceId == enteringId) return@mapNotNull null
            val mod = effect.modification as? Modification.AddChosenSubtype ?: return@mapNotNull null
            if (!mod.includeControlledSpells && !mod.includeOwnedCardsOutsideBattlefield) return@mapNotNull null
            val controllerId = projectedValues[effect.sourceId]?.controllerId ?: return@mapNotNull null
            val chosenType = state.getEntity(effect.sourceId)?.chosenCreatureType() ?: return@mapNotNull null
            CrossZoneSubtypeGrant(
                controllerId = controllerId,
                chosenType = chosenType,
                includeControlledSpells = mod.includeControlledSpells,
                includeOwnedCardsOutsideBattlefield = mod.includeOwnedCardsOutsideBattlefield
            )
        }

        return ProjectedState(state, finalValues, crossZoneGrants)
    }

    fun getProjectedPower(state: GameState, entityId: EntityId): Int {
        val projected = project(state)
        return projected.getPower(entityId) ?: 0
    }

    fun getProjectedToughness(state: GameState, entityId: EntityId): Int {
        val projected = project(state)
        return projected.getToughness(entityId) ?: 0
    }

    fun getProjectedKeywords(state: GameState, entityId: EntityId): Set<Keyword> {
        val projected = project(state)
        return projected.getKeywords(entityId).mapNotNull { keywordName ->
            try {
                Keyword.valueOf(keywordName)
            } catch (e: IllegalArgumentException) {
                null
            }
        }.toSet()
    }

    fun hasProjectedKeyword(state: GameState, entityId: EntityId, keyword: Keyword): Boolean {
        val projected = project(state)
        return projected.hasKeyword(entityId, keyword)
    }

    private fun applyTextReplacements(
        state: GameState,
        projectedValues: MutableMap<EntityId, MutableProjectedValues>
    ) {
        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val textReplacement = container.get<TextReplacementComponent>() ?: continue
            val values = projectedValues[entityId] ?: continue

            val transformedSubtypes = values.subtypes.map { textReplacement.applyToCreatureType(it) }.toMutableSet()
            values.subtypes.clear()
            values.subtypes.addAll(transformedSubtypes)

            val oldSubtypesInTypes = values.types.filter { type ->
                container.get<CardComponent>()?.typeLine?.subtypes?.any { it.value == type } == true
            }.toSet()
            values.types.removeAll(oldSubtypesInTypes)
            values.types.addAll(transformedSubtypes)

            val protectionSubtypePrefix = "PROTECTION_FROM_SUBTYPE_"
            val protectionKeywords = values.keywords.filter { it.startsWith(protectionSubtypePrefix) }
            for (keyword in protectionKeywords) {
                val originalSubtype = keyword.removePrefix(protectionSubtypePrefix)
                val transformed = textReplacement.applyToCreatureType(originalSubtype).uppercase()
                if (transformed != originalSubtype) {
                    values.keywords.remove(keyword)
                    values.keywords.add("$protectionSubtypePrefix$transformed")
                }
            }

            // Rewrite protection-from-color keywords for color-word changes (Crystal Spray:
            // "protection from red" -> "protection from blue"). Color protection keywords are
            // "PROTECTION_FROM_<COLOR.name>"; skip the SUBTYPE_/SUPERTYPE_ variants by only
            // matching suffixes that name an actual Color.
            val colorPrefix = "PROTECTION_FROM_"
            val colorProtectionKeywords = values.keywords.filter { kw ->
                kw.startsWith(colorPrefix) &&
                    com.wingedsheep.sdk.core.Color.entries.any { it.name == kw.removePrefix(colorPrefix) }
            }
            for (keyword in colorProtectionKeywords) {
                val originalColor = com.wingedsheep.sdk.core.Color.valueOf(keyword.removePrefix(colorPrefix))
                val transformed = textReplacement.replaceColor(originalColor)
                if (transformed != originalColor) {
                    values.keywords.remove(keyword)
                    values.keywords.add("$colorPrefix${transformed.name}")
                }
            }
        }
    }

    private fun extractTypes(card: CardComponent): MutableSet<String> {
        val types = linkedSetOf<String>()
        card.typeLine.supertypes.forEach { types.add(it.name) }
        card.typeLine.cardTypes.forEach { types.add(it.name) }
        card.typeLine.subtypes.forEach { types.add(it.value) }
        return types
    }

    /**
     * Enforce [ContinuousEffect.controllerGate] ("for as long as you control it") and
     * [ContinuousEffect.sourceControllerGate] ("for as long as you control this [source]").
     * Called after Layer 2 control is resolved, so it reflects every control-changing effect
     * (steals, Threaten, static control Auras). A no-op for effects without either gate.
     *
     * The two gates differ in *what* they watch: [controllerGate] drops the affected entities
     * whose own controller drifted; [sourceControllerGate] drops the entire effect if the
     * source's controller drifted.
     */
    private fun applyControllerGate(
        effect: ContinuousEffect,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): ContinuousEffect {
        // Source-controller gate first — failure wipes the whole effect, so the per-affected gate
        // below has nothing left to do.
        val sourceGate = effect.sourceControllerGate
        if (sourceGate != null) {
            val sourceController = projectedValues[effect.sourceId]?.controllerId
            if (sourceController != sourceGate) {
                return if (effect.affectedEntities.isEmpty()) effect
                else effect.copy(affectedEntities = emptySet())
            }
        }
        val gate = effect.controllerGate ?: return effect
        val stillControlled = effect.affectedEntities.filterTo(mutableSetOf()) { entityId ->
            projectedValues[entityId]?.controllerId == gate
        }
        return if (stillControlled.size == effect.affectedEntities.size) {
            effect
        } else {
            effect.copy(affectedEntities = stillControlled)
        }
    }

    private fun collectContinuousEffects(
        state: GameState,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): List<ContinuousEffect> {
        val effects = mutableListOf<ContinuousEffect>()

        // 1. Collect effects from static abilities on permanents
        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val continuousEffectComponent = container.get<ContinuousEffectSourceComponent>()
            if (continuousEffectComponent != null) {
                val textReplacement = container.get<TextReplacementComponent>()
                effects.addAll(continuousEffectComponent.effects.map { effect ->
                    val effectiveFilter = if (textReplacement != null && effect.affectsFilter != null) {
                        effect.affectsFilter.applyTextReplacement(textReplacement)
                    } else {
                        effect.affectsFilter
                    }
                    ContinuousEffect(
                        sourceId = entityId,
                        timestamp = container.get<com.wingedsheep.engine.state.components.battlefield.TimestampComponent>()?.timestamp
                            ?: state.timestamp,
                        modification = effect.modification,
                        affectedEntities = filterResolver.resolveAffectedEntities(state, entityId, effectiveFilter, projectedValues),
                        sourceCondition = effect.sourceCondition,
                        affectsFilter = effectiveFilter,
                        groupId = effect.groupId
                    )
                })
            }
        }

        // 1b. Hone counters (CR 122.1j): "A hone counter on an Equipment gives +1/+0 to any
        // creature that Equipment is attached to." Synthesized here rather than lowered from a
        // static ability because the bonus belongs to the *counter*, not to the permanent holding
        // it — Dwalin, Weaponmaster puts a hone counter on *each* Equipment you control, and those
        // Equipment pump their equipped creature without ever mentioning hone.
        //
        // Layer 7c (CR 613.4c — "effects and counters that modify power and/or toughness"), so it
        // stacks additively with lords and lands after any Layer 7b base-setting effect.
        //
        // The Equipment check reads the in-progress projection, which at collection time holds base
        // types plus Layer 3 text changes; a Layer 4 effect that turned something into an Equipment
        // this same projection pass would not be seen. That matches how every other filter resolved
        // here behaves and no printed card reaches the case.
        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val honeCount = container.get<CountersComponent>()?.getCount(CounterType.HONE) ?: 0
            if (honeCount <= 0) continue
            if (projectedValues[entityId]?.subtypes?.contains(Subtype.EQUIPMENT.value) != true) continue
            // AttachedPermanent resolves to the empty set while the Equipment is unattached, so an
            // unequipped honed Equipment contributes nothing without a separate guard.
            val affected = filterResolver.resolveAffectedEntities(
                state,
                entityId,
                AffectsFilter.AttachedPermanent,
                projectedValues
            )
            if (affected.isEmpty()) continue
            effects.add(
                ContinuousEffect(
                    sourceId = entityId,
                    timestamp = container.get<com.wingedsheep.engine.state.components.battlefield.TimestampComponent>()?.timestamp
                        ?: state.timestamp,
                    modification = Modification.ModifyPowerToughness(honeCount, 0),
                    affectedEntities = affected,
                    affectsFilter = AffectsFilter.AttachedPermanent
                )
            )
        }

        // 2. Collect floating effects (from resolved spells like Giant Growth)
        for (floating in state.floatingEffects) {
            if (floating.duration is Duration.WhileSourceTapped) {
                val sourceId = floating.sourceId
                if (sourceId == null || !state.getBattlefield().contains(sourceId) ||
                    state.getEntity(sourceId)?.has<TappedComponent>() != true) {
                    continue
                }
            }
            if (floating.duration is Duration.WhileSourceTappedAndAffectedPowerAtMostSource) {
                val sourceId = floating.sourceId
                if (sourceId == null || !state.getBattlefield().contains(sourceId) ||
                    state.getEntity(sourceId)?.has<TappedComponent>() != true) {
                    continue
                }
            }
            if (floating.duration is Duration.WhileSourceOnBattlefield) {
                val sourceId = floating.sourceId
                if (sourceId == null || !state.getBattlefield().contains(sourceId)) {
                    continue
                }
            }
            if (floating.duration is Duration.WhileYouControlSource) {
                // Battlefield half of the gate; the source-controller half is deferred to a
                // post-Layer-2 sweep ([sourceControllerGate]) because Layer 2 hasn't run yet
                // at collection time.
                val sourceId = floating.sourceId
                if (sourceId == null || !state.getBattlefield().contains(sourceId)) {
                    continue
                }
            }
            // Seasinger — both halves at once. The battlefield and tapped halves are checkable
            // here; the source-controller half joins WhileYouControlSource's post-Layer-2 sweep.
            if (floating.duration is Duration.WhileYouControlSourceAndSourceTapped) {
                val sourceId = floating.sourceId
                if (sourceId == null || !state.getBattlefield().contains(sourceId) ||
                    state.getEntity(sourceId)?.has<TappedComponent>() != true
                ) {
                    continue
                }
            }
            // "for as long as [the source Aura/Equipment] remains attached to it" — gate the whole
            // effect on the source still being on the battlefield (CR 611.2b). The per-affected
            // "still attached to *this* entity" half is applied below.
            if (floating.duration is Duration.WhileSourceAttachedToAffected) {
                val sourceId = floating.sourceId
                if (sourceId == null || !state.getBattlefield().contains(sourceId)) {
                    continue
                }
            }

            var validAffectedEntities = if (floating.effect.dynamicGroupFilter != null) {
                // Rule 611.2c: re-evaluate filter dynamically to include entities that entered later
                filterResolver.resolveAffectedEntities(
                    state,
                    floating.sourceId ?: EntityId("floating-${floating.id}"),
                    AffectsFilter.Generic(floating.effect.dynamicGroupFilter),
                    projectedValues
                )
            } else {
                // Floating effects normally target battlefield permanents, but a color-change
                // effect can target a spell on the stack (Blind Seer). Stack entities are valid
                // affected targets so the recolor projects onto the spell during resolution; an
                // entity that has since left both zones is dropped (its effect is now inert).
                floating.effect.affectedEntities.filter { entityId ->
                    state.getBattlefield().contains(entityId) || state.stack.contains(entityId)
                }.toSet()
            }

            // Per-affected "still attached to this entity" half of
            // [Duration.WhileSourceAttachedToAffected]: drop any affected entity the source is no
            // longer attached to (source moved to a different host, or detached). The latch-off is
            // handled by EndedDurationExpiryCheck so a re-attach can't resurrect it.
            if (floating.duration is Duration.WhileSourceAttachedToAffected) {
                val attachedTo = floating.sourceId?.let {
                    state.getEntity(it)
                        ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                        ?.targetId
                }
                validAffectedEntities = validAffectedEntities.filterTo(LinkedHashSet()) { it == attachedTo }
            }

            // "for as long as it has a [X] counter on it" (Ultima, Origin of Oblivion): keep only
            // affected entities that currently carry the counter. Per-frame gate; the latch-off is
            // in EndedDurationExpiryCheck so removing then re-adding the counter can't resurrect it.
            (floating.duration as? Duration.WhileAffectedHasCounter)?.let { dur ->
                val counterType = CounterType.fromName(dur.counterType)
                validAffectedEntities = if (counterType == null) LinkedHashSet()
                    else validAffectedEntities.filterTo(LinkedHashSet()) { id ->
                        (state.getEntity(id)?.get<CountersComponent>()?.getCount(counterType) ?: 0) > 0
                    }
            }

            // "for as long as it remains tapped" (Braided Net): keep only affected entities that
            // are currently tapped. Per-frame gate; the latch-off is in EndedDurationExpiryCheck
            // so untapping then re-tapping can't resurrect it (CR 611.2b).
            if (floating.duration is Duration.WhileAffectedTapped) {
                validAffectedEntities = validAffectedEntities.filterTo(LinkedHashSet()) { id ->
                    state.getEntity(id)?.has<TappedComponent>() == true
                }
            }

            // The per-affected-entity power gate for
            // [Duration.WhileSourceTappedAndAffectedPowerAtMostSource] is deferred to a
            // post-Layer-7 fix-up in [project] — we can't compare projected power here
            // because Layer 7 hasn't run yet (and reading `state.projectedState` would
            // recurse). Include the effect now; the fix-up reverts control for any affected
            // entity whose final projected power exceeds the source's final projected power.

            if (validAffectedEntities.isNotEmpty()) {
                effects.add(
                    ContinuousEffect(
                        sourceId = floating.sourceId ?: EntityId("floating-${floating.id}"),
                        timestamp = floating.timestamp,
                        modification = floating.effect.modification.toModification(),
                        affectedEntities = validAffectedEntities,
                        // A conditional clause inside a durational grant ("becomes a creature with
                        // 'During your turn, this creature has first strike'"). Re-asked on every
                        // projection by EffectApplicator against the *source's* projected controller,
                        // so it goes dark on an opponent's turn or if the source is stolen — and
                        // comes back if that reverses. Distinct from the latching Duration.While…
                        // gates above.
                        sourceCondition = floating.effect.sourceCondition,
                        // "for as long as you control it" (e.g. suspend haste — CR 702.62g):
                        // the gate is applied after Layer 2, against the projected controller,
                        // so the effect drops the instant another player gains control.
                        controllerGate = if (floating.duration is Duration.WhileControlledByController) {
                            floating.controllerId
                        } else {
                            null
                        },
                        // "for as long as you control this [source]" (Aladdin, Scroll of Isildur I).
                        // Source-side mirror of [controllerGate]: drops the entire effect after Layer 2
                        // if the source's projected controller drifts (Threaten-style steal of the
                        // source, static control Aura, etc.). One-way: EndedDurationExpiryCheck removes
                        // the floating effect itself so regaining control does not re-apply.
                        sourceControllerGate = when (floating.duration) {
                            is Duration.WhileYouControlSource,
                            is Duration.WhileYouControlSourceAndSourceTapped -> floating.controllerId
                            else -> null
                        },
                        // Captured controller — lets a dynamic P/T (or other controller-dependent)
                        // effect still resolve a controller after its source has left the
                        // battlefield (Titania's Song's until-EOT linger).
                        controllerId = floating.controllerId,
                        // CR 611.2a: this effect was created by a resolved spell or ability, so it
                        // is independent of its source's abilities — stripping those abilities in
                        // Layer 6 must not retract it.
                        fromStaticAbility = false
                    )
                )
            }
        }

        return effects
    }

    /**
     * Post-Layer-7 gate for [Duration.WhileSourceTappedAndAffectedPowerAtMostSource]:
     * walk the floating effects with this duration, compare each affected entity's
     * final projected power to the source's final projected power, and revert the
     * controller to the entity's base [ControllerComponent] if the affected entity is
     * now stronger. Reverting to the base controller (rather than the previously-projected
     * controller) is correct for the single-control-changer case Old Man of the Sea covers;
     * if another control effect targets the same entity simultaneously, this gate hides it,
     * which is acceptable for the current SDK surface.
     *
     * This gate is the *instantaneous* view only — it hides the effect while the condition is
     * false but would re-apply it if power dropped back. The one-way half of CR 611.2b is
     * supplied by [com.wingedsheep.engine.mechanics.sba.permanent.EndedDurationExpiryCheck],
     * which physically removes the floating effect the moment the gate fails so it can never
     * restart.
     */
    private fun applyAffectedPowerAtMostSourceGate(
        state: GameState,
        projectedValues: MutableMap<EntityId, MutableProjectedValues>
    ) {
        for (floating in state.floatingEffects) {
            if (floating.duration !is Duration.WhileSourceTappedAndAffectedPowerAtMostSource) continue
            val sourceId = floating.sourceId ?: continue
            if (!state.getBattlefield().contains(sourceId)) continue
            if (state.getEntity(sourceId)?.has<TappedComponent>() != true) continue

            val sourcePower = projectedValues[sourceId]?.power ?: continue

            for (affectedId in floating.effect.affectedEntities) {
                if (!state.getBattlefield().contains(affectedId)) continue
                val affectedPower = projectedValues[affectedId]?.power ?: continue
                if (affectedPower > sourcePower) {
                    val baseController = state.getEntity(affectedId)
                        ?.get<ControllerComponent>()
                        ?.playerId
                    projectedValues[affectedId]?.controllerId = baseController
                }
            }
        }
    }

    private fun resolveCDAs(
        state: GameState,
        projectedValues: MutableMap<EntityId, MutableProjectedValues>,
        dynamicStatEntities: List<Pair<EntityId, CardComponent>>
    ) {
        if (dynamicStatEntities.isEmpty()) return

        val intermediateProjected = buildIntermediateProjectedState(state, projectedValues)
        for ((entityId, cardComponent) in dynamicStatEntities) {
            val values = projectedValues[entityId] ?: continue
            val controllerId = values.controllerId ?: continue
            val context = EffectContext(
                sourceId = entityId,
                controllerId = controllerId,
            )
            val baseStats = cardComponent.baseStats ?: continue
            val textReplacement = state.getEntity(entityId)?.get<TextReplacementComponent>()

            fun resolveDynamicAmount(source: DynamicAmount): Int {
                val effective = if (textReplacement != null) {
                    source.applyTextReplacement(textReplacement)
                } else {
                    source
                }
                return dynamicAmountEvaluator.evaluate(state, effective, context, intermediateProjected)
            }

            when (val power = baseStats.power) {
                is CharacteristicValue.Dynamic ->
                    values.power = resolveDynamicAmount(power.source)
                is CharacteristicValue.DynamicWithOffset ->
                    values.power = resolveDynamicAmount(power.source) + power.offset
                is CharacteristicValue.Fixed -> {}
            }
            when (val toughness = baseStats.toughness) {
                is CharacteristicValue.Dynamic ->
                    values.toughness = resolveDynamicAmount(toughness.source)
                is CharacteristicValue.DynamicWithOffset ->
                    values.toughness = resolveDynamicAmount(toughness.source) + toughness.offset
                is CharacteristicValue.Fixed -> {}
            }
        }
    }

    /**
     * Grant CANT_BE_BLOCKED to every creature a [CantBeBlockedWhilePropertyAtMostComponent] affects
     * whose projected power (or toughness, per the component's flags) is at most its threshold —
     * Tetsuko Umezawa, Fugitive across its controller's creatures, Stature, Size Shifter on itself.
     *
     * Runs after every P/T layer, which is the whole point: this is a Layer 6-shaped ability whose
     * gate reads Layer 7 stats, so evaluating it during layer application would read the printed
     * P/T and the evasion would never switch off when the creature grows. Re-asked on every
     * projection, so it also comes back if the creature shrinks again.
     *
     * The affected set goes through [filterResolver] against the in-progress projection, so "you
     * control" follows the *projected* controller — a creature stolen this turn evades under its new
     * controller's Tetsuko, not its old one's.
     */
    private fun applyCantBeBlockedWhilePropertyAtMost(
        state: GameState,
        projectedValues: MutableMap<EntityId, MutableProjectedValues>,
        enteringId: EntityId?,
    ) {
        for (sourceId in state.getBattlefield()) {
            val grant = state.getEntity(sourceId)
                ?.get<CantBeBlockedWhilePropertyAtMostComponent>() ?: continue
            val affected = filterResolver.resolveAffectedEntities(
                state, sourceId, grant.affects, projectedValues
            )
            for (entityId in affected) {
                if (sourceId == enteringId && entityId != enteringId) continue
                val values = projectedValues[entityId] ?: continue
                if (!values.types.contains("CREATURE")) continue
                val power = values.power
                val toughness = values.toughness
                val qualifies = (grant.checkPower && power != null && power <= grant.maxValue) ||
                    (grant.checkToughness && toughness != null && toughness <= grant.maxValue)
                if (qualifies) values.keywords.add(AbilityFlag.CANT_BE_BLOCKED.name)
            }
        }
    }
}
