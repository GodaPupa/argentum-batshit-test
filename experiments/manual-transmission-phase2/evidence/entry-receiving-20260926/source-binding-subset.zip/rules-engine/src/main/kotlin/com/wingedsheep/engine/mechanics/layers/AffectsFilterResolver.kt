package com.wingedsheep.engine.mechanics.layers

import com.wingedsheep.engine.state.components.battlefield.chosenColor
import com.wingedsheep.engine.state.components.battlefield.chosenCreatureType
import com.wingedsheep.engine.state.components.battlefield.CastChoicesComponent
import com.wingedsheep.engine.state.components.battlefield.ChoiceValue
import com.wingedsheep.engine.handlers.predicates.becameTappedOnlyOnceThisTurn
import com.wingedsheep.engine.handlers.predicates.hasDealtDamage
import com.wingedsheep.engine.handlers.predicates.receivedCounterThisTurn
import com.wingedsheep.engine.state.ComponentContainer
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.battlefield.AttachmentsComponent
import com.wingedsheep.engine.state.components.battlefield.CountersComponent
import com.wingedsheep.engine.state.components.battlefield.EnteredThisTurnComponent
import com.wingedsheep.engine.state.components.battlefield.HasDealtCombatDamageToPlayerComponent
import com.wingedsheep.engine.state.components.battlefield.TappedComponent
import com.wingedsheep.engine.state.components.battlefield.WasDealtDamageThisTurnComponent
import com.wingedsheep.engine.state.components.combat.AttackedThisCombatComponent
import com.wingedsheep.engine.state.components.combat.AttackersDeclaredThisTurnComponent
import com.wingedsheep.engine.state.components.combat.AttackingComponent
import com.wingedsheep.engine.state.components.combat.BlockedThisCombatComponent
import com.wingedsheep.engine.state.components.combat.BlockedThisTurnComponent
import com.wingedsheep.engine.state.components.combat.BlockingComponent
import com.wingedsheep.engine.state.components.combat.PlayerAttackersThisTurnComponent
import com.wingedsheep.engine.state.components.combat.PlayerAttackersLastTurnComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.identity.ControllerComponent
import com.wingedsheep.engine.state.components.identity.FaceDownComponent
import com.wingedsheep.engine.state.components.identity.RoomComponent
import com.wingedsheep.engine.state.components.identity.HasMorphAbilityComponent
import com.wingedsheep.engine.state.components.identity.MorphDataComponent
import com.wingedsheep.sdk.core.CounterType
import com.wingedsheep.sdk.core.Keyword
import com.wingedsheep.sdk.core.Subtype
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.scripting.filters.unified.GroupFilter
import com.wingedsheep.sdk.scripting.predicates.CardPredicate
import com.wingedsheep.sdk.scripting.predicates.ControllerPredicate
import com.wingedsheep.sdk.scripting.predicates.evaluateWith
import com.wingedsheep.sdk.scripting.predicates.StatePredicate

/**
 * Resolves which entities are affected by continuous effects based on AffectsFilter.
 */
internal class AffectsFilterResolver {

    /**
     * Check if an entity is a creature, preferring projected types over base types.
     * This ensures that Layer 4 type changes (e.g., Opalescence making enchantments into creatures)
     * are visible to creature-filtering effects in later layers.
     */
    private fun isCreatureInProjection(
        state: GameState,
        entityId: EntityId,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): Boolean {
        val projected = projectedValues[entityId]
        if (projected != null) {
            return "CREATURE" in projected.types || projected.isFaceDown
        }
        val container = state.getEntity(entityId) ?: return false
        val card = container.get<CardComponent>() ?: return false
        return card.typeLine.isCreature || container.has<FaceDownComponent>()
    }

    /**
     * Check if an entity currently has a given top-level [CardType], preferring projected
     * types over base types. Mirrors [isCreatureInProjection] for the generic
     * type-check used by `AttachedToCardType` and similar predicates.
     */
    private fun hasTypeInProjection(
        state: GameState,
        entityId: EntityId,
        cardTypeName: String,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): Boolean {
        val projected = projectedValues[entityId]
        if (projected != null) {
            return cardTypeName in projected.types
        }
        val card = state.getEntity(entityId)?.get<CardComponent>() ?: return false
        return card.typeLine.cardTypes.any { it.name == cardTypeName }
    }

    fun resolveAffectedEntities(
        state: GameState,
        sourceId: EntityId,
        filter: AffectsFilter?,
        projectedValues: Map<EntityId, MutableProjectedValues> = emptyMap()
    ): Set<EntityId> {
        if (filter == null) return setOf(sourceId)

        return when (filter) {
            is AffectsFilter.Self -> setOf(sourceId)
            is AffectsFilter.AllCreaturesYouControl -> {
                val controller = projectedController(state, sourceId, projectedValues)
                    ?: return emptySet()
                state.getBattlefield().filter { entityId ->
                    state.getEntity(entityId)?.get<CardComponent>() ?: return@filter false
                    val entityController = projectedController(state, entityId, projectedValues)
                    isCreatureInProjection(state, entityId, projectedValues) && entityController == controller
                }.toSet()
            }
            is AffectsFilter.AllCreatures -> {
                state.getBattlefield().filter { entityId ->
                    state.getEntity(entityId)?.get<CardComponent>() ?: return@filter false
                    isCreatureInProjection(state, entityId, projectedValues)
                }.toSet()
            }
            is AffectsFilter.AllCreaturesOpponentsControl -> {
                val controller = projectedController(state, sourceId, projectedValues)
                    ?: return emptySet()
                state.getBattlefield().filter { entityId ->
                    state.getEntity(entityId)?.get<CardComponent>() ?: return@filter false
                    val entityController = projectedController(state, entityId, projectedValues)
                    isCreatureInProjection(state, entityId, projectedValues) && entityController != controller
                }.toSet()
            }
            is AffectsFilter.SpecificEntities -> filter.entityIds
            is AffectsFilter.WithSubtype -> {
                state.getBattlefield().filter { entityId ->
                    val card = state.getEntity(entityId)?.get<CardComponent>() ?: return@filter false
                    val projected = projectedValues[entityId]
                    if (projected != null) {
                        projected.subtypes.any { it.equals(filter.subtype, ignoreCase = true) }
                    } else {
                        card.typeLine.hasSubtype(Subtype(filter.subtype))
                    }
                }.toSet()
            }
            is AffectsFilter.OtherCreaturesWithSubtype -> {
                state.getBattlefield().filter { entityId ->
                    if (entityId == sourceId) return@filter false
                    val container = state.getEntity(entityId) ?: return@filter false
                    val card = container.get<CardComponent>() ?: return@filter false
                    val projected = projectedValues[entityId]
                    val hasSubtype = if (projected != null) {
                        projected.subtypes.any { it.equals(filter.subtype, ignoreCase = true) }
                    } else {
                        card.typeLine.hasSubtype(Subtype(filter.subtype))
                    }
                    isCreatureInProjection(state, entityId, projectedValues) && hasSubtype
                }.toSet()
            }
            is AffectsFilter.OtherTappedCreaturesYouControl -> {
                val controller = projectedController(state, sourceId, projectedValues)
                    ?: return emptySet()
                state.getBattlefield().filter { entityId ->
                    if (entityId == sourceId) return@filter false
                    val container = state.getEntity(entityId) ?: return@filter false
                    container.get<CardComponent>() ?: return@filter false
                    val entityController = projectedController(state, entityId, projectedValues)
                    val isTapped = container.has<TappedComponent>()
                    isCreatureInProjection(state, entityId, projectedValues) && entityController == controller && isTapped
                }.toSet()
            }
            is AffectsFilter.OtherCreaturesYouControl -> {
                val controller = projectedController(state, sourceId, projectedValues)
                    ?: return emptySet()
                state.getBattlefield().filter { entityId ->
                    if (entityId == sourceId) return@filter false
                    val container = state.getEntity(entityId) ?: return@filter false
                    container.get<CardComponent>() ?: return@filter false
                    val entityController = projectedController(state, entityId, projectedValues)
                    isCreatureInProjection(state, entityId, projectedValues) && entityController == controller
                }.toSet()
            }
            is AffectsFilter.AllOtherCreatures -> {
                state.getBattlefield().filter { entityId ->
                    if (entityId == sourceId) return@filter false
                    state.getEntity(entityId)?.get<CardComponent>() ?: return@filter false
                    isCreatureInProjection(state, entityId, projectedValues)
                }.toSet()
            }
            is AffectsFilter.AttachedPermanent -> {
                val attachedTo = state.getEntity(sourceId)
                    ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                if (attachedTo != null) setOf(attachedTo.targetId) else emptySet()
            }
            // CR 702.95b: "both creatures" of a soulbond pair. Empty while unpaired, so a payoff
            // static's "as long as this creature is paired" clause needs no separate gate.
            is AffectsFilter.SoulbondPair ->
                com.wingedsheep.engine.mechanics.SoulbondPairing.pairOf(state, sourceId)
            is AffectsFilter.FaceDownCreatures -> {
                state.getBattlefield().filter { entityId ->
                    state.getEntity(entityId)?.has<FaceDownComponent>() == true
                }.toSet()
            }
            is AffectsFilter.CreaturesWithCounter -> {
                val counterType = parseCounterType(filter.counterType) ?: return emptySet()
                state.getBattlefield().filter { entityId ->
                    val container = state.getEntity(entityId) ?: return@filter false
                    val card = container.get<CardComponent>() ?: return@filter false
                    val counters = container.get<CountersComponent>()
                    (card.typeLine.isCreature || container.has<FaceDownComponent>()) && (counters?.getCount(counterType) ?: 0) > 0
                }.toSet()
            }
            is AffectsFilter.OwnCreaturesWithCounter -> {
                val counterType = parseCounterType(filter.counterType) ?: return emptySet()
                val sourceController = projectedController(state, sourceId, projectedValues)
                    ?: return emptySet()
                state.getBattlefield().filter { entityId ->
                    val container = state.getEntity(entityId) ?: return@filter false
                    val card = container.get<CardComponent>() ?: return@filter false
                    val counters = container.get<CountersComponent>()
                    val controller = projectedController(state, entityId, projectedValues)
                    controller == sourceController &&
                        (card.typeLine.isCreature || container.has<FaceDownComponent>()) &&
                        (counters?.getCount(counterType) ?: 0) > 0
                }.toSet()
            }
            is AffectsFilter.LandsWithCounter -> {
                val counterType = parseCounterType(filter.counterType) ?: return emptySet()
                state.getBattlefield().filter { entityId ->
                    val container = state.getEntity(entityId) ?: return@filter false
                    val card = container.get<CardComponent>() ?: return@filter false
                    val counters = container.get<CountersComponent>()
                    card.typeLine.isLand && (counters?.getCount(counterType) ?: 0) > 0
                }.toSet()
            }
            is AffectsFilter.Generic -> {
                resolveGenericFilter(state, sourceId, filter.groupFilter, projectedValues)
            }
        }
    }

    fun isSubtypeDependentFilter(filter: AffectsFilter): Boolean {
        return filter is AffectsFilter.OtherCreaturesWithSubtype ||
            filter is AffectsFilter.WithSubtype ||
            (filter is AffectsFilter.Generic && (
                filter.groupFilter.baseFilter.cardPredicates.any { it is CardPredicate.HasSubtype } ||
                filter.groupFilter.chosenSubtypeKey != null
            ))
    }

    fun isControllerDependentFilter(filter: AffectsFilter): Boolean {
        return filter is AffectsFilter.AllCreaturesYouControl ||
            filter is AffectsFilter.AllCreaturesOpponentsControl ||
            filter is AffectsFilter.OtherTappedCreaturesYouControl ||
            filter is AffectsFilter.OtherCreaturesYouControl ||
            filter is AffectsFilter.OwnCreaturesWithCounter ||
            filter is AffectsFilter.OtherCreaturesWithSubtype ||
            (filter is AffectsFilter.Generic && filter.groupFilter.baseFilter.controllerPredicate != null)
    }

    /**
     * Returns true if the filter depends on an entity's creature status.
     * These filters must be re-resolved after Layer 4 (type-changing) effects apply,
     * since a permanent may have become a creature (e.g., Opalescence) or stopped
     * being a creature after Layer 4.
     */
    fun isCreatureDependentFilter(filter: AffectsFilter): Boolean {
        return filter is AffectsFilter.AllCreatures ||
            filter is AffectsFilter.AllCreaturesYouControl ||
            filter is AffectsFilter.AllCreaturesOpponentsControl ||
            filter is AffectsFilter.OtherCreaturesYouControl ||
            filter is AffectsFilter.AllOtherCreatures ||
            filter is AffectsFilter.OtherCreaturesWithSubtype ||
            filter is AffectsFilter.OtherTappedCreaturesYouControl ||
            filter is AffectsFilter.OwnCreaturesWithCounter ||
            filter is AffectsFilter.CreaturesWithCounter ||
            filter is AffectsFilter.FaceDownCreatures ||
            (filter is AffectsFilter.Generic && filter.groupFilter.baseFilter.cardPredicates.any {
                it is CardPredicate.IsCreature
            })
    }

    private fun resolveGenericFilter(
        state: GameState,
        sourceId: EntityId,
        groupFilter: GroupFilter,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): Set<EntityId> {
        val baseFilter = groupFilter.baseFilter
        val controller = projectedController(state, sourceId, projectedValues)

        // Read chosen subtype once from source's CastChoicesComponent if needed
        val chosenSubtype = if (groupFilter.chosenSubtypeKey != null) {
            state.getEntity(sourceId)?.chosenCreatureType()
                ?: return emptySet()
        } else null

        // If the base filter keys off the source's durably-chosen card name (Petrified Hamlet),
        // resolve it once from the source's CastChoicesComponent. Fail closed (match nothing) when
        // the source has made no such choice yet.
        val nameComponentPredicate = baseFilter.cardPredicates
            .filterIsInstance<CardPredicate.NameEqualsChosenComponent>()
            .firstOrNull()
        val sourceChosenName = if (nameComponentPredicate != null) {
            (state.getEntity(sourceId)?.get<CastChoicesComponent>()
                ?.chosen?.get(nameComponentPredicate.slot) as? ChoiceValue.TextChoice)?.text
                ?: return emptySet()
        } else null

        // If the base filter keys off the source's durably-chosen color (Heraldic Banner:
        // "creatures you control of the chosen color"), resolve it once from the source's
        // CastChoicesComponent. Fail closed (match nothing) when no color has been chosen yet.
        val needsChosenColor = baseFilter.cardPredicates.any { it == CardPredicate.HasChosenColor }
        val sourceChosenColor = if (needsChosenColor) {
            state.getEntity(sourceId)?.chosenColor() ?: return emptySet()
        } else null

        return state.getBattlefield().filter { entityId ->
            if (groupFilter.excludeSelf && entityId == sourceId) return@filter false

            val container = state.getEntity(entityId) ?: return@filter false
            val card = container.get<CardComponent>() ?: return@filter false
            val projected = projectedValues[entityId]

            // Check controller predicate
            baseFilter.controllerPredicate?.let { pred ->
                val entityController = projectedController(state, entityId, projectedValues)
                val controllerMatches = pred.evaluateWith { leaf ->
                    when (leaf) {
                        ControllerPredicate.ControlledByYou -> entityController == controller
                        ControllerPredicate.ControlledByOpponent -> entityController != controller
                        ControllerPredicate.ControlledByAny -> true
                        // Turn-scoped floating restrictions (Sandswirl Wanderglyph's "they can't
                        // attack ... this turn" via a CantAttackGroup over the active player's
                        // creatures). Unknown leaves fail OPEN in evaluateWith, so leaving this
                        // unhandled silently matched every creature.
                        ControllerPredicate.ControlledByActivePlayer -> entityController == state.activePlayerId
                        // Owner-axis leaves read the card's owner relative to the source's
                        // controller (Laughing Jasper Flint: "creatures you control but don't own").
                        ControllerPredicate.OwnedByYou -> card.ownerId != null && card.ownerId == controller
                        ControllerPredicate.OwnedByOpponent -> card.ownerId != null && card.ownerId != controller
                        else -> null // other predicates not applicable in static ability context
                    }
                }
                if (!controllerMatches) return@filter false
            }

            // Check card predicates using projected values when available
            val types = projected?.types ?: card.typeLine.cardTypes.map { it.name }.toSet()
            val subtypes = projected?.subtypes ?: run {
                val baseSubtypes = card.typeLine.subtypes.map { it.value }.toSet()
                if (Keyword.CHANGELING in card.baseKeywords) baseSubtypes + Subtype.ALL_CREATURE_TYPES
                else baseSubtypes
            }
            val colors = projected?.colors ?: card.colors.map { it.name }.toSet()
            val keywords = projected?.keywords ?: (card.baseKeywords.map { it.name } + card.baseFlags.map { it.name }).toSet()
            val isFaceDown = projected?.isFaceDown ?: container.has<FaceDownComponent>()

            for (predicate in baseFilter.cardPredicates) {
                // The source-chosen-name predicate is resolved once above (sourceChosenName) and
                // applied as a separate constraint below — skip it in the generic projection loop,
                // which has no source in scope and would fail it closed.
                if (predicate is CardPredicate.NameEqualsChosenComponent) continue
                // HasChosenColor is resolved once above (sourceChosenColor) and applied as a
                // separate constraint below; the generic projection has no source in scope and
                // would fail it closed.
                if (predicate == CardPredicate.HasChosenColor) continue
                if (!matchesCardPredicateForProjection(predicate, card, container, projected, types, subtypes, colors, keywords, isFaceDown)) {
                    return@filter false
                }
            }

            // Source-chosen card name constraint (from source's CastChoicesComponent).
            if (sourceChosenName != null && !card.name.equals(sourceChosenName, ignoreCase = true)) {
                return@filter false
            }

            // Source-chosen color constraint (from source's CastChoicesComponent).
            if (sourceChosenColor != null && sourceChosenColor.name !in colors) {
                return@filter false
            }

            // Check state predicates
            for (predicate in baseFilter.statePredicates) {
                if (!matchesStatePredicateForProjection(state, entityId, predicate, container, isFaceDown, projectedValues, controller, sourceId)) {
                    return@filter false
                }
            }

            // Check chosen subtype constraint (from source's CastChoicesComponent)
            if (chosenSubtype != null) {
                if (!subtypes.any { it.equals(chosenSubtype, ignoreCase = true) }) return@filter false
            }

            true
        }.toSet()
    }

    private fun matchesStatePredicateForProjection(
        state: GameState,
        entityId: EntityId,
        predicate: StatePredicate,
        container: ComponentContainer,
        isFaceDown: Boolean,
        projectedValues: Map<EntityId, MutableProjectedValues>,
        /**
         * Controller of the permanent whose static ability is being projected — the "you" for
         * predicates that scope some *other* object's controller (currently
         * [StatePredicate.IsEnchantedByAura]'s Aura). Null when the source has no controller, in
         * which case those predicates fail closed rather than matching everything.
         */
        sourceController: EntityId?,
        /**
         * The permanent whose static ability is being projected. Needed by predicates that read the
         * source's own attachment rather than its controller — currently
         * [StatePredicate.IsAttackingEnchantedPlayer], which has to find the player the source Aura
         * enchants. Null when there is no source in scope, in which case those predicates fail closed.
         */
        sourceId: EntityId?
    ): Boolean = when (predicate) {
        // Everything this resolver is handed is already a battlefield permanent, so the predicate
        // is trivially satisfied here; it only does work in PredicateEvaluator, where an object
        // that has left the battlefield can still be asked about.
        StatePredicate.IsOnBattlefield -> true
        StatePredicate.IsTapped -> container.has<TappedComponent>()
        StatePredicate.IsUntapped -> !container.has<TappedComponent>()
        StatePredicate.IsAttacking -> container.has<AttackingComponent>()
        StatePredicate.IsAttackingAlone -> container.has<AttackingComponent>() &&
            state.getBattlefield().none {
                it != entityId && state.getEntity(it)?.has<AttackingComponent>() == true
            }
        // "Attacking one of your opponents" — the defender must be an opponent *player* of the
        // static ability's controller, so an attacker aimed at a planeswalker or battle drops out.
        // Fails closed without a controller to scope "your" against.
        StatePredicate.IsAttackingAnOpponent -> {
            val defenderId = container.get<AttackingComponent>()?.defenderId
            sourceController != null && defenderId != null &&
                defenderId in state.getOpponents(sourceController)
        }
        // The defender-side mirror: attacking the static's controller themself, or a planeswalker
        // that player controls. Reads the *base* controller of the defender rather than a
        // projection — this resolver runs while the projection is being built, and a planeswalker's
        // controller is the fact being asked about, not a layered characteristic.
        StatePredicate.IsAttackingYouOrYourPlaneswalkers -> {
            val defenderId = container.get<AttackingComponent>()?.defenderId
            sourceController != null && defenderId != null && (
                defenderId == sourceController ||
                    (
                        state.getEntity(defenderId)
                            ?.get<com.wingedsheep.engine.state.components.identity.ControllerComponent>()
                            ?.playerId == sourceController &&
                            state.getEntity(defenderId)
                                ?.get<com.wingedsheep.engine.state.components.identity.CardComponent>()
                                ?.typeLine?.cardTypes
                                ?.contains(com.wingedsheep.sdk.core.CardType.PLANESWALKER) == true
                        )
                )
        }
        // "Attacking enchanted player" — the defender must be the player the *source* Aura is
        // attached to (Curse of Hospitality). Scoped by attachment rather than by controller, so
        // unlike its two siblings above it reads `sourceId`, not `sourceController`. The
        // `in state.turnOrder` check is what keeps a planeswalker or battle the enchanted player
        // controls out: only a player id survives it.
        StatePredicate.IsAttackingEnchantedPlayer -> {
            val enchanted = sourceId
                ?.let { state.getEntity(it) }
                ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                ?.targetId
                ?.takeIf { it in state.turnOrder }
            val defenderId = container.get<AttackingComponent>()?.defenderId
            enchanted != null && defenderId == enchanted
        }
        StatePredicate.IsBlocking -> container.has<BlockingComponent>()
        StatePredicate.IsBlocked -> {
            container.has<AttackingComponent>() && state.getBattlefield().any { blockerId ->
                state.getEntity(blockerId)?.get<BlockingComponent>()?.blockedAttackerIds?.contains(entityId) == true
            }
        }
        StatePredicate.IsUnblocked -> {
            container.has<AttackingComponent>() && state.getBattlefield().none { blockerId ->
                state.getEntity(blockerId)?.get<BlockingComponent>()?.blockedAttackerIds?.contains(entityId) == true
            }
        }
        // Source-relative band membership has no meaning when projecting a group static ability
        // (there's no per-recipient "source" here); it's only evaluated in damage-prevention
        // recipient filters via PredicateEvaluator. Never match in this context.
        StatePredicate.InSameBandAsSource -> false
        // Source-relative: "blocking the source" needs the ability's source permanent, absent in
        // group-static projection. Only meaningful in target/group-damage contexts via
        // PredicateEvaluator. Never match here.
        StatePredicate.IsBlockingSource -> false
        // Same reasoning for the both-directions live pairing — no source permanent here.
        StatePredicate.IsCombatPairedWithSource -> false
        // Loop-relative; only meaningful inside a ForEach at resolution, never in projection.
        StatePredicate.IsBlockingIterationEntity -> false
        // Source-relative: "created with the source" needs the ability's source permanent, absent
        // in group-static projection. Only meaningful in target/gather-filter contexts via
        // PredicateEvaluator. Never match here.
        StatePredicate.CreatedBySource -> false
        // Source-relative + stack-aware: "isn't the target of an ability from another same-named
        // source" only matters when validating/choosing a target via PredicateEvaluator. Group-static
        // projection has no source permanent and no candidate target on the stack — never match here.
        StatePredicate.NotTargetedByAbilityFromSameNamedSource -> false
        // Source-relative: "dealt combat damage to the source's controller this turn" needs the
        // ability's source permanent, absent in group-static projection. Only meaningful in
        // target/edict-filter contexts via PredicateEvaluator. Never match here.
        StatePredicate.DealtCombatDamageToSourceControllerThisTurn -> false
        // Mirror of the above, equally source-relative: "whose controller was dealt combat damage
        // by the source this turn" needs the ability's source permanent, absent in group-static
        // projection. Only meaningful in gather-filter contexts via PredicateEvaluator.
        StatePredicate.ControllerDealtCombatDamageBySourceThisTurn -> false
        // Likewise source-relative: "crewed/saddled the source this turn" needs the ability's
        // source permanent, absent in group-static projection. Only meaningful in target/count
        // contexts via PredicateEvaluator / DynamicAmountEvaluator. Never match here.
        StatePredicate.CrewedOrSaddledSourceThisTurn -> false
        // Mirror source-relative predicate: needs the ability's source crewer, absent in
        // group-static projection. Only meaningful in trigger-filter contexts via PredicateEvaluator.
        StatePredicate.CrewedOrSaddledBySourceThisTurn -> false
        // Source-relative: "the permanent the source is attached to" needs the ability's source
        // permanent, absent in group-static projection. Only meaningful in target/gather-filter
        // contexts via PredicateEvaluator. Never match here.
        StatePredicate.IsAttachedToBySource -> false
        StatePredicate.IsAttachedToSource -> false
        // Source-relative: "the source permanent itself" — for a group static projecting onto
        // its own source, use GroupFilter's Scope.Self instead. Only meaningful in point-of-use
        // checks (activation legality) via PredicateEvaluator. Never match here.
        StatePredicate.IsSource -> false
        // No granter context during projection — granter-relative exclusion is resolution-time only.
        StatePredicate.IsGrantingPermanent -> false
        // Source-relative exile linkage (LinkedExileComponent on the effect source). Only
        // meaningful in target/gather-filter contexts via PredicateEvaluator; never match in
        // group-static projection.
        StatePredicate.ExiledWithSource -> false
        StatePredicate.EnteredThisTurn -> container.has<EnteredThisTurnComponent>()
        // Counter history — the per-permanent marker, so a group static gated on "each creature you
        // control that you've put one or more +1/+1 counters on this turn" (Kid Loki) resolves
        // during projection. Plain per-entity state with no source-relative half, so the answer here
        // is identical to PredicateEvaluator's.
        is StatePredicate.ReceivedCounterThisTurn ->
            receivedCounterThisTurn(container, predicate)
        // Tap history — likewise plain per-entity state, so a group static gated on "each creature
        // that has become tapped for the first time this turn" resolves during projection.
        StatePredicate.BecameTappedOnlyOnceThisTurn ->
            becameTappedOnlyOnceThisTurn(container, state.turnNumber)
        StatePredicate.WasDealtDamageThisTurn -> container.has<WasDealtDamageThisTurnComponent>()
        // Damage history — plain per-entity state with no source-relative half, so a group static
        // gated on "each creature that dealt damage this turn" resolves during projection and gives
        // the identical answer to PredicateEvaluator's.
        is StatePredicate.HasDealtDamage ->
            hasDealtDamage(container, state.turnNumber, predicate)
        StatePredicate.HasDealtCombatDamageToPlayer -> container.has<HasDealtCombatDamageToPlayerComponent>()
        // Controller comes from the in-progress projection first: an effect that changed control
        // this turn (Act of Treason) makes the base ControllerComponent the wrong player to ask,
        // and PredicateEvaluator reads the projected one. Falls back to base for an entity the
        // projection hasn't reached yet, which is the same shape the keyword reads below use.
        StatePredicate.AttackedThisTurn -> {
            val controllerId = projectedController(state, entityId, projectedValues)
            val attackerSet = controllerId?.let {
                state.getEntity(it)
                    ?.get<PlayerAttackersThisTurnComponent>()
                    ?.attackerIds
            } ?: emptySet()
            entityId in attackerSet
        }
        // "Couldn't attack" — controlled by someone whose turn it isn't so they never declared
        // attackers (CR 508.1a), or controlled by someone who did have the turn but never reached a
        // Declare Attackers Step (False Peace, Fatespinner), or defender (CR 702.3b) / a projected
        // "can't attack" — the CR 508.1c restrictions — or summoning sick (entered this turn without
        // haste). Keywords come from the in-progress projection when this entity already has one,
        // falling back to base keywords + flags, the same read line 340 uses for card predicates;
        // that keeps this branch in step with PredicateEvaluator's without re-entering the projector.
        StatePredicate.CouldNotHaveAttackedThisTurn -> {
            val card = container.get<CardComponent>()
            val inProjection = projectedValues[entityId]
            val keywords = inProjection?.keywords
                ?: card?.let { (it.baseKeywords.map { k -> k.name } + it.baseFlags.map { f -> f.name }).toSet() }
                ?: emptySet()
            val controllerId = projectedController(state, entityId, projectedValues)
            controllerId == null ||
                !state.isActiveTurnFor(controllerId) ||
                state.getEntity(controllerId)?.has<AttackersDeclaredThisTurnComponent>() != true ||
                Keyword.DEFENDER.name in keywords ||
                inProjection?.cantAttack == true ||
                (container.has<EnteredThisTurnComponent>() && Keyword.HASTE.name !in keywords)
        }
        // The same read one turn back — see PlayerAttackersLastTurnComponent. Kept in step with
        // PredicateEvaluator's branch so projection and resolution agree.
        StatePredicate.AttackedLastTurn -> {
            val controllerId = projectedController(state, entityId, projectedValues)
            val attackerSet = controllerId?.let {
                state.getEntity(it)
                    ?.get<PlayerAttackersLastTurnComponent>()
                    ?.attackerIds
            } ?: emptySet()
            entityId in attackerSet
        }
        StatePredicate.AttackedThisCombat ->
            container.has<AttackedThisCombatComponent>()
        StatePredicate.BlockedThisTurn ->
            container.has<BlockedThisTurnComponent>()
        StatePredicate.BlockedThisCombat ->
            container.has<BlockedThisCombatComponent>()
        // Graveyard-zone-only predicates (Abyssal Harvester; Samwise/Lobelia). Battlefield
        // projection never sees a card whose stamp would match — every battlefield permanent
        // has had its from-graveyard marker stripped on battlefield entry — so the
        // projection answer is unconditionally false here.
        StatePredicate.PutIntoGraveyardThisTurn -> false
        StatePredicate.PutIntoGraveyardFromBattlefieldThisTurn -> false
        StatePredicate.BlockedOrWasBlockedByLegendaryThisTurn ->
            container.has<com.wingedsheep.engine.state.components.combat.BlockedOrWasBlockedByLegendaryThisTurnComponent>()
        StatePredicate.IsFaceDown -> isFaceDown
        StatePredicate.IsFaceUp -> !isFaceDown
        // "Creature with a morph ability" (Backslide) means *morph* specifically — a manifested,
        // cloaked or disguised permanent also carries turn-up data, so match on the procedure's
        // mechanic rather than on the component's presence.
        StatePredicate.HasMorphAbility ->
            container.has<HasMorphAbilityComponent>() ||
                container.get<MorphDataComponent>()?.hasMorphProcedure == true
        // Disguise (CR 702.168) is the printed keyword, read off the card in any zone — see
        // StatePredicate.HasDisguiseAbility for why there is no turn-up-data fallback here.
        StatePredicate.HasDisguiseAbility ->
            container.has<com.wingedsheep.engine.state.components.identity.HasDisguiseAbilityComponent>()
        StatePredicate.IsRingBearer -> {
            val bearer = container.get<com.wingedsheep.engine.state.components.identity.RingBearerComponent>()
            bearer != null && projectedController(state, entityId, projectedValues) == bearer.ownerId
        }
        // Soulbond pairing (CR 702.95b) — a plain "is this creature paired at all" question, with
        // no source-relative half, so it goes through the same shared read as PredicateEvaluator.
        // "Paired *with the source*" is Scope.SoulbondPair / AffectsFilter.SoulbondPair instead.
        StatePredicate.IsPaired ->
            com.wingedsheep.engine.mechanics.SoulbondPairing.isPaired(state, entityId)
        StatePredicate.IsEquipped -> {
            val attachments = container.get<AttachmentsComponent>()
            attachments != null && attachments.attachedIds.any { attachId ->
                state.getEntity(attachId)?.get<CardComponent>()?.typeLine?.isEquipment == true
            }
        }
        // "Enchanted creatures you control get +2/+2" (A Tale for the Ages) is a layer-7c group
        // static, so this has to resolve during projection: read the base attachment index and the
        // attached card's printed type line — an Aura's own Aura-ness is never granted or removed by
        // a continuous effect, so no projected lookup is needed for the attachment itself.
        StatePredicate.IsEnchanted -> {
            val attachments = container.get<AttachmentsComponent>()
            attachments != null && attachments.attachedIds.any { attachId ->
                state.getEntity(attachId)?.get<CardComponent>()?.typeLine?.isAura == true
            }
        }
        // "…enchanted by Auras you control…" (Archon of the Wild Rose) — same attachment scan as
        // IsEnchanted, but the Aura's own projected controller has to match the static's controller.
        // Control is a Layer 2 effect, so read it through the projection rather than off the base
        // ControllerComponent: an Aura stolen this turn is no longer one you control.
        is StatePredicate.IsEnchantedByAura -> {
            val attachments = container.get<AttachmentsComponent>()
            attachments != null && sourceController != null && attachments.attachedIds.any { attachId ->
                if (state.getEntity(attachId)?.get<CardComponent>()?.typeLine?.isAura != true) return@any false
                val auraController = projectedController(state, attachId, projectedValues) ?: return@any false
                predicate.auraController.evaluateWith { leaf ->
                    when (leaf) {
                        ControllerPredicate.ControlledByYou -> auraController == sourceController
                        ControllerPredicate.ControlledByOpponent -> auraController != sourceController
                        ControllerPredicate.ControlledByAny -> true
                        ControllerPredicate.ControlledByActivePlayer -> auraController == state.activePlayerId
                        else -> null
                    }
                }
            }
        }
        StatePredicate.IsModified -> com.wingedsheep.engine.handlers.predicates.isModified(state, entityId)
        // A general "attached to <filter>" host constraint whose nested filter may carry a controller
        // predicate ("a creature you control"). Group-static projection has no ability controller to
        // resolve that "you", so this predicate is only meaningful in target/condition contexts via
        // PredicateEvaluator (where the controllerId is supplied). Never match in projection.
        is StatePredicate.AttachedTo -> false
        // "whose controller controls <filter>" needs a battlefield scan bound to the
        // candidate's controller, which the group-static projection pass cannot do here.
        // Only meaningful in target/condition contexts via PredicateEvaluator.
        is StatePredicate.ControllerControls -> false
        is StatePredicate.AttachedToCardType -> {
            val attached = container.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
            attached != null &&
                hasTypeInProjection(state, attached.targetId, predicate.cardType.name, projectedValues)
        }
        StatePredicate.IsSaddled ->
            container.has<com.wingedsheep.engine.state.components.battlefield.SaddledComponent>()
        // Solved (CR 719.3b) is a component-backed designation, not a layer modification, so it
        // reads off base state and is stable for the whole projection pass — a "Solved —" static
        // ability can gate on it without the self-referential caveat that IsSuspected carries.
        StatePredicate.IsSolved ->
            container.has<com.wingedsheep.engine.state.components.battlefield.SolvedComponent>()
        // Renowned (CR 702.112b) is component-backed for the same reason as solved: a designation,
        // not a layer modification, so it reads off base state and is stable for the whole
        // projection pass. That is what lets "as long as this creature is renowned, it has menace"
        // (Goblin Glory Chaser) be a plain conditional static.
        StatePredicate.IsRenowned ->
            container.has<com.wingedsheep.engine.state.components.battlefield.RenownedComponent>()
        // Suspected (CR 701.60a) is itself a Layer-ability modification, so it is read off the
        // values accumulated so far in this projection pass — the same source `ProjectedState`
        // exposes as `isSuspected`, and the same self-referential caveat as IsModified above.
        StatePredicate.IsSuspected -> projectedValues[entityId]?.isSuspected == true
        StatePredicate.IsWarpExiled ->
            container.has<com.wingedsheep.engine.state.components.identity.WarpExiledComponent>()
        StatePredicate.WasCastForWarp ->
            container.has<com.wingedsheep.engine.state.components.battlefield.WarpedComponent>()
        // Stack-only: cast-origin zone reads SpellOnStackComponent, which battlefield permanents
        // in group-static projection never carry. Only meaningful in target/counter contexts via
        // PredicateEvaluator. Never match here.
        is StatePredicate.WasCastFromZone -> false
        StatePredicate.HasGreatestPower -> hasGreatestPowerInProjection(state, entityId, container, projectedValues)
        StatePredicate.HasLeastPowerAmongAllCreatures -> hasLeastPowerAmongAllCreaturesInProjection(state, entityId, container, projectedValues)
        // Relational minimum-mana-value matching is intended for point-of-use filters (targeting
        // and gathering), where PredicateEvaluator has the full ability context. It is not a
        // continuous-effect applicability predicate.
        is StatePredicate.HasLeastManaValueAmong -> false
        StatePredicate.HasGreatestManaValueAmongAllCreatures ->
            hasGreatestManaValueAmongAllCreaturesInProjection(state, entityId, container, projectedValues)
        StatePredicate.HasLeastPower -> hasLeastPowerInProjection(state, entityId, container, projectedValues)
        StatePredicate.HasAnyCounter -> {
            val counters = container.get<CountersComponent>()
            counters != null && counters.counters.values.any { it > 0 }
        }
        is StatePredicate.HasCounter -> {
            val counters = container.get<CountersComponent>()
            val counterType = parseCounterType(predicate.counterType)
            counters != null && counterType != null && counters.getCount(counterType) > 0
        }
        StatePredicate.HasLockedDoor ->
            container.get<RoomComponent>()?.lockedFaces?.isNotEmpty() == true
        is StatePredicate.Or -> predicate.predicates.any {
            matchesStatePredicateForProjection(state, entityId, it, container, isFaceDown, projectedValues, sourceController, sourceId)
        }
        is StatePredicate.And -> predicate.predicates.all {
            matchesStatePredicateForProjection(state, entityId, it, container, isFaceDown, projectedValues, sourceController, sourceId)
        }
        is StatePredicate.Not -> !matchesStatePredicateForProjection(
            state, entityId, predicate.predicate, container, isFaceDown, projectedValues, sourceController, sourceId
        )
    }

    private fun hasGreatestPowerInProjection(
        state: GameState,
        entityId: EntityId,
        container: ComponentContainer,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): Boolean {
        val entityController = projectedController(state, entityId, projectedValues) ?: return false
        val entityPower = projectedValues[entityId]?.power
            ?: container.get<CardComponent>()?.baseStats?.basePower
            ?: return false
        val maxPower = state.getBattlefield()
            .filter { id ->
                projectedController(state, id, projectedValues) == entityController &&
                    isCreatureInProjection(state, id, projectedValues)
            }
            .maxOfOrNull {
                projectedValues[it]?.power
                    ?: state.getEntity(it)?.get<CardComponent>()?.baseStats?.basePower
                    ?: Int.MIN_VALUE
            }
            ?: return false
        return entityPower >= maxPower
    }

    /**
     * Global greatest mana value across every creature on the battlefield — the projection-pass
     * reading of [StatePredicate.HasGreatestManaValueAmongAllCreatures] (Favor of the Mighty).
     *
     * Creature-ness is read from the projection (so a permanent that only *became* a creature this
     * pass counts), while mana value is a printed characteristic no layer modifies and is read off
     * [CardComponent]. A face-down creature has no mana cost, so it counts as 0. Ties match every
     * maximum-mana-value creature, which is what the card's 2007-10-01 ruling asks for.
     */
    private fun hasGreatestManaValueAmongAllCreaturesInProjection(
        state: GameState,
        entityId: EntityId,
        container: ComponentContainer,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): Boolean {
        if (!isCreatureInProjection(state, entityId, projectedValues)) return false
        val entityManaValue = if (projectedValues[entityId]?.isFaceDown == true) 0
        else container.get<CardComponent>()?.manaValue ?: return false
        val maxManaValue = state.getBattlefield()
            .asSequence()
            .filter { isCreatureInProjection(state, it, projectedValues) }
            .mapNotNull { candidateId ->
                if (projectedValues[candidateId]?.isFaceDown == true) 0
                else state.getEntity(candidateId)?.get<CardComponent>()?.manaValue
            }
            .maxOrNull()
            ?: return false
        return entityManaValue >= maxManaValue
    }

    private fun hasLeastPowerAmongAllCreaturesInProjection(
        state: GameState,
        entityId: EntityId,
        container: ComponentContainer,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): Boolean {
        if (!isCreatureInProjection(state, entityId, projectedValues)) return false
        val entityPower = projectedValues[entityId]?.power
            ?: container.get<CardComponent>()?.baseStats?.basePower
            ?: return false
        val minPower = state.getBattlefield()
            .filter { isCreatureInProjection(state, it, projectedValues) }
            .minOfOrNull {
                projectedValues[it]?.power
                    ?: state.getEntity(it)?.get<CardComponent>()?.baseStats?.basePower
                    ?: Int.MAX_VALUE
            }
            ?: return false
        return entityPower <= minPower
    }

    private fun hasLeastPowerInProjection(
        state: GameState,
        entityId: EntityId,
        container: ComponentContainer,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): Boolean {
        val entityController = projectedController(state, entityId, projectedValues) ?: return false
        val entityPower = projectedValues[entityId]?.power
            ?: container.get<CardComponent>()?.baseStats?.basePower
            ?: return false
        val minPower = state.getBattlefield()
            .filter { id ->
                projectedController(state, id, projectedValues) == entityController &&
                    isCreatureInProjection(state, id, projectedValues)
            }
            .minOfOrNull {
                projectedValues[it]?.power
                    ?: state.getEntity(it)?.get<CardComponent>()?.baseStats?.basePower
                    ?: Int.MAX_VALUE
            }
            ?: return false
        return entityPower <= minPower
    }

    private fun matchesCardPredicateForProjection(
        predicate: CardPredicate,
        card: CardComponent,
        container: ComponentContainer,
        projected: MutableProjectedValues?,
        types: Set<String>,
        subtypes: Set<String>,
        colors: Set<String>,
        keywords: Set<String>,
        isFaceDown: Boolean
    ): Boolean = when (predicate) {
        CardPredicate.IsCreature -> "CREATURE" in types || isFaceDown
        CardPredicate.IsLand -> "LAND" in types
        CardPredicate.IsArtifact -> "ARTIFACT" in types
        CardPredicate.IsEnchantment -> "ENCHANTMENT" in types
        CardPredicate.IsPlaneswalker -> "PLANESWALKER" in types
        is CardPredicate.HasCardType -> predicate.cardType.name in types
        CardPredicate.IsInstant -> "INSTANT" in types
        CardPredicate.IsSorcery -> "SORCERY" in types
        // Adventure-ness is a static whole-card characteristic, not a projected type.
        CardPredicate.HasAdventure -> card.hasAdventure
        // Double-faced-ness is likewise a static whole-card characteristic, not a projected type.
        CardPredicate.IsDoubleFaced -> card.isDoubleFaced
        CardPredicate.HasNoAbilities -> card.oracleText.isBlank()
        // Static projection has no EffectContext chosenValues; dynamic card-type predicates
        // are resolution-local and therefore fail closed here.
        is CardPredicate.HasCardTypeFromVariable -> false
        CardPredicate.IsPermanent -> types.any { it in setOf("CREATURE", "LAND", "ARTIFACT", "ENCHANTMENT", "PLANESWALKER") }
        CardPredicate.IsNonland -> "LAND" !in types
        CardPredicate.IsNoncreature -> "CREATURE" !in types
        CardPredicate.IsNonenchantment -> "ENCHANTMENT" !in types
        CardPredicate.IsNonartifact -> "ARTIFACT" !in types
        CardPredicate.IsBasicLand -> "LAND" in types && card.typeLine.supertypes.any { it.name == "BASIC" }
        CardPredicate.IsToken -> container.has<com.wingedsheep.engine.state.components.identity.TokenComponent>()
        CardPredicate.IsNontoken -> !container.has<com.wingedsheep.engine.state.components.identity.TokenComponent>()
        CardPredicate.IsLegendary -> "LEGENDARY" in types
        CardPredicate.IsSnow -> "SNOW" in types
        CardPredicate.IsNonlegendary -> "LEGENDARY" !in types
        CardPredicate.HasNonManaActivatedAbility -> card.hasNonManaActivatedAbility
        CardPredicate.HasActivatedAbility -> card.hasActivatedAbility
        is CardPredicate.HasSubtype -> if (isFaceDown) false else subtypes.any { it.equals(predicate.subtype.value, ignoreCase = true) }
        is CardPredicate.NotSubtype -> if (isFaceDown) true else subtypes.none { it.equals(predicate.subtype.value, ignoreCase = true) }
        is CardPredicate.HasAnyOfSubtypes -> if (isFaceDown) false else predicate.subtypes.any { sub -> subtypes.any { it.equals(sub.value, ignoreCase = true) } }
        is CardPredicate.HasColor -> predicate.color.name in colors
        is CardPredicate.NotColor -> predicate.color.name !in colors
        // No resolution-time chosen color in a static-ability projection context.
        CardPredicate.HasChosenColor -> false
        CardPredicate.IsColorless -> colors.isEmpty()
        CardPredicate.IsColored -> colors.isNotEmpty()
        CardPredicate.IsMulticolored -> colors.size > 1
        CardPredicate.IsMonocolored -> colors.size == 1
        is CardPredicate.HasKeyword -> predicate.keyword.name in keywords
        is CardPredicate.NotKeyword -> predicate.keyword.name !in keywords
        is CardPredicate.PowerAtMost -> (projected?.power ?: card.baseStats?.basePower ?: 0) <= predicate.max
        is CardPredicate.PowerAtLeast -> (projected?.power ?: card.baseStats?.basePower ?: 0) >= predicate.min
        is CardPredicate.PowerEquals -> (projected?.power ?: card.baseStats?.basePower) == predicate.value
        // PowerEqualsX / PowerAtLeastX are resolution-time only; layer-projection has no
        // chosen-number context.
        CardPredicate.PowerEqualsX -> false
        CardPredicate.PowerAtLeastX -> false
        is CardPredicate.ToughnessAtMost -> (projected?.toughness ?: card.baseStats?.baseToughness ?: 0) <= predicate.max
        // ToughnessAtMostX is resolution-time only; layer-projection has no X context, so it never matches here.
        CardPredicate.ToughnessAtMostX -> false
        is CardPredicate.ToughnessAtLeast -> (projected?.toughness ?: card.baseStats?.baseToughness ?: 0) >= predicate.min
        is CardPredicate.ToughnessEquals -> (projected?.toughness ?: card.baseStats?.baseToughness) == predicate.value
        is CardPredicate.PowerOrToughnessAtLeast -> {
            val power = projected?.power ?: card.baseStats?.basePower ?: 0
            val toughness = projected?.toughness ?: card.baseStats?.baseToughness ?: 0
            power >= predicate.min || toughness >= predicate.min
        }
        is CardPredicate.PowerOrToughnessAtMost -> {
            val power = projected?.power ?: card.baseStats?.basePower ?: 0
            val toughness = projected?.toughness ?: card.baseStats?.baseToughness ?: 0
            power <= predicate.max || toughness <= predicate.max
        }
        is CardPredicate.TotalPowerAndToughnessAtMost -> {
            val power = projected?.power ?: card.baseStats?.basePower ?: 0
            val toughness = projected?.toughness ?: card.baseStats?.baseToughness ?: 0
            (power + toughness) <= predicate.max
        }
        is CardPredicate.ManaValueEquals -> card.manaValue == predicate.value
        is CardPredicate.ManaValueAtMost -> card.manaValue <= predicate.max
        // ManaValueAtMostX / ManaValueEqualsX are resolution-time only; layer-projection has no chosen-number context.
        CardPredicate.ManaValueAtMostX -> false
        CardPredicate.ManaValueEqualsX -> false
        is CardPredicate.ManaValueAtLeast -> card.manaValue >= predicate.min
        // Entity-relative — layer-projection has no trigger/source context for filter purposes here.
        is CardPredicate.ManaValueAtMostEntity -> false
        is CardPredicate.ManaValueAtMostEntityManaSpent -> false
        is CardPredicate.ManaValueAtMostColorsSpent -> false
        is CardPredicate.ManaValueAtMostDynamic -> false
        is CardPredicate.ManaValueEqualsDynamic -> false
        is CardPredicate.PowerEqualsDynamic -> false
        is CardPredicate.ToughnessEqualsDynamic -> false
        is CardPredicate.PowerGreaterThanEntity -> false
        is CardPredicate.PowerAtMostEntity -> false
        is CardPredicate.PowerLessThanEntity -> false
        CardPredicate.PowerGreaterThanBase -> {
            // Self-relative: projected power vs the object's own printed base power.
            val basePower = card.baseStats?.basePower
            val currentPower = projected?.power ?: basePower
            basePower != null && currentPower != null && currentPower > basePower
        }
        CardPredicate.ManaValueIsEven -> card.manaValue % 2 == 0
        CardPredicate.ManaValueIsOdd -> card.manaValue % 2 != 0
        CardPredicate.HasXInManaCost -> if (isFaceDown) false else card.manaCost.hasX
        is CardPredicate.ColoredManaSymbolsAtLeast ->
            // Printed cost's colored pips (CR 107.4e/f); face-down has no mana cost (CR 708.2).
            if (isFaceDown) false
            else card.manaCost.coloredSymbolCount(predicate.colors.toSet()) >= predicate.min
        is CardPredicate.NameEquals -> card.name == predicate.name
        // Room-name distinctness is a resolution-time search filter, not a continuous/static
        // affects-filter concern.
        CardPredicate.NameNotSharedWithControlledRoom -> false
        CardPredicate.NameNotSharedWithControlledToken -> false
        // Likewise "no other permanent you control shares this name" — a targeting restriction
        // evaluated against live battlefield state, not a static affects-filter.
        CardPredicate.NameNotSharedWithAnotherControlledPermanent -> false
        is CardPredicate.OriginallyPrintedInSet ->
            card.originalSetCode?.equals(predicate.setCode, ignoreCase = true) == true
        is CardPredicate.HasBasicLandType -> if (isFaceDown) false else subtypes.any { it.equals(predicate.landType, ignoreCase = true) }
        is CardPredicate.And -> predicate.predicates.all { matchesCardPredicateForProjection(it, card, container, projected, types, subtypes, colors, keywords, isFaceDown) }
        is CardPredicate.Or -> predicate.predicates.any { matchesCardPredicateForProjection(it, card, container, projected, types, subtypes, colors, keywords, isFaceDown) }
        is CardPredicate.Not -> !matchesCardPredicateForProjection(predicate.predicate, card, container, projected, types, subtypes, colors, keywords, isFaceDown)
        CardPredicate.ToughnessGreaterThanPower -> {
            val power = projected?.power ?: card.baseStats?.basePower ?: 0
            val toughness = projected?.toughness ?: card.baseStats?.baseToughness ?: 0
            toughness > power
        }
        // Source-, trigger-, and pipeline-context-relative predicates have no meaning during
        // layer projection (no source/trigger/pipeline context in scope). Fail closed so a new
        // predicate variant forces an exhaustive-when compile failure here instead of silently
        // matching every entity.
        CardPredicate.NotOfSourceChosenType,
        CardPredicate.SharesCreatureTypeWithSource,
        CardPredicate.SharesCreatureTypeWithTriggeringEntity,
        CardPredicate.HasChosenSubtype,
        CardPredicate.SharesChosenColorWithSource,
        CardPredicate.SharesColorWithRecipient,
        is CardPredicate.SharesCreatureTypeWith,
        is CardPredicate.SharesCardTypeWith,
        CardPredicate.SharesCardTypeWithLinkedExile,
        CardPredicate.SharesNameWithLinkedExile,
        is CardPredicate.SharesColorWith,
        is CardPredicate.SharesManaValueWith,
        is CardPredicate.SharesNameWith,
        is CardPredicate.SharesColorWithPermanentYouControl,
        is CardPredicate.SharesNameWithPermanentYouControl,
        is CardPredicate.DoesNotShareCreatureTypeWithPermanentYouControl,
        is CardPredicate.DoesNotShareLandTypeWithPermanentYouControl,
        is CardPredicate.HasSubtypeFromVariable,
        is CardPredicate.HasSubtypeInStoredList,
        is CardPredicate.NameEqualsChosen,
        // Resolved separately in resolveGenericFilter against the source's CastChoicesComponent
        // (no source in scope here) — fail closed if it ever reaches this generic path.
        is CardPredicate.NameEqualsChosenComponent,
        is CardPredicate.CardTypeEqualsChosenComponent,
        is CardPredicate.HasSubtypeInEachStoredGroup -> false
        // Stack-only predicates — never match a battlefield entity being projected.
        CardPredicate.IsActivatedOrTriggeredAbility,
        CardPredicate.IsTriggeredAbility,
        CardPredicate.IsActivatedAbility -> false
        is CardPredicate.TargetsMatching -> false
        is CardPredicate.AbilitySourceMatches -> false
    }

    /**
     * Get the controller of an entity, preferring projected state over base state.
     * This ensures control-changing effects are respected during state projection.
     */
    private fun projectedController(
        state: GameState,
        entityId: EntityId,
        projectedValues: Map<EntityId, MutableProjectedValues>
    ): EntityId? {
        return projectedValues[entityId]?.controllerId
            ?: state.getEntity(entityId)?.get<ControllerComponent>()?.playerId
    }

    private fun parseCounterType(counterTypeString: String): CounterType? {
        return when (counterTypeString) {
            "+1/+1" -> CounterType.PLUS_ONE_PLUS_ONE
            "-1/-1" -> CounterType.MINUS_ONE_MINUS_ONE
            else -> try {
                CounterType.valueOf(counterTypeString.uppercase().replace(' ', '_'))
            } catch (e: IllegalArgumentException) {
                null
            }
        }
    }
}
