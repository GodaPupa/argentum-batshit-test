package com.wingedsheep.sdk.scripting

import com.wingedsheep.sdk.core.CardType
import com.wingedsheep.sdk.core.Color
import com.wingedsheep.sdk.core.Keyword
import com.wingedsheep.sdk.core.Subtype
import com.wingedsheep.sdk.scripting.predicates.CardPredicate
import com.wingedsheep.sdk.scripting.predicates.ControllerPredicate
import com.wingedsheep.sdk.scripting.predicates.StatePredicate
import com.wingedsheep.sdk.scripting.targets.EffectTarget
import com.wingedsheep.sdk.scripting.text.TextReplaceable
import com.wingedsheep.sdk.scripting.text.TextReplacer
import com.wingedsheep.sdk.scripting.values.DynamicAmount
import com.wingedsheep.sdk.scripting.values.EntityReference
import kotlinx.serialization.Serializable

/**
 * Universal filter for matching game objects (cards, permanents, spells).
 * Composes CardPredicate, StatePredicate, and ControllerPredicate for flexible filtering.
 *
 * This replaces the scattered filter types (CardFilter, CountFilter, etc.) with a unified,
 * composable approach.
 *
 * Note: Named GameObjectFilter to distinguish from other filter types in the SDK
 *
 * ## Usage Examples
 *
 * ```kotlin
 * // Simple type filter
 * GameObjectFilter.Creature
 *
 * // Creature with specific properties
 * GameObjectFilter.Creature.withColor(Color.BLACK).tapped()
 *
 * // Controlled creatures
 * GameObjectFilter.Creature.youControl()
 *
 * // Complex filter: tapped creatures with power 2 or less that opponent controls
 * GameObjectFilter.Creature
 *     .tapped()
 *     .powerAtMost(2)
 *     .opponentControls()
 * ```
 */
@Serializable
data class GameObjectFilter(
    val cardPredicates: List<CardPredicate> = emptyList(),
    val statePredicates: List<StatePredicate> = emptyList(),
    val controllerPredicate: ControllerPredicate? = null,
    /**
     * Recursive union: when non-empty, an object matches this filter only if it matches
     * the base predicates above AND at least one of these sub-filters. This is what the
     * [or] infix builds, and it is the only faithful way to express a *heterogeneous* OR —
     * one whose branches carry different state/controller predicates (e.g. "artifact or
     * tapped creature", where the tapped restriction applies only to the creature branch).
     * Each branch is a full [GameObjectFilter], so it composes to any depth.
     */
    val anyOf: List<GameObjectFilter> = emptyList()
) : TextReplaceable<GameObjectFilter> {
    val description: String
        get() = buildDescription()

    /**
     * The English indefinite article ("a" or "an") for this filter's type name.
     * Derived from the card predicates' leading type word (e.g. "artifact", "equipment"),
     * not from the full [description] — which may include "you control" prefixes
     * that would give the wrong first letter.
     *
     * Reads the predicates in [orderedCardPredicates] order, the same order [description] renders
     * them in, so the article always agrees with the word it precedes: "**an** Elf creature", not
     * "a Elf creature". The only consumer pairs the two directly (`CostAtom`'s
     * "from <article> <description> you control").
     */
    val indefiniteArticle: String
        get() {
            val typeWord = orderedCardPredicates().firstOrNull()?.description?.trim()
                ?: if (anyOf.isNotEmpty()) return anyOf.first().indefiniteArticle
                else description.trim()
            val first = typeWord.firstOrNull()?.lowercaseChar() ?: return "a"
            return if (first in "aeiou") "an" else "a"
        }

    /**
     * Card predicates in rendering order: subtypes ahead of the card type, because Magic templates
     * them that way — "Wolf creature", "Equipment artifact", never "creature Wolf". A stable
     * partition, so every other pairing keeps its original insertion order.
     */
    private fun orderedCardPredicates(): List<CardPredicate> {
        val (subtypes, rest) = cardPredicates.partition { it is CardPredicate.HasSubtype }
        return subtypes + rest
    }

    private fun buildDescription(): String = buildString {
        controllerPredicate?.let {
            if (it.description.isNotEmpty()) {
                append(it.description)
                append(" ")
            }
        }
        statePredicates.forEach { predicate ->
            append(predicate.description)
            append(" ")
        }
        orderedCardPredicates().forEach { predicate ->
            append(predicate.description)
            append(" ")
        }
        if (anyOf.isNotEmpty()) {
            append(anyOf.joinToString(" or ") { it.description })
        }
    }.trim().ifEmpty { "card" }

    // =============================================================================
    // Pre-built Common Filters
    // =============================================================================

    companion object {
        /** Match any object */
        val Any = GameObjectFilter()

        // Type filters
        val Creature = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsCreature))
        val Land = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsLand))
        val BasicLand = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsBasicLand))
        val NonbasicLand = GameObjectFilter(
            cardPredicates = listOf(CardPredicate.IsLand, CardPredicate.Not(CardPredicate.IsBasicLand))
        )
        /**
         * A land with one of the five basic land types (CR 205.3i) — Boseiju, Who Endures' "a
         * land card with a basic land type". Deliberately *not* [BasicLand]: a shockland
         * (`Land — Forest Island`) or Dryad Arbor qualifies, and a basic is only the common case.
         */
        val LandWithBasicLandType = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.IsLand,
                CardPredicate.Or(
                    listOf(
                        CardPredicate.HasBasicLandType(Subtype.PLAINS.value),
                        CardPredicate.HasBasicLandType(Subtype.ISLAND.value),
                        CardPredicate.HasBasicLandType(Subtype.SWAMP.value),
                        CardPredicate.HasBasicLandType(Subtype.MOUNTAIN.value),
                        CardPredicate.HasBasicLandType(Subtype.FOREST.value),
                    )
                )
            )
        )
        val Artifact = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsArtifact))
        val Enchantment = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsEnchantment))
        val Planeswalker = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsPlaneswalker))
        val Instant = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsInstant))
        val Sorcery = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsSorcery))
        val Permanent = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsPermanent))
        val Nonland = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsNonland))
        val NonlandPermanent = GameObjectFilter(
            cardPredicates = listOf(CardPredicate.IsNonland, CardPredicate.IsPermanent)
        )
        val Noncreature = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsNoncreature))
        val Nonenchantment = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsNonenchantment))
        val Nonartifact = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsNonartifact))
        val Token = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsToken))
        val Multicolored = GameObjectFilter(cardPredicates = listOf(CardPredicate.IsMulticolored))

        // Combined type filters
        val InstantOrSorcery = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsInstant, CardPredicate.IsSorcery))
            )
        )

        /** Instant, sorcery, or a card with an Adventure — Frantic Firebolt's graveyard tally. */
        val InstantSorceryOrAdventure = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(
                    listOf(CardPredicate.IsInstant, CardPredicate.IsSorcery, CardPredicate.HasAdventure)
                )
            )
        )
        val CreatureOrPlaneswalker = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsCreature, CardPredicate.IsPlaneswalker))
            )
        )
        val CreatureOrLand = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsCreature, CardPredicate.IsLand))
            )
        )
        val CreatureOrSorcery = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsCreature, CardPredicate.IsSorcery))
            )
        )
        val CreatureOrEnchantment = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsCreature, CardPredicate.IsEnchantment))
            )
        )
        val ArtifactOrEnchantment = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsArtifact, CardPredicate.IsEnchantment))
            )
        )

        /**
         * Artifact, enchantment, or token — the permanents bargain lets you sacrifice
         * (CR 702.166a). "Token" is not a card type, so it's an independent alternative here:
         * a Food artifact token, an Aura, and a plain 1/1 creature token all qualify, while a
         * nontoken creature does not.
         */
        val ArtifactEnchantmentOrToken = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(
                    listOf(
                        CardPredicate.IsArtifact,
                        CardPredicate.IsEnchantment,
                        CardPredicate.IsToken,
                    )
                )
            )
        )
        val CreatureOrArtifact = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsCreature, CardPredicate.IsArtifact))
            )
        )
        // A Vehicle is always an artifact carrying the Vehicle subtype, so matching the subtype
        // alone identifies it. Used for "creature and/or Vehicle" wording (Rip, Spawn Hunter).
        val CreatureOrVehicle = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsCreature, CardPredicate.HasSubtype(Subtype.VEHICLE)))
            )
        )
        val ArtifactOrLand = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(CardPredicate.IsArtifact, CardPredicate.IsLand))
            )
        )

        /**
         * Artifact, enchantment, or land — the "flexible Naturalize" target family
         * (Creeping Mold, Fade from History). Sits alongside [ArtifactOrEnchantment]
         * and [ArtifactOrLand] as the third member of the same union family.
         */
        val ArtifactEnchantmentOrLand = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(
                    listOf(
                        CardPredicate.IsArtifact,
                        CardPredicate.IsEnchantment,
                        CardPredicate.IsLand,
                    )
                )
            )
        )
        val ArtifactCreature = GameObjectFilter(
            cardPredicates = listOf(CardPredicate.IsArtifact, CardPredicate.IsCreature)
        )
        val ArtifactCreatureOrEnchantment = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(
                    listOf(
                        CardPredicate.IsArtifact,
                        CardPredicate.IsCreature,
                        CardPredicate.IsEnchantment
                    )
                )
            )
        )
        val NoncreaturePermanent = GameObjectFilter(
            cardPredicates = listOf(CardPredicate.IsNoncreature, CardPredicate.IsPermanent)
        )
        val Historic = GameObjectFilter(
            cardPredicates = listOf(
                CardPredicate.Or(listOf(
                    CardPredicate.IsArtifact,
                    CardPredicate.IsLegendary,
                    CardPredicate.HasSubtype(Subtype("Saga"))
                ))
            )
        )
    }

    // =============================================================================
    // Fluent Builder Methods - Card Predicates
    // =============================================================================

    /** Add a color requirement */
    fun withColor(color: Color) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasColor(color)
    )

    /** Match any of the specified colors (OR logic) */
    fun withAnyColor(vararg colors: Color) = copy(
        cardPredicates = cardPredicates + CardPredicate.Or(colors.map { CardPredicate.HasColor(it) })
    )

    /** Exclude a color */
    fun notColor(color: Color) = copy(
        cardPredicates = cardPredicates + CardPredicate.NotColor(color)
    )

    /** Match the color chosen during the current effect's resolution (e.g. via ChooseColorThen). */
    fun withChosenColor() = copy(
        cardPredicates = cardPredicates + CardPredicate.HasChosenColor
    )

    /** Restrict to monocolored objects (exactly one color). Colorless objects do not match. */
    fun monocolored() = copy(
        cardPredicates = cardPredicates + CardPredicate.IsMonocolored
    )

    /** Add a subtype requirement */
    /** Match any fixed card type, including Battle, without narrowing to a named legacy filter. */
    fun withCardType(cardType: CardType) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasCardType(cardType)
    )

    fun withSubtype(subtype: Subtype) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasSubtype(subtype)
    )

    /** Add a subtype requirement by string */
    fun withSubtype(subtype: String) = withSubtype(Subtype(subtype))

    /** Match any of the specified subtypes (OR logic). */
    fun withAnySubtype(vararg subtypes: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.Or(
            subtypes.map { CardPredicate.HasSubtype(Subtype(it)) }
        )
    )

    /** Exclude a subtype */
    fun notSubtype(subtype: Subtype) = copy(
        cardPredicates = cardPredicates + CardPredicate.NotSubtype(subtype)
    )

    /** Restrict to nonartifact objects ("nonartifact creature", the Terror template). */
    fun nonartifact() = copy(
        cardPredicates = cardPredicates + CardPredicate.IsNonartifact
    )

    /** Exclude creatures ("noncreature artifact", e.g. Guardian Beast). */
    fun notCreature() = copy(
        cardPredicates = cardPredicates + CardPredicate.Not(CardPredicate.IsCreature)
    )

    /**
     * Restrict to spells/abilities on the stack that target at least one object matching
     * [subfilter]. Used for "an instant or sorcery spell that targets a creature" (Repartee —
     * Forum Necroscribe, Lecturing Scornmage) and "target spell that targets a land you control"
     * (Teferi's Response). Player targets are skipped (CR — they have no game-object filter).
     */
    fun targetsMatching(subfilter: GameObjectFilter) = copy(
        cardPredicates = cardPredicates + CardPredicate.TargetsMatching(subfilter)
    )

    /**
     * Restrict to activated/triggered abilities on the stack whose *source* (CR 113.7) matches
     * [subfilter] — "from a creature source" (Echo, Perceptive Prodigy), "from an artifact source"
     * (Scientist Supreme of A.I.M.). Read with last known information when the source has already
     * left the battlefield. See [CardPredicate.AbilitySourceMatches].
     */
    fun abilitySourceMatches(subfilter: GameObjectFilter) = copy(
        cardPredicates = cardPredicates + CardPredicate.AbilitySourceMatches(subfilter)
    )

    /**
     * Add an arbitrary [CardPredicate] requirement. General-purpose combinator for predicates that
     * don't have a dedicated helper — e.g. `GameObjectFilter.Nonland.withCardPredicate(
     * CardPredicate.HasActivatedAbility)` for The Enigma Jewel's craft materials.
     */
    fun withCardPredicate(predicate: CardPredicate) = copy(
        cardPredicates = cardPredicates + predicate
    )

    /** Add a keyword requirement */
    fun withKeyword(keyword: Keyword) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasKeyword(keyword)
    )

    /** Exclude a keyword */
    fun withoutKeyword(keyword: Keyword) = copy(
        cardPredicates = cardPredicates + CardPredicate.NotKeyword(keyword)
    )

    /** Match by exact card name */
    fun named(name: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.NameEquals(name)
    )

    /** Match cards whose name is **not** [name] — e.g. "creatures … that don't have the same name". */
    fun notNamed(name: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.Not(CardPredicate.NameEquals(name))
    )

    /** Match cards whose name equals the card name stored in chosenValues[variableName] */
    fun namedFromVariable(variableName: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.NameEqualsChosen(variableName)
    )

    /**
     * Match Room cards whose name isn't shared with a Room the evaluating player controls
     * (CR 709, by unlocked door names) — "a Room card that doesn't have the same name as a
     * Room you control" (Central Elevator).
     */
    fun nameNotSharedWithControlledRoom() = copy(
        cardPredicates = cardPredicates + CardPredicate.NameNotSharedWithControlledRoom
    )

    /** Match permanents whose name isn't shared with a token the evaluating player controls. */
    fun nameNotSharedWithControlledToken() = copy(
        cardPredicates = cardPredicates + CardPredicate.NameNotSharedWithControlledToken
    )

    /**
     * Match permanents whose name isn't shared with *another* permanent the evaluating player
     * controls — "that doesn't have the same name as another permanent you control" (Yenna,
     * Redtooth Regent). The candidate itself is excluded from the comparison; see
     * [CardPredicate.NameNotSharedWithAnotherControlledPermanent].
     */
    fun nameNotSharedWithAnotherControlledPermanent() = copy(
        cardPredicates = cardPredicates + CardPredicate.NameNotSharedWithAnotherControlledPermanent
    )

    /**
     * Match cards whose name equals the name durably chosen by the *source permanent* as it
     * entered (its [com.wingedsheep.engine.state.components.battlefield.CastChoicesComponent] under
     * [slot]). Static-projection / activation-legality safe — use this in static-ability filters
     * (Petrified Hamlet), where [namedFromVariable] would fail closed.
     */
    fun namedFromChosenComponent(slot: com.wingedsheep.sdk.scripting.ChoiceSlot = com.wingedsheep.sdk.scripting.ChoiceSlot.CARD_NAME) = copy(
        cardPredicates = cardPredicates + CardPredicate.NameEqualsChosenComponent(slot)
    )

    /**
     * Match cards whose *card type* equals the card type durably chosen by the *source permanent*
     * as it entered (its [com.wingedsheep.engine.state.components.battlefield.CastChoicesComponent]
     * under [slot]). Static-projection / cost-calculation safe — use this in cost-static filters
     * (Arachne, Psionic Weaver's "spells of the chosen type cost {1} more").
     */
    fun ofChosenCardTypeComponent(slot: com.wingedsheep.sdk.scripting.ChoiceSlot = com.wingedsheep.sdk.scripting.ChoiceSlot.CARD_TYPE) = copy(
        cardPredicates = cardPredicates + CardPredicate.CardTypeEqualsChosenComponent(slot)
    )

    /** Mana value equals */
    fun manaValue(value: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueEquals(value)
    )

    /** Mana value at most */
    fun manaValueAtMost(max: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueAtMost(max)
    )

    /** Mana value at most the X chosen for the source spell/ability */
    fun manaValueAtMostX() = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueAtMostX
    )

    /** Mana value exactly equal to the number chosen for the source spell/ability (Void) */
    fun manaValueEqualsX() = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueEqualsX
    )

    /** Mana value at least */
    fun manaValueAtLeast(min: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueAtLeast(min)
    )

    /** Mana value at most that of a referenced entity (triggering, source, etc.) */
    fun manaValueAtMostEntity(reference: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueAtMostEntity(reference)
    )

    /** Mana value at most the mana actually spent to cast a referenced entity (source, etc.) */
    fun manaValueAtMostEntityManaSpent(reference: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueAtMostEntityManaSpent(reference)
    )

    /** Mana value at most the number of colors of mana spent to cast a referenced entity (Converge). */
    fun manaValueAtMostColorsSpent(reference: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueAtMostColorsSpent(reference)
    )

    /** Mana value at most a resolved [DynamicAmount] (e.g. "X or less, where X is the life you gained this turn"). */
    fun manaValueAtMostDynamic(amount: DynamicAmount) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueAtMostDynamic(amount)
    )

    /**
     * Mana value **exactly** a resolved [DynamicAmount] — "a creature card with mana value equal to
     * the number of harmony counters on this artifact" (Instrument of the Bards).
     *
     * The equality sibling of [manaValueAtMostDynamic]. Oracle marks the difference with the word in
     * front of the clause rather than after it: "equal to …" is this, "less than or equal to …" is
     * the cap.
     */
    fun manaValueEqualsDynamic(amount: DynamicAmount) = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueEqualsDynamic(amount)
    )

    /** Mana value is even (zero is even). */
    fun manaValueIsEven() = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueIsEven
    )

    /** Mana value is odd. */
    fun manaValueIsOdd() = copy(
        cardPredicates = cardPredicates + CardPredicate.ManaValueIsOdd
    )

    /** Printed mana cost contains an {X} symbol (Paradox Surveyor). */
    fun hasXInManaCost() = copy(
        cardPredicates = cardPredicates + CardPredicate.HasXInManaCost
    )

    /**
     * Printed mana cost contains at least [min] mana symbols of [colors] — "with one or more blue
     * mana symbols in its mana cost" (Namor the Sub-Mariner), or every colour at `min = 3` for
     * Omnath, Locus of All's "three or more colored mana symbols in its mana cost". Hybrid and
     * Phyrexian pips count for their colour(s); this is the printed cost, not the object's colour
     * (see [CardPredicate.ColoredManaSymbolsAtLeast]).
     *
     * Colours are varargs to match the amount-side facade
     * [com.wingedsheep.sdk.dsl.DynamicAmounts.coloredManaSymbolsOf], so the gate and the count
     * read the same way at a card's two call sites; [min] follows them and must be named.
     */
    fun coloredManaSymbolsAtLeast(vararg colors: Color, min: Int = 1) = copy(
        cardPredicates = cardPredicates + CardPredicate.ColoredManaSymbolsAtLeast(colors.toList(), min)
    )

    /** Power equals */
    fun power(value: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerEquals(value)
    )

    /** Power exactly equal to the X chosen for the source spell/ability (Ent-Draught Basin) */
    fun powerEqualsX() = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerEqualsX
    )

    /** Power at most */
    fun powerAtMost(max: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerAtMost(max)
    )

    /** Power at least */
    fun powerAtLeast(min: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerAtLeast(min)
    )

    /** Power at least the X chosen for the source spell/ability (Expel the Interlopers). */
    fun powerAtLeastX() = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerAtLeastX
    )

    /** Power strictly greater than the projected power of a referenced entity (source, triggering, etc.) */
    fun powerGreaterThanEntity(reference: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerGreaterThanEntity(reference)
    )

    /** Power less than or equal to the projected power of a referenced entity (source, triggering, etc.) */
    fun powerLessThanEntity(reference: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerLessThanEntity(reference)
    )

    fun powerAtMostEntity(reference: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerAtMostEntity(reference)
    )

    /** Projected power strictly greater than the object's own base (printed) power. */
    fun powerGreaterThanBase() = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerGreaterThanBase
    )

    /** Toughness at most */
    fun toughnessAtMost(max: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.ToughnessAtMost(max)
    )

    /** Toughness at most the X chosen for the source spell/ability. */
    fun toughnessAtMostX() = copy(
        cardPredicates = cardPredicates + CardPredicate.ToughnessAtMostX
    )

    /** Toughness at least */
    fun toughnessAtLeast(min: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.ToughnessAtLeast(min)
    )

    /** Power or toughness at least */
    fun powerOrToughnessAtLeast(min: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerOrToughnessAtLeast(min)
    )

    /** Power or toughness at most */
    fun powerOrToughnessAtMost(max: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.PowerOrToughnessAtMost(max)
    )

    /** Total power and toughness (sum) at most */
    fun totalPowerAndToughnessAtMost(max: Int) = copy(
        cardPredicates = cardPredicates + CardPredicate.TotalPowerAndToughnessAtMost(max)
    )

    /** Toughness strictly greater than power */
    fun toughnessGreaterThanPower() = copy(
        cardPredicates = cardPredicates + CardPredicate.ToughnessGreaterThanPower
    )

    /** Must be legendary */
    fun legendary() = copy(
        cardPredicates = cardPredicates + CardPredicate.IsLegendary
    )

    /** Must not be legendary */
    fun nonlegendary() = copy(
        cardPredicates = cardPredicates + CardPredicate.IsNonlegendary
    )

    /** Must not be a basic land ("nonbasic land", e.g. Rocket Volley, Shivan Harvest). */
    fun nonbasic() = copy(
        cardPredicates = cardPredicates + CardPredicate.Not(CardPredicate.IsBasicLand)
    )

    /** Must not be a token */
    fun nontoken() = copy(
        cardPredicates = cardPredicates + CardPredicate.IsNontoken
    )

    /**
     * Must be *originally printed* in the given set (canonical set code, case-insensitive) —
     * reprints still match their original set. Models "a name originally printed in the [set]
     * expansion" (Golgothian Sylex → "ATQ"; City in a Bottle → "ARN").
     */
    fun originallyPrintedInSet(setCode: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.OriginallyPrintedInSet(setCode)
    )

    /** Must be a token */
    fun token() = copy(
        cardPredicates = cardPredicates + CardPredicate.IsToken
    )

    /** Must not be of the creature type chosen on the source permanent */
    fun notOfSourceChosenType() = copy(
        cardPredicates = cardPredicates + CardPredicate.NotOfSourceChosenType
    )

    /** Match cards whose card type equals a value stored earlier in this resolution. */
    fun withCardTypeFromVariable(variableName: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasCardTypeFromVariable(variableName)
    )

    /** Must have a subtype matching the value stored in chosenValues[variableName] */
    fun withSubtypeFromVariable(variableName: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasSubtypeFromVariable(variableName)
    )

    /** Must have a subtype matching any value in storedStringLists[listName] */
    fun withSubtypeInStoredList(listName: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasSubtypeInStoredList(listName)
    )

    /**
     * Must share at least one subtype with every group in the stored subtype list
     * `pipeline.storedSubtypeGroups[groupName]`. Pair with
     * [com.wingedsheep.sdk.scripting.effects.GatherSubtypesEffect] to populate the
     * stored groups from an entity collection.
     */
    fun withSubtypeInEachStoredGroup(groupName: String) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasSubtypeInEachStoredGroup(groupName)
    )

    /** Must have any one of the given subtypes (OR logic) */
    fun withAnyOfSubtypes(subtypes: List<Subtype>) = copy(
        cardPredicates = cardPredicates + CardPredicate.HasAnyOfSubtypes(subtypes)
    )

    /**
     * Must have none of the given subtypes (e.g. "non-outlaw creature" for a
     * group of outlaw subtypes). Composes [CardPredicate.Not] over
     * [CardPredicate.HasAnyOfSubtypes], so it reuses existing evaluator support.
     */
    fun notAnyOfSubtypes(subtypes: List<Subtype>) = copy(
        cardPredicates = cardPredicates + CardPredicate.Not(CardPredicate.HasAnyOfSubtypes(subtypes))
    )

    /** Must have the subtype chosen on the source permanent */
    fun withChosenSubtype() = copy(
        cardPredicates = cardPredicates + CardPredicate.HasChosenSubtype
    )

    /** Must include the color chosen on the source permanent (CastChoicesComponent) */
    fun sharingChosenColorWithSource() = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesChosenColorWithSource
    )

    /** Must share a creature type with the referenced entity */
    fun sharingCreatureTypeWith(entity: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesCreatureTypeWith(entity)
    )

    /**
     * Must share a **card type** with the referenced entity (Confusion in the Ranks: "target
     * permanent another player controls that shares a card type with it"). The card-type sibling
     * of [sharingCreatureTypeWith] — see [CardPredicate.SharesCardTypeWith] for why the two axes
     * stay apart.
     */
    /**
     * Must share a card type with **any** card exiled with the filtering ability's source — "shares
     * a card type with a card exiled with this creature" (Cemetery Illuminator). The pile-wide form
     * of [sharingCardTypeWith]`(EntityReference.LinkedExiledCard())`; see
     * [CardPredicate.SharesCardTypeWithLinkedExile].
     */
    fun sharingCardTypeWithLinkedExile() = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesCardTypeWithLinkedExile
    )

    /**
     * Must share a **name** with any card exiled with the filtering ability's source — "spells with
     * the same name as a card exiled with Circu" (Circu, Dimir Lobotomist). The name axis of
     * [sharingCardTypeWithLinkedExile]; see [CardPredicate.SharesNameWithLinkedExile].
     */
    fun sharingNameWithLinkedExile() = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesNameWithLinkedExile
    )

    fun sharingCardTypeWith(entity: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesCardTypeWith(entity)
    )

    /** Must share a color with the referenced entity */
    fun sharingColorWith(entity: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesColorWith(entity)
    )

    /**
     * Must have the same name as the referenced entity (Extraplanar Lens: "a land with the same
     * name as the exiled card"). The entity-referencing counterpart of
     * [sharingNameWithPermanentYouControl].
     */
    fun sharingNameWith(entity: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesNameWith(entity)
    )

    /** Must have the same mana value as the referenced entity */
    fun sharingManaValueWith(entity: EntityReference) = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesManaValueWith(entity)
    )

    /**
     * Must share a color with the recipient of the in-flight damage (and not be that
     * recipient). Only meaningful in a damage replacement's source filter. Used by
     * Well-Laid Plans.
     */
    fun sharingColorWithRecipient() = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesColorWithRecipient
    )

    /**
     * Must share a color with at least one permanent the evaluating player controls matching
     * [filter] (Ringsight: "a card that shares a color with a legendary creature you control").
     */
    fun sharingColorWithPermanentYouControl(filter: GameObjectFilter) = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesColorWithPermanentYouControl(filter)
    )

    /**
     * Must have the same name as at least one permanent the evaluating player controls matching
     * [filter] (Key to the Side-Door: "a legendary card with the same name as a legendary permanent
     * you control").
     */
    fun sharingNameWithPermanentYouControl(filter: GameObjectFilter) = copy(
        cardPredicates = cardPredicates + CardPredicate.SharesNameWithPermanentYouControl(filter)
    )

    /**
     * Must share **no** creature type with any permanent the evaluating player controls matching
     * [filter] (Radagast the Brown: "a creature card that doesn't share a creature type with a
     * creature you control").
     */
    fun notSharingCreatureTypeWithPermanentYouControl(filter: GameObjectFilter) = copy(
        cardPredicates = cardPredicates + CardPredicate.DoesNotShareCreatureTypeWithPermanentYouControl(filter)
    )

    /**
     * Must share **no** land type with any permanent the evaluating player controls matching
     * [filter] (Hiveheart Shaman: "a basic land card that doesn't share a land type with a land
     * you control").
     */
    fun notSharingLandTypeWithPermanentYouControl(filter: GameObjectFilter) = copy(
        cardPredicates = cardPredicates + CardPredicate.DoesNotShareLandTypeWithPermanentYouControl(filter)
    )

    // =============================================================================
    // Fluent Builder Methods - State Predicates
    // =============================================================================

    /** Must be tapped */
    fun tapped() = copy(
        statePredicates = statePredicates + StatePredicate.IsTapped
    )

    /** Must be untapped */
    fun untapped() = copy(
        statePredicates = statePredicates + StatePredicate.IsUntapped
    )

    /** Must be a Room with at least one locked door (CR 709.5c). */
    fun hasLockedDoor() = copy(
        statePredicates = statePredicates + StatePredicate.HasLockedDoor
    )

    /**
     * Must be on the battlefield right now. Pair with a predicate that carries a last-known-info
     * fallback to force a live reading — `onBattlefield().attacking()` is "is attacking", where a
     * bare `attacking()` is "is or was attacking" for an object that has already left.
     */
    fun onBattlefield() = copy(
        statePredicates = statePredicates + StatePredicate.IsOnBattlefield
    )

    /** Must be attacking */
    fun attacking() = copy(
        statePredicates = statePredicates + StatePredicate.IsAttacking
    )

    /** Must be attacking, with no other creature attacking (CR 506.5). */
    fun attackingAlone() = copy(
        statePredicates = statePredicates + StatePredicate.IsAttackingAlone
    )

    /**
     * Must be attacking one of *your* opponents — the player themselves, so an attacker pointed at
     * an opponent's planeswalker or battle doesn't match. Narrower than [attacking]; "you" is the
     * controller of whatever ability applies the filter.
     */
    fun attackingAnOpponent() = copy(
        statePredicates = statePredicates + StatePredicate.IsAttackingAnOpponent
    )

    /**
     * The defender-side mirror of [attackingAnOpponent]: must be attacking *you* or a planeswalker
     * *you* control (Tomik, Wielder of Law). "You" is the controller of whatever ability applies
     * the filter, so this matches regardless of who controls the attacker. Battles are excluded.
     */
    fun attackingYouOrYourPlaneswalkers() = copy(
        statePredicates = statePredicates + StatePredicate.IsAttackingYouOrYourPlaneswalkers
    )

    /**
     * Must be attacking the player the filtering ability's source is attached to — "creatures
     * attacking enchanted player" (Curse of Hospitality). The attachment-scoped sibling of
     * [attackingAnOpponent]; only meaningful on an Aura that enchants a player.
     */
    fun attackingEnchantedPlayer() = copy(
        statePredicates = statePredicates + StatePredicate.IsAttackingEnchantedPlayer
    )

    /**
     * Must have been declared as an attacker at least once during the current turn.
     * Survives leaving combat; cleared at end-of-turn cleanup.
     */
    fun attackedThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.AttackedThisTurn
    )

    /** Was **not** declared as an attacker at any point this turn. Negation of [attackedThisTurn]. */
    fun didntAttackThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.AttackedThisTurn)
    )

    /**
     * Could **not** have been declared as an attacker this turn — its controller wasn't the one
     * declaring attackers, no Declare Attackers Step happened at all, or it has defender, can't
     * attack, or is summoning sick. "Except for creatures that couldn't attack" (Season of the
     * Witch). See [StatePredicate.CouldNotHaveAttackedThisTurn] for exactly what it covers.
     */
    fun couldNotHaveAttackedThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.CouldNotHaveAttackedThisTurn
    )

    /** The complement: the creature *could* have been declared as an attacker this turn. */
    fun couldHaveAttackedThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.CouldNotHaveAttackedThisTurn)
    )

    /**
     * Was declared as an attacker during its controller's **most recent own turn** — the one-turn-back
     * sibling of [attackedThisTurn]. False on the turn it actually attacked, true on the next one.
     */
    fun attackedLastTurn() = copy(
        statePredicates = statePredicates + StatePredicate.AttackedLastTurn
    )

    /** Was declared as a blocker at least once this turn (CR 509.1). */
    fun blockedThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.BlockedThisTurn
    )

    /**
     * Was declared as an attacker at least once during the current combat (CR 508.1). Backed by a
     * per-entity marker stamped at attacker-declaration time; cleared when the combat phase ends.
     * Survives removal from combat. Pair with [blockedThisCombat] for "attacked or blocked this combat".
     */
    fun attackedThisCombat() = copy(
        statePredicates = statePredicates + StatePredicate.AttackedThisCombat
    )

    /**
     * Was declared as a blocker at least once during the current combat (CR 509.1). Backed by a
     * per-entity marker stamped at blocker-declaration time; cleared when the combat phase ends.
     * Survives the blocked attacker dying (which clears the live `BlockingComponent`).
     */
    fun blockedThisCombat() = copy(
        statePredicates = statePredicates + StatePredicate.BlockedThisCombat
    )

    /**
     * Must have become tapped **exactly once so far this turn** — the live reading of "if it's the
     * first time that creature has become tapped this turn" (Captain America, Living Legend), backed
     * by [StatePredicate.BecameTappedOnlyOnceThisTurn].
     *
     * Answers from the permanent's current tap count, so it is the half of that printed intervening
     * "if" that CR 603.4 re-checks at resolution; the trigger-time half rides on the tap event as
     * `Triggers.becomesTapped(firstTimeEachTurn = true)`. `Conditions
     * .TriggeringPermanentBecameTappedOnlyOnceThisTurn` is this predicate aimed at the triggering
     * permanent.
     */
    fun becameTappedOnlyOnceThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.BecameTappedOnlyOnceThisTurn
    )

    /**
     * Must have had one or more counters put on it this turn — the counter-history counterpart of
     * [wasDealtDamageThisTurn]. Recorded at placement time, so it survives the counters being removed
     * again; cleared at end-of-turn cleanup.
     *
     * [counterType] scopes it to one kind ("one or more **+1/+1** counters") and
     * [placedByController] to counters the permanent's own controller put on ("**you've** put").
     * Used by Kid Loki's "each creature you control that you've put one or more +1/+1 counters on
     * this turn"; `Conditions.SourceReceivedCounterThisTurn` is this predicate under `SourceMatches`.
     */
    fun receivedCounterThisTurn(
        counterType: String? = null,
        placedByController: Boolean = false
    ) = copy(
        statePredicates = statePredicates +
            StatePredicate.ReceivedCounterThisTurn(counterType, placedByController)
    )

    /**
     * Must have been dealt damage this turn — the **passive** voice (damage *received*), marked-damage
     * *history* rather than current marked damage. Survives damage removal / leaving combat; cleared at
     * end-of-turn cleanup. Used by "...that was dealt damage this turn" (Rooftop Assassin, Unsparing
     * Boltcaster). The active-voice counterpart is [hasDealtDamageThisTurn].
     */
    fun wasDealtDamageThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.WasDealtDamageThisTurn
    )

    /**
     * Must have **dealt** damage this turn — the active voice, and the mirror of
     * [wasDealtDamageThisTurn]. Combat and noncombat damage both count, to any recipient. Used by
     * "target creature an opponent controls that dealt damage this turn" (Red Guardian,
     * Super-Soldier).
     *
     * Named `hasDealtDamageThisTurn`, not the shorter `dealtDamageThisTurn`, deliberately: the short
     * name used to mean the *passive* predicate above. Retiring it outright turns any un-rebased
     * caller into a compile error at the exact line instead of a silent flip to the opposite set of
     * permanents. It also pairs with [hasDealtDamage], the same predicate's lifetime window.
     */
    fun hasDealtDamageThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.HasDealtDamage(thisTurnOnly = true)
    )

    /**
     * Must have dealt damage at least once since entering the battlefield — [hasDealtDamageThisTurn]
     * widened to the permanent's whole lifetime as the current object. `Conditions.SourceHasDealtDamage`
     * is this predicate under `SourceMatches` (Karakyk Guardian).
     */
    fun hasDealtDamage() = copy(
        statePredicates = statePredicates + StatePredicate.HasDealtDamage()
    )

    /**
     * Must be in the same combat band as the effect's source (the source itself, or a band-mate
     * sharing its band id — CR 702.22). Source-relative; only matches while the source attacks.
     */
    fun inSameBandAsSource() = copy(
        statePredicates = statePredicates + StatePredicate.InSameBandAsSource
    )

    /**
     * Must have dealt combat damage *this turn* to the player who controls the effect's source.
     * Source-relative; cleared at end-of-turn cleanup. Used by "each opponent sacrifices a
     * creature ... that dealt combat damage to you this turn" (Witch-king of Angmar).
     */
    fun dealtCombatDamageToSourceControllerThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.DealtCombatDamageToSourceControllerThisTurn
    )

    /**
     * Must be controlled — right now — by a player the effect's *source* dealt combat damage to
     * this turn. Mirror of [dealtCombatDamageToSourceControllerThisTurn]; source-relative and
     * cleared at end-of-turn cleanup. Used by "destroy each nonland permanent … whose controller
     * was dealt combat damage by this creature this turn" (Steel Hellkite).
     */
    fun controllerDealtCombatDamageBySourceThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.ControllerDealtCombatDamageBySourceThisTurn
    )

    /**
     * The candidate's controller controls at least one permanent matching [subfilter] — Seasinger's
     * "target creature whose controller controls an Island". The subfilter's "you" is the
     * *candidate's* controller, not the ability's.
     */
    fun controllerControls(subfilter: GameObjectFilter) = copy(
        statePredicates = statePredicates + StatePredicate.ControllerControls(subfilter)
    )

    /** Must be blocking */
    fun blocking() = copy(
        statePredicates = statePredicates + StatePredicate.IsBlocking
    )

    /**
     * Must be blocking the effect's source (CR 509). Source-relative; only matches the source's
     * own blockers. "Whenever this becomes blocked, it deals N damage to each creature blocking it."
     */
    fun blockingSource() = copy(
        statePredicates = statePredicates + StatePredicate.IsBlockingSource
    )

    /**
     * Must be blocking the effect's source **or** blocked by it (CR 509), read live from combat
     * state. Source-relative. "Each creature blocking or blocked by this creature" (Spitting Slug).
     */
    fun blockingOrBlockedBySource() = copy(
        statePredicates = statePredicates + StatePredicate.IsCombatPairedWithSource
    )

    /**
     * Blocking the entity the enclosing `ForEachInGroup` is iterating over — Tidal Flats'
     * "creatures you control blocking that creature".
     */
    fun blockingIterationEntity() = copy(
        statePredicates = statePredicates + StatePredicate.IsBlockingIterationEntity
    )

    /**
     * Must be a token created by the effect's source permanent (CR 111 provenance), recognized via
     * the source's stamped `CreatedByComponent`. "Tokens created with this creature" (Tetravus).
     */
    fun createdBySource() = copy(
        statePredicates = statePredicates + StatePredicate.CreatedBySource
    )

    /**
     * Not the target of an ability on the stack from another permanent sharing the effect source's
     * name. Goblin Artisans: "counter target artifact spell you control that isn't the target of an
     * ability from another creature named Goblin Artisans."
     */
    fun notTargetedByAbilityFromSameNamedSource() = copy(
        statePredicates = statePredicates + StatePredicate.NotTargetedByAbilityFromSameNamedSource
    )

    /**
     * Must NOT be the permanent the effect's source is attached to (its enchanted/equipped
     * creature). "Other than enchanted creature" exclusions on Aura/Equipment edicts — e.g.
     * Sporogenic Infection's "sacrifices a creature of their choice other than enchanted creature".
     */
    fun notAttachedToBySource() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.IsAttachedToBySource)
    )

    /**
     * Must BE the permanent the effect's source is attached to (its enchanted/equipped
     * permanent). Source-relative — scopes a static ability on an Aura/Equipment to just its
     * host, e.g. Stuck in Summoner's Sanctum's "enchanted permanent's activated abilities can't
     * be activated" via [com.wingedsheep.sdk.scripting.PreventActivatedAbilities].
     */
    fun attachedToBySource() = copy(
        statePredicates = statePredicates + StatePredicate.IsAttachedToBySource
    )

    /**
     * Must BE the effect's source permanent itself — the [GameObjectFilter] counterpart of
     * `GroupFilter`'s `Scope.Self`. Scopes a filter-carrying static ability to the very
     * permanent that carries it: granting
     * [PreventActivatedAbilities][com.wingedsheep.sdk.scripting.PreventActivatedAbilities]
     * with this filter locks the *holder's own* activated abilities (Braided Net's
     * "Its activated abilities can't be activated for as long as it remains tapped").
     */
    fun sourceItself() = copy(
        statePredicates = statePredicates + StatePredicate.IsSource
    )

    /**
     * Must NOT be the effect's source permanent — the negation of [sourceItself], and the
     * [GameObjectFilter] counterpart of `GroupFilter`/`TargetFilter`'s `excludeSelf`. Needed
     * wherever "other [permanents]" has to be expressed as a bare `GameObjectFilter` rather
     * than a group/target filter — e.g. a `RecipientFilter.Matching` on a damage replacement
     * ("prevent all noncombat damage that would be dealt to *other* creatures you control",
     * Crystal Barricade).
     */
    fun notSourceItself() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.IsSource)
    )

    /**
     * Must BE an Aura/Equipment attached to the effect's source permanent — the mirror of
     * [attachedToBySource]. Source-relative — scopes a static ability on the *host* to its own
     * attachments, e.g. Cloud, Midgar Mercenary's "an Equipment attached to it".
     */
    fun attachedToSource() = copy(
        statePredicates = statePredicates + StatePredicate.IsAttachedToSource
    )

    /**
     * Must NOT be an Aura/Equipment attached to the effect's source permanent — the negation of
     * [attachedToSource].
     */
    fun notAttachedToSource() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.IsAttachedToSource)
    )

    /**
     * Must NOT be the *granting permanent* of the resolving ability — excludes exactly the
     * Equipment/Aura/permanent whose static ability granted the ability (read from the evaluation
     * context's `granterId`, CR 201.5a). Backs "an artifact other than [this granting Equipment]"
     * on a granted triggered ability whose source is the equipped creature (Dire Blunderbuss's
     * "sacrifice an artifact other than Dire Blunderbuss"): unlike [notAttachedToSource] it
     * excludes only the specific granter, leaving other attachments and same-named copies legal.
     */
    fun notGrantingPermanent() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.IsGrantingPermanent)
    )

    /**
     * Must be attached to a permanent matching [hostFilter] (general form of attachment matching —
     * the host filter may carry a controller predicate, e.g. "a creature you control"). Used by
     * Stolen Uniform's reflexive "if it's attached to a creature you control" guard.
     */
    fun attachedTo(hostFilter: GameObjectFilter) = copy(
        statePredicates = statePredicates + StatePredicate.AttachedTo(hostFilter)
    )

    /** Must be attacking or blocking */
    fun attackingOrBlocking() = copy(
        statePredicates = statePredicates + StatePredicate.Or(
            listOf(StatePredicate.IsAttacking, StatePredicate.IsBlocking)
        )
    )

    /** Must be attacking, blocking, or tapped */
    fun attackingOrBlockingOrTapped() = copy(
        statePredicates = statePredicates + StatePredicate.Or(
            listOf(StatePredicate.IsAttacking, StatePredicate.IsBlocking, StatePredicate.IsTapped)
        )
    )

    /** Must have entered the battlefield this turn */
    fun enteredThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.EnteredThisTurn
    )

    /**
     * Must currently be in a graveyard *and* have been put there from the battlefield
     * during the current turn. Used by LTR's Samwise the Stouthearted / Lobelia
     * Sackville-Baggins. See [StatePredicate.PutIntoGraveyardFromBattlefieldThisTurn].
     */
    fun putIntoGraveyardFromBattlefieldThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.PutIntoGraveyardFromBattlefieldThisTurn
    )

    /**
     * Must currently be in a graveyard *and* have been put there during the current turn,
     * from any zone. The zone-agnostic sibling of [putIntoGraveyardFromBattlefieldThisTurn],
     * used by FDN's Abyssal Harvester. See [StatePredicate.PutIntoGraveyardThisTurn].
     */
    fun putIntoGraveyardThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.PutIntoGraveyardThisTurn
    )

    /** Must be saddled (CR 702.171b) */
    fun saddled() = copy(
        statePredicates = statePredicates + StatePredicate.IsSaddled
    )

    /** Must be suspected (CR 701.60a) — see [StatePredicate.IsSuspected]. */
    fun suspected() = copy(
        statePredicates = statePredicates + StatePredicate.IsSuspected
    )

    /** Must have the solved designation (CR 719.3b) — see [StatePredicate.IsSolved]. */
    fun solved() = copy(
        statePredicates = statePredicates + StatePredicate.IsSolved
    )

    /** Must have the renowned designation (CR 702.112b) — see [StatePredicate.IsRenowned]. */
    fun renowned() = copy(
        statePredicates = statePredicates + StatePredicate.IsRenowned
    )

    /**
     * Must have crewed (CR 702.122) or saddled (CR 702.171) the effect's source permanent this
     * turn. Source-relative — see [StatePredicate.CrewedOrSaddledSourceThisTurn].
     */
    fun crewedOrSaddledSourceThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.CrewedOrSaddledSourceThisTurn
    )

    /**
     * Must be a Vehicle/Mount that the effect's source creature crewed (CR 702.122) or saddled
     * (CR 702.171) this turn. Source-relative mirror of [crewedOrSaddledSourceThisTurn] — see
     * [StatePredicate.CrewedOrSaddledBySourceThisTurn].
     */
    fun crewedOrSaddledBySourceThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.CrewedOrSaddledBySourceThisTurn
    )

    /** Must be face-down */
    fun faceDown() = copy(
        statePredicates = statePredicates + StatePredicate.IsFaceDown
    )

    /** Must be face-up (not face-down) */
    fun faceUp() = copy(
        statePredicates = statePredicates + StatePredicate.IsFaceUp
    )

    /** Must have a morph ability */
    fun withMorph() = copy(
        statePredicates = statePredicates + StatePredicate.HasMorphAbility
    )

    /**
     * Must have a printed disguise ability (CR 702.168) — see [StatePredicate.HasDisguiseAbility].
     * Zone-independent, and independent of whether the object is currently face down.
     */
    fun withDisguise() = copy(
        statePredicates = statePredicates + StatePredicate.HasDisguiseAbility
    )

    /** Must have a counter of the specified type */
    fun withCounter(counterType: String) = copy(
        statePredicates = statePredicates + StatePredicate.HasCounter(counterType)
    )

    /** Must not have a counter of the specified type. Other counter types are allowed. */
    fun withoutCounter(counterType: String) = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.HasCounter(counterType))
    )

    /** Must have any counter of any type */
    fun withAnyCounter() = copy(
        statePredicates = statePredicates + StatePredicate.HasAnyCounter
    )

    /** Must have no counters of any type ("with no counters on it" — Heartless Act). */
    fun withoutCounters() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.HasAnyCounter)
    )

    /** Must have the greatest power among creatures its controller controls */
    fun hasGreatestPower() = copy(
        statePredicates = statePredicates + StatePredicate.HasGreatestPower
    )

    /**
     * Must have the least power among *all* creatures on the battlefield (global, both players).
     * On a tie every minimum-power creature matches — pair with a "choose one" selection to break
     * the tie (Drop of Honey).
     */
    fun hasLeastPowerAmongAllCreatures() = copy(
        statePredicates = statePredicates + StatePredicate.HasLeastPowerAmongAllCreatures
    )

    /**
     * Must have the greatest mana value among *all* creatures on the battlefield (global, both
     * players). On a tie every maximum-mana-value creature matches (Favor of the Mighty).
     */
    fun hasGreatestManaValueAmongAllCreatures() = copy(
        statePredicates = statePredicates + StatePredicate.HasGreatestManaValueAmongAllCreatures
    )

    /** Must have the least mana value among battlefield permanents matching [candidates]. */
    fun hasLeastManaValueAmong(candidates: GameObjectFilter) = copy(
        statePredicates = statePredicates + StatePredicate.HasLeastManaValueAmong(candidates)
    )

    /** Must have the least power among creatures its controller controls */
    fun hasLeastPower() = copy(
        statePredicates = statePredicates + StatePredicate.HasLeastPower
    )

    /** Must be its controller's Ring-bearer (CR 701.54). */
    fun ringBearer() = copy(
        statePredicates = statePredicates + StatePredicate.IsRingBearer
    )

    /** Must be soulbond-paired with another creature (CR 702.95b). */
    fun paired() = copy(
        statePredicates = statePredicates + StatePredicate.IsPaired
    )

    /** Must **not** be soulbond-paired — the "unpaired creature" of CR 702.95b. */
    fun unpaired() = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.IsPaired)
    )

    /** Must have blocked, or been blocked by, a legendary creature this turn (You Cannot Pass!). */
    fun blockedOrWasBlockedByLegendaryThisTurn() = copy(
        statePredicates = statePredicates + StatePredicate.BlockedOrWasBlockedByLegendaryThisTurn
    )

    /** Must have at least one Equipment attached */
    fun equipped() = copy(
        statePredicates = statePredicates + StatePredicate.IsEquipped
    )

    /**
     * Must have at least one Aura attached — "enchanted creature" as a group adjective. Compose with
     * [youControl] for "enchanted creatures you control" (A Tale for the Ages); the Aura's own
     * controller is irrelevant. See [StatePredicate.IsEnchanted].
     */
    fun enchanted() = copy(
        statePredicates = statePredicates + StatePredicate.IsEnchanted
    )

    /**
     * Must have at least one attached Aura controlled by [auraController] — the aura-control-scoped
     * form of [enchanted] ("enchanted by Auras you control", Archon of the Wild Rose). Compose with
     * [youControl] to constrain the enchanted permanent's controller too; the two bind to different
     * objects. See [StatePredicate.IsEnchantedByAura].
     */
    fun enchantedByAura(auraController: ControllerPredicate = ControllerPredicate.ControlledByYou) = copy(
        statePredicates = statePredicates + StatePredicate.IsEnchantedByAura(auraController)
    )

    /**
     * Must be marked as a "warped card in exile" (CR 702.185b) — i.e., the
     * engine wrote a `WarpExiledComponent` when the warped permanent left the
     * battlefield at end of turn. Use this when filtering candidates in the
     * exile zone for costs like Close Encounter.
     */
    fun warpExiled() = copy(
        statePredicates = statePredicates + StatePredicate.IsWarpExiled
    )

    /**
     * Must be a card exiled by the effect's source permanent (recorded in the source's
     * `LinkedExileComponent`). Source-relative — use when filtering candidates in the exile zone
     * for "target card exiled with ~" reanimation abilities (The Darkness Crystal).
     */
    fun exiledWithSource() = copy(
        statePredicates = statePredicates + StatePredicate.ExiledWithSource
    )

    /**
     * Must be a permanent on the battlefield that was cast for its warp cost
     * (CR 702.185) — i.e., the engine wrote a `WarpedComponent` when the
     * warped spell resolved. Use this to gate effects on warp-cast permanents,
     * e.g. Full Bore's conditional trample + haste branch.
     */
    fun castForWarp() = copy(
        statePredicates = statePredicates + StatePredicate.WasCastForWarp
    )

    /**
     * Must be a spell on the stack cast from [zone] — reads the engine's stamped
     * `SpellOnStackComponent.castFromZone`. See [StatePredicate.WasCastFromZone].
     */
    fun castFromZone(zone: com.wingedsheep.sdk.core.Zone) = copy(
        statePredicates = statePredicates + StatePredicate.WasCastFromZone(zone)
    )

    /**
     * Must be a spell on the stack that was *not* cast from [zone]. Backs Wash Away's
     * "counter target spell that wasn't cast from its owner's hand" (`Zone.HAND`).
     */
    fun notCastFromZone(zone: com.wingedsheep.sdk.core.Zone) = copy(
        statePredicates = statePredicates + StatePredicate.Not(StatePredicate.WasCastFromZone(zone))
    )

    // =============================================================================
    // Fluent Builder Methods - Controller Predicates
    // =============================================================================

    /** Must be controlled by you */
    fun youControl() = copy(controllerPredicate = ControllerPredicate.ControlledByYou)

    /** Must be controlled by an opponent */
    fun opponentControls() = copy(controllerPredicate = ControllerPredicate.ControlledByOpponent)

    /** Controlled by any player (no controller scope) */
    fun anyController() = copy(controllerPredicate = ControllerPredicate.ControlledByAny)

    /**
     * Controlled by the player the asking ability's *source* Aura is attached to — "creatures
     * enchanted player controls" (Radiant Restraints). The attachment-scoped controller sibling of
     * [StatePredicate.IsAttackingEnchantedPlayer]: every other controller scope here resolves
     * against the ability's own controller, which for a curse is exactly the wrong player.
     *
     * A named recipe over [ControllerPredicate.ControlledByReferencedPlayer], not a new predicate —
     * `PlayerRef(Player.EnchantedPlayer)` already names the player; this only spares every curse
     * from spelling out the reference and gives the shape a searchable name.
     *
     * Fails closed when the source isn't an Aura attached to a player, so a curse that has fallen
     * off (or a filter asked with no source in scope) matches nothing rather than everything.
     */
    fun controlledByEnchantedPlayer() = copy(
        controllerPredicate = ControllerPredicate.ControlledByReferencedPlayer(
            EffectTarget.PlayerRef(com.wingedsheep.sdk.scripting.references.Player.EnchantedPlayer)
        )
    )

    /** Must be controlled by the active player (the player whose turn it is) */
    fun controlledByActivePlayer() = copy(controllerPredicate = ControllerPredicate.ControlledByActivePlayer)

    /** Must be controlled by the target opponent */
    fun targetOpponentControls() = copy(controllerPredicate = ControllerPredicate.ControlledByTargetOpponent)

    /** Must be controlled by the target player */
    fun targetPlayerControls() = copy(controllerPredicate = ControllerPredicate.ControlledByTargetPlayer)

    /**
     * Must be controlled by the player referenced by [target].
     *
     * Preferred over [targetPlayerControls] when a spell declares the player target
     * explicitly (e.g., `val p = target("target player", TargetPlayer())`) and threads
     * that reference into the filter — avoids relying on implicit "first player target"
     * resolution.
     */
    fun targetPlayerControls(target: EffectTarget) =
        copy(controllerPredicate = ControllerPredicate.ControlledByReferencedPlayer(target))

    /** Must be owned by you (for cards in graveyards/exile that don't have controllers) */
    fun ownedByYou() = copy(controllerPredicate = ControllerPredicate.OwnedByYou)

    /** Must be owned by an opponent (for cards in graveyards/exile that don't have controllers) */
    fun ownedByOpponent() = copy(controllerPredicate = ControllerPredicate.OwnedByOpponent)

    /**
     * Must be owned by the target player (Hurkyl's Recall — "all artifacts target player owns").
     * Matches the card's immutable owner, so it captures battlefield permanents the target owns
     * even when another player controls them.
     */
    fun ownedByTargetPlayer() = copy(controllerPredicate = ControllerPredicate.OwnedByTargetPlayer)

    /**
     * Must be owned by the trigger's associated player — the damaged player for a combat/damage
     * trigger (Fire Lord Sozin — "creature cards … from that player's graveyard"). Matches the
     * card's immutable owner, so it captures cards in a graveyard the triggering player owns.
     */
    fun ownedByTriggeringPlayer() = copy(controllerPredicate = ControllerPredicate.OwnedByTriggeringPlayer)

    /**
     * Must be controlled by the trigger's associated player — the damaged player for a combat/damage
     * trigger (Dreadmaw's Ire — "destroy target artifact that player controls"). Reads projected
     * control, so it tracks control-changing effects, unlike the owner-based
     * [ownedByTriggeringPlayer].
     */
    fun controlledByTriggeringPlayer() = copy(controllerPredicate = ControllerPredicate.ControlledByTriggeringPlayer)

    /**
     * Must match [predicate] on the controller/owner axis. The entry point for *composed*
     * predicates ([ControllerPredicate.And] / [ControllerPredicate.Or] / [ControllerPredicate.Not])
     * — e.g. "permanents you own but don't control":
     * `withControllerPredicate(ControllerPredicate.And(listOf(OwnedByYou, ControlledByOpponent)))`.
     * For the plain single predicates, prefer the named builders ([youControl],
     * [opponentControls], [ownedByYou], …).
     */
    fun withControllerPredicate(predicate: ControllerPredicate) = copy(controllerPredicate = predicate)

    // =============================================================================
    // Composition
    // =============================================================================

    /**
     * Combine with another filter using AND logic.
     *
     * Both sides may carry the *same* controller predicate (or only one side any), but two
     * *different* controller predicates are rejected: silently keeping one of them was the
     * old fail-open behavior, and there is no single right merge (AND-ing `youControl` with
     * `opponentControls` is unsatisfiable, while "owned by you AND controlled by an
     * opponent" is a real MTG concept). State the intent explicitly with a composed
     * [ControllerPredicate.And] via [withControllerPredicate] instead.
     */
    infix fun and(other: GameObjectFilter): GameObjectFilter {
        require(
            controllerPredicate == null ||
                other.controllerPredicate == null ||
                controllerPredicate == other.controllerPredicate
        ) {
            "Cannot AND two filters with different controller predicates " +
                "('${controllerPredicate?.description}' vs '${other.controllerPredicate?.description}'). " +
                "Compose them explicitly with withControllerPredicate(ControllerPredicate.And(...))."
        }
        require(other.anyOf.isEmpty()) {
            "Cannot AND a filter whose right-hand side carries an anyOf union " +
                "('${other.description}') — the union branches would be silently dropped. " +
                "Restructure so the union is the left-hand side, or distribute the AND over the branches."
        }
        return copy(
            cardPredicates = cardPredicates + other.cardPredicates,
            statePredicates = statePredicates + other.statePredicates,
            controllerPredicate = controllerPredicate ?: other.controllerPredicate
        )
    }

    /**
     * Combine with another filter using OR logic.
     *
     * A *homogeneous* OR — both branches sharing the same state and controller gate and
     * differing only in card-type predicates (e.g. `Creature.youControl() or
     * Artifact.youControl()`) — collapses to a single [CardPredicate.Or] under that shared
     * gate. This is the flat representation the whole engine already understands (including
     * lord / subtype resolution), so the common case stays simple.
     *
     * A *heterogeneous* OR, whose branches carry different state/controller predicates
     * (e.g. `Artifact or Creature.tapped()` — the tapped restriction binds only to the
     * creature branch), cannot be flattened and instead builds the recursive [anyOf] union,
     * where each branch is matched as a complete filter.
     */
    infix fun or(other: GameObjectFilter): GameObjectFilter {
        val homogeneous = controllerPredicate == other.controllerPredicate &&
            statePredicates == other.statePredicates &&
            anyOf.isEmpty() && other.anyOf.isEmpty()
        return if (homogeneous) {
            GameObjectFilter(
                cardPredicates = listOf(
                    CardPredicate.Or(
                        listOf(cardPredicates.toConjunction(), other.cardPredicates.toConjunction())
                    )
                ),
                statePredicates = statePredicates,
                controllerPredicate = controllerPredicate
            )
        } else {
            GameObjectFilter(anyOf = listOf(this, other))
        }
    }

    override fun applyTextReplacement(replacer: TextReplacer): GameObjectFilter {
        var changed = false
        val newPredicates = cardPredicates.map {
            val new = it.applyTextReplacement(replacer)
            if (new !== it) changed = true
            new
        }
        val newAnyOf = anyOf.map {
            val new = it.applyTextReplacement(replacer)
            if (new !== it) changed = true
            new
        }
        return if (changed) copy(cardPredicates = newPredicates, anyOf = newAnyOf) else this
    }
}

/** Wraps a list of predicates into a single conjunction; returns the single element if only one. */
private fun List<CardPredicate>.toConjunction(): CardPredicate =
    if (isEmpty()) CardPredicate.And(emptyList())
    else if (size == 1) first() else CardPredicate.And(this)
