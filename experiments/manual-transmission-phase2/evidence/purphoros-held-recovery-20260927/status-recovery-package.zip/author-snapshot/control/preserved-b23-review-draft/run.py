#!/usr/bin/env python3
"""Observe one unchanged deterministic assertion; never admit Manual gameplay."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(os.environ["GITHUB_WORKSPACE"])
SOURCE, CONTROL, OUT = ROOT / "source", ROOT / "control", ROOT / "output"
TOOLS = ROOT / "diagnostic-tools"
HEAD = "99f5611185d4338a45b60b988c9afe227bf74944"
TREE = "ee14faf380805b04bfcccc722eb2b0e320ac2508"
BRANCH = "refs/heads/lab/manual-purphoros-one-case-diagnostic-20260927"
CONTROLS = ["run.py", "scope.json", ".github/workflows/manual-purphoros-one-case-diagnostic.yml"]
RESERVE = 4 * 1024 * 1024


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return sha_bytes(path.read_bytes())


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def git(*args, root=SOURCE):
    return subprocess.check_output(["git", *args], cwd=root, text=True,
                                   stderr=subprocess.STDOUT, timeout=60).strip()


def size(path):
    return sum(p.stat().st_size for p in path.rglob("*") if p.is_file()) if path.exists() else 0


def terminate_owned(process):
    # Only the process group created by this invocation is ever signalled.
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    finally:
        # A wrapper can exit before its children/pipe. Kill this same owned group only.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)


def run_capped(command, cwd, log, reports, limits, env, timeout):
    started = time.monotonic()
    reason, written, discarded = None, 0, 0
    process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, start_new_session=True)
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)
    try:
        with log.open("wb") as stream:
            while selector.get_map() or process.poll() is None:
                if time.monotonic() - started > timeout:
                    reason = "OWNED_COMMAND_TIMEOUT"; break
                if size(reports) > limits["test_result_bytes"]:
                    reason = "OBSERVED_REPORT_BYTE_LIMIT"; break
                if size(OUT) >= limits["artifact_bytes"] - RESERVE:
                    reason = "ARTIFACT_BYTE_LIMIT"; break
                for key, _ in selector.select(timeout=0.1):
                    raw = os.read(key.fileobj.fileno(), 65536)
                    if not raw:
                        selector.unregister(key.fileobj)
                        continue
                    available = max(0, min(limits["stdout_bytes"] - written,
                                          limits["artifact_bytes"] - size(OUT) - RESERVE))
                    kept = raw[:available]
                    stream.write(kept); stream.flush(); written += len(kept)
                    discarded += len(raw) - len(kept)
                    if len(kept) != len(raw):
                        reason = "STDOUT_OR_ARTIFACT_BYTE_LIMIT"; break
                if reason:
                    break
                if not selector.get_map() and process.poll() is None:
                    time.sleep(0.1)
            if not reason:
                process.wait(timeout=5)
            # Catch the final XML flush after the last pipe event.
            if size(reports) > limits["test_result_bytes"]:
                reason = reason or "OBSERVED_REPORT_BYTE_LIMIT"
    finally:
        if reason or process.poll() is None:
            terminate_owned(process)
        selector.close()
        process.stdout.close()
    return {"exit_status": process.returncode, "technical_limit": reason,
            "retained_stdout_bytes": written, "discarded_observed_bytes": discarded,
            "output_complete": reason is None, "elapsed_seconds": time.monotonic() - started}


def retain(path, target, limits, per_file):
    available = max(0, min(per_file, limits["artifact_bytes"] - size(OUT) - RESERVE))
    observed = path.stat().st_size
    with path.open("rb") as source:
        raw = source.read(min(observed, available))
    complete = len(raw) == observed
    if not complete:
        target = target.with_name(target.name + ".partial")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    return {"path": str(target.relative_to(OUT)), "observed_bytes": observed,
            "retained_bytes": len(raw), "sha256": sha_bytes(raw), "complete": complete}


def source_observation(scope, stage, instrumented=False):
    row = {"stage": stage, "head": None, "tree": None, "status": None,
           "pins": {}, "validation": "INCOMPLETE"}
    destination = OUT / ("source-" + stage + ".json")
    try:
        for key, args in [("head", ("rev-parse", "HEAD")),
                          ("tree", ("rev-parse", "HEAD^{tree}")),
                          ("status", ("status", "--porcelain"))]:
            row[key] = git(*args)
            write_json(destination, row)
        assert row["head"] == scope["source_head"] == HEAD
        assert row["tree"] == scope["source_tree"] == TREE
        expected_status = "M " + scope["test_source"] if instrumented else ""
        # git() strips the leading space in the one allowed unstaged modification.
        assert row["status"] == expected_status, "Unexpected source change"
        for path, expected in scope["source_pins"].items():
            raw = (SOURCE / path).read_bytes()
            actual = {"sha256": sha_bytes(raw),
                      "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}
            row["pins"][path] = actual
            write_json(destination, row)  # Preserve observations before any rejection.
            if instrumented and path == scope["test_source"]:
                assert actual["sha256"] == scope["instrumentation"]["instrumented_sha256"]
            else:
                assert actual == expected, "Source pin mismatch: " + path
        row["validation"] = "PASS"
    except Exception as error:
        row["validation"] = "FAILED_PRESERVED"
        row["error"] = repr(error)
        if isinstance(error, subprocess.CalledProcessError):
            row["git_output"] = error.output
        raise
    finally:
        write_json(destination, row)
    return row


def validate_xml(raw, scope):
    suite = ET.fromstring(raw)
    assert suite.tag == "testsuite" and suite.attrib["name"] == scope["class"]
    cases = suite.findall("testcase")
    assert int(suite.attrib["tests"]) == len(cases)
    assert all(c.attrib.get("classname") == scope["class"] for c in cases)
    names = [c.attrib["name"] for c in cases]
    assert len(set(names)) == len(names) and set(names).issubset(scope["original_case_names"])
    executed = [c for c in cases if c.find("skipped") is None]
    assert [c.attrib["name"] for c in executed] == [scope["selected_case"]], "Wrong executed identity"
    assert all(c.find("failure") is None and c.find("error") is None
               for c in cases if c.find("skipped") is not None), "Conflicting skipped/failure record"
    target = executed[0]
    assert target.find("error") is None, "Unexpected test error; preserve without interpretation"
    for key in ("failures", "errors", "skipped"):
        child = {"failures": "failure", "errors": "error", "skipped": "skipped"}[key]
        assert int(suite.attrib.get(key, "0")) == sum(c.find(child) is not None for c in cases)
    texts = [node.text or "" for node in suite.findall(".//system-out")]
    marker = scope["instrumentation"]["marker"]
    records = [line[len(marker):] for text in texts for line in text.splitlines() if line.startswith(marker)]
    assert len(records) == 1, "Exactly one passive observation is required"
    assert len(records[0]) <= ((scope["resource_limits"]["decoded_state_bytes"] + 2) // 3) * 4
    decoded = base64.b64decode(records[0], validate=True)
    assert len(decoded) <= scope["resource_limits"]["decoded_state_bytes"]
    json.loads(decoded)
    return {"xml_records": len(cases), "executed_identities": [scope["selected_case"]],
            "selection_skipped_identities": [c.attrib["name"] for c in cases if c.find("skipped") is not None],
            "target_assertion_failed": target.find("failure") is not None,
            "marker_count": len(records), "decoded_state_sha256": sha_bytes(decoded)}, decoded


def main():
    OUT.mkdir(exist_ok=False)
    audit = {"schema": "manual-purphoros-one-case-diagnostic-audit-v1", "status": "INCOMPLETE",
             "source_head": HEAD, "source_tree": TREE, "official_games": 0, "official_allocations": 0,
             "gameplay_authorized": False, "runtime_accepted": False, "commands": [],
             "control_sha256": {}, "errors": [], "case_attempted": False,
             "unattempted": ["two simultaneous creature tokens generate two independent damage triggers"]}
    write_json(OUT / "audit.json", audit)
    original = None
    scope = None
    patched = False
    result = 2
    try:
        for path in CONTROLS:
            target = OUT / "control" / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(CONTROL / path, target)
            audit["control_sha256"][path] = sha(target)
            write_json(OUT / "audit.json", audit)
        scope = json.loads((CONTROL / "scope.json").read_text())
        assert os.environ["GITHUB_REPOSITORY"] == "GodaPupa/argentum-batshit-test"
        assert os.environ["GITHUB_EVENT_NAME"] == "push" and os.environ["GITHUB_RUN_ATTEMPT"] == "1"
        assert os.environ["GITHUB_REF"] == BRANCH
        event = json.loads(Path(os.environ["GITHUB_EVENT_PATH"]).read_text())
        assert event["before"] == "0" * 40, "Only the one branch-creation event is allowed"
        audit["control_head"] = git("rev-parse", "HEAD", root=CONTROL)
        audit["control_tree"] = git("rev-parse", "HEAD^{tree}", root=CONTROL)
        audit["event"] = {"run": os.environ["GITHUB_RUN_ID"], "attempt": os.environ["GITHUB_RUN_ATTEMPT"],
                          "sha": os.environ["GITHUB_SHA"], "before": event["before"]}
        assert audit["control_head"] == os.environ["GITHUB_SHA"]
        assert not git("status", "--porcelain", root=CONTROL)
        assert sorted(git("ls-files", root=CONTROL).splitlines()) == sorted(CONTROLS)
        assert scope["ready_for_execution"] is True and scope["source_review"]
        limits = scope["resource_limits"]
        assert shutil.disk_usage(ROOT).free >= limits["minimum_free_bytes"]
        source_observation(scope, "initial")
        report_dir = SOURCE / scope["module"] / "build/test-results/test"
        assert not list(report_dir.glob("TEST-*.xml")), "Fresh checkout must not contain old test XML"
        env = {k: os.environ[k] for k in ["PATH", "HOME", "JAVA_HOME", "JAVA_TOOL_OPTIONS", "LANG",
                                        "LC_ALL", "TMPDIR", "GRADLE_USER_HOME"] if k in os.environ}
        env.update({"CI": "true", "GRADLE_LOCK_SLOTS": "1", "GRADLE_LOCK_TIMEOUT": "300",
                    **scope["selector_environment"]})
        TOOLS.mkdir(exist_ok=False)
        setup = OUT / "setup"
        setup.mkdir()

        def command(name, args, cwd=ROOT, timeout=300):
            row = {"name": name, "command": args, "started_ns": time.time_ns()}
            audit["commands"].append(row); write_json(OUT / "audit.json", audit)
            row.update(run_capped(args, cwd, setup / (name + ".log"), report_dir, limits, env, timeout))
            row["finished_ns"] = time.time_ns(); write_json(OUT / "audit.json", audit)
            assert row["output_complete"] and row["exit_status"] == 0, "Setup command failed: " + name

        command("java-version", ["java", "-version"])
        assert re.search(r'version "21(?:\.|\")', (setup / "java-version.log").read_text())
        # Extract the distribution's existing shlock; install no packages or services.
        command("apt-index", ["sudo", "apt-get", "update"], timeout=limits["setup_command_timeout_seconds"])
        command("apt-download-inn2", ["apt-get", "download", "inn2"], cwd=TOOLS,
                timeout=limits["setup_command_timeout_seconds"])
        packages = list(TOOLS.glob("inn2_*.deb"))
        assert len(packages) == 1
        package = packages[0]
        command("package-metadata", ["dpkg-deb", "--info", str(package)])
        command("package-extract", ["dpkg-deb", "--extract", str(package), str(TOOLS / "extracted")])
        binaries = [p for p in (TOOLS / "extracted").rglob("shlock") if p.is_file() and os.access(p, os.X_OK)]
        assert len(binaries) == 1, "One executable shlock binary required"
        shlock = binaries[0]
        audit["semaphore"] = {"package": retain(package, setup / package.name, limits, 16 * 1024 * 1024),
                              "binary": retain(shlock, setup / "shlock", limits, 4 * 1024 * 1024)}
        assert all(x["complete"] for x in audit["semaphore"].values())
        env["PATH"] = str(shlock.parent) + os.pathsep + env["PATH"]
        command("shlock-linkage", ["ldd", str(shlock)])
        assert "not found" not in (setup / "shlock-linkage.log").read_text()
        probe = TOOLS / "owned-semaphore-probe.lock"
        probe_args = [str(shlock), "-f", str(probe), "-p", str(os.getpid())]
        first = subprocess.run(probe_args, capture_output=True, timeout=10, env=env)
        second = subprocess.run(probe_args, capture_output=True, timeout=10, env=env)
        proof = {"command": probe_args, "first_exit": first.returncode, "second_exit": second.returncode,
                 "first_stdout": first.stdout.decode(errors="replace"), "first_stderr": first.stderr.decode(errors="replace"),
                 "second_stdout": second.stdout.decode(errors="replace"), "second_stderr": second.stderr.decode(errors="replace"),
                 "observed_lock": probe.read_text() if probe.exists() else None}
        write_json(setup / "semaphore-probe.json", proof)
        assert first.returncode == 0 and second.returncode != 0
        assert proof["observed_lock"].strip() == str(os.getpid())
        probe.unlink()  # This unique probe belongs to this process; real Gradle locks are never removed here.
        assert shutil.which("shlock", path=env["PATH"]) == str(shlock)
        source_observation(scope, "before-instrumentation")
        test = SOURCE / scope["test_source"]
        original = test.read_bytes()
        (OUT / "original-test.kt").write_bytes(original)
        old, new = scope["instrumentation"]["old"], scope["instrumentation"]["new"]
        text = original.decode()
        assert text.count(old) == 1
        instrumented = text.replace(old, new).encode()
        assert sha_bytes(instrumented) == scope["instrumentation"]["instrumented_sha256"]
        test.write_bytes(instrumented); patched = True
        (OUT / "instrumented-test.kt").write_bytes(instrumented)
        source_observation(scope, "instrumented", True)
        args = ["just", "test-class", scope["class"].rsplit(".", 1)[1], "--rerun", "--no-build-cache",
                "--no-daemon", "-DupdateSnapshots=false", "-Dbenchmark=false", "--info", "--stacktrace",
                "--max-workers=1", "-PkotlinCompileParallelism=1",
                "-Pkotlin.compiler.execution.strategy=in-process", "-Dorg.gradle.jvmargs=-Xmx4g"]
        row = {"name": "one-existing-case", "command": args, "selector_environment": scope["selector_environment"],
               "started_ns": time.time_ns()}
        audit["commands"].append(row); audit["case_attempted"] = True; audit["unattempted"] = []
        write_json(OUT / "audit.json", audit)
        row.update(run_capped(args, SOURCE, OUT / "diagnostic-command.log", report_dir, limits, env,
                              limits["command_timeout_seconds"]))
        row["finished_ns"] = time.time_ns()
        audit["xml_retention"] = [retain(p, OUT / "xml" / p.name, limits, limits["test_result_bytes"])
                                  for p in sorted(report_dir.glob("TEST-*.xml"))]
        write_json(OUT / "audit.json", audit)  # Failure/exit/raw XML precede all interpretation.
        assert row["output_complete"] and all(x["complete"] for x in audit["xml_retention"])
        xml_paths = sorted((OUT / "xml").glob("TEST-*.xml"))
        assert len(xml_paths) == 1 and xml_paths[0].name == "TEST-" + scope["class"] + ".xml"
        observation, decoded = validate_xml(xml_paths[0].read_bytes(), scope)
        original_xml = report_dir / xml_paths[0].name
        assert row["started_ns"] - 2_000_000_000 <= original_xml.stat().st_mtime_ns <= row["finished_ns"] + 2_000_000_000
        assert len(decoded) <= limits["artifact_bytes"] - size(OUT) - RESERVE
        (OUT / "observed-state.json").write_bytes(decoded)
        audit["observed_case"] = observation
        lines = (OUT / "diagnostic-command.log").read_text(errors="replace").splitlines()
        task = ":" + scope["module"].replace("/", ":") + ":test"
        assert any(l.strip() in ["> Task " + task, "> Task " + task + " FAILED"] for l in lines)
        assert not any(l.strip() == "> Task " + task + " " + s for l in lines
                       for s in ["FROM-CACHE", "UP-TO-DATE", "NO-SOURCE", "SKIPPED"])
        assert any("Gradle Test Executor" in l and "started executing tests" in l for l in lines)
        assert any("Gradle Test Executor" in l and "finished executing tests" in l for l in lines)
        assert not any("running ./gradlew unlocked" in l for l in lines)
        source_observation(scope, "after-diagnostic", True)
        audit["status"] = "OBSERVED_ORIGINAL_ASSERTION_FAILURE" if observation["target_assertion_failed"] else "OBSERVED_EXISTING_ASSERTION_PASS"
        # An original test failure always remains a failing workflow, even with complete observation.
        result = 1 if observation["target_assertion_failed"] or row["exit_status"] != 0 else 0
    except Exception as error:
        audit["status"] = "INCOMPLETE_OR_REJECTED_PRESERVED"
        audit["errors"].append(repr(error))
    finally:
        if patched and scope is not None and original is not None:
            test = SOURCE / scope["test_source"]
            try:
                assert sha(test) == scope["instrumentation"]["instrumented_sha256"], "Observed test source drift; do not overwrite"
                test.write_bytes(original)
                source_observation(scope, "restored")
                audit["source_restored"] = True
            except Exception as error:
                audit["source_restored"] = False
                audit["errors"].append("RESTORE: " + repr(error)); result = 2
        write_json(OUT / "audit.json", audit)
    return result


if __name__ == "__main__":
    raise SystemExit(main())
