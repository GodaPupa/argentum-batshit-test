"""Read-only source/artifact audit. Does not compile, initialize, or execute the engine."""
from pathlib import Path
from collections import Counter
import hashlib, json, gzip, re, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / 'manual-shared-composition'
OUT = Path(__file__).resolve().parent
def digest(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def read(p): return json.loads(p.read_text())
def pin(p):
    b=p.read_bytes()
    return {'path':str(p.relative_to(ROOT)), 'bytes':len(b), 'sha256':digest(b), 'git_blob':blob(b)}

manifest=read(SRC/'draft-seventy-one-file-pins.json')
assert len(manifest)==71 and len({x['path'] for x in manifest})==71
assert digest((SRC/'draft-seventy-one-file-pins.json').read_bytes())=='47648f305ea2444585964cfe07b9796ed2ac3ff574b8128eea737e6c71e802bc'
assert sorted(x['path'] for x in manifest)==sorted(str(p.relative_to(SRC/'candidate')) for p in (SRC/'candidate').rglob('*') if p.is_file())
candidate=[]
for x in manifest:
    p=SRC/'candidate'/x['path']; b=p.read_bytes()
    assert (len(b),digest(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob']),x['path']
    candidate.append(pin(p))
rows=read(SRC/'common-ancestor-code-delta.json')['rows']
live=read(OUT/'independent-live-tree-scope.json')
assert live['complete_differing_blob_rows_under_roots']==rows
live_maps={s:{x['path']:x for x in v['selected']} for s,v in live['trees'].items()}
for s,tree in live['trees'].items():
    assert tree['truncated'] is False
by_path={x['path']:x for x in rows}
source_pins=[]
for side in ['manual','shared','base']:
    for p in (SRC/'source-inputs'/side).rglob('*'):
        if not p.is_file(): continue
        path=str(p.relative_to(SRC/'source-inputs'/side)); b=p.read_bytes()
        expected=by_path.get(path,{}).get(side)
        if expected is not None:
            assert blob(b)==expected,(side,path)
            source_pins.append({'side':side,**pin(p)})
shared_only=read(SRC/'runtime-shared-only-scope.json')
assert len(shared_only)==54
shared_exact=[];shared_carrier=[]
for x in shared_only:
    assert x['manual']==x['base'] and x['shared']!=x['base']
    b=(SRC/'candidate'/x['path']).read_bytes()
    (shared_exact if blob(b)==x['shared'] else shared_carrier).append(x['path'])
assert len(shared_exact)==51 and len(shared_carrier)==3
merges=[]
for x in [r for r in rows if r['relation']=='both-diverged']+[{'path':'docs/card-sdk-language-reference.md'}]:
    p=x['path']
    proc=subprocess.run(['git','merge-file','-p',str(SRC/'source-inputs/manual'/p),str(SRC/'source-inputs/base'/p),str(SRC/'source-inputs/shared'/p)],capture_output=True)
    assert proc.returncode in [0,1],(p,proc.returncode)
    same=proc.stdout==(SRC/'candidate'/p).read_bytes()
    if proc.returncode==0: assert same,p
    merges.append({'path':p,'automatic_merge_exit':proc.returncode,'candidate_equals_automatic_output':same,'automatic_output_sha256':digest(proc.stdout)})
assert Counter(x['automatic_merge_exit'] for x in merges)=={0:10,1:4}

scope=read(SRC/'entry-batch-regression-scope.json')
test=(SRC/'candidate'/scope['source']['path']).read_text()
names=re.findall(r'test\("([^"\n]+)"\)',test)
assert names==[x['identity'] for x in scope['cases']] and len(names)==4

archive=SRC/'replay-compatibility/accepted-journal-targeted-original.zip'
receipt=read(SRC/'replay-compatibility/source-inputs/experiments/manual-transmission-phase2/evidence/attempt-journal-36254534014/receipt.json')
oldreview=read(SRC/'replay-compatibility/source-inputs/experiments/manual-transmission-phase2/evidence/attempt-journal-36254534014/independent-artifact-review.json')
assert len(archive.read_bytes())==receipt['targeted_qualification']['artifact_bytes']==17710
assert digest(archive.read_bytes())==receipt['targeted_qualification']['artifact_sha256']=='c265a58f804d2f552f991839b86da6214e092a8077289d9c84a39af34bd3bd54'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==10
    members=[]
    for name in z.namelist():
        b=z.read(name); assert digest(b)==oldreview['files'][name]
        members.append({'path':name,'bytes':len(b),'sha256':digest(b)})
    trace_b=z.read('build/reports/manual-transmission-phase2/engine-telemetry/excluded-fixture-engine-trace.json')
    trace=json.loads(trace_b)
    assert digest(trace_b)=='012059d9400763f8aaa1909cfb08a2fbfbeef33b0e72e3f30170edea3a048984'
    assert trace['initialState']['continuationStack']==[]
    assert [x['action']['type'] for x in trace['steps']]==['Concede']*3
    assert trace['engineSourceSha']=='8'*40 and trace['executionAuthorizedByThisComponent'] is False
    assert not any(t.encode() in trace_b for t in ['CreateTokenCopyRemainingContinuation','CreateTokenCopyAuraHostContinuation'])

dep=read(SRC/'bank-dependencies/dependency-proposal.json')
closure=read(SRC/'exact52-shared-bank-test-closure.json')
assert len(closure)==len({x['class'] for x in closure})==52
assert sum(x['cases'] for x in closure)==407
assert Counter(x['relation'] for x in closure)=={'same':29,'shared-only':23}
assert sum(x['manual'] is None for x in closure)==13
proposed=[]
for x in dep['proposed_files']:
    p=SRC/'bank-dependencies/shared'/x['path'];b=p.read_bytes()
    assert (len(b),digest(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
    row=next((y for y in closure if y['path']==x['path']),None)
    if row: assert x['git_blob']==row['shared']
    assert x['git_blob']==live_maps['shared'][x['path']]['sha']
    proposed.append(pin(p))
assert len(proposed)==25
assert {x['path'] for x in dep['proposed_files']}=={x['path'] for x in closure if x['relation']=='shared-only'}|{x['path'] for x in dep['required_test_helpers']}
assert all(x['path'] not in {y['path'] for y in manifest} for x in dep['proposed_files'])
for x in closure:
    for side in ['manual','shared','base']:
        assert live_maps[side][x['path']].get('sha')==x[side]
for path in ['rules-engine/src/test/resources/legacy-suspensions','rules-engine/src/test/resources/suspension-traces']:
    assert live_maps['manual'][path]['sha']==live_maps['shared'][path]['sha']
policy=read(SRC/'policy-boundary/finding.json')
for x in policy['files']:
    p=SRC/'policy-boundary/manual'/x['path'];b=p.read_bytes()
    assert (len(b),digest(b),blob(b))==(x['bytes'],x['sha256'],x['git_blob'])
    assert live_maps['manual'][x['path']]['sha']==x['git_blob']
    assert x['path'] not in {y['path'] for y in manifest}
report={
 'schema':'sphinx-independent-manual71-static-byte-audit-v1',
 'engine_execution':False,'fixture_execution':False,'candidate_modified':False,
 'input_inventory':pin(SRC/'draft-seventy-one-file-pins.json'),
 'independent_fresh_live_tree_scope':pin(OUT/'independent-live-tree-scope.json'),
 'candidate_files':candidate,'retained_source_pins_against_owner_complete_delta_map':source_pins,
 'shared_only_scope':{'total':54,'exact_donor':shared_exact,'explicit_carrier_deviations':shared_carrier},
 'automatic_three_way_proofs':merges,'prospective_fixture_names':names,
 'historical_archive':{**pin(archive),'crc':'PASS','members':members,'trace_steps':3,'initial_frames':0,'changed_frame_occurrences':0,'candidate_deserialization_or_replay_executed':False},
 'dependency_proposal':{**pin(SRC/'bank-dependencies/dependency-proposal.json'),'files':proposed,'classes':52,'cases':407,'unchanged':29,'changed':23,'absent_in_receiver':13,'applied':False},
 'policy_finding':pin(SRC/'policy-boundary/finding.json'),
 'limits':['Live commit/merge-base provenance and all three full untruncated Git trees were independently fetched. Complete differing rows and relevant scoped entries are retained; the full original recursive tree HTTP responses are not included.', 'This script verifies source and original bytes only, not compiler success, new replay behavior, full receiver coverage, pilots or gameplay.']}
(OUT/'independent-byte-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','candidate_files':71,'retained_source_pins':len(source_pins),'automatic_merges':10,'explicit_conflicts':4,'prospective_cases':4,'original_members':10,'proposed_dependency_files':25,'report_sha256':digest((OUT/'independent-byte-checks.json').read_bytes())}))
