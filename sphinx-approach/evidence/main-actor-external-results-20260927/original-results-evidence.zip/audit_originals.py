#!/usr/bin/env python3
"""Read original actor ZIPs only. Never import/run experiment or gate code."""
from pathlib import Path
import datetime as dt
import gzip, hashlib, json, re, zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
PREP = ROOT.parent
def digest(b): return hashlib.sha256(b).hexdigest()
def identity(b): return {'bytes':len(b),'sha256':digest(b),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def readj(z,n): return json.loads(z.read(n))
def require(x,msg):
    if not x: raise AssertionError(msg)

CONTROL='0377a9639061b75bf04f01e466dee247963066b8'
CTREE='062e5624c74795d38bd937c299d3750b764a729f'
RUNTIME='22cf67791fda69a65d7e1eeb76c2ae369407cb01'
RTREE='3b4e50dd7a0fe484b796bb191bd848b048bea12b'
PARENTS='ff34ac8fa2efbd41f233e877cb2908c2cab5929a 8ed9787ad75b8bc6c2438a8c0b526ff822aa776e'
CANONICAL='8ed9787ad75b8bc6c2438a8c0b526ff822aa776e'
proof=json.loads((ROOT/'root-source-byte-proof.json').read_text())
controls={x['path']:{k:v for k,v in x.items() if k!='path'} for x in proof['five_control_files']}
sources={x['path']:{k:v for k,v in x.items() if k!='path'} for x in proof['source_bodies_rehashed']}
fulltree=json.loads(gzip.decompress((ROOT/'immutable-runtime-full-tree.json.gz').read_bytes()))
require(fulltree['sha']==RTREE and fulltree['truncated'] is False,'complete runtime tree')
tree={x['path']:x for x in fulltree['tree']}
specs=[('shared-50',10922142148,419121,'11617efc668f25b4d443110d1679f2f9ad4c12e4c058ea19d40c89ebc8fd4d28','shared_actor_50',50,58),('sphinx-136',10922675113,430441,'759fbcb77ef8dccc0d78cc954f28931e4138636cbd8e6024945ed6d1becb96c5','sphinx_actor_136',136,61)]
shared_counts={'ActorObservationBoundaryTest':28,'ActorStackSourceObservationTest':12,'ActorTriggerOrderObservationTest':6,'ActorPriorityObservationTest':4}
reports=[];case_sets=[]
for label,aid,size,sha,group,count,members in specs:
    p=ROOT/(label+'-original.zip');b=p.read_bytes();require(len(b)==size and digest(b)==sha,'original identity')
    z=zipfile.ZipFile(p);require(z.testzip() is None,'CRC');require(len(z.infolist())==members and len(set(z.namelist()))==members,'members')
    inventories=[dict(path=i.filename,crc32=f'{i.CRC:08x}',**identity(z.read(i))) for i in z.infolist()]
    for path,v in controls.items(): require(identity(z.read('control/'+path))==v,'control bytes '+path)
    pre=readj(z,'pre-bind-attempt.json')
    require(pre['run_id']=='36290490623' and pre['run_attempt']=='1' and pre['github_sha']==CONTROL and pre['event_name']=='push','activation')
    require(pre['errors']==[] and pre['official_games']==0 and pre['gameplay_authorized'] is False,'preflight')
    expected_ids={'runtime':{'head':RUNTIME,'tree':RTREE,'parents':PARENTS,'status':''},'control':{'head':CONTROL,'tree':CTREE,'parents':CANONICAL,'status':''}}
    require({k:pre[k] for k in expected_ids}==expected_ids,'identities')
    outcomes=readj(z,'step-outcomes.json');require(all(outcomes[k]=='success' for k in ['preserve','bind','tests','collect']),'outcomes')
    cmd=readj(z,'test-command.json');require(cmd['exit_status']==0 and cmd['cwd']=='runtime' and cmd['started_ns']<cmd['finished_ns'],'command receipt')
    require(z.read('test-exit-code.txt').strip()==b'0' and z.read('receiving-reports/test-exit-code.txt').strip()==b'0','exits')
    require(cmd['command'][:2]==['just','test-class'] and all(x in cmd['command'] for x in ['--rerun','--max-workers=1','-PkotlinCompileParallelism=1','-Pkotlin.compiler.execution.strategy=in-process','--info','--stacktrace']),'command routing')
    log=z.read('test-command.log').decode();require("Task ':gym:test' is not up-to-date because:" in log and 'BUILD SUCCESSFUL' in log,'fresh task')
    require(not re.search(r'^> Task :gym:test (?:UP-TO-DATE|FROM-CACHE|NO-SOURCE|SKIPPED)',log,re.M),'no cached task')
    starts=re.findall(r"^Starting process 'Gradle Test Executor [0-9]+'.+",log,re.M)
    finishes=re.findall(r'^Gradle Test Executor [0-9]+ finished executing tests\.',log,re.M)
    require(len(starts)==len(finishes)==1 and '/temurin-21-' in starts[0],'one fresh Java21 worker')
    attempts=[]
    for i in range(1,4):
        prefix=f'receiving-reports/external-main-binding-attempts/attempt-{i:03d}/';a=readj(z,prefix+'attempt.json')
        require(a['status']=='BOUND_FOR_ORIGINAL_SOFTWARE_BANK_ONLY' and a['run_id']=='36290490623' and a['run_attempt']=='1','attempt')
        ob=a['observed_source'];require(ob['identities']==expected_ids and not ob['scope_read_errors'],'observed identities')
        require(ob['control_files']==controls,'observed control bytes')
        require(len(ob['runtime_files'])==75,'complete observed source union')
        for path,v in sources.items(): require(ob['runtime_files'][path]==v,'reviewed source body '+path)
        for path,v in ob['runtime_files'].items():
            require(path in tree and tree[path]['sha']==v['git_blob_sha1'],'immutable runtime tree '+path)
        for path,sha2 in a['preserved_files'].items(): require(digest(z.read(prefix+path))==sha2,'preserved '+path)
        binding=a['binding'];require(binding['runtime']['complete_main_only_files']==proof['exact_actual_main_delta'],'14 runtime delta')
        require(binding['external_controls']['head']==CONTROL and binding['external_controls']['tree']==CTREE,'bound control')
        event=binding['activation_event'];require(event=={'event_name':'push','ref':'refs/heads/lab/sphinx-main-actor-external-20260927','before':'0'*40,'after':CONTROL,'created':True,'run_id':'36290490623','run_attempt':1},'one creation')
        require(binding['group']==group and binding['official_games']==0 and binding['gameplay_authorized'] is False and binding['independent_receiving_acceptance'] is False,'scope')
        attempts.append(a)
    require(all(a['binding']==attempts[0]['binding'] and a['observed_source']==attempts[0]['observed_source'] for a in attempts),'before/after identical')
    xmls=[];cases=[];counts={}
    for n in sorted(z.namelist()):
        if not (n.startswith('original-test-xml/') and n.endswith('.xml')):continue
        xb=z.read(n);x=ET.fromstring(xb);cs=x.findall('.//testcase');name=x.attrib['name'].split('.')[-1]
        require(int(x.attrib['tests'])==len(cs),'XML cases')
        require(all(int(x.attrib.get(k,0))==0 for k in ['failures','errors','skipped']),'XML outcomes')
        t=dt.datetime.fromisoformat(x.attrib['timestamp']).replace(tzinfo=dt.timezone.utc).timestamp()
        require(cmd['started_ns']/1e9-1<=t<=cmd['finished_ns']/1e9+1,'fresh XML timestamp')
        for c in cs:
            require(not list(c.findall('failure')+c.findall('error')+c.findall('skipped')),'case status')
            cases.append((c.attrib['classname'],c.attrib['name']))
        counts[name]=len(cs);xmls.append({'path':n,'sha256':digest(xb),'timestamp':x.attrib['timestamp'],'cases':len(cs)})
    expected=dict(shared_counts)
    if count==136:expected.update({'SphinxStageEPilotComponentTest':56,'ActorSpellPaymentProjectionTest':10,'SphinxStageEActorAdapterTest':20})
    require(counts==expected and len(cases)==len(set(cases))==count,'bank geometry')
    if count==136:
        require(readj(z,'receiving-reports/source-before.json')==readj(z,'receiving-reports/source-after.json'),'Sphinx source before/after')
        collector=readj(z,'receiving-reports/audit.json');require(collector['actual_distinct_cases']==136 and collector['errors']==[],'Sphinx collector')
        require(not any(collector[k] for k in ['component_accepted','full_receiving_accepted','whole_pilot_accepted','gameplay_authorized']),'no self admission')
    else:
        collector=readj(z,'receiving-reports/manifest.json');require(collector['actual_cases']==50 and all(collector[k]==0 for k in ['failures','errors','skipped']),'shared collector')
    decoded=gzip.decompress((ROOT/(label+'-decoded-job.log.gz')).read_bytes())
    require(b'0377a9639061b75bf04f01e466dee247963066b8' in decoded and RUNTIME.encode() in decoded,'decoded log identities')
    reports.append({'group':group,'artifact_id':aid,'original':dict(path=p.name,**identity(b)),'members':inventories,'test_command':cmd,'fresh_worker_start':starts[0],'fresh_worker_finish':finishes[0],'xml':xmls,'class_counts':counts,'exact_cases':sorted(cases),'cases':count,'failures':0,'errors':0,'skipped':0,'binding_attempts':3,'identical_observed_source_maps':True,'runtime_paths_observed_each_time':75,'runtime_paths_compared_to_root_reviewed_body_proof':60,'all75_git_blobs_match_immutable_runtime_tree':True,'decoded_job_log':{'gzip':identity((ROOT/(label+'-decoded-job.log.gz')).read_bytes()),'decoded':identity(decoded)}})
    case_sets.append(set(cases))
require(case_sets[0]<=case_sets[1],'shared 50 exact subset')
out={'schema':'sphinx-external-main-actor-author-raw-audit/v1','scope':'Original bounded software actor banks; not independent receiving admission, full pilot/runtime admission, PR check repair, merge authority or gameplay.','run_id':36290490623,'attempt':1,'control':CONTROL,'control_tree':CTREE,'runtime':RUNTIME,'runtime_tree':RTREE,'root_source_review_sha256':'c064c8d797dcfbfbb59c00119a97913f738a0e8af8794e450bda7d5488930dcf','groups':reports,'distinct_cases_union':136,'case_executions':186,'overlap_cases':50,'official_games':0,'gameplay_authorized':False,'independent_review_pending':True,'commands_run_by_this_audit':'Python archive/XML/hash parsing only; no JVM or experiment code execution'}
(ROOT/'author-raw-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS_BOUNDED_AUTHOR_RAW_AUDIT','groups':[{'group':r['group'],'cases':r['cases'],'members':len(r['members'])}for r in reports],'distinct_cases':136,'sha256':digest((ROOT/'author-raw-audit.json').read_bytes())}))
