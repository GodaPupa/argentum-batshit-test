"""Read-only prospective creation-event audit; does not activate the branch."""
from pathlib import Path
import ast,hashlib,json,re,yaml
from datetime import datetime,timezone
B=Path(__file__).resolve().parent
live=json.loads((B/'preparation-live-inputs.json').read_text());prepared=json.loads((B/'prepared-control-checkpoint.json').read_text())
assert live['main']['object']['sha']=='ff34ac8fa2efbd41f233e877cb2908c2cab5929a'
assert live['canonical']['object']['sha']==prepared['parent']=='8ed9787ad75b8bc6c2438a8c0b526ff822aa776e'
assert live['new_branch']['structuredContent']['error_code']=='NOT_FOUND' and live['runs']['total_count']==0
assert len(live['prs'])<100
branch='lab/sphinx-main-actor-external-20260927'
assert not any(p['head']['ref']==branch or p['base']['ref']==branch for p in live['prs'])
old=ast.parse(Path('ferocity-takeover/sphinx-pr205-merge-review/check_triggers.py').read_text());ns={'re':re}
exec(compile(ast.Module(body=[n for n in old.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'retained-push-filter-functions','exec'),ns)
source=json.loads((B/'inherited-workflow-source-bodies.json').read_text());assert len(source['files'])==85
rows=[];eligible=[]
for r in source['files']:
 raw=r['result']['content'].encode();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==r['result']['sha']
 doc=yaml.load(raw,Loader=yaml.BaseLoader);on=doc['on'];push=on.get('push');select=False
 if 'push' in on:
  push=push or {};select=not ('tags' in push and 'branches' not in push) and not ('tags-ignore' in push and 'branches' not in push)
  if 'branches' in push:select=select and ns['selected'](branch,push['branches'])
  if 'branches-ignore' in push:select=select and not any(ns['match'](branch,p) for p in push['branches-ignore'])
 if select:eligible.append(r['path'])
 rows.append({'path':r['path'],'git_blob_sha1':blob,'sha256':hashlib.sha256(raw).hexdigest(),'events':list(on),'push_branch_selected_before_any_path_filter':select,'push_filters':push,'concurrency':doc.get('concurrency')})
assert not eligible,eligible
path='.github/workflows/sphinx-main-actor-receiving-qualification.yml';raw=(B/'candidate'/path).read_bytes();doc=yaml.load(raw,Loader=yaml.BaseLoader)
assert list(doc['on'])==['push'] and doc['on']['push']=={'branches':[branch]}
assert doc['permissions']=={'contents':'read'} and 'concurrency' not in doc
job=doc['jobs']['qualify'];assert job['if']=="${{ github.event.before == '0000000000000000000000000000000000000000' && github.run_attempt == 1 }}"
assert job['timeout-minutes']=='40' and job['strategy']['fail-fast']=='false'
assert {r['group'] for r in job['strategy']['matrix']['include']}=={'shared_actor_50','sphinx_actor_136'}
assert job['env']['SPHINX_MAIN_RUNTIME_SHA']=='22cf67791fda69a65d7e1eeb76c2ae369407cb01'
checkouts=[s['with'] for s in job['steps'] if s.get('uses','').startswith('actions/checkout@')]
assert checkouts==[{'ref':'${{ github.sha }}','path':'control','fetch-depth':'0','persist-credentials':'false'},{'ref':'22cf67791fda69a65d7e1eeb76c2ae369407cb01','path':'runtime','fetch-depth':'0','persist-credentials':'false'}]
report={'schema':'sphinx-external-actor-prospective-activation-preflight/v1','at_utc':datetime.now(timezone.utc).isoformat(),'status':'PREPARED_COMMIT_NO_REF_EVENT_REQUIRES_ROOT_FINAL_DISPOSITION','control_commit':prepared['commit'],'control_tree':prepared['tree'],'control_parent':prepared['parent'],'changed_paths':[f['path'] for f in prepared['files']],'proposed_branch':branch,'branch_absent_observed':True,'prior_branch_runs':0,'open_prs_inspected':len(live['prs']),'new_branch_head_or_base_prs':0,'all_inherited_workflow_bodies':rows,'inherited_push_branch_matches':[],'new_workflow':{'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'jobs':{'matrix':['shared_actor_50','sphinx_actor_136'],'cases':[50,136],'overlap':'50 included in136; not186distinct','same_original_bank_commands':True,'job_if':job['if'],'job_timeout_minutes':40,'owned_test_timeout_seconds':1200},'permissions':doc['permissions'],'concurrency':None,'checkout':checkouts},'event_effects':['Only the new exact-branch push workflow matches; every inherited workflow is excluded by branch filtering before path filtering. New-branch path-diff ambiguity therefore cannot trigger an inherited workflow.','No PR has this proposed branch as head or base, so creating it has no PR synchronization, ready or closed event.','No workflow_run trigger is present among inherited bodies; schedules apply to unchanged default branch, and no dispatch or repository edit is requested.','No concurrency group is defined by the new workflow; it cannot cancel PR207, Industrial, Pest or another external run.','Only original actor software banks are callable by reviewed controls; no entropy/game runner/resource/browser/claim command is present.'],'outside_ownership_PR207':{'head':live['pr207']['head']['sha'],'base':live['pr207']['base']['ref'],'ownership':'external; no cancellation, retarget, rerun or source interpretation supplied'},'remaining':['Root must inspect this actual commit/tree and preflight before any branch creation.','Immediately before an authorized activation, recheck source anchors/branch absence/ownership and record exact created ref/event.','Passing external bank results still require raw review and do not themselves repair protected PR175 contexts or authorize merge/gameplay.'],'actual_actor_cases':0,'official_games':0}
assert not any('workflow_run' in r['events'] for r in rows)
(B/'prospective-activation-preflight.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'commit':prepared['commit'],'tree':prepared['tree'],'inherited_bodies':len(rows),'inherited_matching_push':0,'new_matching_workflows':1,'new_matrix_banks':2,'branch_absent':True,'open_prs_checked':len(live['prs'])},indent=2))
