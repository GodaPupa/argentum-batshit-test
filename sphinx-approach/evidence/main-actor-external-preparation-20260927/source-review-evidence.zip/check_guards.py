#!/usr/bin/env python3
"""Synthetic Python control checks only; no GitHub event, JVM or gameplay execution."""
import ast, base64, copy, hashlib, importlib.util, json, os, shutil, tempfile, traceback
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parent
CANDIDATE=BASE/'candidate'
spec=importlib.util.spec_from_file_location('binding_under_test',CANDIDATE/'sphinx-approach/main_receiving_binding.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
results=[]

def check(name,operation,error=None):
    row={'name':name,'expected':'reject' if error else 'pass'}
    try:
        operation()
        assert error is None, 'Guard unexpectedly accepted'
        row['result']='PASS'
    except Exception as exc:
        if error is not None and error in str(exc):
            row.update(result='PASS',observed_rejection={'type':type(exc).__name__,'message':str(exc)})
        else:
            row.update(result='FAIL',exception={'type':type(exc).__name__,'message':str(exc)},traceback=traceback.format_exc())
    results.append(row)

def eq(a,b): assert a==b,(a,b)
def payloads(value,out):
    if isinstance(value,dict):
        if isinstance(value.get('content'),str):
            raw=base64.b64decode(''.join(value['content'].split()),validate=True) if value.get('encoding')=='base64' else value['content'].encode();out[h.sha(raw)]=raw
            if value.get('sha'):
                eq(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),value['sha'])
        for child in value.values():payloads(child,out)
    elif isinstance(value,list):
        for child in value:payloads(child,out)

cache={}
inputs=json.loads((BASE/'cache-index.json').read_text())['inputs']+['ferocity-takeover/sphinx-main-binding/additional-exact-authorities.json','ferocity-takeover/sphinx-main-binding/additional-exact-source.json']
for path in inputs:payloads(json.loads(Path(path).read_text()),cache)
release=Path('sphinx-audit/canonical-integration/release')
for path in release.rglob('*'):
    if path.is_file():cache[h.sha(path.read_bytes())]=path.read_bytes()
descriptor=json.loads((release/h.CANONICAL_DESCRIPTOR).read_text())

with tempfile.TemporaryDirectory(prefix='synthetic-control-',dir=BASE) as temp:
    work=Path(temp);control=work/'control';runtime=work/'runtime';runtime.mkdir();shutil.copytree(CANDIDATE,control)
    manifest_raw=(control/h.MANIFEST).read_bytes();manifest=json.loads(manifest_raw)
    wanted=dict(descriptor['preserved_authority_sha256'])
    wanted[h.CANONICAL_DESCRIPTOR]=h.CANONICAL_DESCRIPTOR_SHA256
    wanted['sphinx-approach/canonical_receiving_binding.py']=h.CANONICAL_HELPER_SHA256
    wanted[descriptor['independent_source_review']['path']]=descriptor['independent_source_review']['sha256']
    for path in descriptor['qualification_control_paths']:
        wanted[path]=h.sha((release/path).read_bytes())
    def put(path,raw):
        dest=runtime/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    for path,digest in wanted.items():put(path,cache[digest])
    for group in h.REPORTS:
        pins=h.original_pins(runtime,group,descriptor)
        for row in descriptor['groups'][group]['explicit_overrides']:pins[row['path']]=row['receiving_sha256']
        for path,digest in pins.items():put(path,cache[digest])
    event={'before':'0'*40,'created':True,'after':'a'*40,'ref':'refs/heads/'+h.BRANCH,'repository':{'full_name':'GodaPupa/argentum-batshit-test'}}
    event_path=work/'event.json';event_path.write_text(json.dumps(event))
    env={'SPHINX_RECEIVING_CONTEXT':h.CONTEXT,'GITHUB_EVENT_NAME':'push','GITHUB_REF':event['ref'],'GITHUB_RUN_ATTEMPT':'1','GITHUB_EVENT_PATH':str(event_path),'GITHUB_SHA':'a'*40,'GITHUB_RUN_ID':'SYNTHETIC_NOT_A_GITHUB_RUN','SPHINX_MAIN_BINDING_SHA256':h.sha(manifest_raw),'SPHINX_MAIN_RUNTIME_SHA':h.RUNTIME}
    def fake_git(root,*args):
        if root==control:
            if args==('rev-parse','HEAD'):return 'a'*40
            if args==('rev-parse','HEAD^{tree}'):return 'b'*40
            if args==('rev-list','--parents','-n','1','a'*40):return 'a'*40+' '+h.CANONICAL
            if args==('diff','--name-only',h.CANONICAL,'a'*40):return '\n'.join(h.CONTROL_FILES)
            if args==('status','--porcelain','--untracked-files=all'):return ''
            if args==('show','-s','--format=%P','HEAD'):return h.CANONICAL
        if root==runtime:
            fixed={('rev-parse','HEAD'):h.RUNTIME,('rev-parse','HEAD^{tree}'):h.RUNTIME_TREE,('show','-s','--format=%P','HEAD'):' '.join([h.MAIN,h.CANONICAL]),('status','--porcelain','--untracked-files=all'):''}
            if args in fixed:return fixed[args]
        raise AssertionError(('Unexpected synthetic Git query',str(root),args))
    with patch.dict(os.environ,env,clear=True),patch.object(h,'git',fake_git):
        check('event-valid-synthetic-creation',h.event_identity)
        for key,value,message in [('SPHINX_RECEIVING_CONTEXT','wrong','Explicit main'),('GITHUB_EVENT_NAME','workflow_dispatch','Only the reviewed'),('GITHUB_REF','refs/heads/main','Wrong control'),('GITHUB_RUN_ATTEMPT','2','Consumed control')]:
            with patch.dict(os.environ,{key:value}):check('reject-env-'+key,h.event_identity,message)
        for key,value,message in [('before','c'*40,'branch creation'),('created',False,'branch creation'),('after','d'*40,'Push event'),('ref','refs/heads/main','payload ref'),('repository',{'full_name':'foreign/repo'},'Unexpected repository')]:
            changed=copy.deepcopy(event);changed[key]=value;event_path.write_text(json.dumps(changed));check('reject-event-'+key,h.event_identity,message)
        event_path.write_text(json.dumps(event))
        check('actual-five-controls-normalize-and-bind-under-synthetic-git',lambda:h.control_identity(control,manifest,manifest_raw))
        with patch.dict(os.environ,{'SPHINX_MAIN_BINDING_SHA256':'0'*64}):check('reject-manifest-env',lambda:h.control_identity(control,manifest,manifest_raw),'Manifest does not match')
        for path,message in [('sphinx-approach/main_receiving_binding.py','Control source changed'),(h.WORKFLOW,'Workflow control changed')]:
            original=(control/path).read_bytes();(control/path).write_bytes(original+b'\n# mutated\n');check('reject-mutated-'+Path(path).name,lambda:h.control_identity(control,manifest,manifest_raw),message);(control/path).write_bytes(original)
        for bad_args,answer,message in [(('rev-parse','HEAD'),'c'*40,'Actual control commit'),(('rev-list','--parents','-n','1','a'*40),'a'*40+' '+'b'*40,'one isolated child'),(('diff','--name-only',h.CANONICAL,'a'*40),'\n'.join(h.CONTROL_FILES+['extra.py']),'outside the exact five'),(('status','--porcelain','--untracked-files=all'),' M changed','Control checkout is dirty')]:
            def wrong_git(root,*args):return answer if args==bad_args else fake_git(root,*args)
            with patch.object(h,'git',wrong_git):check('reject-control-'+bad_args[0]+'-'+message,lambda:h.control_identity(control,manifest,manifest_raw),message)
        for group,count in [('shared_actor_50',18),('sphinx_actor_136',41)]:
            check('actual-original-pins-'+group,lambda:eq(len(h.original_pins(runtime,group,descriptor)),count))
        synthetic_source={'head':h.RUNTIME,'tree':h.RUNTIME_TREE,'parents':[h.MAIN,h.CANONICAL],'synthetic_runtime_git_stub':True}
        with patch.object(h,'runtime_identity',return_value=synthetic_source):
            for group in h.REPORTS:
                check('actual-pins-positive-bind-with-synthetic-git-'+group,lambda g=group:h._bind(g,runtime,control))
            for path,message in [(h.CANONICAL_DESCRIPTOR,'Canonical eleven-path'),('sphinx-approach/canonical_receiving_binding.py','Canonical receiving helper'),('sphinx-approach/STAGE_E_ACTOR_FIXTURE_BUDGET.json','Original authority changed')]:
                original=(runtime/path).read_bytes();(runtime/path).write_bytes(original+b'\n');check('reject-runtime-authority-'+Path(path).name,lambda:h._bind('sphinx_actor_136',runtime,control),message);(runtime/path).write_bytes(original)
            original=(runtime/'gym/src/main/kotlin/com/wingedsheep/gym/actorinput/ActorActionMenu.kt').read_bytes()
            (runtime/'gym/src/main/kotlin/com/wingedsheep/gym/actorinput/ActorActionMenu.kt').write_bytes(original+b'\n')
            check('reject-altered-qualified-source',lambda:h._bind('sphinx_actor_136',runtime,control),'Original qualified runtime source changed')
            check('reject-altered-qualified-source-with-durable-observation',lambda:h.bind('sphinx_actor_136',runtime,control),'Original qualified runtime source changed')
            rejected=json.loads((runtime/'build/reports/sphinx-stage-e-actor/external-main-binding-attempts/attempt-001/attempt.json').read_text())
            actual=rejected['observed_source']['runtime_files']['gym/src/main/kotlin/com/wingedsheep/gym/actorinput/ActorActionMenu.kt']
            check('mutated-actual-source-digest-retained',lambda:eq(actual['sha256'],h.sha(original+b'\n')))
            check('mutated-actual-source-is-different-from-expected',lambda:eq(actual['sha256']!=h.sha(original),True))
            check('rejected-observed-runtime-head-retained',lambda:eq(rejected['observed_source']['identities']['runtime']['head'],h.RUNTIME))
            missing=runtime/'gym/src/main/kotlin/com/wingedsheep/gym/actorinput/ActorActionMenu.kt';missing.unlink()
            observation=h.observe_source(runtime,control)
            check('missing-actual-source-error-retained',lambda:eq(observation['runtime_files']['gym/src/main/kotlin/com/wingedsheep/gym/actorinput/ActorActionMenu.kt']['error_type'],'FileNotFoundError'))
            (runtime/'gym/src/main/kotlin/com/wingedsheep/gym/actorinput/ActorActionMenu.kt').write_bytes(original)
        check('reject-unknown-group',lambda:h._bind('unknown',runtime,control),'Only the two original')
        check('reject-coincident-checkouts',lambda:h._bind('shared_actor_50',control,control),'must be separate')
        with patch.dict(os.environ,{'GITHUB_RUN_ATTEMPT':'2'}):
            check('durable-early-rejection',lambda:h.bind('shared_actor_50',runtime,control),'Consumed control')
        report=runtime/'build/reports/shared-actor-input/external-main-binding-attempts/attempt-001'
        receipt=json.loads((report/'attempt.json').read_text())
        check('rejection-receipt-scope',lambda:eq(receipt['status'],'REJECTED_BINDING_NO_QUALIFICATION'))
        check('rejection-preserves-all-five-controls',lambda:eq(set(receipt['preserved_files']) & {'control/'+p for p in h.CONTROL_FILES},{'control/'+p for p in h.CONTROL_FILES}))
        check('rejection-preserves-hidden-workflow',lambda:eq((report/'control'/h.WORKFLOW).read_bytes(),(control/h.WORKFLOW).read_bytes()))
        # Exercise every runtime Git/file guard on explicitly synthetic payloads.
        synthetic_manifest=copy.deepcopy(manifest)
        for index,row in enumerate(synthetic_manifest['main_only_files']):
            raw=('SYNTHETIC CONTROL GUARD PAYLOAD '+str(index)+'\n').encode();put(row['path'],raw)
            row['git_blob_sha1']=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        def runtime_git(root,*args):
            eq(root,runtime)
            fixed={('rev-parse','HEAD'):h.RUNTIME,('rev-parse','HEAD^{tree}'):h.RUNTIME_TREE,('rev-list','--parents','-n','1',h.RUNTIME):' '.join([h.RUNTIME,h.MAIN,h.CANONICAL]),('rev-parse',h.MAIN+'^{tree}'):h.MAIN_TREE,('rev-parse',h.CANONICAL+'^{tree}'):h.CANONICAL_TREE,('status','--porcelain','--untracked-files=all'):'',('diff','--name-status',h.CANONICAL,h.RUNTIME):'\n'.join(r['status_code']+'\t'+r['path'] for r in synthetic_manifest['main_only_files'])}
            if args in fixed:return fixed[args]
            for row in synthetic_manifest['main_only_files']:
                if args==('ls-tree',h.RUNTIME,'--',row['path']):return '100644 blob '+row['git_blob_sha1']+'\t'+row['path']
            raise AssertionError(args)
        with patch.object(h,'git',runtime_git):
            check('runtime-all-guards-positive-synthetic-14-payloads',lambda:h.runtime_identity(runtime,synthetic_manifest))
            with patch.dict(os.environ,{'SPHINX_MAIN_RUNTIME_SHA':'d'*40}):check('reject-requested-runtime',lambda:h.runtime_identity(runtime,synthetic_manifest),'Wrong requested runtime')
            for args,answer,message in [(('rev-parse','HEAD'),'d'*40,'Wrong actual runtime'),(('rev-parse','HEAD^{tree}'),'d'*40,'Wrong runtime tree'),(('rev-list','--parents','-n','1',h.RUNTIME),' '.join([h.RUNTIME,h.CANONICAL,h.MAIN]),'merge parents differ'),(('rev-parse',h.MAIN+'^{tree}'),'d'*40,'Anchor tree differs'),(('status','--porcelain','--untracked-files=all'),'?? new.py','Runtime checkout is dirty'),(('diff','--name-status',h.CANONICAL,h.RUNTIME),'A\textra.py','complete main delta differs')]:
                def wrong_runtime_git(root,*query):return answer if query==args else runtime_git(root,*query)
                with patch.object(h,'git',wrong_runtime_git):check('reject-runtime-'+message,lambda:h.runtime_identity(runtime,synthetic_manifest),message)
            row=synthetic_manifest['main_only_files'][0];original=(runtime/row['path']).read_bytes();(runtime/row['path']).write_bytes(original+b'x');check('reject-main-file-bytes',lambda:h.runtime_identity(runtime,synthetic_manifest),'Main-only file changed');(runtime/row['path']).write_bytes(original)
            rows=copy.deepcopy(synthetic_manifest);rows['main_only_files'].pop();check('reject-missing-main-row',lambda:h.runtime_identity(runtime,rows),'Main-only inventory changed')

# AST checks preserve substantive original collectors and exact reused watchdog.
def functions(path):return {x.name:x for x in ast.parse(path.read_text()).body if isinstance(x,ast.FunctionDef)}
def same(a,b):return ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
original_run=functions(Path('sphinx-audit/full-ci-control/sphinx-full-ci.py'))['run']
check('owned-watchdog-identical-reviewed-function-AST',lambda:eq(same(functions(CANDIDATE/'sphinx-approach/main_receiving_binding.py')['run'],original_run),True))
check('Sphinx-original-collect-body-unchanged-AST',lambda:eq(same(functions(CANDIDATE/'sphinx-approach/collect-stage-e-actor.py')['collect'],functions(release/'sphinx-approach/collect-stage-e-actor.py')['collect']),True))
old=functions(release/'lab-coordinator/shared-capabilities/collect-actor-input.py')['collect']
new=copy.deepcopy(functions(CANDIDATE/'lab-coordinator/shared-capabilities/collect-actor-input.py')['collect']);del new.body[1:3]
check('shared-original-collect-AST-retained-plus-only-external-recheck',lambda:eq(same(old,new),True))
for path,name,total in [('lab-coordinator/shared-capabilities/collect-actor-input.py','EXPECTED',50),('sphinx-approach/collect-stage-e-actor.py','BANKS',136)]:
    def geometry(p):
        return next(ast.literal_eval(n.value) for n in ast.parse(p.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
    check('original-case-geometry-'+name,lambda p=path:eq(geometry(CANDIDATE/p),geometry(release/p)))
    check('original-total-'+name,lambda p=path,t=total:eq(sum(geometry(CANDIDATE/p).values()),t))
report={'schema':'sphinx-external-main-control-synthetic-checks/v1','limits':['Python-only controls; synthetic Git returns and synthetic fourteen-file payloads are explicitly not actual receiving qualification.','Real source-authority bytes/pins were reused from exact cached Git blobs; no JVM, tests, official seeds, games, GitHub event or resource command executed.'],'candidate_sha256':{str(p.relative_to(CANDIDATE)):h.sha(p.read_bytes()) for p in sorted(CANDIDATE.rglob('*')) if p.is_file()},'checks':results,'checks_total':len(results),'failed':sum(r['result']!='PASS' for r in results),'official_games':0,'gameplay_authorized':False}
(BASE/'synthetic-guard-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'total':len(results),'failed':report['failed'],'failures':[r for r in results if r['result']!='PASS']},indent=2))
raise SystemExit(bool(report['failed']))
