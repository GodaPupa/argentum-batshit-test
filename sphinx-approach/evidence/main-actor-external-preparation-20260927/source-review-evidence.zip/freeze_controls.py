"""Deterministic local bytes only; no publication or activation."""
from pathlib import Path
import difflib,hashlib,json
base=Path(__file__).resolve().parent;c=base/'candidate'
m=c/'sphinx-approach/STAGE_E_MAIN_RECEIVING_BINDING.json';value=json.loads(m.read_text())
for p in value['control_source_sha256']:value['control_source_sha256'][p]=hashlib.sha256((c/p).read_bytes()).hexdigest()
value['normalized_workflow_sha256']=hashlib.sha256((base/'workflow.template.yml').read_bytes()).hexdigest()
m.write_text(json.dumps(value,indent=2)+'\n');digest=hashlib.sha256(m.read_bytes()).hexdigest()
w=c/'.github/workflows/sphinx-main-actor-receiving-qualification.yml';w.write_text((base/'workflow.template.yml').read_text().replace('__BINDING_SHA256__',digest))
rows=[];diff=[]
for p in sorted(c.rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(c));raw=p.read_bytes();rows.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
 prior=Path('sphinx-audit/canonical-integration/release')/rel
 before=prior.read_text().splitlines(keepends=True) if prior.exists() else []
 diff.extend(difflib.unified_diff(before,p.read_text().splitlines(keepends=True),fromfile='a/'+rel if prior.exists() else '/dev/null',tofile='b/'+rel))
(base/'candidate-inventory.json').write_text(json.dumps({'status':'LOCAL_CANDIDATE_UNREVIEWED_UNACTIVATED','parent':'8ed9787ad75b8bc6c2438a8c0b526ff822aa776e','manifest_sha256':digest,'files':rows,'official_games':0,'gameplay_authorized':False},indent=2)+'\n')
(base/'candidate.patch').write_text(''.join(diff));print(json.dumps(rows,indent=2))
