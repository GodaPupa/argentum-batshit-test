import ast, base64, hashlib, json, zipfile
from pathlib import Path
P=Path('/workspace/scratch/94f5141e9448/ferocity-takeover/sphinx-main-binding')
ROOT=P.parents[1]
C=P/'candidate'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def blob(raw): return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def functions(raw): return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
inventory=json.loads((P/'candidate-inventory.json').read_text())
assert len(inventory['files'])==5
for row in inventory['files']:
 raw=(C/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and blob(raw)==row['git_blob_sha1']
manifest_raw=(C/'sphinx-approach/STAGE_E_MAIN_RECEIVING_BINDING.json').read_bytes();manifest=json.loads(manifest_raw)
assert sha(manifest_raw)==inventory['manifest_sha256']
for path,digest in manifest['control_source_sha256'].items():assert sha((C/path).read_bytes())==digest
workflow=(C/'.github/workflows/sphinx-main-actor-receiving-qualification.yml').read_bytes()
needle=("SPHINX_MAIN_BINDING_SHA256: '"+sha(manifest_raw)+"'").encode()
assert workflow.count(needle)==1
assert sha(workflow.replace(needle,b"SPHINX_MAIN_BINDING_SHA256: '__BINDING_SHA256__'"))==manifest['normalized_workflow_sha256']
initial=(P/'initial-candidate-ec99.zip').read_bytes();assert sha(initial)=='0fac251f913fc1d9c4dea97cb8f0923ac45b666925c71b07232390a8dc61c091'
with zipfile.ZipFile(P/'initial-candidate-ec99.zip') as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==10
 prior=json.loads(z.read('candidate-inventory.json'))
 for row in prior['files']:
  raw=z.read('candidate/'+row['path']);assert sha(raw)==row['sha256'] and blob(raw)==row['git_blob_sha1']
 old=functions(z.read('candidate/sphinx-approach/main_receiving_binding.py'))
 new=functions((C/'sphinx-approach/main_receiving_binding.py').read_bytes())
 assert set(new)-set(old)=={'observe_source'}
 assert {n for n in old if old[n]!=new[n]}=={'bind'}
 for path in ['sphinx-approach/collect-stage-e-actor.py','lab-coordinator/shared-capabilities/collect-actor-input.py']:
  assert z.read('candidate/'+path)==(C/path).read_bytes()
 old_manifest=json.loads(z.read('candidate/sphinx-approach/STAGE_E_MAIN_RECEIVING_BINDING.json'))
 old_manifest['control_source_sha256']=manifest['control_source_sha256'];assert old_manifest==manifest
 previous_workflow=z.read('candidate/.github/workflows/sphinx-main-actor-receiving-qualification.yml')
 assert previous_workflow.replace(prior['manifest_sha256'].encode(),inventory['manifest_sha256'].encode())==workflow
metadata=json.loads((P/'root-fresh-runtime-metadata.json').read_text())['records']
assert [(r['data']['sha'],r['data']['tree']['sha']) for r in metadata[:3]]==[(manifest['runtime'],manifest['runtime_tree']),('8ed9787ad75b8bc6c2438a8c0b526ff822aa776e','4693352c4a22d9f3b35eb47048c8edaabe8157f1'),('ff34ac8fa2efbd41f233e877cb2908c2cab5929a','88967f3a9ba0479661f02150f82ddcc9a2066e42')]
assert [r['sha'] for r in metadata[0]['data']['parents']]==[manifest['main'],manifest['canonical']]
comparison=metadata[3]['data'];assert len(comparison['files'])==14
current={e['path']:e for e in metadata[4]['data']['tree']}
assert not metadata[4]['data']['truncated'] and metadata[4]['data']['entry_count']==29622
for row in manifest['main_only_files']:
 got=next(f for f in comparison['files'] if f['filename']==row['path'])
 assert got['sha']==row['git_blob_sha1'] and {'added':'A','modified':'M'}[got['status']]==row['status_code']
 assert current[row['path']]['sha']==row['git_blob_sha1'] and current[row['path']]['mode']=='100644'
cache={}
def payloads(value):
 if isinstance(value,dict):
  if isinstance(value.get('content'),str):
   raw=base64.b64decode(''.join(value['content'].split()),validate=True) if value.get('encoding')=='base64' else value['content'].encode()
   if value.get('sha'):assert blob(raw)==value['sha']
   cache[sha(raw)]=raw
  for item in value.values():payloads(item)
 elif isinstance(value,list):
  for item in value:payloads(item)
paths=json.loads((P/'cache-index.json').read_text())['inputs']+['ferocity-takeover/sphinx-main-binding/additional-exact-authorities.json','ferocity-takeover/sphinx-main-binding/additional-exact-source.json']
for path in paths:payloads(json.loads((ROOT/path).read_text()))
release=ROOT/'sphinx-audit/canonical-integration/release'
for path in release.rglob('*'):
 if path.is_file():cache[sha(path.read_bytes())]=path.read_bytes()
descriptor_path='sphinx-approach/STAGE_E_CANONICAL_RECEIVING_BINDING.json'
descriptor_raw=(release/descriptor_path).read_bytes();assert sha(descriptor_raw)=='1316e5dc9ad26db03e655d4fd5aa96427309eb04700d929e6433e64786f50682'
descriptor=json.loads(descriptor_raw)
def read_exact(path,digest):
 raw=cache[digest];assert sha(raw)==digest and blob(raw)==current[path]['sha'],path
 return raw
wanted=dict(descriptor['preserved_authority_sha256'])
wanted[descriptor_path]=sha(descriptor_raw)
wanted['sphinx-approach/canonical_receiving_binding.py']='a014e1e4ebf37db57bf3a77d5a4f1963476710ebe76692b1a213e60cb7f7f300'
wanted[descriptor['independent_source_review']['path']]=descriptor['independent_source_review']['sha256']
for path in descriptor['qualification_control_paths']:wanted[path]=sha((release/path).read_bytes())
groups={}
for group in ['shared_actor_50','sphinx_actor_136']:
 if group=='shared_actor_50':
  path='lab-coordinator/shared-capabilities/actor-input-extraction.json';data=json.loads(read_exact(path,wanted[path]))
  banks=[{row['receiving_path']:row['receiving_sha256'] for row in data['source_records']},data['local_integration_files_sha256']]
 else:
  p='sphinx-approach/STAGE_E_ACTOR_FIXTURE_BUDGET.json';b=json.loads(read_exact(p,wanted[p]))
  p='sphinx-approach/STAGE_E_ACTOR_RECEIVING_SCOPE.json';s=json.loads(read_exact(p,wanted[p]))
  banks=[b['protected_source_sha256'],b['fixture_source_sha256'],s['receiving_source_sha256']]
 pins={}
 for bank in banks:
  for path,digest in bank.items():assert path not in pins or pins[path]==digest;pins[path]=digest
 assert sha(json.dumps(pins,sort_keys=True,separators=(',',':')).encode())==descriptor['groups'][group]['original_pins_sha256']
 groups[group]={'original_pins':len(pins),'overrides':len(descriptor['groups'][group]['explicit_overrides'])}
 for row in descriptor['groups'][group]['explicit_overrides']:
  assert pins[row['path']]==row['original_sha256'];pins[row['path']]=row['receiving_sha256']
 for path,digest in pins.items():assert path not in wanted or wanted[path]==digest;wanted[path]=digest
proof=[]
for path,digest in sorted(wanted.items()):
 raw=read_exact(path,digest);proof.append({'path':path,'bytes':len(raw),'sha256':digest,'git_blob_sha1':blob(raw)})
report={'schema':'root-sphinx-external-source-byte-proof-v1','read_only':True,'runtime':manifest['runtime'],'runtime_tree':manifest['runtime_tree'],'candidate_inventory_sha256':sha((P/'candidate-inventory.json').read_bytes()),'five_control_files':inventory['files'],'groups':groups,'exact_actual_main_delta':manifest['main_only_files'],'source_bodies_rehashed':proof,'retention_delta':'Only new observe_source and bind observation-before-comparison; both collectors byte-identical, manifest only helper hash and workflow only manifest digest change.','original_candidate_archive_sha256':sha(initial),'official_games':0,'runtime_commands':0}
(P/'root-source-byte-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'files':len(inventory['files']),'main_delta':14,'source_bodies':len(proof),'groups':groups,'runtime_commands':0}))
