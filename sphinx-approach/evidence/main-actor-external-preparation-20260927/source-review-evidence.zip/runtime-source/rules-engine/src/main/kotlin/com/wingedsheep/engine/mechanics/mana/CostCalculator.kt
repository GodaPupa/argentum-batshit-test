package com.wingedsheep.engine.mechanics.mana
import com.wingedsheep.engine.state.components.battlefield.chosenCreatureType
import com.wingedsheep.engine.state.components.battlefield.chosenColor
import com.wingedsheep.engine.state.components.battlefield.CastChoicesComponent
import com.wingedsheep.engine.state.components.battlefield.ChoiceValue

import com.wingedsheep.engine.mechanics.layers.ProjectedState
import com.wingedsheep.engine.handlers.effects.linkedexile.LinkedExileLookup
import com.wingedsheep.engine.registry.CardRegistry
import com.wingedsheep.engine.state.GameState
import com.wingedsheep.engine.state.components.battlefield.ClassLevelComponent
import com.wingedsheep.engine.state.components.combat.PlayerAttackersThisTurnComponent
import com.wingedsheep.engine.state.components.identity.CardComponent
import com.wingedsheep.engine.state.components.player.CreaturesDiedThisTurnComponent
import com.wingedsheep.engine.state.components.player.CardsDrawnThisTurnComponent
import com.wingedsheep.engine.state.components.identity.CommanderComponent
import com.wingedsheep.sdk.core.CardType
import com.wingedsheep.sdk.core.Color
import com.wingedsheep.sdk.core.ManaCost
import com.wingedsheep.sdk.core.Zone
import com.wingedsheep.sdk.core.ManaSymbol
import com.wingedsheep.sdk.model.CardDefinition
import com.wingedsheep.sdk.model.CharacteristicValue
import com.wingedsheep.sdk.scripting.ChoiceSlot
import com.wingedsheep.sdk.scripting.values.EntityNumericProperty
import com.wingedsheep.sdk.model.EntityId
import com.wingedsheep.sdk.core.Subtype
import com.wingedsheep.engine.state.components.battlefield.CountersComponent
import com.wingedsheep.sdk.core.CounterType
import com.wingedsheep.sdk.scripting.AdditionalCost
import com.wingedsheep.sdk.scripting.CostGating
import com.wingedsheep.sdk.scripting.CostModification
import com.wingedsheep.sdk.scripting.CostReductionSource
import com.wingedsheep.sdk.scripting.GameObjectFilter
import com.wingedsheep.sdk.scripting.GrantAlternativeCastingCost
import com.wingedsheep.sdk.scripting.MayCastWithoutPayingManaCost
import com.wingedsheep.sdk.scripting.KeywordAbility
import com.wingedsheep.sdk.scripting.ModifySpellCost
import com.wingedsheep.sdk.scripting.SpellCostTarget
import com.wingedsheep.sdk.scripting.filters.unified.GroupFilter
import com.wingedsheep.sdk.scripting.filters.unified.Scope
import com.wingedsheep.engine.handlers.ConditionEvaluator
import com.wingedsheep.engine.handlers.DynamicAmountEvaluator
import com.wingedsheep.engine.handlers.EffectContext
import com.wingedsheep.engine.handlers.PredicateEvaluator
import com.wingedsheep.sdk.scripting.values.DynamicAmount
import com.wingedsheep.engine.state.components.stack.ChosenTarget
import com.wingedsheep.engine.state.components.stack.SpellOnStackComponent
import com.wingedsheep.engine.handlers.PredicateContext
import com.wingedsheep.sdk.scripting.predicates.CardPredicate

/**
 * Calculates effective spell costs after applying cost reductions.
 *
 * All cost modifiers go through the unified [ModifySpellCost] static ability:
 * generic/colored reductions, dynamic reductions sourced from game state, global
 * tax effects, face-down (morph) cast cost adjustments, and morph (turn face-up)
 * activation cost adjustments.
 *
 * Cost reductions only reduce generic mana costs by default; colored modifications
 * are explicit (`CostModification.ReduceColored*`).
 * A spell's cost can never be reduced below its colored mana requirements.
 */
class CostCalculator(
    private val cardRegistry: CardRegistry,
    private val predicateEvaluator: PredicateEvaluator = PredicateEvaluator(),
    private val conditionEvaluator: ConditionEvaluator = ConditionEvaluator(),
    private val dynamicAmountEvaluator: DynamicAmountEvaluator = DynamicAmountEvaluator()
) {

    /**
     * Calculate the effective cost of casting a spell after applying all cost reductions.
     *
     * @param state The current game state
     * @param cardDef The card definition being cast
     * @param casterId The player casting the spell
     * @return The effective mana cost after reductions
     */
    fun calculateEffectiveCost(
        state: GameState,
        cardDef: CardDefinition,
        casterId: EntityId,
        chosenTargets: List<EntityId> = emptyList(),
        fromZone: Zone? = null,
        declaredCostSlot: ChoiceSlot? = null,
    ): ManaCost {
        var totalReduction = 0
        var totalIncrease = 0
        val coloredReductionSymbols = mutableListOf<ManaSymbol>()
        val coloredReductionWithOverflow = mutableListOf<ManaSymbol>()
        val coloredIncreaseSymbols = mutableListOf<ManaSymbol>()

        // Self-reductions read from the spell card's own static abilities.
        for (ability in cardDef.script.staticAbilities) {
            if (ability !is ModifySpellCost) continue
            if (ability.target != SpellCostTarget.SelfCast) continue
            if (!gatingApplies(state, casterId, cardDef, ability, declaredCostSlot)) continue
            applyToSpellCast(
                // A self-cast modifier has no source *permanent*: the card is the spell being cast,
                // so source-relative reduction sources read nothing.
                state, cardDef, casterId, ability.modification, chosenTargets, sourceId = null,
                addGenericReduction = { totalReduction += it },
                addGenericIncrease = { totalIncrease += it },
                addColoredReduction = { coloredReductionSymbols += it },
                addColoredReductionWithOverflow = { coloredReductionWithOverflow += it },
                addColoredIncrease = { coloredIncreaseSymbols += it },
            )
        }

        // Affinity keyword abilities (handled separately from ModifySpellCost).
        for (keywordAbility in cardDef.keywordAbilities) {
            if (keywordAbility is KeywordAbility.Affinity) {
                totalReduction += countPermanentsOfType(state, casterId, keywordAbility.forType)
            }
            if (keywordAbility is KeywordAbility.AffinityForSubtype) {
                totalReduction += countPermanentsWithSubtype(state, casterId, keywordAbility.forSubtype)
            }
        }

        // Granted "your next spell this turn has affinity for X" riders (Don & Raph). Each matching
        // rider reduces this spell by the caster's count of its card type at cast time; the rider is
        // consumed by CastSpellHandler when the spell is actually cast.
        for (rider in state.pendingNextSpellAffinities) {
            if (rider.controllerId != casterId) continue
            if (!matchesCardDefinition(cardDef, rider.spellFilter, null, state, state.projectedState)) continue
            totalReduction += countPermanentsOfType(state, casterId, rider.forType)
        }

        // Turn-scoped "spells you cast this turn that match … cost {N} less" discounts (Will /
        // Rowan, Scion of …). The amount was fixed when the granting ability resolved, so unlike
        // the affinity riders above nothing is recomputed here — and unlike them, a matching cast
        // does not consume the entry.
        for (reduction in state.turnSpellCostReductions) {
            if (reduction.controllerId != casterId) continue
            if (!matchesCardDefinition(cardDef, reduction.spellFilter, null, state, state.projectedState)) continue
            totalReduction += reduction.amount
        }

        // Battlefield-sourced ModifySpellCost abilities.
        for ((sourceId, ability) in scanBattlefieldModifySpellCost(state)) {
            if (!targetMatchesSpell(ability.target, cardDef, casterId, sourceId, state, chosenTargets, fromZone)) continue
            if (!gatingApplies(state, casterId, cardDef, ability, declaredCostSlot)) continue
            applyToSpellCast(
                state, cardDef, casterId, ability.modification, chosenTargets, sourceId = sourceId,
                addGenericReduction = { totalReduction += it },
                addGenericIncrease = { totalIncrease += it },
                addColoredReduction = { coloredReductionSymbols += it },
                addColoredReductionWithOverflow = { coloredReductionWithOverflow += it },
                addColoredIncrease = { coloredIncreaseSymbols += it },
                abilitySourceId = sourceId,
            )
        }

        // Stack-sourced ModifySpellCost abilities. These are opt-in only: ordinary permanent
        // static abilities retain the default battlefield-only source zone.
        for ((sourceId, ability) in scanStackModifySpellCost(state)) {
            if (!targetMatchesSpell(ability.target, cardDef, casterId, sourceId, state, chosenTargets, fromZone)) continue
            if (!gatingApplies(state, casterId, cardDef, ability, declaredCostSlot)) continue
            applyToSpellCast(
                state, cardDef, casterId, ability.modification, chosenTargets, sourceId = sourceId,
                addGenericReduction = { totalReduction += it },
                addGenericIncrease = { totalIncrease += it },
                addColoredReduction = { coloredReductionSymbols += it },
                addColoredReductionWithOverflow = { coloredReductionWithOverflow += it },
                addColoredIncrease = { coloredIncreaseSymbols += it },
                abilitySourceId = sourceId,
            )
        }

        // Commander tax (CR 903.8).
        totalIncrease += calculateCommanderTax(state, cardDef, casterId, fromZone)

        // CR 601.2f: the total cost is the base cost plus all cost increases, then minus all cost
        // reductions; the mana component is floored at {0} (it can't be reduced below {0}). Apply
        // increases first so a reduction that overshoots {0} doesn't leave a stale increase behind
        // (e.g. {U} +{1} −{2} → {U}, not {1}{U}).
        var effectiveCost = increaseGenericCost(cardDef.manaCost, totalIncrease)
        if (coloredIncreaseSymbols.isNotEmpty()) {
            effectiveCost = increaseColoredCost(effectiveCost, coloredIncreaseSymbols)
        }
        effectiveCost = reduceGenericCost(effectiveCost, totalReduction)
        if (coloredReductionSymbols.isNotEmpty()) {
            effectiveCost = reduceColoredCost(effectiveCost, coloredReductionSymbols)
        }
        if (coloredReductionWithOverflow.isNotEmpty()) {
            effectiveCost = reduceColoredCostWithOverflow(effectiveCost, coloredReductionWithOverflow)
        }
        return effectiveCost
    }

    /**
     * Compute commander tax for [cardDef] when cast from [fromZone].
     *
     * Returns 0 unless [fromZone] is `Zone.COMMAND` and the corresponding entity carries a
     * `CommanderComponent`. The tax is `2 * castsFromCommandZone` generic mana, applied alongside
     * other generic-cost increases. Locating the entity uses the deck-time `cardDefinitionId`
     * suffix (`Name#Set-CN`) plus the bare name, mirroring how `GameInitializer` builds the id.
     */
    private fun calculateCommanderTax(
        state: GameState,
        cardDef: CardDefinition,
        casterId: EntityId,
        fromZone: Zone?,
    ): Int {
        if (fromZone != Zone.COMMAND) return 0
        val commandZone = state.zones[
            com.wingedsheep.engine.state.ZoneKey(casterId, Zone.COMMAND),
        ] ?: return 0
        val match = commandZone.firstNotNullOfOrNull { entityId ->
            val container = state.getEntity(entityId) ?: return@firstNotNullOfOrNull null
            val card = container.get<CardComponent>() ?: return@firstNotNullOfOrNull null
            val commander = container.get<CommanderComponent>() ?: return@firstNotNullOfOrNull null
            if (commander.ownerId != casterId) return@firstNotNullOfOrNull null
            if (card.name != cardDef.name) return@firstNotNullOfOrNull null
            commander
        } ?: return 0
        return 2 * match.castsFromCommandZone
    }

    /**
     * Scan the battlefield for [ModifySpellCost] static abilities, returning each
     * (sourceEntityId, ability) pair. Class-level filtering via [ClassLevelComponent]
     * is honored.
     */
    private fun scanBattlefieldModifySpellCost(state: GameState): List<Pair<EntityId, ModifySpellCost>> {
        val results = mutableListOf<Pair<EntityId, ModifySpellCost>>()
        for (playerId in state.turnOrder) {
            for (entityId in state.getBattlefield(playerId)) {
                val container = state.getEntity(entityId) ?: continue
                val card = container.get<CardComponent>() ?: continue
                val permanentDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
                val classLevel = container.get<ClassLevelComponent>()?.currentLevel
                for (ability in permanentDef.script.effectiveStaticAbilities(classLevel)) {
                    if (ability is ModifySpellCost && Zone.BATTLEFIELD in ability.sourceZones) {
                        results += entityId to ability
                    }
                }
            }
        }
        return results
    }

    /** Stack-native [ModifySpellCost] abilities explicitly opted into [Zone.STACK]. */
    private fun scanStackModifySpellCost(state: GameState): List<Pair<EntityId, ModifySpellCost>> {
        val results = mutableListOf<Pair<EntityId, ModifySpellCost>>()
        for (entityId in state.stack) {
            val container = state.getEntity(entityId) ?: continue
            if (container.get<SpellOnStackComponent>() == null) continue
            val card = container.get<CardComponent>() ?: continue
            val spellDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
            for (ability in spellDef.script.staticAbilities) {
                if (ability is ModifySpellCost && Zone.STACK in ability.sourceZones) {
                    results += entityId to ability
                }
            }
        }
        return results
    }

    private fun sourceController(state: GameState, sourceId: EntityId): EntityId? =
        state.projectedState.getController(sourceId)
            ?: state.getEntity(sourceId)?.get<SpellOnStackComponent>()?.casterId

    /**
     * Whether [cardDef] (cast by [casterId]) is a target of [target] for the given
     * [sourceId] permanent on the battlefield (or null for self-cast).
     */
    private fun targetMatchesSpell(
        target: SpellCostTarget,
        cardDef: CardDefinition,
        casterId: EntityId,
        sourceId: EntityId,
        state: GameState,
        chosenTargets: List<EntityId> = emptyList(),
        fromZone: Zone? = null,
    ): Boolean {
        return when (target) {
            SpellCostTarget.SelfCast -> false
            is SpellCostTarget.YouCast -> {
                val controller = sourceController(state, sourceId)
                controller == casterId &&
                    matchesCardDefinition(cardDef, target.filter, sourceId, state, state.projectedState)
            }
            is SpellCostTarget.AnyCaster -> matchesCardDefinition(cardDef, target.filter, sourceId, state, state.projectedState)
            is SpellCostTarget.AnyCasterTargeting ->
                castTargetingMatches(state, sourceId, target.targetFilter, chosenTargets)
            is SpellCostTarget.OpponentsCastTargeting ->
                opponentsCastTargetingMatches(state, casterId, sourceId, target.targetFilter, chosenTargets)
            is SpellCostTarget.OpponentsCastFromZones -> {
                // Source must be controlled by an opponent of the caster, the spell must be cast
                // from one of the named zones, and the card must match the filter.
                if (fromZone == null || fromZone !in target.zones) return false
                val sourceController = sourceController(state, sourceId) ?: return false
                if (sourceController == casterId) return false
                matchesCardDefinition(cardDef, target.filter, sourceId, state, state.projectedState)
            }
            is SpellCostTarget.YouCastFromZones -> {
                // Source must be controlled by the caster, the spell must be cast from one of the
                // named zones, and the card must match the filter (Doc Aurlock).
                if (fromZone == null || fromZone !in target.zones) return false
                val sourceController = sourceController(state, sourceId) ?: return false
                if (sourceController != casterId) return false
                matchesCardDefinition(cardDef, target.filter, sourceId, state, state.projectedState)
            }
            // FaceDown / Morph targets are spell-cast modifiers only when applied to a face-down cast.
            // calculateEffectiveCost is only called for face-up casts; face-down handling is in
            // calculateFaceDownCost / calculateMorphCostIncrease.
            SpellCostTarget.FaceDownYouCast -> false
            SpellCostTarget.MorphActivation -> false
        }
    }

    /** True iff one chosen target matches [targetFilter] relative to [sourceId]. */
    private fun castTargetingMatches(
        state: GameState,
        sourceId: EntityId,
        targetFilter: GroupFilter,
        chosenTargets: List<EntityId>,
    ): Boolean {
        if (chosenTargets.isEmpty()) return false
        val controller = sourceController(state, sourceId) ?: return false
        val context = PredicateContext(controllerId = controller, sourceId = sourceId)
        val projected = state.projectedState
        return chosenTargets.any { targetId ->
            when (val scope = targetFilter.scope) {
                is Scope.Self -> targetId == sourceId
                is Scope.Specific -> targetId == scope.entityId
                is Scope.AttachedTo -> {
                    val attached = state.getEntity(sourceId)
                        ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                        ?.targetId
                    attached != null && targetId == attached
                }
                is Scope.SoulbondPair ->
                    com.wingedsheep.engine.mechanics.SoulbondPairing.isInPairOf(state, sourceId, targetId)
                is Scope.Battlefield ->
                    predicateEvaluator.matches(state, projected, targetId, targetFilter.baseFilter, context)
            }
        }
    }

    /**
     * True iff the source is controlled by an opponent of the caster, and at least
     * one of the caster's chosen targets matches [targetFilter] relative to the
     * source. Implements the matching half of [SpellCostTarget.OpponentsCastTargeting]
     * (e.g. Terror of the Peaks' "this creature", Kopala's "Merfolk you control").
     */
    private fun opponentsCastTargetingMatches(
        state: GameState,
        casterId: EntityId,
        sourceId: EntityId,
        targetFilter: GroupFilter,
        chosenTargets: List<EntityId>,
    ): Boolean {
        if (chosenTargets.isEmpty()) return false
        val sourceController = state.projectedState.getController(sourceId) ?: return false
        if (sourceController == casterId) return false
        val context = PredicateContext(controllerId = sourceController, sourceId = sourceId)
        val projected = state.projectedState
        return chosenTargets.any { targetId ->
            when (val scope = targetFilter.scope) {
                is Scope.Self -> targetId == sourceId
                is Scope.Specific -> targetId == scope.entityId
                is Scope.AttachedTo -> {
                    val attached = state.getEntity(sourceId)
                        ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
                        ?.targetId
                    attached != null && targetId == attached
                }
                is Scope.SoulbondPair ->
                    com.wingedsheep.engine.mechanics.SoulbondPairing.isInPairOf(state, sourceId, targetId)
                is Scope.Battlefield ->
                    predicateEvaluator.matches(state, projected, targetId, targetFilter.baseFilter, context)
            }
        }
    }

    /**
     * Whether the [ability]'s gating allows it to apply to a cast of [cardDef] by [casterId].
     */
    private fun gatingApplies(
        state: GameState,
        casterId: EntityId,
        cardDef: CardDefinition,
        ability: ModifySpellCost,
        declaredCostSlot: ChoiceSlot? = null,
    ): Boolean {
        return when (val gating = ability.gating) {
            CostGating.None -> true
            is CostGating.NthOfTypePerTurn -> {
                val filter = filterForGating(ability.target) ?: return false
                val records = state.spellsCastThisTurnByPlayer[casterId] ?: emptyList()
                val priorMatching = records.count { predicateEvaluator.matchesFilter(it, filter) }
                priorMatching == gating.n - 1
            }
            is CostGating.OnlyIf -> {
                // Player-scoped conditions ("during your turn", "you've cast another spell", ...)
                // evaluate against the caster. The cost modifier's source is a non-spell permanent
                // (or the spell card itself for SelfCast), neither of which the condition needs.
                // The optional additional cost this cast declares is part of the branch being
                // priced, not of the game state — a "costs {2} less to cast if it's bargained"
                // reduction (CR 702.166, Hamlet Glutton) applies only to the bargained variant, and
                // the spell has no durable choice bag yet, so the declaration rides the context.
                val ctx = EffectContext(
                    sourceId = null,
                    controllerId = casterId,
                    declaredCostSlot = declaredCostSlot,
                )
                conditionEvaluator.evaluate(state, gating.condition, ctx)
            }
        }
    }

    private fun filterForGating(target: SpellCostTarget) = when (target) {
        is SpellCostTarget.YouCast -> target.filter
        is SpellCostTarget.AnyCaster -> target.filter
        else -> null  // Gating requires a filter to know what "of type" means.
    }

    /**
     * Apply a single cost modification to the running totals for a spell cast.
     *
     * [sourceId] is the battlefield permanent whose [ModifySpellCost] this is, or null for a
     * self-cast modifier printed on the spell itself. Source-relative reduction sources
     * ([CostReductionSource.Dynamic]) read it; every other source ignores it.
     */
    private fun applyToSpellCast(
        state: GameState,
        cardDef: CardDefinition,
        casterId: EntityId,
        modification: CostModification,
        chosenTargets: List<EntityId>,
        sourceId: EntityId?,
        addGenericReduction: (Int) -> Unit,
        addGenericIncrease: (Int) -> Unit,
        addColoredReduction: (ManaSymbol) -> Unit,
        addColoredReductionWithOverflow: (ManaSymbol) -> Unit,
        addColoredIncrease: (ManaSymbol) -> Unit,
        abilitySourceId: EntityId? = null,
    ) {
        when (modification) {
            is CostModification.ReduceGeneric -> addGenericReduction(modification.amount)
            is CostModification.ReduceGenericBy ->
                addGenericReduction(
                    evaluateReduction(state, modification.source, casterId, chosenTargets, abilitySourceId, cardDef)
                )
            is CostModification.ReduceColored -> {
                ManaCost.parse(modification.symbols).symbols
                    .filterIsInstance<ManaSymbol.Colored>()
                    .forEach(addColoredReduction)
            }
            is CostModification.ReduceColoredPerUnit -> {
                val units =
                    evaluateReduction(state, modification.countSource, casterId, chosenTargets, abilitySourceId, cardDef)
                val coloredSymbols = ManaCost.parse(modification.symbols).symbols
                    .filterIsInstance<ManaSymbol.Colored>()
                repeat(units) { coloredSymbols.forEach(addColoredReductionWithOverflow) }
            }
            is CostModification.ReduceColoredIfAnyTargetMatches -> {
                if (chosenTargets.isNotEmpty() &&
                    anyTargetMatchesFilter(state, casterId, chosenTargets, modification.filter)
                ) {
                    ManaCost.parse(modification.symbols).symbols
                        .filterIsInstance<ManaSymbol.Colored>()
                        .forEach(addColoredReduction)
                }
            }
            is CostModification.IncreaseGeneric -> addGenericIncrease(modification.amount)
            is CostModification.IncreaseGenericBy ->
                addGenericIncrease(
                    evaluateReduction(state, modification.source, casterId, chosenTargets, abilitySourceId, cardDef)
                )
            is CostModification.IncreaseColored -> {
                ManaCost.parse(modification.symbols).symbols
                    .filterIsInstance<ManaSymbol.Colored>()
                    .forEach(addColoredIncrease)
            }
            is CostModification.IncreaseColoredPerUnit -> {
                val units =
                    evaluateReduction(state, modification.countSource, casterId, chosenTargets, abilitySourceId, cardDef)
                val coloredSymbols = ManaCost.parse(modification.symbols).symbols
                    .filterIsInstance<ManaSymbol.Colored>()
                repeat(units) { coloredSymbols.forEach(addColoredIncrease) }
            }
            is CostModification.IncreaseGenericPerOtherSpellThisTurn -> {
                val spellsCast = state.playerSpellsCastThisTurn[casterId] ?: 0
                addGenericIncrease(spellsCast * modification.amountPerSpell)
            }
            is CostModification.IncreaseGenericIfAnyTargetMatches -> {
                if (chosenTargets.isNotEmpty() &&
                    anyTargetMatchesFilter(state, casterId, chosenTargets, modification.filter)
                ) {
                    addGenericIncrease(modification.amount)
                }
            }
            is CostModification.IncreaseLife -> {
                // Life is not part of the mana cost — collected separately via
                // [calculateAdditionalLifeCost] and paid alongside mana in CastSpellHandler.
            }
        }
    }

    /**
     * Evaluate the reduction amount from a CostReductionSource.
     *
     * [abilitySourceId] is the battlefield permanent the reducing [ModifySpellCost] is printed on,
     * or null when the reduction comes from the spell's own script (a `SelfCast` reduction, where
     * there is no permanent to read). Only the source-reading sources need it — the
     * attachment-reading [CostReductionSource.AttachedPermanentProperty] and the general
     * [CostReductionSource.Dynamic], which reads the source permanent's own characteristics rather
     * than those of whatever it is attached to. Everything else aggregates over what [playerId]
     * controls.
     */
    private fun evaluateReduction(
        state: GameState,
        source: CostReductionSource,
        playerId: EntityId,
        chosenTargets: List<EntityId> = emptyList(),
        abilitySourceId: EntityId? = null,
        spellCard: CardDefinition? = null
    ): Int {
        return when (source) {
            is CostReductionSource.Fixed -> source.amount
            // CR 702.179f — "no speed" is 0, which GameState.speed already returns, so no has-speed
            // branch is needed. playerId is the casting player, and speed is never team-pooled.
            is CostReductionSource.YourSpeed -> state.speed(playerId)
            is CostReductionSource.CreaturesYouControl -> countCreatures(state, playerId)
            is CostReductionSource.TotalPowerYouControl -> sumPower(state, playerId)
            is CostReductionSource.ArtifactsYouControl -> countArtifacts(state, playerId)
            is CostReductionSource.ColorsAmongPermanentsYouControl -> countColors(state, playerId)
            is CostReductionSource.FixedIfControlFilter -> {
                val controls = controlsMatchingPermanent(state, playerId, source.filter)
                if (controls) source.amount else 0
            }
            CostReductionSource.CardsDrawnThisTurn ->
                state.getEntity(playerId)?.get<CardsDrawnThisTurnComponent>()?.count ?: 0
            is CostReductionSource.CardsInGraveyardMatchingFilter -> {
                countGraveyardCardsMatchingFilter(state, playerId, source.filter) * source.amountPerCard
            }
            is CostReductionSource.CardsInGraveyardAndExileMatchingFilter -> {
                val graveyardCount = countGraveyardCardsMatchingFilter(state, playerId, source.filter)
                val exileCount = countExileCardsMatchingFilter(state, playerId, source.filter)
                (graveyardCount + exileCount) * source.amountPerCard
            }
            is CostReductionSource.PermanentsWithCounterYouControl -> {
                countPermanentsWithCounter(state, playerId, source.filter, source.counterType)
            }
            is CostReductionSource.FixedIfAnyTargetMatches -> {
                if (chosenTargets.isEmpty()) 0
                else if (anyTargetMatchesFilter(state, playerId, chosenTargets, source.filter)) source.amount
                else 0
            }
            // "for each target beyond the first" — 0 while targets are still unchosen, which is
            // also the right answer for affordability enumeration (one target is the cheapest
            // legal cast, so the unmodified cost is the true minimum).
            CostReductionSource.ChosenTargetsBeyondTheFirst ->
                (chosenTargets.size - 1).coerceAtLeast(0)
            is CostReductionSource.FixedIfCreatureAttackingYou -> {
                if (isAnyCreatureAttacking(state, playerId)) source.amount else 0
            }
            is CostReductionSource.GreatestPropertyAmongPermanentsYouControl -> {
                greatestPropertyAmongMatching(state, playerId, source.filter, source.property)
            }
            is CostReductionSource.TotalPropertyAmongPermanentsYouControl -> {
                totalPropertyAmongMatching(state, playerId, source.filter, source.property)
            }
            is CostReductionSource.AttachedPermanentProperty -> {
                attachedPermanentProperty(state, abilitySourceId, source.property)
            }
            is CostReductionSource.Dynamic -> {
                dynamicReductionValue(state, abilitySourceId, playerId, source.amount)
            }
            is CostReductionSource.FixedIfCreatureDiedThisTurn -> {
                if (anyCreatureDiedThisTurn(state)) source.amount else 0
            }
            is CostReductionSource.FixedIfVoid -> {
                if (state.nonlandPermanentLeftBattlefieldThisTurn || state.spellWarpedThisTurn)
                    source.amount
                else 0
            }
            is CostReductionSource.PermanentsYouControlMatching ->
                countControlledPermanentsMatching(state, playerId, source.filter)
            is CostReductionSource.DifferentlyNamedPermanentsYouControl ->
                countDifferentlyNamedPermanents(state, playerId, source.filter)
            is CostReductionSource.PermanentsOnBattlefieldMatching ->
                countBattlefieldPermanentsMatching(state, playerId, source.filter)
            is CostReductionSource.PermanentsSacrificedThisTurn ->
                state.permanentsSacrificedThisTurn * source.amountPerPermanent
            is CostReductionSource.CreaturesThatAttackedThisTurn ->
                countCreaturesThatAttackedThisTurn(state) * source.amountPerCreature
            is CostReductionSource.CardTypesInYourGraveyard ->
                countGraveyardCardTypes(state, playerId) * source.amountPerType
            is CostReductionSource.SharedCardTypesWithLinkedExile ->
                sharedCardTypesWithLinkedExile(state, abilitySourceId, spellCard) * source.amountPerType
        }
    }

    /**
     * The number of card types (CR 205.2a) the spell being cast shares with the cards exiled with
     * [abilitySourceId] — Cemetery Prowler. Distinct types on both sides, so two exiled creature
     * cards share one type with a creature spell, not two (the card's own ruling).
     *
     * Reads printed type lines: the spell is on the stack and the exiled cards are in exile, and
     * neither is a battlefield permanent whose types a continuous effect could have changed. A
     * spell with no visible card types (a face-down morph, which reaches here with a null
     * [spellCard]) shares nothing and reduces by 0.
     */
    private fun sharedCardTypesWithLinkedExile(
        state: GameState,
        abilitySourceId: EntityId?,
        spellCard: CardDefinition?
    ): Int {
        val spellTypes = spellCard?.typeLine?.cardTypes?.toSet().orEmpty()
        if (spellTypes.isEmpty()) return 0
        val exiledTypes = LinkedExileLookup.exiledCards(state, abilitySourceId)
            .mapNotNull { state.getEntity(it)?.get<CardComponent>()?.typeLine?.cardTypes }
            .flatMapTo(mutableSetOf()) { it }
        return spellTypes.count { it in exiledTypes }
    }

    /**
     * The number of distinct card types (CR 205.2a) among the cards in [playerId]'s graveyard —
     * Emrakul, the Promised End. Supertypes and subtypes never count, and a type shared by several
     * cards counts once, so this is bounded by the number of card types rather than the graveyard's
     * size.
     *
     * The graveyard is not the battlefield, so the printed type line is authoritative and no
     * projection is needed (continuous effects don't change the types of cards in a graveyard).
     * Mirrors `Aggregation.DISTINCT_TYPES` in `DynamicAmountEvaluator`, which backs
     * `Conditions.Delirium` over the same zone.
     */
    private fun countGraveyardCardTypes(state: GameState, playerId: EntityId): Int =
        state.getGraveyard(playerId)
            .mapNotNull { state.getEntity(it)?.get<CardComponent>()?.typeLine?.cardTypes }
            .flatMapTo(mutableSetOf()) { it }
            .size

    /**
     * The number of creatures declared as attackers this turn by any player, across every combat
     * phase. Reads the per-player `PlayerAttackersThisTurnComponent` sets that
     * `AttackPhaseManager` unions at each declare-attackers step, so an attacker that has since
     * died, been exiled, or been bounced still counts — the count is turn history, not a
     * battlefield scan. Cleared with the components at end-of-turn cleanup.
     *
     * A creature can only be declared as an attacker once per combat and the sets are per
     * controller, so no de-duplication across players is needed.
     */
    private fun countCreaturesThatAttackedThisTurn(state: GameState): Int =
        state.turnOrder.sumOf { playerId ->
            state.getEntity(playerId)
                ?.get<PlayerAttackersThisTurnComponent>()
                ?.attackerIds
                ?.size
                ?: 0
        }

    /**
     * Whether a creature died this turn under any player's control. Reads the same per-player
     * `CreaturesDiedThisTurnComponent` tallies that back
     * [com.wingedsheep.sdk.scripting.conditions.CreatureDiedThisTurnCondition] — turn history that
     * `ZoneTransitionService` increments on death and `CleanupPhaseManager` clears at end of turn,
     * so a creature that died and then left the graveyard still counts.
     */
    private fun anyCreatureDiedThisTurn(state: GameState): Boolean =
        state.turnOrder.any { playerId ->
            (state.getEntity(playerId)?.get<CreaturesDiedThisTurnComponent>()?.count ?: 0) > 0
        }

    /**
     * Count permanents the player controls matching the filter. Iterates the projected-control
     * view (`controlledBattlefield`) so control-changing effects are honored, and evaluates the
     * filter through [PredicateEvaluator] against projected state so type/power/subtype checks
     * see buffs, counters, and lords (CR 613). The "you control" analogue of
     * [countBattlefieldPermanentsMatching].
     */
    private fun countControlledPermanentsMatching(
        state: GameState,
        playerId: EntityId,
        filter: GameObjectFilter
    ): Int {
        val projected = state.projectedState
        val context = PredicateContext(controllerId = playerId)
        return state.controlledBattlefield(playerId).count { entityId ->
            predicateEvaluator.matches(state, projected, entityId, filter, context)
        }
    }

    /**
     * Count permanents on the battlefield (across all players) matching the filter.
     * Uses projected state for type/subtype checks to honor continuous effects.
     */
    private fun countBattlefieldPermanentsMatching(
        state: GameState,
        playerId: EntityId,
        filter: GameObjectFilter
    ): Int {
        val projected = state.projectedState
        val context = PredicateContext(controllerId = playerId)
        return state.getBattlefield().count { entityId ->
            predicateEvaluator.matches(state, projected, entityId, filter, context)
        }
    }

    /**
     * Find the greatest value of [property] among permanents the player controls matching a filter.
     * Returns 0 if none match. Power/toughness are read from projected state (CR 613) so counters
     * and continuous buffs count, falling back to the printed base when a permanent has no projected
     * P/T; base power/toughness read the printed base directly; mana value is read from
     * CardDefinition.manaCost.cmc (X-costs contribute X = 0 per Rule 202.3b on the battlefield).
     */
    private fun greatestPropertyAmongMatching(
        state: GameState,
        playerId: EntityId,
        filter: GameObjectFilter,
        property: EntityNumericProperty
    ): Int {
        val projectedState = state.projectedState
        var maxValue = 0
        for (entityId in state.getBattlefield(playerId)) {
            val card = state.getEntity(entityId)?.get<CardComponent>() ?: continue
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
            val matches = filter.cardPredicates.all { predicate ->
                matchesBattlefieldPredicate(entityId, cardDef, predicate, projectedState)
            }
            if (!matches) continue
            val value = numericProperty(projectedState, entityId, card, cardDef, property)
            if (value > maxValue) maxValue = value
        }
        return maxValue
    }

    /**
     * Sum [property] over the permanents the player controls matching a filter — the sum twin of
     * [greatestPropertyAmongMatching] (The Lord of the Eagles: "the total power of creatures you
     * control with flying"). Returns 0 if none match.
     *
     * Iterates the projected-control view and evaluates the filter through [PredicateEvaluator]
     * against projected state, exactly like [countControlledPermanentsMatching], so stolen
     * permanents, granted keywords, and type-changing effects are all honored. Negative power
     * subtracts from the total (Ghalta's 2018-01-19 ruling on the same "total power" wording), and
     * only the finished sum is floored at 0 — a net-negative board reduces nothing rather than
     * taxing the spell.
     */
    private fun totalPropertyAmongMatching(
        state: GameState,
        playerId: EntityId,
        filter: GameObjectFilter,
        property: EntityNumericProperty
    ): Int {
        val projected = state.projectedState
        val context = PredicateContext(controllerId = playerId)
        var total = 0
        for (entityId in state.controlledBattlefield(playerId)) {
            if (!predicateEvaluator.matches(state, projected, entityId, filter, context)) continue
            val card = state.getEntity(entityId)?.get<CardComponent>() ?: continue
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
            total += numericProperty(projected, entityId, card, cardDef, property)
        }
        return total.coerceAtLeast(0)
    }

    /**
     * The [property] of the permanent [abilitySourceId] is attached to — "equipped creature's
     * power" (Glamdring, Foe-hammer).
     *
     * Returns 0 whenever there is nothing to read: no source permanent (a `SelfCast` reduction
     * printed on the spell itself), a source that isn't attached to anything, or an attachment
     * target that has since left the battlefield. An unequipped Equipment reducing costs by 0 is
     * the correct reading of the oracle text, so failing to 0 here is faithful rather than merely
     * defensive.
     *
     * The attachment is read from the source's `AttachedToComponent` — the same seam
     * `Scope.AttachedTo` uses — and the value from projected state, so the equipped creature's
     * counters, anthems, and the Equipment's own P/T bonus are all included.
     */
    private fun attachedPermanentProperty(
        state: GameState,
        abilitySourceId: EntityId?,
        property: EntityNumericProperty
    ): Int {
        val sourceId = abilitySourceId ?: return 0
        val attachedTo = state.getEntity(sourceId)
            ?.get<com.wingedsheep.engine.state.components.battlefield.AttachedToComponent>()
            ?.targetId
            ?: return 0
        val card = state.getEntity(attachedTo)?.get<CardComponent>() ?: return 0
        val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: return 0
        return numericProperty(state.projectedState, attachedTo, card, cardDef, property)
            .coerceAtLeast(0)
    }

    /**
     * The value of a [CostReductionSource.Dynamic] amount, evaluated against the permanent that
     * carries the cost modifier (The Scarlet Witch's "where X is The Scarlet Witch's power").
     *
     * Delegates to [DynamicAmountEvaluator] rather than re-deriving the reads here, so
     * `EntityReference.Source` and the rest of the [DynamicAmount] vocabulary behave exactly as they
     * do everywhere else — power/toughness come from projected state (CR 613: counters, Auras, and
     * anthems on the source count), base P/T and mana value come from the printed card, and counter
     * counts read the source's [CountersComponent].
     *
     * "You" for the amount is the **source's** controller, not the caster: the amount is a property
     * of the permanent the static lives on, and under [SpellCostTarget.AnyCaster] those are
     * different players. Same choice `CastPermissionUtils` makes for `ReduceActivatedAbilityCost`,
     * except that the controller is read from projected state here so a control-change effect is
     * respected. [casterId] is only a fallback for the unreachable case of a source with no
     * projected controller.
     *
     * The result is floored at 0 per CR 107.1b — "if a calculation that would determine the result
     * of an effect yields a negative number, zero is used instead" — so a source shrunk below 0
     * power reduces nothing rather than taxing the spell. Flooring happens *per source*, which is
     * what CR 107.1b describes: each modifier is its own calculation, so one shrunk source can never
     * eat another source's discount.
     *
     * [sourceId] is null only for a self-cast modifier, where there is no source permanent at all
     * (the card is the spell being cast) — that contributes 0.
     */
    private fun dynamicReductionValue(
        state: GameState,
        sourceId: EntityId?,
        casterId: EntityId,
        amount: DynamicAmount
    ): Int {
        if (sourceId == null) return 0
        return dynamicAmountEvaluator.evaluate(
            state,
            amount,
            EffectContext(
                sourceId = sourceId,
                controllerId = state.projectedState.getController(sourceId) ?: casterId,
            ),
        ).coerceAtLeast(0)
    }

    /**
     * One battlefield permanent's value for [property]. Power/toughness read projected state
     * (CR 613) and fall back to the printed base when a permanent has no projected P/T; base
     * power/toughness read the printed base directly; mana value comes from
     * `CardDefinition.manaCost.cmc` (X-costs contribute X = 0 per CR 202.3b on the battlefield).
     */
    private fun numericProperty(
        projectedState: ProjectedState,
        entityId: EntityId,
        card: CardComponent,
        cardDef: CardDefinition,
        property: EntityNumericProperty
    ): Int = when (property) {
        EntityNumericProperty.Power ->
            projectedState.getPower(entityId) ?: baseCharacteristic(card.baseStats?.power)
        EntityNumericProperty.Toughness ->
            projectedState.getToughness(entityId) ?: baseCharacteristic(card.baseStats?.toughness)
        EntityNumericProperty.BasePower -> baseCharacteristic(card.baseStats?.power)
        EntityNumericProperty.BaseToughness -> baseCharacteristic(card.baseStats?.toughness)
        EntityNumericProperty.ManaValue -> cardDef.manaCost.cmc
        else -> 0
    }

    /** Printed base P/T from a [CharacteristicValue] — the fixed value, a CDA's offset, or 0. */
    private fun baseCharacteristic(value: CharacteristicValue?): Int = when (value) {
        is CharacteristicValue.Fixed -> value.value
        is CharacteristicValue.DynamicWithOffset -> value.offset
        else -> 0
    }

    /**
     * Returns true if any creature on the battlefield is currently attacking [playerId]
     * or a planeswalker they control. Reads [AttackingComponent.defenderId] against the
     * caster and their controlled planeswalkers.
     */
    private fun isAnyCreatureAttacking(state: GameState, playerId: EntityId): Boolean {
        val projected = state.projectedState
        val planeswalkersControlled = state.getBattlefield()
            .filter { id ->
                projected.isPlaneswalker(id) && projected.getController(id) == playerId
            }.toSet()
        for (entityId in state.getBattlefield()) {
            val attacking = state.getEntity(entityId)
                ?.get<com.wingedsheep.engine.state.components.combat.AttackingComponent>()
                ?: continue
            if (attacking.defenderId == playerId || attacking.defenderId in planeswalkersControlled) {
                return true
            }
        }
        return false
    }

    /**
     * Calculate the minimum possible cost for affordability gating during legal-action
     * enumeration. For target-conditional reductions, this assumes the reduction WILL apply
     * iff at least one legal target matching the filter currently exists on the battlefield.
     *
     * Used by CastSpellEnumerator so spells like Dire Downdraft show as castable when a
     * discounted target exists, even though the actual cost is locked from chosen targets
     * at cast time.
     */
    fun calculateMinPossibleCost(
        state: GameState,
        cardDef: CardDefinition,
        casterId: EntityId
    ): ManaCost {
        val optimisticTargets = mutableListOf<EntityId>()
        for (ability in cardDef.script.staticAbilities) {
            if (ability !is ModifySpellCost) continue
            if (ability.target != SpellCostTarget.SelfCast) continue
            val src = sourceFromModification(ability.modification)
            if (src is CostReductionSource.FixedIfAnyTargetMatches) {
                val match = findAnyBattlefieldMatch(state, casterId, src.filter)
                if (match != null) optimisticTargets += match
            }
        }
        return calculateEffectiveCost(state, cardDef, casterId, optimisticTargets)
    }

    private fun sourceFromModification(modification: CostModification): CostReductionSource? = when (modification) {
        is CostModification.ReduceGenericBy -> modification.source
        is CostModification.ReduceColoredPerUnit -> modification.countSource
        else -> null
    }

    /**
     * The per-target tax this card levies on its own cast — the mana owed for
     * [chosenTargets] beyond the first by every self-cast [ModifySpellCost] whose count source is
     * [CostReductionSource.ChosenTargetsBeyondTheFirst]. [ManaCost.ZERO] for cards that have none.
     *
     * Split out from [calculateEffectiveCost] because it must be charged **even on a free cast**:
     * "without paying its mana cost" waives the mana cost, not the increases applied to the total
     * cost (CR 601.2f), and Officious Interrogation's 2024-02-02 ruling says so in as many words —
     * "you must still pay the additional cost for any targets beyond the first". The free-cast
     * branches never reach [calculateEffectiveCost] at all, so the cast pipeline adds this on top.
     */
    fun selfPerTargetTax(cardDef: CardDefinition, chosenTargets: List<EntityId>): ManaCost {
        val extraTargets = (chosenTargets.size - 1).coerceAtLeast(0)
        if (extraTargets == 0) return ManaCost.ZERO
        var tax = ManaCost.ZERO
        for (ability in cardDef.script.staticAbilities) {
            if (ability !is ModifySpellCost) continue
            if (ability.target != SpellCostTarget.SelfCast) continue
            val perTarget = perExtraTargetCost(ability.modification) ?: continue
            repeat(extraTargets) { tax = tax + ManaCost.parse(perTarget) }
        }
        return tax
    }

    /**
     * The mana [modification] adds for each target the spell has beyond the first, as a cost
     * string (`"{W}{U}"`, `"{1}"`), or null if it does not price the spell's own chosen targets.
     *
     * The enumerator sends this to the client so the mana-source picker can charge the real price
     * once targets are chosen — the advertised `manaCostString` is priced with no targets and is
     * therefore only the one-target minimum.
     */
    fun perExtraTargetCost(modification: CostModification): String? = when {
        modification is CostModification.IncreaseColoredPerUnit &&
            modification.countSource == CostReductionSource.ChosenTargetsBeyondTheFirst ->
            modification.symbols
        modification is CostModification.IncreaseGenericBy &&
            modification.source == CostReductionSource.ChosenTargetsBeyondTheFirst -> "{1}"
        else -> null
    }

    /**
     * Check whether any of the given targets (which may be in any zone, but typically
     * battlefield permanents) satisfies the filter. Uses projected state.
     */
    private fun anyTargetMatchesFilter(
        state: GameState,
        playerId: EntityId,
        targets: List<EntityId>,
        filter: GameObjectFilter
    ): Boolean {
        val projected = state.projectedState
        val context = PredicateContext(controllerId = playerId)
        return targets.any { entityId ->
            predicateEvaluator.matches(state, projected, entityId, filter, context)
        }
    }

    /**
     * Find any battlefield permanent matching the filter (both players' battlefields).
     * Used by calculateMinPossibleCost to check if a legal discounted target exists.
     */
    private fun findAnyBattlefieldMatch(
        state: GameState,
        playerId: EntityId,
        filter: GameObjectFilter
    ): EntityId? {
        val projected = state.projectedState
        val context = PredicateContext(controllerId = playerId)
        for (entityId in state.getBattlefield()) {
            if (predicateEvaluator.matches(state, projected, entityId, filter, context)) {
                return entityId
            }
        }
        return null
    }

    /**
     * Count creatures controlled by a player.
     */
    private fun countCreatures(state: GameState, playerId: EntityId): Int {
        val projected = state.projectedState
        return state.getBattlefield(playerId).count { entityId -> projected.isCreature(entityId) }
    }

    /**
     * Sum the power of all creatures controlled by a player.
     * Uses projected state if available to account for continuous effects.
     */
    private fun sumPower(state: GameState, playerId: EntityId): Int {
        val projectedState = state.projectedState

        var totalPower = 0
        for (entityId in state.getBattlefield(playerId)) {
            val container = state.getEntity(entityId) ?: continue
            val card = container.get<CardComponent>() ?: continue

            if (!projectedState.isCreature(entityId)) continue

            val basePower: Int = when (val p = card.baseStats?.power) {
                is CharacteristicValue.Fixed -> p.value
                is CharacteristicValue.Dynamic -> 0
                is CharacteristicValue.DynamicWithOffset -> p.offset
                null -> 0
            }
            val projectedPower: Int? = projectedState.getPower(entityId)
            val power: Int = (projectedPower ?: basePower).coerceAtLeast(0)

            totalPower += power
        }
        return totalPower
    }

    /**
     * Count artifacts controlled by a player.
     */
    private fun countArtifacts(state: GameState, playerId: EntityId): Int {
        return state.getBattlefield(playerId).count { entityId ->
            val card = state.getEntity(entityId)?.get<CardComponent>()
            card?.typeLine?.isArtifact == true
        }
    }

    /**
     * Check if a player controls any permanent matching a GameObjectFilter.
     * Uses projected state for type/subtype matching to account for continuous effects.
     */
    private fun controlsMatchingPermanent(state: GameState, playerId: EntityId, filter: GameObjectFilter): Boolean {
        val projectedState = state.projectedState
        return state.getBattlefield(playerId).any { entityId ->
            val card = state.getEntity(entityId)?.get<CardComponent>() ?: return@any false
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: return@any false
            filter.cardPredicates.all { predicate ->
                matchesBattlefieldPredicate(entityId, cardDef, predicate, projectedState)
            }
        }
    }

    /**
     * Count cards in a player's graveyard that match a filter.
     * Graveyard cards use base state (no continuous effects apply in graveyard).
     */
    private fun countGraveyardCardsMatchingFilter(state: GameState, playerId: EntityId, filter: GameObjectFilter): Int {
        return state.getGraveyard(playerId).count { entityId ->
            val card = state.getEntity(entityId)?.get<CardComponent>() ?: return@count false
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: return@count false
            filter.cardPredicates.all { predicate ->
                matchesGraveyardPredicate(cardDef, predicate)
            }
        }
    }

    /**
     * Count cards in a player's exile that match a filter.
     * Exile cards use base state (no continuous effects apply in exile).
     */
    private fun countExileCardsMatchingFilter(state: GameState, playerId: EntityId, filter: GameObjectFilter): Int {
        return state.getExile(playerId).count { entityId ->
            val card = state.getEntity(entityId)?.get<CardComponent>() ?: return@count false
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: return@count false
            filter.cardPredicates.all { predicate ->
                matchesGraveyardPredicate(cardDef, predicate)
            }
        }
    }

    /**
     * Match a graveyard card against a card predicate using base state.
     */
    private fun matchesGraveyardPredicate(
        cardDef: CardDefinition,
        predicate: CardPredicate
    ): Boolean {
        return when (predicate) {
            is CardPredicate.IsCreature -> cardDef.typeLine.isCreature
            is CardPredicate.IsArtifact -> cardDef.typeLine.isArtifact
            is CardPredicate.IsEnchantment -> cardDef.typeLine.isEnchantment
            is CardPredicate.IsLand -> cardDef.typeLine.isLand
            is CardPredicate.IsInstant -> cardDef.typeLine.isInstant
            is CardPredicate.IsSorcery -> cardDef.typeLine.isSorcery
            is CardPredicate.IsPermanent -> cardDef.typeLine.isPermanent
            is CardPredicate.HasSubtype -> predicate.subtype in cardDef.typeLine.subtypes
            is CardPredicate.Or -> predicate.predicates.any { matchesGraveyardPredicate(cardDef, it) }
            is CardPredicate.And -> predicate.predicates.all { matchesGraveyardPredicate(cardDef, it) }
            is CardPredicate.Not -> !matchesGraveyardPredicate(cardDef, predicate.predicate)
            else -> false
        }
    }

    /**
     * Match a battlefield permanent against a card predicate.
     * Uses projected state when available for type/subtype checks.
     */
    private fun matchesBattlefieldPredicate(
        entityId: EntityId,
        cardDef: CardDefinition,
        predicate: CardPredicate,
        projectedState: com.wingedsheep.engine.mechanics.layers.ProjectedState?
    ): Boolean {
        return when (predicate) {
            is CardPredicate.IsCreature -> projectedState?.isCreature(entityId) ?: cardDef.typeLine.isCreature
            is CardPredicate.IsArtifact -> projectedState?.hasType(entityId, "ARTIFACT") ?: cardDef.typeLine.isArtifact
            is CardPredicate.IsEnchantment -> projectedState?.hasType(entityId, "ENCHANTMENT") ?: cardDef.typeLine.isEnchantment
            is CardPredicate.IsLand -> projectedState?.hasType(entityId, "LAND") ?: cardDef.typeLine.isLand
            is CardPredicate.IsPermanent -> cardDef.typeLine.isPermanent
            is CardPredicate.HasSubtype -> projectedState?.hasSubtype(entityId, predicate.subtype.value) ?: (predicate.subtype in cardDef.typeLine.subtypes)
            else -> false
        }
    }

    /**
     * Count permanents matching a filter that have a specific counter type.
     * Uses projected state for type/subtype checks.
     */
    private fun countPermanentsWithCounter(
        state: GameState,
        playerId: EntityId,
        filter: GameObjectFilter,
        counterType: String
    ): Int {
        val projectedState = state.projectedState
        val ct = CounterType.entries.find { it.name.equals(counterType, ignoreCase = true) }
            ?: return 0
        return state.getBattlefield(playerId).count { entityId ->
            val container = state.getEntity(entityId) ?: return@count false
            val card = container.get<CardComponent>() ?: return@count false
            val counters = container.get<CountersComponent>()
            if ((counters?.getCount(ct) ?: 0) <= 0) return@count false
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: return@count false
            filter.cardPredicates.all { predicate ->
                matchesBattlefieldPredicate(entityId, cardDef, predicate, projectedState)
            }
        }
    }

    /**
     * Count unique colors among permanents controlled by a player.
     * Used for Vivid cost reduction.
     *
     * Uses projected state for both controller and color so that:
     * - Control-changing effects (Mind Control, Threaten) are honored — the rule reads
     *   "permanents you control", which is the projected controller (CR 613.1c).
     * - Color-changing effects (Foraging Wickermaw's "becomes that color until end of turn",
     *   Painter's Servant, Moonlace, etc.) contribute their granted colors, since the rule
     *   reads "colors among permanents".
     */
    private fun countColors(state: GameState, playerId: EntityId): Int {
        val projected = state.projectedState
        val colors = mutableSetOf<String>()

        state.controlledBattlefield(playerId).forEach { entityId ->
            colors.addAll(projected.getColors(entityId))
        }

        return colors.size
    }

    private fun countDifferentlyNamedPermanents(
        state: GameState,
        playerId: EntityId,
        filter: GameObjectFilter
    ): Int {
        val projectedState = state.projectedState
        val names = mutableSetOf<String>()
        for (entityId in state.getBattlefield(playerId)) {
            val card = state.getEntity(entityId)?.get<CardComponent>() ?: continue
            val cardDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
            val matches = filter.cardPredicates.all { predicate ->
                matchesBattlefieldPredicate(entityId, cardDef, predicate, projectedState)
            }
            if (matches) names.add(card.name)
        }
        return names.size
    }

    /**
     * Count permanents of a specific card type controlled by a player.
     * Used for Affinity keyword.
     * Uses projected state for both controller and type (respects control-changing and type-changing effects).
     */
    private fun countPermanentsOfType(state: GameState, playerId: EntityId, cardType: CardType): Int {
        val projected = state.projectedState
        return state.controlledBattlefield(playerId).count { entityId ->
            projected.hasType(entityId, cardType.name)
        }
    }

    /**
     * Count permanents with a specific subtype controlled by a player.
     * Used for Affinity for subtypes (e.g., "Affinity for Lizards").
     * Uses projected state for both controller and subtype (respects control-changing and type-changing effects).
     */
    private fun countPermanentsWithSubtype(state: GameState, playerId: EntityId, subtype: Subtype): Int {
        val projected = state.projectedState
        return state.controlledBattlefield(playerId).count { entityId ->
            projected.hasSubtype(entityId, subtype.value)
        }
    }

    /**
     * Add specific colored mana symbols to a mana cost (colored tax effect).
     * Each symbol in [symbolsToAdd] appends one matching colored pip. Does not affect generic mana.
     */
    private fun increaseColoredCost(cost: ManaCost, symbolsToAdd: List<ManaSymbol>): ManaCost {
        if (symbolsToAdd.isEmpty()) return cost
        return ManaCost(cost.symbols + symbolsToAdd)
    }

    /**
     * Remove specific colored mana symbols from a mana cost.
     * Each symbol in symbolsToRemove removes at most one matching colored symbol from the cost.
     * Does not affect generic mana.
     */
    private fun reduceColoredCost(cost: ManaCost, symbolsToRemove: List<ManaSymbol>): ManaCost {
        val remainingSymbols = cost.symbols.toMutableList()

        for (symbolToRemove in symbolsToRemove) {
            val index = remainingSymbols.indexOfFirst { it == symbolToRemove }
            if (index >= 0) {
                remainingSymbols.removeAt(index)
            }
        }

        return ManaCost(remainingSymbols)
    }

    /**
     * Remove colored mana symbols from a cost, with overflow to generic reduction.
     * First removes matching colored symbols; excess that can't match reduces generic mana.
     * Used for Eluge: "{U} less for each flood-counter land" — if more {U} reductions
     * than blue pips, excess reduces generic cost.
     */
    private fun reduceColoredCostWithOverflow(cost: ManaCost, symbolsToRemove: List<ManaSymbol>): ManaCost {
        val remainingSymbols = cost.symbols.toMutableList()
        var overflowReduction = 0

        for (symbolToRemove in symbolsToRemove) {
            val index = remainingSymbols.indexOfFirst { it == symbolToRemove }
            if (index >= 0) {
                remainingSymbols.removeAt(index)
            } else {
                overflowReduction++
            }
        }

        val result = ManaCost(remainingSymbols)
        return if (overflowReduction > 0) reduceGenericCost(result, overflowReduction) else result
    }

    /**
     * Match a CardDefinition against a GameObjectFilter's card predicates.
     * Only evaluates card predicates (type, subtype, color, mana value, etc.)
     * since state and controller predicates don't apply to spells being cast.
     *
     * @param sourceEntityId The entity providing the cost reduction (for source-relative predicates)
     * @param state The current game state (for source-relative predicates)
     * @param projectedState The projected state (for source-relative predicates using projected types)
     */
    private fun matchesCardDefinition(
        cardDef: CardDefinition,
        filter: GameObjectFilter,
        sourceEntityId: EntityId? = null,
        state: GameState? = null,
        projectedState: com.wingedsheep.engine.mechanics.layers.ProjectedState? = null
    ): Boolean {
        if (filter.cardPredicates.isEmpty() && filter.anyOf.isEmpty()) return true
        // Conjunction over card predicates; OR lives inside a CardPredicate.Or.
        if (!filter.cardPredicates.all { matchesCardPredicate(cardDef, it, sourceEntityId, state, projectedState) }) return false
        // Recursive union (`or` infix): match if any branch matches.
        if (filter.anyOf.isNotEmpty()) {
            return filter.anyOf.any { matchesCardDefinition(cardDef, it, sourceEntityId, state, projectedState) }
        }
        return true
    }

    private fun matchesCardPredicate(
        cardDef: CardDefinition,
        predicate: CardPredicate,
        sourceEntityId: EntityId? = null,
        state: GameState? = null,
        projectedState: com.wingedsheep.engine.mechanics.layers.ProjectedState? = null
    ): Boolean {
        val typeLine = cardDef.typeLine
        return when (predicate) {
            CardPredicate.IsCreature -> typeLine.isCreature
            CardPredicate.IsLand -> typeLine.isLand
            CardPredicate.IsArtifact -> typeLine.isArtifact
            CardPredicate.IsEnchantment -> typeLine.isEnchantment
            CardPredicate.IsPlaneswalker -> CardType.PLANESWALKER in typeLine.cardTypes
            CardPredicate.IsInstant -> typeLine.isInstant
            CardPredicate.IsSorcery -> typeLine.isSorcery
            CardPredicate.HasAdventure -> cardDef.isAdventure
            CardPredicate.IsDoubleFaced -> cardDef.isDoubleFaced
            CardPredicate.HasNoAbilities -> cardDef.oracleText.isBlank()
            // Cost calculation has no resolution-time chosenValues. This predicate is only
            // meaningful inside effect pipelines (e.g. Winding Way), so fail closed here.
            is CardPredicate.HasCardTypeFromVariable -> false
            CardPredicate.IsBasicLand -> typeLine.isBasicLand
            CardPredicate.IsPermanent -> typeLine.isPermanent
            CardPredicate.IsNonland -> !typeLine.isLand
            CardPredicate.IsNoncreature -> !typeLine.isCreature
            CardPredicate.IsNonenchantment -> !typeLine.isEnchantment
            CardPredicate.IsNonartifact -> !typeLine.isArtifact
            CardPredicate.IsToken -> false
            CardPredicate.IsNontoken -> true
            CardPredicate.IsLegendary -> typeLine.isLegendary
            CardPredicate.IsNonlegendary -> !typeLine.isLegendary
            CardPredicate.HasNonManaActivatedAbility -> cardDef.hasNonManaActivatedAbility
            CardPredicate.HasActivatedAbility -> cardDef.hasActivatedAbility

            is CardPredicate.HasColor -> predicate.color in cardDef.colors
            is CardPredicate.NotColor -> predicate.color !in cardDef.colors
            // CostCalculator has no resolution-time chosen color; no static answer here.
            CardPredicate.HasChosenColor -> false
            CardPredicate.IsColorless -> cardDef.colors.isEmpty()
            CardPredicate.IsColored -> cardDef.colors.isNotEmpty()
            CardPredicate.IsMulticolored -> cardDef.colors.size > 1
            CardPredicate.IsMonocolored -> cardDef.colors.size == 1

            is CardPredicate.HasSubtype -> typeLine.hasSubtype(predicate.subtype)
            is CardPredicate.NotSubtype -> !typeLine.hasSubtype(predicate.subtype)
            is CardPredicate.HasAnyOfSubtypes -> predicate.subtypes.any { typeLine.hasSubtype(it) }
            is CardPredicate.HasBasicLandType -> typeLine.hasSubtype(Subtype(predicate.landType))
            is CardPredicate.NameEquals -> cardDef.name == predicate.name
            // Room-name distinctness is a resolution-time search filter, not a cost concern.
            CardPredicate.NameNotSharedWithControlledRoom -> false
            CardPredicate.NameNotSharedWithControlledToken -> false
            // Same for "no other permanent you control shares this name" — a targeting
            // restriction, never a cost-reduction condition.
            CardPredicate.NameNotSharedWithAnotherControlledPermanent -> false

            is CardPredicate.OriginallyPrintedInSet ->
                cardDef.setCode?.equals(predicate.setCode, ignoreCase = true) == true

            is CardPredicate.HasKeyword -> predicate.keyword in cardDef.keywords
            is CardPredicate.NotKeyword -> predicate.keyword !in cardDef.keywords

            is CardPredicate.ManaValueEquals -> cardDef.manaCost.cmc == predicate.value
            is CardPredicate.ManaValueAtMost -> cardDef.manaCost.cmc <= predicate.max
            // CostCalculator has no chosen-number context; predicate has no static answer here.
            CardPredicate.ManaValueAtMostX -> false
            CardPredicate.ManaValueEqualsX -> false
            is CardPredicate.ManaValueAtLeast -> cardDef.manaCost.cmc >= predicate.min
            // CostCalculator has no entity context; predicate has no static answer here.
            is CardPredicate.ManaValueAtMostEntity -> false
            is CardPredicate.ManaValueAtMostEntityManaSpent -> false
            is CardPredicate.ManaValueAtMostColorsSpent -> false
            is CardPredicate.ManaValueAtMostDynamic -> false
        is CardPredicate.ManaValueEqualsDynamic -> false
        is CardPredicate.PowerEqualsDynamic -> false
        is CardPredicate.ToughnessEqualsDynamic -> false
            is CardPredicate.PowerGreaterThanEntity -> false
            is CardPredicate.PowerAtMostEntity -> false
            is CardPredicate.PowerLessThanEntity -> false
            // A printed card's power never exceeds its own base power statically (they're equal).
            CardPredicate.PowerGreaterThanBase -> false
            CardPredicate.ManaValueIsEven -> cardDef.manaCost.cmc % 2 == 0
            CardPredicate.ManaValueIsOdd -> cardDef.manaCost.cmc % 2 != 0
            CardPredicate.HasXInManaCost -> cardDef.manaCost.hasX
            is CardPredicate.ColoredManaSymbolsAtLeast ->
                cardDef.manaCost.coloredSymbolCount(predicate.colors.toSet()) >= predicate.min

            is CardPredicate.PowerEquals -> cardDef.creatureStats?.basePower == predicate.value
            // CostCalculator has no X context; predicate has no static answer here.
            CardPredicate.PowerEqualsX -> false
            is CardPredicate.PowerAtMost -> (cardDef.creatureStats?.basePower ?: 0) <= predicate.max
            is CardPredicate.PowerAtLeast -> (cardDef.creatureStats?.basePower ?: 0) >= predicate.min
            // CostCalculator has no X context; predicate has no static answer here.
            CardPredicate.PowerAtLeastX -> false
            is CardPredicate.ToughnessEquals -> cardDef.creatureStats?.baseToughness == predicate.value
            is CardPredicate.ToughnessAtMost -> (cardDef.creatureStats?.baseToughness ?: 0) <= predicate.max
            // CostCalculator has no X context; predicate has no static answer here.
            CardPredicate.ToughnessAtMostX -> false
            is CardPredicate.ToughnessAtLeast -> (cardDef.creatureStats?.baseToughness ?: 0) >= predicate.min
            is CardPredicate.PowerOrToughnessAtLeast -> {
                val power = cardDef.creatureStats?.basePower ?: 0
                val toughness = cardDef.creatureStats?.baseToughness ?: 0
                power >= predicate.min || toughness >= predicate.min
            }
            is CardPredicate.PowerOrToughnessAtMost -> {
                val power = cardDef.creatureStats?.basePower ?: 0
                val toughness = cardDef.creatureStats?.baseToughness ?: 0
                power <= predicate.max || toughness <= predicate.max
            }
            is CardPredicate.TotalPowerAndToughnessAtMost -> {
                val power = cardDef.creatureStats?.basePower ?: 0
                val toughness = cardDef.creatureStats?.baseToughness ?: 0
                (power + toughness) <= predicate.max
            }
            CardPredicate.ToughnessGreaterThanPower -> {
                val power = cardDef.creatureStats?.basePower ?: 0
                val toughness = cardDef.creatureStats?.baseToughness ?: 0
                toughness > power
            }

            CardPredicate.NotOfSourceChosenType -> true

            CardPredicate.SharesCreatureTypeWithSource -> {
                if (sourceEntityId == null) return true
                val spellSubtypes = cardDef.typeLine.subtypes
                if (spellSubtypes.isEmpty()) return false
                val sourceSubtypes = if (projectedState != null) {
                    projectedState.getSubtypes(sourceEntityId)
                } else {
                    val card = state?.getEntity(sourceEntityId)?.get<CardComponent>()
                    card?.typeLine?.subtypes?.map { it.value }?.toSet() ?: emptySet()
                }
                spellSubtypes.any { spellSubtype ->
                    sourceSubtypes.any { it.equals(spellSubtype.value, ignoreCase = true) }
                }
            }

            CardPredicate.SharesCreatureTypeWithTriggeringEntity -> true
            CardPredicate.HasChosenSubtype -> {
                if (sourceEntityId == null || state == null) return false
                val chosenType = state.getEntity(sourceEntityId)
                    ?.chosenCreatureType()
                    ?: return false
                val spellSubtypes = cardDef.typeLine.subtypes.map { it.value }
                spellSubtypes.any { it.equals(chosenType, ignoreCase = true) } ||
                    (com.wingedsheep.sdk.core.Keyword.CHANGELING in cardDef.keywords &&
                        chosenType in Subtype.ALL_CREATURE_TYPES)
            }
            is CardPredicate.SharesCreatureTypeWith -> true
            is CardPredicate.SharesCardTypeWith -> true
            CardPredicate.SharesCardTypeWithLinkedExile -> true
            CardPredicate.SharesNameWithLinkedExile -> true
            is CardPredicate.SharesColorWith -> true
            is CardPredicate.SharesManaValueWith -> true
            is CardPredicate.SharesNameWith -> true
            is CardPredicate.SharesColorWithPermanentYouControl -> true
            is CardPredicate.SharesNameWithPermanentYouControl -> true
            is CardPredicate.DoesNotShareCreatureTypeWithPermanentYouControl -> true
            is CardPredicate.DoesNotShareLandTypeWithPermanentYouControl -> true
            CardPredicate.SharesColorWithRecipient -> false
            CardPredicate.SharesChosenColorWithSource -> {
                if (sourceEntityId == null || state == null) return false
                val chosenColor = state.getEntity(sourceEntityId)
                    ?.chosenColor()
                    ?: return false
                cardDef.colors.contains(chosenColor)
            }

            is CardPredicate.HasSubtypeFromVariable -> true
            is CardPredicate.HasSubtypeInStoredList -> true
            is CardPredicate.HasSubtypeInEachStoredGroup -> true
            is CardPredicate.NameEqualsChosen -> true
            is CardPredicate.NameEqualsChosenComponent -> {
                if (sourceEntityId == null || state == null) return false
                val chosenName = (state.getEntity(sourceEntityId)
                    ?.get<CastChoicesComponent>()?.chosen?.get(predicate.slot)
                    as? ChoiceValue.TextChoice)?.text ?: return false
                cardDef.name.equals(chosenName, ignoreCase = true)
            }
            is CardPredicate.CardTypeEqualsChosenComponent -> {
                if (sourceEntityId == null || state == null) return false
                val chosenType = (state.getEntity(sourceEntityId)
                    ?.get<CastChoicesComponent>()?.chosen?.get(predicate.slot)
                    as? ChoiceValue.TextChoice)?.text ?: return false
                cardDef.typeLine.cardTypes.any { it.displayName.equals(chosenType, ignoreCase = true) }
            }

            is CardPredicate.And -> predicate.predicates.all { matchesCardPredicate(cardDef, it, sourceEntityId, state, projectedState) }
            is CardPredicate.Or -> predicate.predicates.any { matchesCardPredicate(cardDef, it, sourceEntityId, state, projectedState) }
            is CardPredicate.Not -> !matchesCardPredicate(cardDef, predicate.predicate, sourceEntityId, state, projectedState)

            CardPredicate.IsActivatedOrTriggeredAbility -> false
            CardPredicate.IsTriggeredAbility -> false
            CardPredicate.IsActivatedAbility -> false
            is CardPredicate.TargetsMatching -> false
            is CardPredicate.AbilitySourceMatches -> false
        }
    }

    /**
     * Reduce the generic mana cost by the specified amount.
     * Never reduces below 0 generic mana. Colored costs are preserved.
     */
    private fun reduceGenericCost(cost: ManaCost, reduction: Int): ManaCost {
        return cost.reduceGeneric(reduction)
    }

    /**
     * Calculate the effective cost of casting a face-down creature spell (morph).
     * The base cost is {3}, reduced by any [ModifySpellCost] with target
     * [SpellCostTarget.FaceDownYouCast] on permanents the caster controls.
     */
    fun calculateFaceDownCost(state: GameState, casterId: EntityId): ManaCost {
        val baseMorphCost = ManaCost.parse("{3}")
        var totalReduction = 0

        for ((sourceId, ability) in scanBattlefieldModifySpellCost(state)) {
            if (ability.target != SpellCostTarget.FaceDownYouCast) continue
            if (state.projectedState.getController(sourceId) != casterId) continue
            when (val mod = ability.modification) {
                is CostModification.ReduceGeneric -> totalReduction += mod.amount
                is CostModification.ReduceGenericBy ->
                    totalReduction += evaluateReduction(
                        state, mod.source, casterId, abilitySourceId = sourceId
                    )
                else -> { /* face-down only supports generic reduction */ }
            }
        }

        return reduceGenericCost(baseMorphCost, totalReduction)
    }

    /**
     * Calculate the total morph cost increase from all [ModifySpellCost] abilities
     * on the battlefield with target [SpellCostTarget.MorphActivation]. This affects
     * all players globally (turn-face-up activated cost).
     */
    fun calculateMorphCostIncrease(state: GameState): Int {
        var totalIncrease = 0
        for ((_, ability) in scanBattlefieldModifySpellCost(state)) {
            if (ability.target != SpellCostTarget.MorphActivation) continue
            when (val mod = ability.modification) {
                is CostModification.IncreaseGeneric -> totalIncrease += mod.amount
                else -> { /* morph-activation only supports generic increase */ }
            }
        }
        return totalIncrease
    }

    /**
     * The mana a player actually pays to turn a face-down permanent face up: the procedure's
     * printed cost, plus every global [SpellCostTarget.MorphActivation] increase
     * ([calculateMorphCostIncrease] — Exiled Doomsayer), minus the procedure's own self-scoped
     * reduction (Fugitive Codebreaker's "reduced by {1} for each instant and sorcery card in your
     * graveyard").
     *
     * Increases before reductions, per CR 601.2f, which the special action follows the same way a
     * spell does. Both adjustments are generic-only, so the colored pips of a disguise cost always
     * survive.
     *
     * The three sites that price a turn-up — enumeration, action validation, and payment — all go
     * through here, so an enumerated price can never disagree with the one charged.
     *
     * @param printedCost the procedure's mana cost as printed
     * @param reduction the procedure's [TurnUpProcedure.costReduction], or null for the ordinary
     *   morph/disguise/manifest shape
     * @param controllerId the player taking the special action — whose graveyard, permanents, and
     *   speed the reduction reads
     * @param permanentId the face-down permanent, passed as the reduction's ability source
     */
    fun calculateTurnFaceUpCost(
        state: GameState,
        printedCost: ManaCost,
        reduction: CostReductionSource?,
        controllerId: EntityId,
        permanentId: EntityId
    ): ManaCost {
        val increased = increaseGenericCost(printedCost, calculateMorphCostIncrease(state))
        if (reduction == null) return increased
        return reduceGenericCost(
            increased,
            evaluateReduction(state, reduction, controllerId, abilitySourceId = permanentId)
        )
    }

    /**
     * Apply a generic mana increase to an existing ManaCost.
     * Used to increase morph costs by adding generic mana.
     */
    fun increaseGenericCost(cost: ManaCost, increase: Int): ManaCost {
        if (increase <= 0) return cost

        val coloredSymbols = cost.symbols.filter { it !is ManaSymbol.Generic }
        val currentGeneric = cost.genericAmount
        val newGeneric = currentGeneric + increase

        val newSymbols = if (newGeneric > 0) {
            listOf(ManaSymbol.Generic(newGeneric)) + coloredSymbols
        } else {
            coloredSymbols
        }

        return ManaCost(newSymbols)
    }

    /**
     * One battlefield-granted alternative casting cost, both halves.
     *
     * [manaCost] is what replaces the spell's mana cost (Jodah's `{W}{U}{B}{R}{G}`); it is `{0}`
     * when the substituted cost is entirely non-mana. [additionalCosts] is the non-mana half
     * (Conspiracy Unraveler's "collect evidence 10") and is paid alongside it — the two halves are
     * one cost, so a caller must never take the mana half without the additional half.
     */
    data class AlternativeCastingCostGrant(
        val manaCost: ManaCost,
        val additionalCosts: List<AdditionalCost> = emptyList()
    )

    /**
     * Find alternative casting costs available to the caster from battlefield permanents.
     * Scans permanents controlled by the caster for GrantAlternativeCastingCost abilities.
     *
     * @return List of alternative cost grants available (may be empty)
     */
    fun findAlternativeCastingCosts(state: GameState, casterId: EntityId): List<AlternativeCastingCostGrant> {
        val costs = mutableListOf<AlternativeCastingCostGrant>()
        for (entityId in state.getBattlefield(casterId)) {
            val container = state.getEntity(entityId) ?: continue
            val card = container.get<CardComponent>() ?: continue
            val permanentDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
            val classLevel = container.get<ClassLevelComponent>()?.currentLevel

            for (ability in permanentDef.script.effectiveStaticAbilities(classLevel)) {
                if (ability is GrantAlternativeCastingCost) {
                    costs.add(
                        AlternativeCastingCostGrant(
                            manaCost = ManaCost.parse(ability.cost),
                            additionalCosts = ability.additionalCosts
                        )
                    )
                }
            }
        }
        return costs
    }

    /**
     * Whether any battlefield permanent is currently granting [casterId] a
     * [MayCastWithoutPayingManaCost] permission whose gates are all open
     * (e.g. Weftwalking's `firstSpellOfTurnOnly = true`).
     *
     * Gates honored per source:
     *  - `controllerOnly` — when true, the source's controller (read from projected state) must
     *    be [casterId].
     *  - `firstSpellOfTurnOnly` — when true, [casterId] must be the active player and must have
     *    cast no spells yet this turn.
     *
     * Scans every battlefield zone (not just the caster's) so that an opponent's source can
     * still grant the caster their free cast when the source's wording doesn't require
     * controller-only.
     */
    fun hasFreeCastPermission(
        state: GameState,
        casterId: EntityId,
        spellCardDef: CardDefinition? = null,
        castFromZone: com.wingedsheep.sdk.core.Zone? = null
    ): Boolean {
        // A state-held "the next matching spell you cast this turn can be cast without paying its
        // mana cost" rider (World War Hulk I) is checked first: it isn't tied to a battlefield
        // source and isn't restricted to a cast zone, so none of the per-source gates below apply.
        if (hasFreeCastRider(state, casterId, spellCardDef)) return true
        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val card = container.get<CardComponent>() ?: continue
            val permanentDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
            // Fold in unlocked Room-face statics (CR 709.5) so a face-level Warped Space is seen.
            for (ability in com.wingedsheep.engine.state.components.identity.RoomFaceStatics.activeStaticAbilities(container, permanentDef)) {
                if (ability !is MayCastWithoutPayingManaCost) continue
                // `fromExileOnly` (Warped Space) frees only spells cast from exile. When the cast
                // zone is unknown (a coarse "any free-cast source?" probe), such a source doesn't
                // count toward a hand cast — require an explicit EXILE zone.
                if (ability.fromExileOnly && castFromZone != com.wingedsheep.sdk.core.Zone.EXILE) continue
                if (ability.controllerOnly) {
                    val controllerId = state.projectedState.getController(entityId) ?: continue
                    if (controllerId != casterId) continue
                }
                if (ability.firstSpellOfTurnOnly) {
                    if (!state.isActiveTurnFor(casterId)) continue
                    if ((state.playerSpellsCastThisTurn[casterId] ?: 0) > 0) continue
                }
                // `oncePerTurn` (Zaffai and the Tempests): only during the caster's own turn, and
                // only while this specific source hasn't already been used this turn.
                if (ability.oncePerTurn) {
                    if (!state.isActiveTurnFor(casterId)) continue
                    if (container.has<com.wingedsheep.engine.state.components.battlefield.MayCastWithoutPayingCostUsedThisTurnComponent>()) continue
                }
                // The permission may be scoped to a spell type (e.g. Dracogenesis — Dragons only).
                // When the caller knows the spell being cast, enforce the filter; with no spell in
                // hand (a generic "does any free-cast source exist?" probe) a filtered source still
                // counts, since some castable spell may match.
                if (spellCardDef != null && ability.spellFilter != GameObjectFilter.Any &&
                    !matchesCardDefinition(spellCardDef, ability.spellFilter, entityId, state, state.projectedState)
                ) continue
                return true
            }
        }
        return hasEmblemFreeCastPermission(state, casterId, spellCardDef, castFromZone)
    }

    /**
     * The pending-rider half of [hasFreeCastPermission]: a
     * [com.wingedsheep.engine.state.PendingFreeCastSpell] installed by
     * [com.wingedsheep.sdk.scripting.effects.GrantNextSpellFreeCastEffect] (World War Hulk I).
     *
     * The rider's own `sourceId` goes in as the predicate source so source-relative predicates
     * ("shares a creature type with this permanent") resolve against the permanent that installed
     * it, matching how [com.wingedsheep.engine.handlers.actions.spell.CastSpellHandler] evaluates
     * the same filter when it consumes the rider. With no spell in hand (the coarse "does any
     * free-cast permission exist?" probe) a filtered rider still counts, exactly as a filtered
     * battlefield source does.
     *
     * **What "matching" means differs by characteristic source between the two sites.** Here the
     * filter is evaluated against the [CardDefinition] — *printed* types/colors/keywords, with no
     * continuous effects applied. The consumption site evaluates the same filter against the spell
     * *entity* through `PredicateEvaluator`, which prefers projected values and falls back to base
     * when the entity has no projection entry. Today they always agree, because objects on the
     * stack have no projection entry; if that ever changes (or a Painter's-Servant-style colour
     * effect reaches hand/stack), a card whose printed characteristics match but whose actual ones
     * don't would be *offered* the free cast here and would *not* spend the rider there. Widening
     * this to projected characteristics is the fix if that day comes — the asymmetry is recorded
     * rather than papered over.
     */
    private fun hasFreeCastRider(
        state: GameState,
        casterId: EntityId,
        spellCardDef: CardDefinition?
    ): Boolean = state.pendingFreeCastSpells.any { rider ->
        rider.controllerId == casterId &&
            (
                spellCardDef == null ||
                    rider.spellFilter == GameObjectFilter.Any ||
                    matchesCardDefinition(
                        spellCardDef,
                        rider.spellFilter,
                        rider.sourceId,
                        state,
                        state.projectedState
                    )
            )
    }

    /**
     * The emblem half of [hasFreeCastPermission] (Tamiyo, Field Researcher's −7). Emblems are
     * synthetic entities that live outside every zone, so the battlefield scan can't see them;
     * their statics are read from
     * [com.wingedsheep.engine.state.components.identity.EmblemStaticAbilityComponent] instead.
     *
     * The `firstSpellOfTurnOnly` / `oncePerTurn` gates are deliberately not honored here: those key
     * off a *battlefield source* being marked used, and no emblem prints them. An emblem carrying
     * one would silently grant an unlimited permission, so it is rejected outright rather than
     * approximated.
     */
    private fun hasEmblemFreeCastPermission(
        state: GameState,
        casterId: EntityId,
        spellCardDef: CardDefinition?,
        castFromZone: com.wingedsheep.sdk.core.Zone?
    ): Boolean {
        for ((entityId, container) in state.entities) {
            val statics = container
                .get<com.wingedsheep.engine.state.components.identity.EmblemStaticAbilityComponent>()
                ?: continue
            val emblemController = container
                .get<com.wingedsheep.engine.state.components.identity.ControllerComponent>()
                ?.playerId
            for (ability in statics.abilities) {
                if (ability !is MayCastWithoutPayingManaCost) continue
                if (ability.firstSpellOfTurnOnly || ability.oncePerTurn) continue
                if (ability.fromExileOnly && castFromZone != com.wingedsheep.sdk.core.Zone.EXILE) continue
                if (ability.controllerOnly && emblemController != casterId) continue
                if (spellCardDef != null && ability.spellFilter != GameObjectFilter.Any &&
                    !matchesCardDefinition(spellCardDef, ability.spellFilter, entityId, state, state.projectedState)
                ) continue
                return true
            }
        }
        return false
    }

    /**
     * After a successful free cast via [MayCastWithoutPayingManaCost], returns the battlefield
     * source whose `oncePerTurn` permission should be marked used — or null when an unlimited
     * (non-`oncePerTurn`) source for [casterId] already grants this cast, so no once-per-turn use
     * is consumed. With several once-per-turn sources, returns the first eligible one. Errs toward
     * preserving the player's once-per-turn use whenever an unlimited source could have paid.
     */
    fun oncePerTurnFreeCastSourceToConsume(
        state: GameState,
        casterId: EntityId,
        spellCardDef: CardDefinition?,
        castFromZone: com.wingedsheep.sdk.core.Zone? = null
    ): EntityId? {
        // An emblem's permission is always unlimited, so it covers this cast on its own and no
        // battlefield once-per-turn use should be consumed.
        if (hasEmblemFreeCastPermission(state, casterId, spellCardDef, castFromZone)) return null
        // Same for a pending "next spell you cast" rider — it pays for this cast and is itself
        // consumed by the cast, so a Zaffai-style once-per-turn use must not be burned as well.
        if (hasFreeCastRider(state, casterId, spellCardDef)) return null
        var oncePerTurnCandidate: EntityId? = null
        for (entityId in state.getBattlefield()) {
            val container = state.getEntity(entityId) ?: continue
            val card = container.get<CardComponent>() ?: continue
            val permanentDef = cardRegistry.getCard(card.cardDefinitionId) ?: continue
            // Fold in unlocked Room-face statics (CR 709.5) so a face-level Warped Space is seen.
            for (ability in com.wingedsheep.engine.state.components.identity.RoomFaceStatics.activeStaticAbilities(container, permanentDef)) {
                if (ability !is MayCastWithoutPayingManaCost) continue
                // A `fromExileOnly` source (Warped Space) is only a candidate for an exile cast, so
                // it isn't burned by a free hand cast granted by a different source.
                if (ability.fromExileOnly && castFromZone != com.wingedsheep.sdk.core.Zone.EXILE) continue
                if (ability.controllerOnly) {
                    val controllerId = state.projectedState.getController(entityId) ?: continue
                    if (controllerId != casterId) continue
                }
                if (spellCardDef != null && ability.spellFilter != GameObjectFilter.Any &&
                    !matchesCardDefinition(spellCardDef, ability.spellFilter, entityId, state, state.projectedState)
                ) continue
                if (ability.oncePerTurn) {
                    if (!state.isActiveTurnFor(casterId)) continue
                    if (container.has<com.wingedsheep.engine.state.components.battlefield.MayCastWithoutPayingCostUsedThisTurnComponent>()) continue
                    if (oncePerTurnCandidate == null) oncePerTurnCandidate = entityId
                } else {
                    // An unlimited / first-spell source already grants this free cast — don't burn
                    // a once-per-turn use.
                    return null
                }
            }
        }
        return oncePerTurnCandidate
    }

    /**
     * Calculate the effective cost of casting a spell using an alternative base cost.
     * Applies cost increases (tax effects) to the alternative cost.
     * Per Rule 118.9a, cost reductions and increases apply to alternative costs.
     *
     * Note: Self-reduction (`SpellCostTarget.SelfCast`) and Affinity are NOT applied to
     * alternative costs, since those modify the card's own mana cost. Only
     * battlefield-sourced AnyCaster increases apply.
     */
    fun calculateEffectiveCostWithAlternativeBase(
        state: GameState,
        cardDef: CardDefinition,
        alternativeCost: ManaCost,
        casterId: EntityId? = null,
        chosenTargets: List<EntityId> = emptyList(),
    ): ManaCost {
        var totalIncrease = 0
        for ((sourceId, ability) in scanBattlefieldModifySpellCost(state)) {
            val target = ability.target
            if (target !is SpellCostTarget.AnyCaster) continue
            if (!matchesCardDefinition(cardDef, target.filter, sourceId, state, state.projectedState)) continue
            when (val mod = ability.modification) {
                is CostModification.IncreaseGeneric -> totalIncrease += mod.amount
                is CostModification.IncreaseGenericBy -> {
                    if (casterId != null) {
                        totalIncrease += evaluateReduction(
                            state, mod.source, casterId, abilitySourceId = sourceId
                        )
                    }
                }
                is CostModification.IncreaseGenericPerOtherSpellThisTurn -> {
                    if (casterId != null) {
                        val spellsCast = state.playerSpellsCastThisTurn[casterId] ?: 0
                        totalIncrease += spellsCast * mod.amountPerSpell
                    }
                }
                else -> { /* AnyCaster reductions don't apply to alternative casting costs. */ }
            }
        }
        // Stack-native targeting taxes also apply to alternative/free base costs.
        if (casterId != null) {
            for ((sourceId, ability) in scanStackModifySpellCost(state)) {
                if (!targetMatchesSpell(ability.target, cardDef, casterId, sourceId, state, chosenTargets)) continue
                when (val mod = ability.modification) {
                    is CostModification.IncreaseGeneric -> totalIncrease += mod.amount
                    is CostModification.IncreaseGenericBy ->
                        totalIncrease += evaluateReduction(state, mod.source, casterId, chosenTargets, sourceId, cardDef)
                    is CostModification.IncreaseGenericPerOtherSpellThisTurn -> {
                        val spellsCast = state.playerSpellsCastThisTurn[casterId] ?: 0
                        totalIncrease += spellsCast * mod.amountPerSpell
                    }
                    else -> { /* Batch U needs only generic stack-source increases. */ }
                }
            }
        }
        return increaseGenericCost(alternativeCost, totalIncrease)
    }

    /**
     * Calculate the additional life [casterId] must pay as part of casting a spell with
     * the given [targets], summed across every battlefield [ModifySpellCost] ability
     * matching [SpellCostTarget.OpponentsCastTargeting] + [CostModification.IncreaseLife]
     * (e.g. Terror of the Peaks).
     *
     * Called from [CastSpellHandler] to validate affordability and collect payment.
     */
    fun calculateAdditionalLifeCost(
        state: GameState,
        casterId: EntityId,
        targets: List<ChosenTarget>
    ): Int {
        if (targets.isEmpty()) return 0
        val targetEntityIds = targets.mapNotNull { (it as? ChosenTarget.Permanent)?.entityId }
        if (targetEntityIds.isEmpty()) return 0
        var total = 0
        for ((sourceId, ability) in scanBattlefieldModifySpellCost(state)) {
            val target = ability.target as? SpellCostTarget.OpponentsCastTargeting ?: continue
            val modification = ability.modification as? CostModification.IncreaseLife ?: continue
            if (!opponentsCastTargetingMatches(state, casterId, sourceId, target.targetFilter, targetEntityIds)) continue
            total += modification.amount
        }
        return total
    }

    companion object {
        /**
         * Check if a card has any cost reduction abilities.
         */
        fun hasCostReduction(cardDef: CardDefinition): Boolean {
            val hasSelfReduction = cardDef.script.staticAbilities.any { ability ->
                ability is ModifySpellCost && ability.target == SpellCostTarget.SelfCast
            }
            val hasAffinity = cardDef.keywordAbilities.any {
                it is KeywordAbility.Affinity || it is KeywordAbility.AffinityForSubtype
            }
            return hasSelfReduction || hasAffinity
        }
    }
}
