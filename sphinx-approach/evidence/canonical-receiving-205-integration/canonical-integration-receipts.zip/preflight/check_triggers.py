"""Read-only prospective PR205 merge event and PR175 synchronize filter audit."""
import hashlib,json,re
from pathlib import Path
import yaml

OUT=Path(__file__).resolve().parent
BASE=Path('sphinx-audit/canonical-integration')
live=json.loads((OUT/'live-inputs.json').read_text())
tree={x['path']:x['sha'] for x in live['current_tree']['workflows']}
headers=json.loads(Path('izzet-takeover/sphinx-candidate-trigger-audit.json').read_text())
bodies={x['path']:x['result']['content'] for x in json.loads((BASE/'matching-workflow-bodies.json').read_text())}
bodies['.github/workflows/pest-control-tier-one-monster-tron-support-closure.yml']=json.loads((OUT/'extra-workflow-source.json').read_text())['content']
release=json.loads((BASE/'release-hashes.json').read_text())
canonical_paths={x['path'] for x in json.loads((BASE/'runtime-delta-classification.json').read_text())['diff']}|{x['path'] for x in release}
main_paths={x['filename'] for x in live['pr175_comparison']['files']}
assert len(canonical_paths)==511 and len(main_paths)==129
assert live['pr175_comparison']['base']=='ff34ac8fa2efbd41f233e877cb2908c2cab5929a'

def match(value,pattern):
    # All current headers use only literal characters, * and ** glob syntax.
    assert not any(x in pattern for x in ['?','[',']','+']),pattern
    tokens=[];i=0
    while i<len(pattern):
        if pattern[i:i+3]=='**/':tokens.append('(?:.*/)?');i+=3
        elif pattern[i:i+2]=='**':tokens.append('.*');i+=2
        elif pattern[i]=='*':tokens.append('[^/]*');i+=1
        else:tokens.append(re.escape(pattern[i]));i+=1
    return re.fullmatch(''.join(tokens),value) is not None

def selected(value,patterns):
    yes=False
    for p in patterns:
        negative=p.startswith('!')
        if match(value,p[1:] if negative else p):yes=not negative
    return yes

def qualifies(on,event,activity,branch,paths):
    if event not in on:return False,[]
    e=on[event] or {}
    if event=='pull_request' and activity not in e.get('types',['opened','synchronize','reopened']):return False,[]
    if 'branches' in e and not selected(branch,e['branches']):return False,[]
    if any(match(branch,p) for p in e.get('branches-ignore',[])):return False,[]
    witnesses=sorted(p for p in paths if selected(p,e.get('paths',['**'])))
    if 'paths' in e and not witnesses:return False,[]
    if 'paths-ignore' in e and all(any(match(p,g) for g in e['paths-ignore']) for p in paths):return False,[]
    return True,witnesses

rows=[];matched={};events=set()
for h in headers:
    p=h['path'];on=yaml.load(h['trigger'],Loader=yaml.BaseLoader)['on'];events.update(on)
    f=BASE/'release'/p
    if f.is_file():
        raw=f.read_bytes();body=raw.decode()
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==tree[p]
        assert yaml.load(raw,Loader=yaml.BaseLoader)['on']==on
        binding='fresh current tree plus exact release bytes; unchanged header'
    else:
        assert h['sha']==tree[p],p
        body=bodies.get(p)
        binding='fresh current tree blob equals previously fetched complete header source'
    row={'path':p,'git_blob_sha1':tree[p],'binding':binding,'events':{}}
    for label,event,activity,branch,paths in [
        ('canonical_push','push',None,'sphinx-approach/reconstruction-stage-e',canonical_paths),
        ('pr205_closed','pull_request','closed','sphinx-approach/reconstruction-stage-e',canonical_paths),
        ('pr205_ready_for_review','pull_request','ready_for_review','sphinx-approach/reconstruction-stage-e',canonical_paths),
        ('pr175_synchronize','pull_request','synchronize','main',main_paths)]:
        yes,witnesses=qualifies(on,event,activity,branch,paths)
        row['events'][label]={'matches':yes,'witness_paths':witnesses}
        if yes:
            assert body is not None,p
            raw=body.encode();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==tree[p],p
            doc=yaml.load(body,Loader=yaml.BaseLoader)
            matched[p]={'path':p,'git_blob_sha1':tree[p],'sha256':hashlib.sha256(raw).hexdigest(),'body':body,'concurrency':doc.get('concurrency'),'permissions':doc.get('permissions'),'jobs':{k:{'if':v.get('if'),'concurrency':v.get('concurrency'),'uses':v.get('uses'),'steps':[{'name':s.get('name'),'uses':s.get('uses'),'run':s.get('run'),'if':s.get('if')} for s in v.get('steps',[])]} for k,v in doc.get('jobs',{}).items()}}
    rows.append(row)
assert len(rows)==len(tree)==85
report={'scope':'PROSPECTIVE_READ_ONLY_TRIGGER_FILTER_AUDIT_NOT_MERGE_OR_GAMEPLAY_ADMISSION','canonical_paths':len(canonical_paths),'prospective_pr175_paths':len(main_paths),'current_tree':live['current_tree']['sha'],'events_present':sorted(events),'rows':rows,'matches':{e:[r['path'] for r in rows if r['events'][e]['matches']] for e in rows[0]['events']},'diff_method':'Canonical source delta511 from reviewed full tree proof; PR175 three-dot129 paths from actual main ff34 to exact test merge ae590, merge-base994383. Stale PR175 base d0c78 is explicitly not used.'}
# Prospective PR175 merge workflows also retain the sole main-only workflow
# edit. Its newly added PR filter has no witness in the head's129-path diff.
main_override=json.loads((OUT/'main-workflow-source.json').read_text())
raw=main_override['content'].encode()
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==main_override['sha']
main_on=yaml.load(raw,Loader=yaml.BaseLoader)['on']
yes,witness=qualifies(main_on,'pull_request','synchronize','main',main_paths)
assert not yes
report['main_test_merge_workflow_override']={'path':'.github/workflows/shared-postblock-source-qualification.yml','git_blob_sha1':main_override['sha'],'sha256':hashlib.sha256(raw).hexdigest(),'on':main_on,'pr175_synchronize_matches':yes,'witness_paths':witness}
(OUT/'trigger-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'matched-workflow-sources.json').write_text(json.dumps(list(matched.values()),indent=2)+'\n')
print(json.dumps({'events':report['events_present'],'matches':report['matches'],'concurrency':{p:x['concurrency'] for p,x in matched.items()}},indent=2))
