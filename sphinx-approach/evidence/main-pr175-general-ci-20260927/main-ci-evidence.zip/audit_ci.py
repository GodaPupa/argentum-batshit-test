"""Read-only CI evidence audit; no test, engine, checkout or network mutation."""
import collections, datetime, gzip, hashlib, json, pathlib, re, zipfile
import xml.etree.ElementTree as E
ROOT=pathlib.Path('/workspace/scratch/94f5141e9448')
OUT=ROOT/'pest-takeover/sphinx-main-ci-review'
h=lambda b:hashlib.sha256(b).hexdigest()
dt=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
live=json.loads((OUT/'live-metadata.json').read_text()); run=live[0]['data']; jobs=live[1]['data']['jobs'];artmeta=live[2]['data']['artifacts']
assert run['id']==36284779342 and run['run_attempt']==1 and run['event']=='pull_request' and run['conclusion']=='success'
assert run['head_sha']=='8ed9787ad75b8bc6c2438a8c0b526ff822aa776e'
commit=live[3]['data'];assert commit['sha']=='22cf67791fda69a65d7e1eeb76c2ae369407cb01' and commit['tree']['sha']=='3b4e50dd7a0fe484b796bb191bd848b048bea12b'
assert [x['sha']for x in commit['parents']]==['ff34ac8fa2efbd41f233e877cb2908c2cab5929a','8ed9787ad75b8bc6c2438a8c0b526ff822aa776e']
assert len(jobs)==10 and collections.Counter(j['conclusion']for j in jobs)=={'success':9,'skipped':1}
assert next(j for j in jobs if j['conclusion']=='skipped')['name']=='coverage'
current=[]
for x in json.loads((OUT/'artifact-local-locations.json').read_text())['artifacts']:
    meta=next(a for a in artmeta if a['id']==x['artifact_id'])
    current.append({'path':x['download']['path'],'bytes':meta['size_in_bytes'],'sha256':meta['digest'].removeprefix('sha256:'),'name':meta['name'],'id':meta['id']})
prior=[{'path':x['local_path'],'bytes':x['bytes'],'sha256':x['sha256'],'name':pathlib.Path(x['local_path']).name}for x in json.loads((ROOT/'sphinx-audit/full-ci-evidence/publication-files.json').read_text()) if x['local_path'].endswith('.zip')]

def inspect(files,old=False):
    records=[];members=[];archives=[]
    for x in files:
        path=pathlib.Path(x['path']);b=path.read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256']
        a={**x,'members':0,'XML_suites':0};z=zipfile.ZipFile(path);assert len(z.namelist())==len(set(z.namelist()))
        for info in z.infolist():
            name=info.filename;assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
            body=z.read(info);members.append({'archive':path.name,'path':name,'bytes':len(body),'sha256':h(body)})
            a['members']+=1
            if not name.endswith('.xml'):continue
            if old:
                assert name.startswith('xml/') and '/TEST-' in name
                module=name[4:].split('/TEST-')[0]
            else:
                assert '/build/test-results/test/' in name
                module=name.split('/build/test-results/test/')[0]
            r=E.fromstring(body);assert r.tag=='testsuite';cases=r.findall('testcase');assert int(r.get('tests'))==len(cases)
            for tag,attr in [('failure','failures'),('error','errors'),('skipped','skipped')]: assert sum(c.find(tag)is not None for c in cases)==int(r.get(attr))
            a['XML_suites']+=1
            for c in cases:
                states=[tag for tag in ['failure','error','skipped']if c.find(tag)is not None];assert len(states)<=1
                records.append({'module':module,'class':c.get('classname'),'name':c.get('name'),'status':states[0]if states else'passed','timestamp':r.get('timestamp'),'archive':path.name,'XML':name})
        archives.append(a)
    return records,members,archives

cases,members,archives=inspect(current)
oldcases,oldmembers,oldarchives=inspect(prior,True)
identity=lambda c:(c['module'],c['class'],c['name'],c['status'])
marker=lambda c:c['module']=='mtg-sets' and c['class']=='Gradle Test Run :mtg-sets:test' and c['name']=='CardImageUriTest'
assert collections.Counter(map(identity,cases))==collections.Counter(map(identity,oldcases))
markers=[c for c in cases if marker(c)];assert len(markers)==1
actual=[c for c in cases if not marker(c)];assert len(cases)==17547 and len(actual)==17546
assert collections.Counter(c['status']for c in actual)=={'passed':17494,'skipped':52}
cached=[c for c in actual if c['module']in ['mtg-search','mtgish-tooling']]
fresh=[c for c in actual if c['module']not in ['mtg-search','mtgish-tooling']]
assert collections.Counter(c['status']for c in cached)=={'passed':307,'skipped':3}
assert collections.Counter(c['status']for c in fresh)=={'passed':17187,'skipped':49}
tasks={};taskjobs={};logs=[]
for p in sorted(OUT.glob('complete-decoded-job-*.log.gz')):
    b=gzip.decompress(p.read_bytes());s=b.decode();jobid=int(p.name.split('-')[-1].split('.')[0]);j=next(j for j in jobs if j['id']==jobid);assert j['conclusion']=='success'
    found={};records=[];errorlines=[]
    for line in s.splitlines():
        m=re.fullmatch(r'\S+ > Task (:[\w:-]+:test)(?: (FROM-CACHE|UP-TO-DATE|NO-SOURCE|SKIPPED|FAILED))?\s*',line)
        if m:
            task,state=m[1],m[2]or'EXECUTED';assert task not in found or found[task]==state
            found[task]=state;tasks[task]=state;taskjobs[task]=jobid
        if not re.match(r'^\S+ > Task ',line):
            m=re.fullmatch(r'\S+ (.+) > (.+) (PASSED|SKIPPED|FAILED)',line)
            if m:records.append((m[1],m[2],m[3]))
        if re.match(r'^\S+ ##\[error\]',line):errorlines.append(line)
    assert not errorlines
    if j['name'].startswith('test ('):
        assert commit['sha'] in s and 'BUILD SUCCESSFUL' in s and 'BUILD FAILED'not in s
        assert next(step for step in j['steps']if step['name']=='Test')['conclusion']=='success'
    if j['name']=='frontend':
        assert commit['sha'] in s
        for n in ['Install dependencies','Typecheck','Build']: assert next(step for step in j['steps']if step['name']==n)['conclusion']=='success'
    logs.append({'path':str(p.relative_to(ROOT)),'gzip_bytes':p.stat().st_size,'gzip_sha256':h(p.read_bytes()),'decoded_bytes':len(b),'decoded_sha256':h(b),'job_id':jobid,'job_name':j['name'],'tasks':found,'actual_result_suffix_counts':dict(collections.Counter(r[2]for r in records))})
assert len(logs)==9 and collections.Counter(tasks.values())=={'EXECUTED':17,'FROM-CACHE':2}
for c in fresh:
    task=':'+c['module'].replace('/',':')+':test';j=next(j for j in jobs if j['id']==taskjobs[task]);step=next(x for x in j['steps']if x['name']=='Test')
    assert dt(step['started_at'])<=dt(c['timestamp'])<=dt(step['completed_at'])
cmp=json.loads((OUT/'canonical-main-source-comparison.json').read_text());a={x['path']:x for x in cmp[1]['data']['tree']};b={x['path']:x for x in cmp[2]['data']['tree']}
assert not cmp[1]['data']['truncated'] and not cmp[2]['data']['truncated'] and set(a)==set(b)
same=sorted(k for k in a if (a[k]['mode'],a[k]['type'],a[k]['sha'])==(b[k]['mode'],b[k]['type'],b[k]['sha']))
assert len(same)==43 and sorted(set(a)-set(same))==['.github','lab-coordinator']
delta=cmp[0]['data'];assert delta['merge_base_commit']['sha']=='8ed9787ad75b8bc6c2438a8c0b526ff822aa776e'and len(delta['files'])==14
assert [f['filename']for f in delta['files']if not f['filename'].startswith('lab-coordinator/')]==['.github/workflows/shared-postblock-source-qualification.yml']
ci=json.loads((OUT/'cached-module-trees-and-ci-workflow.json').read_text())[0]['data'].encode();ciblob=hashlib.sha1(b'blob '+str(len(ci)).encode()+b'\0'+ci).hexdigest();assert ciblob=='dbf5723efa463b87c94c1a1ea23c08d641c13e3a'
detail={'current_members':members,'prior_members':oldmembers,'case_multiset':sorted(collections.Counter(map(identity,cases)).items()),'skips':sorted(collections.Counter(identity(c)for c in actual if c['status']=='skipped').items())}
raw=(json.dumps(detail,sort_keys=True,separators=(',',':'))+'\n').encode();gz=gzip.compress(raw,mtime=0);(OUT/'raw-detail.json.gz').write_bytes(gz)
report={'schema':'sphinx-pr175-main-ci-independent-byte-audit-v1','run':run['id'],'attempt':1,'head':run['head_sha'],'actual_checkout':commit['sha'],'tree':commit['tree']['sha'],'archives':archives,'prior_archives_rechecked':oldarchives,'raw_records':len(cases),'actual_records':len(actual),'distinct_actual_module_class_name_status_identities':len(set(map(identity,actual))),'counts':dict(collections.Counter(c['status']for c in actual)),'fresh':dict(collections.Counter(c['status']for c in fresh)),'cached':dict(collections.Counter(c['status']for c in cached)),'markers':markers,'fresh_XML_suites_inside_actual_Test_step':len(set((c['archive'],c['XML'])for c in fresh)),'current_members':len(members),'current_XML_suites':sum(x['XML_suites']for x in archives),'all_current_raw_identities_equal_prior_fresh_multiset':True,'all_skips_equal_prior':True,'logs':logs,'tasks':tasks,'same_canonical_root_objects':same,'main_delta_paths':[f['filename']for f in delta['files']],'CI_workflow_blob':ciblob,'detail':{'path':'raw-detail.json.gz','bytes':len(gz),'sha256':h(gz),'decoded_bytes':len(raw),'decoded_sha256':h(raw)},'no_test_or_game_execution':True}
(OUT/'independent-byte-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k]for k in ['raw_records','actual_records','distinct_actual_module_class_name_status_identities','counts','fresh','cached','current_members','fresh_XML_suites_inside_actual_Test_step','detail']},indent=2))
