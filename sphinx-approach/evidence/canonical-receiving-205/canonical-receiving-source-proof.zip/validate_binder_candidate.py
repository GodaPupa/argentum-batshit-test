"""Static and simulated guard checks only; no GitHub, Gradle, JVM or gameplay."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import yaml

BASE=Path(__file__).resolve().parent
ROOT=BASE/'candidate'
manifest_path=ROOT/'sphinx-approach/STAGE_E_CANONICAL_RECEIVING_BINDING.json'
manifest=json.loads(manifest_path.read_bytes())
assert manifest['ready_for_qualification'] is False
files=json.loads((BASE/'candidate-hashes.json').read_bytes())
for item in files:
    raw=(ROOT/item['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==item['sha256']
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==item['git_blob_sha1']
    assert not any(part in item['path'] for part in ['/src/main/','/src/test/','/src/testFixtures/','snapshots/cards/'])

def function_source(text,name):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
    return ast.get_source_segment(text,node)

preserved_functions=[]
for path,name in [('sphinx-approach/collect-stage-e-actor.py','collect'),('lab-coordinator/shared-capabilities/collect-actor-input.py','collect')]:
    assert function_source((BASE/'baseline'/path).read_text(),name)==function_source((ROOT/path).read_text(),name)
    preserved_functions.append(path+'::'+name)

commands=[];inline_count=0
for item in files:
    path=item['path']
    text=(ROOT/path).read_text()
    if path.endswith('.py'):ast.parse(text)
    if not path.endswith('.yml'):continue
    old=yaml.load((BASE/'baseline'/path).read_text(),Loader=yaml.BaseLoader)
    new=yaml.load(text,Loader=yaml.BaseLoader)
    assert old['on']==new['on'] and old['permissions']==new['permissions']
    for job,body in old['jobs'].items():
        before={x.get('name'):x for x in body['steps'] if x.get('name')}
        after={x.get('name'):x for x in new['jobs'][job]['steps'] if x.get('name')}
        for name,step in before.items():
            run=step.get('run','')
            if 'scripts/test-class ' in run or 'just test-class ' in run:
                assert step==after[name],(path,name)
                commands.append({'workflow':path,'step':name,'run_sha256':hashlib.sha256(run.encode()).hexdigest()})
        for step in new['jobs'][job]['steps']:
            lines=step.get('run','').splitlines();start=None
            for i,line in enumerate(lines):
                if "<<'PY'" in line:start=i+1
                elif line=='PY' and start is not None:
                    ast.parse('\n'.join(lines[start:i]));inline_count+=1;start=None

# Simulate exact current source digests and Git replies, with production methods
# otherwise unchanged. These are guard logic tests, not evidence of real ancestry.
spec=importlib.util.spec_from_file_location('candidate_helper',ROOT/'sphinx-approach/canonical_receiving_binding.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
pin_input=json.loads((BASE/'binder-pin-inputs.json').read_bytes())
original={x['path']:x['pins'] for x in pin_input['specs']}
observed=json.loads((BASE/'binder-observed-digests.json').read_bytes())
review_path='sphinx-approach/evidence/canonical-receiving-binder-source-review.json'
results=[]
control_hashes={x['path']:x['sha256'] for x in files}
for group,rule in manifest['groups'].items():
    base=copy.deepcopy(manifest);base['ready_for_qualification']=True
    base['independent_source_review']={'path':review_path,'sha256':'a'*64}
    pins=copy.deepcopy(original[rule['original_binding_authority']])
    cases=['positive','unready','bad_manifest_digest','missing_review','changed_original_authority','runtime_delta','dirty_checkout','changed_original_scope','wrong_receiving_source']
    for case in cases:
        value=copy.deepcopy(base);supplied=copy.deepcopy(pins)
        digests={p:x['sha256'] for p,x in observed.items()}
        digests.update(control_hashes);digests.update(value['preserved_authority_sha256']);digests[review_path]='a'*64
        if case=='unready':value['ready_for_qualification']=False
        if case=='missing_review':value['independent_source_review']=None
        if case=='changed_original_authority':digests[next(iter(value['preserved_authority_sha256']))]='0'*64
        if case=='changed_original_scope':supplied.pop(next(iter(supplied)))
        if case=='wrong_receiving_source':
            target=next(x['path'] for x in rule['explicit_overrides'] if x['kind']=='EXACT_ALREADY_QUALIFIED_A0_RUNTIME')
            digests[target]='0'*64
        raw=(json.dumps(value,indent=2)+'\n').encode();expected=hashlib.sha256(raw).hexdigest()
        digests[helper.BINDING]='0'*64 if case=='bad_manifest_digest' else expected
        def git(root,*args):
            if args==('rev-parse','HEAD'):return 'f'*40
            if args==('rev-parse','HEAD^{tree}'):return 'e'*40
            if args==('rev-parse',helper.QUALIFIED_SOURCE+'^{tree}'):return helper.QUALIFIED_TREE
            if args[:2]==('diff','--name-only'):return 'rules-engine/src/main/forbidden.kt' if case=='runtime_delta' else '\n'.join(value['qualification_control_paths'])
            if args[:2]==('status','--porcelain'):return ' M forbidden' if case=='dirty_checkout' else ''
            raise AssertionError(args)
        def sha(path):return digests[path.relative_to(ROOT.resolve()).as_posix()]
        def read(path):
            assert path==manifest_path.resolve()
            return raw
        failed=False
        with patch.object(helper,'BINDING_SHA256',expected),patch.object(helper,'_sha',sha),patch.object(helper,'_git',git),patch.object(helper.subprocess,'run',return_value=None),patch.object(Path,'read_bytes',read):
            try: effective,proof=helper._bind(group,supplied,ROOT)
            except ValueError:failed=True
        assert failed==(case!='positive'),(group,case,failed)
        if not failed:
            assert set(pins)<=set(effective)
            assert proof['original_pin_count']==len(pins)
            assert proof['gameplay_authorized'] is False
        results.append({'group':group,'case':case,'expected_rejection':case!='positive','passed':True})

# Exercise the real failure-preservation wrapper on a tiny temporary directory.
# Its genuine prospective ready=false guard rejects before any ancestry gate.
retention=[]
foreign=json.loads((BASE/'inherited-binders.json').read_bytes())
preflight=json.loads((BASE/'live-preflight-inputs.json').read_bytes())
authority_bytes={x['path']:x['result']['content'].encode() for x in foreign+preflight['contracts']}
with tempfile.TemporaryDirectory(prefix='binding-retention-',dir=BASE) as temp:
    temp_root=Path(temp)
    for path in [helper.BINDING,'sphinx-approach/canonical_receiving_binding.py']:
        target=temp_root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/path).read_bytes())
    for path in set(p for paths in helper.ORIGINALS.values() for p in paths):
        target=temp_root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(authority_bytes[path])
    def metadata_git(root,*args):
        if args==('rev-parse','HEAD'):return 'f'*40
        if args==('rev-parse','HEAD^{tree}'):return 'e'*40
        if args[:2]==('status','--porcelain'):return ''
        raise AssertionError(args)
    with patch.object(helper,'_git',metadata_git):
        for group,rule in manifest['groups'].items():
            for index in [1,2]:
                env={'GITHUB_SHA':'event-merge-sha','EXPECTED_HEAD':'requested-head-sha'}
                if index==2:env['EXPECTED_SOURCE']='requested-source-sha'
                with patch.dict('os.environ',env,clear=True):
                    try:helper.bind(group,original[rule['original_binding_authority']],temp_root)
                    except ValueError as exc:assert str(exc)=='Prospective receiving binding awaits nonauthor source review'
                    else:raise AssertionError('Unready binding accepted')
                out=temp_root/'build/reports'/helper.REPORTS[group]/'receiving-binding-attempts'/f'attempt-{index:03d}'
                record=json.loads((out/'attempt.json').read_bytes())
                assert record['status']=='REJECTED_BINDING_NO_QUALIFICATION'
                assert record['head']=='f'*40 and record['tree']=='e'*40
                assert record['github_sha']=='event-merge-sha'
                assert record['requested_source']==('requested-head-sha' if index==1 else 'requested-source-sha')
                assert record['original_expected_pins']==original[rule['original_binding_authority']]
                assert set(record['observed_source_sha256'])==set(record['original_expected_pins'])
                for path in helper.ORIGINALS[group]:
                    assert (out/'source'/path).read_bytes()==authority_bytes[path]
                    assert record['preserved_files_sha256'][path]==hashlib.sha256(authority_bytes[path]).hexdigest()
                assert (out/'source'/helper.BINDING).read_bytes()==manifest_path.read_bytes()
            assert len(list((out.parent).glob('attempt-*')))==2
            retention.append({'group':group,'two_separate_rejected_attempts_preserved':True,'original_authority_bytes_exact':True})

report={'scope':'STATIC_AND_SIMULATED_PYTHON_GUARD_LOGIC_ONLY_NO_ENGINE_EXECUTION','candidate_files':files,'yaml_heredoc_python_blocks_parsed':inline_count,'original_execution_steps_byte_preserved':commands,'original_case_collectors_byte_preserved':preserved_functions,'simulated_guard_checks':results,'real_python_rejected_attempt_retention':retention,'tests_or_production_changed':False,'official_games':0,'not_proof_of_real_git_ancestry_or_receiving_execution':True}
(BASE/'static-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'candidate_files':len(files),'original_execution_steps_preserved':len(commands),'heredoc_blocks':inline_count,'simulated_checks':len(results)}))
