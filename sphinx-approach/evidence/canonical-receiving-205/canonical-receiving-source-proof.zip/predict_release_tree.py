"""Reconstruct exact Git trees from immutable parent entries and reviewed blobs."""
import hashlib
import json
from pathlib import Path

BASE=Path(__file__).resolve().parent
source=json.loads((BASE/'affected-parent-git-tree-entries.json').read_bytes())
entries={x['path']:dict(x) for x in source['entries']}


def parent(path):
    return path.rpartition('/')[0]


def tree_sha(directory, values):
    children=[x for p,x in values.items() if parent(p)==directory]
    children.sort(key=lambda x:(x['path'].rsplit('/',1)[-1]+('/' if x['type']=='tree' else '')).encode())
    raw=b''
    for child in children:
        mode=child['mode'].lstrip('0')
        name=child['path'].rsplit('/',1)[-1]
        raw+=mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(child['sha'])
    return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()


for directory in source['directories']:
    expected=source['source_tree'] if not directory else entries[directory]['sha']
    assert tree_sha(directory,entries)==expected,(directory,expected,tree_sha(directory,entries))

release=json.loads((BASE/'release-hashes.json').read_bytes())
assert len(release)==11, 'Use only the corrected ten-control-file release plus its actual peer review'
for item in release:
    raw=(BASE/'release'/item['path']).read_bytes()
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert blob==item['git_blob_sha1']
    entries[item['path']]={'path':item['path'],'mode':'100644','type':'blob','sha':blob}
new={}
for directory in sorted(source['directories'],key=lambda p:(p.count('/'),bool(p)),reverse=True):
    value=tree_sha(directory,entries);new[directory or '/']=value
    if directory:entries[directory]['sha']=value
report={'parent':'a0c5b995c2829c0b4069562b1f1eede8a820dd97','parent_tree':source['source_tree'],'predicted_release_tree':new['/'],'derived_subtrees':new,'release_hashlist_sha256':hashlib.sha256((BASE/'release-hashes.json').read_bytes()).hexdigest(),'changed_blobs':release,'method':'Exact Git tree-object SHA1 from all immediate parent directory entries, after first reproducing every unmodified directory/tree SHA; no repository mutation'}
(BASE/'predicted-release-tree.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'predicted_tree':new['/'],'release_files':len(release)}))
