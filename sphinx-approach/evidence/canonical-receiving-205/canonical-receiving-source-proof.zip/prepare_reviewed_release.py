"""Materialize the independently permitted release formula locally only."""
import hashlib
import json
from pathlib import Path
import shutil

BASE=Path(__file__).resolve().parent
SOURCE=BASE/'candidate'
DEST=BASE/'release'
review_source=Path('pest-takeover/sphinx-binder-review/independent-binder-successor-source-review.json')
review_path='sphinx-approach/evidence/canonical-receiving-binder-source-review.json'
review_bytes=review_source.read_bytes()
review_sha=hashlib.sha256(review_bytes).hexdigest()
assert review_sha=='5938bf134d1a29109d7c0d5f42af5855b6912996312e3df20969c81f2418153a'
review=json.loads(review_bytes)
hashes=json.loads((BASE/'candidate-hashes.json').read_bytes())
assert hashes==review['files']
for item in hashes:
    raw=(SOURCE/item['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==item['sha256']
    target=DEST/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
manifest_path='sphinx-approach/STAGE_E_CANONICAL_RECEIVING_BINDING.json'
value=json.loads((SOURCE/manifest_path).read_bytes())
assert value['ready_for_qualification'] is False and value['independent_source_review'] is None
value['ready_for_qualification']=True
value['independent_source_review']={'path':review_path,'sha256':review_sha}
raw=(json.dumps(value,indent=2)+'\n').encode()
(DEST/manifest_path).write_bytes(raw)
final_sha=hashlib.sha256(raw).hexdigest()
helper_path='sphinx-approach/canonical_receiving_binding.py'
helper=(SOURCE/helper_path).read_text()
old=f'BINDING_SHA256 = "{review["deterministic_release_formula"]["descriptor_input_sha256"]}"'
assert helper.count(old)==1
helper=helper.replace(old,f'BINDING_SHA256 = "{final_sha}"')
(DEST/helper_path).write_text(helper)
(DEST/review_path).parent.mkdir(parents=True,exist_ok=True)
(DEST/review_path).write_bytes(review_bytes)
result=[]
for path in [x['path'] for x in hashes]+[review_path]:
    raw=(DEST/path).read_bytes()
    result.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'bytes':len(raw)})
(BASE/'release-hashes.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'files':len(result),'descriptor_sha256':final_sha,'helper_sha256':next(x['sha256'] for x in result if x['path']==helper_path),'review_sha256':review_sha,'published':False}))
