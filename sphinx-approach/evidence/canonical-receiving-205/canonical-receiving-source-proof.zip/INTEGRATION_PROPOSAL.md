# Sphinx canonical receiving: exact source and prospective binder proposal

This is a source integration proposal awaiting nonauthor review. No branch, PR, merge, receiving test, official allocation, or Stage-E game was started by this proposal. The prospective binding descriptor remains `ready_for_qualification: false`.

The canonical branch is `sphinx-approach/reconstruction-stage-e` at `fae4f5f61260a3e99109b38328afc31894bac8d4`, tree `fa82b9fe8463c0c104f4cfac4d31d8ec972a4d38`. The runtime parent is the reviewed combined source `a0c5b995c2829c0b4069562b1f1eede8a820dd97`, tree `1ee5590bacf2f6507fff6487be9d3e20df8b5e40`; canonical fae is already an ancestor. The proposed new branch is `lab/sphinx-canonical-receiving-20260926`, based on a0, with an eventual ordinary PR targeting the canonical branch. The evidence-only descendant `9f8730dcad9e1c22f369b16067dc5dd67b616c5e` is an evidence link, not the runtime parent.

## Existing evidence and its limits

The exact a0 receiver executed the original 999 cases across 69 classes in run 36273602269 with zero failures/errors/skips. Run 36277074660 then executed all 19 standard backend modules freshly, plus Node-22 frontend installation/typecheck/build. Its 17,547 raw XML records contain 17,546 actual cases: 17,494 passing and 52 unchanged skips, plus one separate Gradle discovery marker that receives no pass credit. All 999 required receiving identities occurred once and were unskipped in full CI. Originals and nonauthor artifact reviews are published at 9f under `sphinx-approach/evidence/`.

These are mechanical and software receiving results. They do not qualify whole-game pilots, the runner, complete runtime identity, or Stage-E gameplay. The historical missing A–D limitation remains. No deck, opponent, pilot-development budget, Stage-E seed, allocation, or outcome changed.

## Complete canonical delta, accounted for before integration

`runtime-delta-classification.json` contains every one of the 508 fae-to-a0 blob differences, with exact before/after Git identities. The categories are:

| Category | Files | Disposition |
| --- | ---: | --- |
| Production | 89 | Preserve exact qualified a0 bytes, including shared priority/LKI/token/actor code, Sphinx extensions and inherited receiving repairs. |
| Tests, fixtures and resource snapshots | 191 | Preserve exact a0 bytes and prior failures; no new baseline or weakened assertion. |
| Build | 1 | Preserve qualified gym dependency routing. |
| Workflows | 18 | Account for all inherited triggers; only four receive the prospective binding edits below. |
| Sphinx contracts and records | 26 | Preserve exact frozen budgets, source history, receipts and limitations. |
| Shared contracts and records | 60 | Preserve reviewed ancestry and raw source authority; historical coordinator prose is navigation, not current admission. |
| Other documentation and foreign records | 61 | Mostly inherited Pest receiving closure evidence and SDK/architecture documentation; no new Pest experimental authority. |
| Collectors and tools | 10 | Preserve a0 tools except two receiving collectors described below. |
| Retained binary evidence | 52 | Preserve historical evidence already in the runtime ancestry; add no duplicate 999/full-CI binaries from the evidence branch. |

The source delta is a coherent accepted ancestry, not a wholesale transplant from an unrelated project. Removing cards, snapshots, fixtures, or source authority files solely to reduce the count would create a different unqualified runtime. The user and root authorized this classified coherent delta. Current compact cross-program status remains owned by root; stale historical coordinator text in this ancestry cannot supersede newer main-branch records.

## Exact source binding discrepancy and ten-file candidate

`binder-mismatch-audit.json` verifies 349 unique current files by both content SHA-256 and immutable a0 Git blob. It finds these precise stale bindings:

| Original gate | Original pins | Runtime pin differences |
| --- | ---: | --- |
| Priority 220 | 250 | Serialization only |
| Token 20 | 47 | Serialization only |
| Shared actor 50 | 18 | ActorLegalAction, ActorObservation, ActorPayloadSchemas, ObservationAdapter, ActorActionMenu |
| Pest Postboard B | 36 | StackResolver only |
| Sphinx actor 136 | 41 | ActorActionMenu and ObservationAdapter |
| Sphinx initialized seat 16 | 58 | ActorActionMenu and ObservationAdapter |

Combat's 30 pins, Pest A's 24 pins and Spy Hydra's compiled source pin agree unchanged. Differences above concern seven distinct runtime paths and do not authorize changing them: the proposal binds the already qualified a0 bytes.

`candidate-hashes.json` identifies the ten proposed files: four workflow binding edits and two full-history checkout corrections, two collector binding edits, one new Sphinx binding helper and one new explicit receiving descriptor. Every original manifest, budget, receipt, source-history byte, test body, bank identity, test-execution command block and XML case validator remains intact. Three existing workflow pins additionally need explicit prospective control hashes: priority and token controls in the priority manifest, and the Postboard-B control in its own manifest. They are labeled separately from the seven runtime overrides.

The helper requires a0/tree1ee ancestry and rejects any intervening Git delta outside the exact ten control paths plus the eventual nonauthor review file. It validates preserved authority hashes, original complete source-map fingerprints and explicit old-to-receiver overrides, then binds every resulting source and control file. Every attempted binding preserves original authorities, descriptor/helper bytes, expected and observed pins, HEAD/tree/run identity and exceptions before rejection. Distinct attempts receive distinct retained directories.

The actor budget's existing correction rule requires the same complete equal 136-case bank with no deleted/replaced/relabeled/softened case. The seat budget requires the same 16 real-initializer binding cases and separate source/artifact review. This proposal uses those existing component-requalification rules; it neither changes the pilot budget nor invents a Stage-E sample size. Shared and Pest overrides remain prospective and require independent review.

## Review and next execution gates

The candidate passed Python syntax and all eight embedded Python-block parses. Its six existing test-execution blocks and both existing case-collection functions are byte-identical. Fifty-four simulated guard checks covered the six binding groups; twelve actual Python calls to the unready guard preserved separate rejected-attempt records and exact original authority bytes. These are static/control checks, not real Git ancestry proof, Kotlin tests, or gameplay.

Before publication/PR activation, Pest's independent review and root's final exact-source review must cover the candidate, activation-only ready/review/hash updates and all final trigger effects. The initial full 85-workflow inventory found no matching push for the proposed branch or canonical merge and 16 matching PR workflows. They include deterministic foreign Pest banks and snapshot-generation steps; their actual raw results and drift must be audited. Izzet independently checked the full 16 bodies. Branch protection is unverified because the connected integration received HTTP 403; repository rulesets were empty. No approval or absence of protection is inferred.

After reviewed inert publication, a normal receiving PR may run the preserved gates. Before canonical integration, audit exact requested head/base/merge-tree identities, actual original cases, fresh commands/XML, snapshot differences, exits, source pins and complete retained artifacts. A green workflow alone does not grant experimental admission. Any merge must use the ordinary repository process and preserve the separate remaining whole-pilot/runner/replay/Stage-E-freeze requirements.

The initial eight-file unexecuted proposal and its review are preserved under `prior-eight-file-proposal/`. Before any publication or attempt, source inspection found the actor workflows used shallow checkout. The successor adds only `fetch-depth: 0` to those two checkout steps so the exact ancestor guard can execute. This is a prospective correction, not a failed receiving run.
