"""Re-evaluate inherited event filters on the final source+control delta."""
import fnmatch
import hashlib
import json
from pathlib import Path
import yaml

BASE=Path(__file__).resolve().parent
headers=json.loads(Path('izzet-takeover/sphinx-candidate-trigger-audit.json').read_bytes())
runtime=json.loads((BASE/'runtime-delta-classification.json').read_bytes())
paths={x['path'] for x in runtime['diff']}
controls=json.loads((BASE/'candidate-hashes.json').read_bytes())
paths|={x['path'] for x in controls}
paths.add('sphinx-approach/evidence/canonical-receiving-binder-source-review.json')
branch='lab/sphinx-canonical-receiving-20260926'
canonical='sphinx-approach/reconstruction-stage-e'

def selected(value,patterns):
    matched=False
    for pattern in patterns:
        negative=pattern.startswith('!');pattern=pattern[1:] if negative else pattern
        if fnmatch.fnmatchcase(value,pattern):matched=not negative
    return matched

def matches(event,ref):
    if event is None:return True
    if not isinstance(event,dict):return False
    if 'branches' in event and not selected(ref,event['branches']):return False
    if any(fnmatch.fnmatchcase(ref,p) for p in event.get('branches-ignore',[])):return False
    if 'paths' in event and not any(selected(p,event['paths']) for p in paths):return False
    if 'paths-ignore' in event and all(any(fnmatch.fnmatchcase(p,g) for g in event['paths-ignore']) for p in paths):return False
    return True

rows=[]
for header in headers:
    path=header['path'];candidate=BASE/'candidate'/path
    old=yaml.load(header['trigger'],Loader=yaml.BaseLoader)['on']
    if candidate.is_file():
        new=yaml.load(candidate.read_text(),Loader=yaml.BaseLoader)['on']
        assert new==old
        sha=next(x['git_blob_sha1'] for x in controls if x['path']==path)
    else:new=old;sha=header['sha']
    row={'path':path,'git_blob_sha1':sha,'trigger_headers_unchanged':True}
    for event,ref,label in [('push',branch,'new_branch_push'),('push',canonical,'canonical_push'),('pull_request',canonical,'canonical_pr')]:
        row[label]=event in new and matches(new[event],ref)
    rows.append(row)
assert len(rows)==85
assert not any(x['new_branch_push'] or x['canonical_push'] for x in rows)
prior=json.loads((BASE/'prospective-trigger-matches.json').read_bytes())
assert {x['path'] for x in rows if x['canonical_pr']}=={x['path'] for x in prior if x['pull_request_matches']}
report={'scope':'STATIC_EVENT_FILTER_RECHECK_REQUIRES_INDEPENDENT_SOURCE_AND_TRIGGER_REVIEW','proposed_branch':branch,'canonical_base':canonical,'canonical_delta_paths':len(paths),'workflows':rows,'matching_pr_workflows':[x['path'] for x in rows if x['canonical_pr']],'push_matches':0,'official_gameplay_authorized':False,'glob_method':'Python fnmatch ordered include/exclude, checked against complete inherited header inventory; workflow if/job conditions remain separately reviewed'}
(BASE/'final-prospective-trigger-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'canonical_paths':len(paths),'workflows':len(rows),'pr_matches':len(report['matching_pr_workflows']),'push_matches':0}))
