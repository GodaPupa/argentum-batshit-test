"""Read original ZIP/decoded job bytes only; never import or run receiving code."""
import ast,gzip,hashlib,json,zipfile
from pathlib import Path

P=Path(__file__).resolve().parent
meta=json.loads((P/'original-github-metadata.json').read_text())['raw']
sources={x['path']:x for x in json.loads((P/'independently-fetched-source.json').read_text())}
compare=json.loads((P/'actual-canonical-to-main-compare.json').read_text())
assert compare['base']==compare['merge_base']=='8ed9787ad75b8bc6c2438a8c0b526ff822aa776e'
main_only={x['path'] for x in compare['files']};assert len(main_only)==14
assert not main_only.intersection(sources)
for path,x in sources.items():
    b=x['content'].encode()
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['sha']
binding=json.loads(sources['sphinx-approach/STAGE_E_CANONICAL_RECEIVING_BINDING.json']['content'])
allowed=set(binding['allowed_qualification_paths']);assert len(allowed)==11
assert not main_only&allowed
rows=[]
for key,ident,run_id,job_id,group,cases,size,sha in [
    ('shared',10920092743,36284779284,108523338837,'shared_actor_50',50,13683,'8a73838da90862cddc0b83a02c1424749b788077ccd1076828abe4ac0b398990'),
    ('sphinx',10919607933,36284779421,108523339173,'sphinx_actor_136',136,19637,'91ecdcb68482af1acba43207fc73aeba007dab8303ca7347ad1d7500b478c788')]:
    f=P/f'original-artifact-{ident}.zip';raw=f.read_bytes();assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha
    run=meta[f'{key}-actor-run'];artifact=meta[f'{key}-actor-artifacts']['artifacts'][0];jobs=meta[f'{key}-jobs']['jobs'];job=jobs[0]
    assert run['id']==run_id and run['run_attempt']==1 and run['conclusion']=='failure'
    assert artifact['id']==ident and artifact['size_in_bytes']==size and artifact['digest']=='sha256:'+sha
    assert job['id']==job_id and job['conclusion']=='failure'
    members=[]
    with zipfile.ZipFile(f) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))
        assert not any(n.endswith('.xml') for n in z.namelist())
        attempt_path=next(n for n in z.namelist() if n.endswith('/attempt.json'))
        a=json.loads(z.read(attempt_path))
        assert a['status']=='REJECTED_BINDING_NO_QUALIFICATION' and a['group']==group
        assert int(a['run_id'])==run_id and a['run_attempt']=='1'
        assert a['head']==a['github_sha']==a['requested_source']=='22cf67791fda69a65d7e1eeb76c2ae369407cb01'
        assert a['tree']=='3b4e50dd7a0fe484b796bb191bd848b048bea12b' and a['checkout_status']==''
        assert a['official_games']==0 and a['gameplay_authorized'] is False
        assert a['exception']['type']=='ValueError'
        prefix='Runtime, test, protocol or unrelated source changed: '
        assert a['exception']['message'].startswith(prefix)
        rejected=ast.literal_eval(a['exception']['message'][len(prefix):]);assert set(rejected)==allowed|main_only and len(rejected)==25
        for n in z.namelist():
            b=z.read(n);row={'member':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
            if '/source/' in n:
                path=n.split('/source/',1)[1]
                assert b==sources[path]['content'].encode()
                assert a['preserved_files_sha256'][path]==row['sha256']
                row['exact_source_git_blob']=sources[path]['sha']
            members.append(row)
    logfile=P/f'{key}-complete-decoded-job.log.gz';lograw=gzip.decompress(logfile.read_bytes());log=lograw.decode()
    assert a['exception']['message'] in log
    assert 'Process completed with exit code 1.' in log
    assert 'Complete job' not in log or log.strip()
    assert not any('Gradle Test Executor' in x and 'started executing tests' in x for x in log.splitlines())
    bank=next(s for s in job['steps'] if ('Execute all 50' in s['name'] or 'Run all 10 shared' in s['name']))
    assert bank['conclusion']=='skipped'
    secondary='source-before.json' in log and 'FileNotFoundError' in log
    assert secondary==(key=='sphinx')
    rows.append({'original_artifact':f.name,'bytes':size,'sha256':sha,'members':members,'run_id':run_id,'job_id':job_id,'run_attempt':1,'event':run['event'],'api_head':run['head_sha'],'observed_checkout':a['head'],'observed_tree':a['tree'],'status':a['status'],'exception':a['exception'],'rejected_paths':rejected,'expected_bank_cases':cases,'actual_bank_executed_cases':0,'xml_members':0,'bank_step':bank,'secondary_collector_missing_source_before':secondary,'job_steps':job['steps'],'decoded_log':{'gzip':logfile.name,'gzip_bytes':logfile.stat().st_size,'gzip_sha256':hashlib.sha256(logfile.read_bytes()).hexdigest(),'decoded_bytes':len(lograw),'decoded_sha256':hashlib.sha256(lograw).hexdigest(),'first_line':log.splitlines()[0],'last_line':log.splitlines()[-1]},'observed_source_hash_scope':'Original emitted maps retained; this audit independently fetched and compared every archived control/authority source, not all runtime files named by those maps.'})
out={'schema':'sphinx-pr175-two-original-actor-binding-failures-audit/v1','disposition':'PRESERVE_ACTUAL_SOURCE_BOUND_REJECTIONS_NO_QUALIFICATION_EXECUTED','rows':rows,'five_unique_archived_sources':[{'path':p,'git_blob_sha1':x['sha'],'sha256':hashlib.sha256(x['content'].encode()).hexdigest()} for p,x in sources.items()],'canonical_allowlist_unchanged':sorted(allowed),'actual_main_only_paths':sorted(main_only),'findings':['Both actual attempt1 failures match the pre-merge static prediction: the exact25 rejected paths equal original11 allowed qualification paths plus14 main-only control/evidence paths.','Neither bank ran:50 and136 are expected fixture identities, not executed counts or Stage-E games.','Sphinx always-run collector then failed because source-before.json was never produced; this secondary failure is retained. Shared actor collection was skipped.','Original ZIPs include every member including helper and authority bytes; no XML exists and no pass outcome is inferred. Connector-decoded complete logs are labeled separately from original archive bytes.','This is a main test-merge receiving guard rejection, not a scientific deck result or rejection of the accepted canonical469335 source.'],'official_games':0,'new_outcomes':0,'source_or_policy_changes':False,'rerun_or_new_test_execution':False,'next_authority':'Separate prospective exact-main source-binding proposal and independent review; unchanged reruns and canonical11 allowlist expansion are not authorized by this audit.'}
(P/'actual-failure-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'members':sum(len(x['members']) for x in rows),'raw_zip_bytes':sum(x['bytes'] for x in rows),'failures':len(rows),'executed_cases':0,'sha256':hashlib.sha256((P/'actual-failure-audit.json').read_bytes()).hexdigest()}))
