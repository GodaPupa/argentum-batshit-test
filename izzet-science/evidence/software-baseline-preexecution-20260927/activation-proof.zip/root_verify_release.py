import ast
import fnmatch
import hashlib
import json
from pathlib import Path
import zipfile
import yaml

ROOT = Path('/workspace/scratch/94f5141e9448')
P = ROOT / 'izzet-takeover/shared-receiving/baseline-qualification-control'
def sha(b): return hashlib.sha256(b).hexdigest()
def gitblob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
meta = json.loads((P/'root-fresh-release-metadata.json').read_text())
obs = [o['value'] for o in meta['observations']]
control = json.loads((P/'prepared-control-remote.json').read_text())
assert obs[0]['sha']==control['parent'] and obs[0]['tree']['sha']=='1a903dc4862d32fdd029e73a916cc9659678db4d'
assert [x['sha'] for x in obs[0]['parents']]==['af8685ec97fd0f56195f25e7d3ca83c609fa018a']
assert obs[1]['sha']==control['prepared_commit'] and obs[1]['tree']['sha']==control['tree']
assert [x['sha'] for x in obs[1]['parents']]==[control['parent']]
assert not obs[2]['truncated']
actual = {e['path']: e for e in obs[2]['tree'] if e['type']=='blob'}
assert set(actual)=={x['path'] for x in control['files']} and len(actual)==3
for x in control['files']:
    b=(ROOT/x['local']).read_bytes()
    assert len(b)==x['bytes'] and sha(b)==x['sha256'] and gitblob(b)==x['git_blob']==actual[x['path']]['sha']
    assert actual[x['path']]['mode']=='100644'
ready=json.loads((P/'final-release/gate.json').read_text())
original=json.loads((P/'gate.json').read_text())
peer_bytes=(P/'pest-independent-control-review.json').read_bytes()
peer=json.loads(peer_bytes)
assert ready['ready_for_execution'] is True
assert ready['source_review']['sha256']==sha(peer_bytes)=='25fbe79dc3c0e5ba9d5a7ac439e49f3a2f362273cb09d458d597395204d24197'
assert ready['source_review']['record']==peer
assert ready['source_review']['archival_location']=='izzet-science/evidence/software-baseline-preexecution-20260927/pest-independent-control-review.json'
ready['ready_for_execution']=False; ready['source_review']=None
assert ready==original
assert sha((json.dumps(ready,indent=2)+'\n').encode())=='de6cce5cb9fb268f9cd8218bd073d170aa959160f66aa23941e101262e4ff889'
functions=lambda path:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
old=functions(ROOT/'izzet-takeover/shared-receiving/scenario-sequence-control/final-release/qualify.py')
new=functions(P/'qualify.py')
assert len(old)==len(new)==9 and all(new[n]==old[n] for n in old if n!='main')
workflows=json.loads((ROOT/'sphinx-audit/izzet-review-workflows-live.json').read_text())
current={e['path']:e for e in obs[3]['tree'] if e['type']=='blob' and e['path'].startswith('.github/workflows/')}
assert set(current)=={w['path'] for w in workflows} and len(current)==111
branches=['lab/izzet-software-baseline-candidate-20260927','review/izzet-shared-receiving-evidence-20260926']
matches={b:[] for b in branches}
workflow_pins=[]
for w in workflows:
    raw=w['content'].encode(); assert gitblob(raw)==current[w['path']]['sha']==w['sha']
    data=yaml.load(raw,Loader=yaml.BaseLoader); on=data.get('on',{})
    push=('push' in on) if isinstance(on,(dict,list)) else on=='push'
    if push:
        cfg=on.get('push') if isinstance(on,dict) else None
        positives=[x for x in cfg.get('branches',[]) if not x.startswith('!')] if isinstance(cfg,dict) else []
        for branch in branches:
            if not positives or any(fnmatch.fnmatchcase(branch,p) for p in positives): matches[branch].append(w['path'])
    workflow_pins.append({'path':w['path'],'git_blob':gitblob(raw),'sha256':sha(raw)})
assert all(not x for x in matches.values()),matches
wf=yaml.load((P/'final-release/izzet-software-baseline-qualification.yml').read_text(),Loader=yaml.BaseLoader)
assert wf['on']=={'push':{'branches':[control['branch']]}}
assert "github.event.before == '0000000000000000000000000000000000000000' && github.run_attempt == 1" in wf['jobs']['original-deterministic-banks']['if']
ap=P/'preexecution-publication/izzet-science/evidence/software-baseline-preexecution-20260927'
index=json.loads((ap/'preparation-index.json').read_text()); data=(ap/'preparation-proof.zip').read_bytes()
assert sha(data)==index['archive_sha256'] and len(data)==index['archive_bytes']
with zipfile.ZipFile(ap/'preparation-proof.zip') as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(index['members'])==25
    for e in index['members']:
        b=z.read(e['path']); assert len(b)==e['bytes'] and sha(b)==e['sha256']
        local=P/e['path'].removeprefix('control/') if e['path'].startswith('control/') else ROOT/'pest-takeover/izzet-baseline-control-review'/e['path'].removeprefix('independent-review/')
        assert local.read_bytes()==b,(e['path'],str(local))
archive=json.loads((P/'prepared-archive-remote.json').read_text())
assert obs[4]['sha']==archive['prepared_commit'] and obs[4]['tree']['sha']==archive['tree']
assert [x['sha'] for x in obs[4]['parents']]==[archive['parent']]
assert obs[5]['total_commits']==1 and obs[5]['ahead_by']==1 and obs[5]['behind_by']==0
assert len(obs[5]['files'])==4 and obs[6]['object']['sha']==archive['parent']
for e in archive['elements']:
    b=(P/'preexecution-publication'/e['path']).read_bytes()
    assert gitblob(b)==e['sha']==next(x['sha'] for x in obs[5]['files'] if x['filename']==e['path'])
event=json.loads((P/'root-fresh-event-and-comparison-check.json').read_text())
comparison=event['records'][0]['value']
assert comparison['ahead_by']==1 and comparison['behind_by']==0 and comparison['total_commits']==1 and len(comparison['files'])==7
assert comparison['files']==json.loads((P/'root-exact-source-comparison.json').read_text())['files']
for record in event['records'][1:]:
    if record['path'].startswith('git/ref/'):
        assert record['isError'] and record['value']['error_code']=='NOT_FOUND'
    elif record['path'].startswith('actions/'):
        assert not record['isError'] and record['value']['total_count']==0
    else: assert not record['isError'] and record['value']==[]
report={'schema':'root-single-baseline-release-byte-proof-v1','read_only':True,'source':obs[0]['sha'],'tree':obs[0]['tree']['sha'],'control':obs[1]['sha'],'control_tree':obs[1]['tree']['sha'],'control_files':control['files'],'gate_normalization':'Only readiness and exact embedded independent review; reproduces de6c bytes','unchanged_helper_ASTs':8,'source_changed_paths':7,'inherited_workflow_bodies':111,'inherited_possible_push_matches_ignoring_paths_and_negative_exclusions':matches,'workflow_pins':workflow_pins,'archive_members':25,'archive_sha256':index['archive_sha256'],'prepared_evidence':archive['prepared_commit'],'fresh_metadata':meta['observed_at'],'fresh_event_checks':event['at'],'executed_engine_cases':0,'official_games':0}
(P/'root-release-byte-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('workflow_pins','control_files')},indent=2))
