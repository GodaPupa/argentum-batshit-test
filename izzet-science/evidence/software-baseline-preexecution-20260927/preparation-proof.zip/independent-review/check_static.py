"""Read-only checks: no collector import, subprocess, engine or test execution."""
from pathlib import Path
import ast, hashlib, json, zipfile, xml.etree.ElementTree as E, difflib
p=Path('izzet-takeover/shared-receiving/baseline-qualification-control')
b=p.parent/'scenario-sequence-control'
out=Path('pest-takeover/izzet-baseline-control-review')
g=json.loads((p/'gate.json').read_text())
h=lambda x:hashlib.sha256(x).hexdigest()
fn=lambda path:{x.name:ast.dump(x,include_attributes=False) for x in ast.parse(path.read_text()).body if isinstance(x,ast.FunctionDef)}
f=fn(p/'qualify.py');of=fn(b/'qualify.py');same=[n for n in f if f[n]==of[n]]
assert len(same)==8 and set(f)-set(same)=={'main'}
for x in json.loads((out/'exact-authority-bodies.json').read_text()):
    assert h(x['body'].encode())==g['preserved_authority_sha256'][x['path']]
live=json.loads((out/'live-metadata-and-source.json').read_text());c=json.loads(live[0]['data'])
assert c['sha']==g['source_head'] and c['tree']['sha']==g['source_tree']
assert [x['sha'] for x in c['parents']]==['af8685ec97fd0f56195f25e7d3ca83c609fa018a']
assert all(x['isError'] and x['data']['error_code']=='NOT_FOUND' for x in live[1:3])
assert json.loads(live[3]['data'])['total_count']==0
baseline=live[4]['data'].encode();bank=g['banks'][0]
assert h(baseline)==g['preserved_authority_sha256'][bank['test_source']]
assert hashlib.sha1(b'blob '+str(len(baseline)).encode()+b'\0'+baseline).hexdigest()==bank['test_source_git_blob']
assert baseline==Path('izzet-takeover/shared-receiving/baseline-expectation-candidate/candidate/FrozenBaselineTest.kt').read_bytes()
zp=Path('attachments/731e4675-260a-4563-8338-94a4dc6b1452/izzet-six-case-diagnostic-original-10919123143.zip')
assert h(zp.read_bytes())==bank['original_archive_sha256']
z=zipfile.ZipFile(zp);assert z.testzip() is None
raw=z.read(bank['original_xml_path']);assert h(raw)==bank['original_xml_sha256']
xml=E.fromstring(raw);cases=xml.findall('testcase')
assert xml.get('name')==bank['class'] and xml.get('tests')=='1' and xml.get('failures')=='1'
assert [x.get('name')for x in cases]==bank['case_names']
comp=json.loads((p/'root-exact-source-comparison.json').read_text())
assert comp['merge_base_commit']['sha']==c['parents'][0]['sha'] and len(comp['files'])==7
paths=[x['filename']for x in comp['files']]
expected=[bank['test_source']]+['izzet-science/software-baseline-disposition-20260927/'+n for n in ['governance-proposal.md','independent-governance-review.json','independent-source-review.json','source-and-governance-proof.zip','source-proof-index.json','unresolved-default-strategy.md']]
assert sorted(paths)==sorted(expected)
for target,base in [('qualify.py','qualify.py'),('gate.json','gate.json'),('izzet-software-baseline-qualification.yml','izzet-scenario-sequence-qualification.yml')]:
    diff=''.join(difflib.unified_diff((b/base).read_text().splitlines(True),(p/target).read_text().splitlines(True),fromfile='reviewed-c658/'+base,tofile='candidate/'+target))
    assert diff==(p/(target+'.diff')).read_text()
r={'scope':__doc__,'same_function_ASTs':same,'changed_function':'main: schema, exact branch and bank/case totals only','authority_pin_count':12,'all_pins_rehashed_from_independent_fixed60d_raw_fetch':True,'prepared_source_commit':c['sha'],'tree':c['tree']['sha'],'parent':c['parents'][0]['sha'],'source_delta_paths_from_root_fresh_compare':paths,'raw_original_XML':{'sha256':h(raw),'cases':len(cases),'failures':int(xml.get('failures')),'names':[x.get('name')for x in cases]},'candidate_baseline_bytes':len(baseline),'candidate_baseline_sha256':h(baseline),'candidate_baseline_git_blob':bank['test_source_git_blob'],'diffs_reproduced_exactly':3,'both_branches_NOT_FOUND':True,'current_source_head_runs':0,'ready':g['ready_for_execution'],'source_review':g['source_review'],'files':{n:{'bytes':(p/n).stat().st_size,'sha256':h((p/n).read_bytes())}for n in ['qualify.py','gate.json','izzet-software-baseline-qualification.yml']},'audit_history':'Initial inline check assumed six evidence paths used izzet-science/evidence/ and rejected that reviewer assumption; actual six software-baseline-disposition-20260927 paths inspected and explicitly enumerated here. No candidate or run mutation.'}
(out/'independent-static-checks.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
