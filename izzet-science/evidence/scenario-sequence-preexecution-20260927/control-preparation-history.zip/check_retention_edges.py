#!/usr/bin/env python3
"""Python-only guards; never launches the engine or a qualification command."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
os.environ.setdefault("GITHUB_WORKSPACE", str(HERE))
spec = importlib.util.spec_from_file_location("qualification_under_test", HERE / "qualify.py")
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
checks = []

with tempfile.TemporaryDirectory(prefix="izzet-five-guards-", dir="/dev/shm") as temporary:
    root = Path(temporary)
    for label, gate_bytes in (("malformed_gate", b"{broken"),
                              ("rejected_readiness", b'{"ready_for_execution":false,"source_review":null}')):
        q.ROOT = root / label
        q.CONTROL = q.ROOT / "control"
        q.CHECKOUT = q.ROOT / "source"
        q.OUT = q.ROOT / "output"
        for path in q.CONTROL_PATHS:
            target = q.CONTROL / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(gate_bytes if path == "gate.json" else ("synthetic-" + path).encode())
        os.environ.update(GITHUB_REPOSITORY="GodaPupa/argentum-batshit-test",
                          GITHUB_RUN_ATTEMPT="1", GITHUB_EVENT_NAME="push", GITHUB_SHA="synthetic-head")
        def fake_git(unused, *args):
            return {("rev-parse", "HEAD"): "synthetic-head", ("status", "--porcelain"): "",
                    ("ls-files",): "\n".join(q.CONTROL_PATHS)}[args]
        q.git = fake_git
        q.source_snapshot = lambda unused: (_ for _ in ()).throw(AssertionError("must not access engine source"))
        try:
            q.main()
            raise AssertionError("Preflight rejection must raise")
        except (json.JSONDecodeError, AssertionError) as error:
            assert str(error) != "Preflight rejection must raise"
        audit = json.loads((q.OUT / "audit.json").read_text())
        assert audit["status"] == "INCOMPLETE" and len(audit["errors"]) == 1 and not audit["stages"]
        assert set(audit["control_files_sha256"]) == set(q.CONTROL_PATHS)
        for path in q.CONTROL_PATHS:
            retained = (q.OUT / "control" / path).read_bytes()
            assert retained == (q.CONTROL / path).read_bytes()
            assert hashlib.sha256(retained).hexdigest() == audit["control_files_sha256"][path]
        checks.append({"check": label, "pass": True, "error": audit["errors"][0],
                       "controls_retained": 3, "engine_commands": 0})

    for label, sizes, expected_reason in (("final_aggregate_exceeds_limit", [6, 6], "TEST_RESULT_BYTE_LIMIT"),
                                           ("final_file_requires_prefix", [12], "INCOMPLETE_XML_BYTE_LIMIT")):
        q.ROOT = root / label
        q.CHECKOUT = q.ROOT / "source"
        q.OUT = q.ROOT / "output"
        q.OUT.mkdir(parents=True)
        bank = {"stage": "SyntheticOnly", "scope": "local-resource-guard", "class": "synthetic.Class",
                "module": "synthetic", "expected_cases": 1, "case_names": ["never interpreted"]}
        def final_flush(unused_command, unused_root, log_path, reports, unused_out, unused_limits):
            reports.mkdir(parents=True, exist_ok=True)
            for index, size in enumerate(sizes):
                (reports / f"TEST-synthetic{index}.xml").write_bytes(b"x" * size)
            log_path.write_bytes(b"synthetic-only; no child command\n")
            return {"exit_status": 0, "technical_limit": None, "stdout_retained_bytes": log_path.stat().st_size,
                    "discarded_observed_pipe_bytes": 0, "output_complete": True, "elapsed_seconds": 0}
        q.run_capped = final_flush
        q.collect_xml = lambda *args: (_ for _ in ()).throw(AssertionError("must not interpret oversized XML"))
        limits = {"test_result_bytes": 10, "artifact_bytes": 5 * 1024 * 1024}
        result = q.run_bank(bank, 1, limits)
        assert result["technical_limit"] == expected_reason and not result["output_complete"]
        assert result["observed_report_bytes_after_exit"] == sum(sizes)
        assert result["status"] == "FAILED_PRESERVED_FOR_REVIEW" and "actual" not in result
        assert "Technical resource stop" in result["error"]
        assert all(item["retained_bytes"] <= 10 for item in result["xml_retention"])
        checks.append({"check": label, "pass": True, "observed_report_bytes": sum(sizes),
                       "technical_limit": expected_reason, "retained": result["xml_retention"], "engine_commands": 0})

report = {"schema": "izzet-five-case-retention-edge-guards-v1", "scope": "Python-only synthetic control guards",
          "script_sha256": hashlib.sha256((HERE / "qualify.py").read_bytes()).hexdigest(),
          "check_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "checks": checks, "passed": len(checks), "engine_commands": 0, "official_games": 0}
(HERE / "retention-edge-guard-check.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"passed": len(checks), "engine_commands": 0, "script_sha256": report["script_sha256"]}))
