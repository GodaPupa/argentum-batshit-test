#!/usr/bin/env python3
"""Read-only audit of the two completed original qualification commands."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
ORIGINAL = ROOT / 'attachments/d4d79b99-0b3e-4bd5-8e61-5929990b7101/izzet-five-sequence-original-10920303876.zip'
WRAPPER = Path('/workspace/scratch/dcc9d005d11f/shared-work/gradle/wrapper/gradle-wrapper.jar')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def main():
    raw = ORIGINAL.read_bytes()
    assert len(raw) == 259224 and sha(raw) == 'a061f984897a77464c98b4ed3e0b9e6325d02edc562314a7bd4b8ff6379acacf'
    tree = json.loads((BASE / 'root-current-pin-tree.json').read_text())
    pins = {r['path']: r for r in tree['files']}
    report = {'schema': 'izzet-five-original-independent-root-raw-audit-v1',
              'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'original_sha256': sha(raw), 'original_bytes': len(raw),
              'members': [], 'banks': [], 'verified_source_bodies': []}
    with zipfile.ZipFile(ORIGINAL) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 14
        for name in z.namelist():
            data = z.read(name)
            report['members'].append({'name': name, 'bytes': len(data), 'sha256': sha(data)})
        audit = json.loads(z.read('audit.json'))
        gate = json.loads(z.read('control/gate.json'))
        assert audit['run_id'] == '36285812386' and audit['attempt'] == '1' and audit['event'] == 'push'
        assert audit['source_head'] == gate['source_head'] == 'af8685ec97fd0f56195f25e7d3ca83c609fa018a'
        assert audit['source_tree'] == gate['source_tree'] == 'b46e165748abf32b2c8856052e5df3d8ffa910f9'
        assert audit['control_head'] == '58802ba41a246cfd6acfbb4cd6298daa61066ed4'
        assert not audit['errors'] and audit['status'] == 'PASS_REQUIRES_INDEPENDENT_ARTIFACT_REVIEW'
        assert audit['official_games'] == audit['official_seeds'] == audit['new_pilot_cases'] == 0
        assert audit['gameplay_authorized'] is False and audit['full_runtime_accepted'] is False
        assert z.read('source-before.json') == z.read('source-after.json')
        before = json.loads(z.read('source-before.json'))
        assert before == audit['source_before'] == audit['source_after'] and before['status'] == ''
        assert before['authority_sha256'] == gate['preserved_authority_sha256']
        for path, expected in audit['control_files_sha256'].items():
            data = z.read('control/' + path)
            assert sha(data) == expected
            local = BASE / 'final-release' / (Path(path).name)
            assert data == local.read_bytes()
        assert len(audit['stages']) == len(gate['banks']) == 2
        identities = []
        for index, (bank, stage) in enumerate(zip(gate['banks'], audit['stages']), 1):
            folder = f"{index:02d}-{bank['stage']}/"
            assert json.loads(z.read(folder + 'command.json')) == stage
            assert z.read(folder + 'exit-status.txt') == b'0\n'
            assert stage['exit_status'] == 0 and stage['technical_limit'] is None
            assert stage['output_complete'] is True and stage['discarded_observed_pipe_bytes'] == 0
            assert stage['status'] == 'PASS_PRESERVED_CASE_IDENTITIES'
            data = z.read(folder + f"TEST-{bank['class']}.xml")
            xml = ET.fromstring(data)
            assert xml.tag == 'testsuite' and xml.attrib['name'] == bank['class']
            assert all(int(xml.attrib.get(k, 0)) == 0 for k in ('failures', 'errors', 'skipped'))
            assert not any(xml.findall('.//' + k) for k in ('failure', 'error', 'skipped'))
            cases = xml.findall('testcase')
            names = [c.attrib['name'] for c in cases]
            assert len(cases) == int(xml.attrib['tests']) == bank['expected_cases']
            assert len(names) == len(set(names)) and sorted(names) == sorted(bank['case_names'])
            assert all(c.attrib['classname'] == bank['class'] for c in cases)
            identities.extend((bank['class'], name) for name in names)
            timestamp = datetime.datetime.fromisoformat(xml.attrib['timestamp']).replace(tzinfo=datetime.timezone.utc).timestamp()
            assert stage['started_ns'] / 1e9 - 2 <= timestamp <= stage['finished_ns'] / 1e9 + 2
            assert sha(data) == stage['actual']['xml_sha256'] == stage['xml_retention'][0]['sha256']
            assert stage['xml_retention'][0]['complete'] is True
            log = z.read(folder + 'command.log')
            assert len(log) == stage['stdout_retained_bytes']
            lines = log.decode().splitlines()
            task = ':' + bank['module'].replace('/', ':') + ':test'
            assert sum(line.strip() == '> Task ' + task for line in lines) == 1
            assert not any(line.strip() == '> Task ' + task + ' ' + suffix for line in lines
                           for suffix in ('NO-SOURCE', 'UP-TO-DATE', 'FROM-CACHE', 'SKIPPED', 'FAILED'))
            starts = [line for line in lines if 'Gradle Test Executor' in line and 'started executing tests' in line]
            ends = [line for line in lines if 'Gradle Test Executor' in line and 'finished executing tests' in line]
            assert len(starts) == len(ends) == 1 and any(line.startswith('BUILD SUCCESSFUL') for line in lines)
            report['banks'].append({'class': bank['class'], 'cases': len(cases), 'names': names,
                                    'xml_sha256': sha(data), 'log_sha256': sha(log),
                                    'exit': 0, 'fresh_required_tasks': 1, 'worker_starts': len(starts),
                                    'worker_finishes': len(ends), 'failures': 0, 'errors': 0, 'skips': 0})
        assert len(identities) == len(set(identities)) == 5
        source = json.loads((BASE / 'completed-source-pins.json').read_text())
        values = {}
        for row in source['results']:
            if row['path'] == 'gradle/wrapper/gradle-wrapper.jar':
                assert row['result'].get('isError') is True
                continue
            result = row['result']['structuredContent']
            assert row['ref'] == audit['source_head'] and result['encoding'] == 'utf-8'
            data = result['content'].encode()
            assert blob(data) == result['sha'] == pins[row['path']]['sha']
            values[row['path']] = sha(data)
            report['verified_source_bodies'].append({'path': row['path'], 'sha256': sha(data), 'git_blob': blob(data),
                                                    'provenance': 'retained exact-ref fetch, independently rehashed and fresh-tree-bound'})
        data = WRAPPER.read_bytes()
        assert len(data) == 48462 and blob(data) == pins['gradle/wrapper/gradle-wrapper.jar']['sha']
        values['gradle/wrapper/gradle-wrapper.jar'] = sha(data)
        report['verified_source_bodies'].append({'path': 'gradle/wrapper/gradle-wrapper.jar', 'bytes': len(data),
                                                'sha256': sha(data), 'git_blob': blob(data),
                                                'provenance': 'read-only original local file ' + str(WRAPPER)})
        assert len(values) == 20
        for path, expected in {**gate['preserved_authority_sha256'], **audit['dependency_files_sha256']}.items():
            assert values[path] == expected
        for bank in gate['banks']:
            assert before['test_source_git_blobs'][bank['test_source']] == bank['test_source_git_blob'] == pins[bank['test_source']]['sha']
        report.update({'source': audit['source_head'], 'tree': audit['source_tree'], 'control': audit['control_head'],
                       'actual_case_count': 5, 'source_before_after_equal_clean': True,
                       'artifact_control_bytes_equal_reviewed_release': True,
                       'source_body_count': 20, 'status': 'PASS_BOUNDED_TWO_CORRECTED_SCENARIOS'})
    (BASE / 'root-five-original-checks.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'source', 'tree', 'actual_case_count', 'source_body_count')}))

if __name__ == '__main__':
    main()
