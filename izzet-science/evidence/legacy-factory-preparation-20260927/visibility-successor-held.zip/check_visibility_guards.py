"""Exact AST functions with in-memory process records only; no live process or signal."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

SOURCE = Path(__file__).with_name('qualify.py')
EXPECTED = 'ed3c72a1fa5494598f212d0981e37eb0f6cf1c9116bf61938f2fa8dca9ad88e8'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
functions = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef)
             and node.name in ('owned_group_members', 'terminate_owned_group')]
assert len(functions) == 2

def check(mode, expected_complete, expected_quiescent):
    saved = []
    namespace_reads = []
    class FakePath:
        def __init__(self, value):
            self.value = str(value)
            self.name = self.value.rsplit('/', 1)[-1]
        def __truediv__(self, other):return FakePath(self.value + '/' + str(other))
        def iterdir(self):
            if mode == 'enumeration_denied':raise PermissionError('synthetic proc enumeration denied')
            return iter([FakePath('/proc/12345')])
        def read_text(self):
            if mode == 'entry_vanished':raise FileNotFoundError('synthetic entry exit')
            if self.value.endswith('/status'):
                if mode == 'status_denied':raise PermissionError('synthetic status denied')
                if mode == 'group_parse_error':return 'NSpgid: invalid\nNSsid: 77\nNSpid: 88\n'
                group = 99 if mode == 'foreign_group_unreadable_namespace' else 77
                return f'NSpgid: 100 {group}\nNSsid: 100 {group}\nNSpid: 101 88\n'
            if mode == 'candidate_stat_parse_error':return 'malformed stat'
            return '12345 (synthetic process) Z ' + ' '.join(['0'] * 18) + ' 123'
    class FakeOS:
        @staticmethod
        def readlink(path):
            value = path.value if isinstance(path, FakePath) else path
            namespace_reads.append(value)
            if mode == 'self_namespace_denied' and value == '/proc/self/ns/pid':raise PermissionError('synthetic self namespace denied')
            if value != '/proc/self/ns/pid':
                if mode in ('candidate_namespace_denied', 'foreign_group_unreadable_namespace'):
                    raise PermissionError('synthetic candidate namespace denied')
                if mode == 'foreign_namespace':return 'pid:[different]'
            return 'pid:[same]'
        @staticmethod
        def killpg(*args):raise AssertionError('No signaling path expected in this static guard')
    class ExitedWrapper:
        pid = 77
        def poll(self):return 0
        def wait(self, timeout=None):return 0
    env = {'Path':FakePath, 'os':FakeOS, 'signal':SimpleNamespace(SIGTERM=15, SIGKILL=9),
           'time':SimpleNamespace(), 'dump':lambda destination, record:saved.append(copy.deepcopy(record))}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(SOURCE), 'exec'), env)
    actual = env['terminate_owned_group'](ExitedWrapper(), 'in-memory-destination')
    assert saved and saved[0]['scans'] == 0 and saved[0]['quiescent'] is False
    assert actual['observation_complete'] is expected_complete
    assert actual['quiescent'] is expected_quiescent
    assert actual['signals'] == []
    assert bool(actual['errors']) is (not expected_complete)
    assert saved[-1] == actual
    if mode == 'foreign_group_unreadable_namespace':
        assert all(path == '/proc/self/ns/pid' for path in namespace_reads)
        assert actual['after_observation']['excluded']['nonmatching_group_or_session'] == 1
    return {'mode':mode, 'passed':True, 'actual':actual, 'durable_mock_writes':len(saved)}

cases = [check(mode, False, False) for mode in ('status_denied','candidate_namespace_denied',
         'group_parse_error','candidate_stat_parse_error','enumeration_denied','self_namespace_denied')]
cases += [check(mode, True, True) for mode in ('entry_vanished','foreign_group_unreadable_namespace',
          'foreign_namespace','known_zombie')]
result = {'source_sha256':EXPECTED, 'scope':'Pure in-memory AST guards; no process/proc/signal/JVM/package operation',
          'passed':len(cases), 'cases':cases}
Path(__file__).with_name('local-visibility-guard-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_sha256':EXPECTED,'passed':len(cases),'scope':result['scope']}))
