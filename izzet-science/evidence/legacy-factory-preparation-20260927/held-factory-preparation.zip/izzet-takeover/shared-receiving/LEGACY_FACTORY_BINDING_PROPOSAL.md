# Proposed structural factory selection for frozen v0

This is a revised review proposal only. `AIPlayer.kt`, `AiProfile.kt`, `DecisionResponder.kt` and existing strategy selections remain unmodified. The original id-only proposal is preserved separately; nonauthor review `fbd3705220c65cb4` identified that a public data class can retain id=v0 while changing other configuration.

The proposed insertion at the existing DecisionResponder construction in AIPlayer.compose is:

```kotlin
yesNoStrategy = if (profile == AiProfile.LEGACY_V0) {
    YesNoDecisionStrategy.LEGACY_SIMULATE_BOTH_V1
} else {
    YesNoDecisionStrategy.COMPLETED_BRANCH_V1
},
```

Use Kotlin data-class structural equality, not the identifier alone. The frozen object and an equal copy receive the original simulate-both strategy. A configuration that changes any profile constructor property, even while retaining id=v0, does not silently receive this restoration. The exact-source AiProfile constructor includes the id, advisor modules, evaluation-weight identifier, budget policy and all behavior flags/settings; its reference has empty advisor modules, the singleton legacy budget, null rollout settings and the frozen default values. This stronger identity guard needs independent review. It does not claim a complete inventory of all external callers or that every configuration mislabeled v0 is equivalent. A mutable or intentionally changed profile remains subject to its own pilot/source binding.

No global responder default or profile fields change. Industrial's explicit legacy choices in its official FullHorizonRunner and CapabilityRunner remain untouched. Other profiles and direct responder constructors retain current strategy selection. Manual's distinct historical unselected completed-branch boundary remains outside this repair.

## Behavioral regression requirements before source acceptance

The public factory and respondToDecision must be exercised. Reuse the existing harmful-singleton/empty-selection-tie optional shape from DecisionResponderCompletedBranchTest: taking its card loses life, while selecting no card ties declining. Do not infer a distinguishing result before actual execution.

Hold every evaluator and profile behavior input equal. A factory with the exact frozen profile and a factory with `AiProfile.LEGACY_V0.copy(id = "v0-completed-control")` differ only in their identity label and the proposed strategy selection; the current composition does not otherwise feed that label into evaluation. Explicit direct legacy/completed responder controls must be constructed with the same resolved evaluation vector, budget, intents, advisor configuration and simulator behavior as the factory. Production-candidate versus v0 alone is insufficient because their evaluator/profile settings differ.

Require actual evidence that the intended legacy assertion fails through the pre-fix factory and passes through the corrected factory on this same decision/state. The retained completed control must decline and remain unchanged. A structurally equal copy must behave like the frozen object; a deliberately altered behavior configuration retaining id=v0 must not pass the structural guard. Verify evaluation does not mutate the authoritative state. Keep the existing seven completed-branch cases byte-identical and require their fresh execution. Define the exact finite case/source/event plan after source review; this proposal itself authorizes no run, fixture count or experimental pilot-development expenditure.

## Exact source inventory and frozen factory path

The read-only recovery is now complete for all 24,628 tracked Kotlin, Java and Kotlin build-source files in immutable8b/tree4f913466. Existing source-archive bytes match 23,760 current Git blobs; another116 bodies were recovered and rehashed from retained JSON source responses; the final752 were recovered by exact blob identity from existing historical Git object stores. No fetch, checkout, index refresh, code modification or build was used for that recovery. Sixty files contain AiProfile or AIPlayer.create references. The exact source/body hashes and matching excerpts are recorded in `legacy-complete-language-caller-inventory.json`; the original partial inventories remain preserved. External callers, generated code and nonlanguage configuration are outside this text inventory; no global absence claim extends to them.

The original accepted50eca ArenaAgent.kt was independently fetched and equals current blob42602b1ee977eebaa102e74ac60421effc78d181. Its ArenaAgents built-in v0 entry passes AiProfile.LEGACY_V0, and ArenaAgent.createPlayer forwards that exact profile to AIPlayer.create. AiProfile.kt and AIPlayer.kt are unchanged old/current Git blobs in the complete retained AI-source binding map. The named reference remains AiProfile(id="v0"). Inspected named variants derived from LEGACY_V0 explicitly change their ids (advisor, blind, meaningful, budget and evaluator variants); no such observed variant is relabeled as the frozen object. Public construction remains possible, so the proposed structural predicate deliberately does not depend on the absence of arbitrary external id reuse.

AIPlayer.respondToDecision delegates directly to the responder; useMeaningfulFilter is consulted in action selection, not this response path. Thus an id-preserving useMeaningfulFilter=true profile is a useful structural-negative control without changing this decision's evaluator or responder inputs.

## Concrete proposed source and finite regression scope

After independent scope review, propose only the named strategy argument at AIPlayer.compose and a new AIPlayerLegacyYesNoStrategyTest.kt file. Keep DecisionResponder, GameSimulator, AiProfile, all explicit strategy users and existing seven DecisionResponderCompletedBranchTest cases unchanged. No SDK or other owner's entry consumers are involved.

Two prospective behavioral cases are proposed, not yet implemented or executed:

1. On the existing harmful-singleton/empty-tie state, the exact frozen factory and a structurally equal copy must match the explicit legacy responder and accept; an otherwise identical profile with only a different control id must match explicit completed strategy and decline. Both explicit responders must use the same resolved evaluation vector, legacy budget, no advisor overrides/intents, and identical simulator settings as the factory. Preserve original state across all decisions. This intended frozen-factory assertion must fail on the pre-fix source and pass after the binding change; do not replace it with reflection or enum-field checks.
2. On that same state, AiProfile.LEGACY_V0.copy(useMeaningfulFilter=true) retains id=v0 but is structurally different and must keep completed behavior. Its action-filter flag is outside respondToDecision, so this negative isolates the predicate without using different evaluation weights.

A later reviewed qualification should execute those same two new cases on the unmodified factory (requiring the specific observed regression failure, not a generic command failure), then on the corrected factory, and retain the seven original completed-branch cases on the corrected source. That would be11 software case executions across9 identities, not11 independent pilot or game cases. No event or budget is granted by this proposal, and unexpected before/after behavior requires investigation rather than changing the fixture to obtain the expected direction.

No implementation, compiler run, golden adoption, gameplay execution or policy qualification has occurred. All programs retain separate exact pilot/actor and information-boundary admission requirements.
