#!/usr/bin/env python3
"""Reviewer-owned Python process check only. Does not execute repository fixtures."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import signal
import sys
import tempfile
import time

control = Path(sys.argv[1])
assert hashlib.sha256(control.read_bytes()).hexdigest() == "b23b6d0256eeccffb999c7eb2b192e55a84b795dcdf12a0a25193dcb18624d66"
with tempfile.TemporaryDirectory(prefix="manual-control-review-") as temporary:
    root = Path(temporary)
    (root / "output").mkdir()
    reports = root / "reports"
    reports.mkdir()
    os.environ["GITHUB_WORKSPACE"] = str(root)
    spec = importlib.util.spec_from_file_location("manual_diagnostic_control_review", control)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    code = """import os,time,sys,json
child=os.fork()
if child:
 print(json.dumps({'leader':os.getpid(),'child':child}),flush=True)
 os._exit(0)
os.close(1);os.close(2)
with open(sys.argv[1],'wb',buffering=0) as f:
 for _ in range(40):
  f.write(b'x');time.sleep(.02)
os._exit(0)
"""
    log = root / "output" / "probe.log"
    result = module.run_capped(
        [sys.executable, "-I", "-B", "-c", code, str(reports / "writer")],
        root, log, reports,
        {"stdout_bytes": 65536, "test_result_bytes": 65536, "artifact_bytes": 8388608},
        dict(os.environ), 2,
    )
    ids = json.loads(log.read_text())
    try:
        before = (reports / "writer").stat().st_size
        time.sleep(.15)
        after = (reports / "writer").stat().st_size
    finally:
        try:
            os.killpg(ids["leader"], signal.SIGKILL)
        except ProcessLookupError:
            pass
    assert result["exit_status"] == 0 and result["output_complete"] and after > before
    print(json.dumps({"result": result, "bytes_at_return": before, "bytes_after150ms": after}))
