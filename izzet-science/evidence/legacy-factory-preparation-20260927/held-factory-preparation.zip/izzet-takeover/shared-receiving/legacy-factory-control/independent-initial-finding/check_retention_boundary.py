"""Synthetic source-observation failure only; no subprocess, JVM, fixture or game."""
from pathlib import Path
import ast, hashlib, json, tempfile

HERE=Path(__file__).resolve().parent
source=Path('izzet-takeover/shared-receiving/legacy-factory-control/qualify.py')
raw=source.read_bytes(); tree=ast.parse(raw)
selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['dump','sha','source_snapshot']]
ns={'Path':Path,'json':json,'hashlib':hashlib}
exec(compile(ast.Module(body=selected,type_ignores=[]),str(source),'exec'),ns)
results=[]
with tempfile.TemporaryDirectory(prefix='legacy-control-retention-only-') as td:
    root=Path(td);(root/'before').mkdir();ns['ROOT']=root;ns['SOURCES']={'before':('h','t')}
    ns['git']=lambda root,*args: {'HEAD':'h','HEAD^{tree}':'t','--porcelain':''}[args[-1]]
    gate={'production_path':'absent-production.kt','preserved_authority_sha256':{},'dependency_sha256':{},'banks':[],'sources':{'before':{'head':'h','tree':'t','production_sha256':'unused'}}}
    target=root/'source-before.json'
    try:ns['source_snapshot'](gate,'before',target)
    except Exception as error:results.append({'case':'missing production source before first observation dump','error':type(error).__name__+': '+str(error),'snapshot_exists':target.exists(),'actual_identity_retained':target.exists()})
    assert len(results)==1 and not results[0]['snapshot_exists']
report={'scope':'Read-only independent review reproduction. Python source_snapshot AST only, stub Git, synthetic temporary empty source path. No real fixture, runtime, process launch, source edit, ref or event.','source_sha256':hashlib.sha256(raw).hexdigest(),'results':results,'finding':'Pre-release actual-source retention gap: production read occurs before the first dump, losing observed source identity on an early source read error.','required_correction':'Record runtime/control identity and per-path observed hash or explicit read error durably before expected-pin comparisons; retain exact rejected source observation and bounded exception. Add a focused synthetic negative assertion for missing/unreadable production and authority pins. Preserve prior candidate and checks; do not change fixture/runtime/commands/banks/caps.'}
(HERE/'initial-retention-finding.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
