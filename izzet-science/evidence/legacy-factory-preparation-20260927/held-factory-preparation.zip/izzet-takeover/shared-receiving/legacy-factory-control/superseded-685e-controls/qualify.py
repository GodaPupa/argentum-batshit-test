#!/usr/bin/env python3
"""Bounded same-input factory differential. No experiment execution or policy admission."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import selectors
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(os.environ['GITHUB_WORKSPACE'])
CONTROL = ROOT / 'control'
OUT = ROOT / 'output'
CONTROL_PATHS = ['.github/workflows/izzet-legacy-factory-qualification.yml', 'qualify.py', 'gate.json']
SOURCES = {
    'before': ('af16191eba3c93efa40f4ab28c2454b4b3c23d88', 'e9aba19e87a05fd6844b536d394b143f8e8a4235'),
    'fixed': ('e825589e1deff9de09f4ffe78aece41dc5ac0df9', '52932b643bc05419435996655903044f798e9f3e'),
}

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def source_snapshot(gate, role, destination):
    root = ROOT / role
    result = {'role': role, 'head': git(root, 'rev-parse', 'HEAD'),
              'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
              'status': git(root, 'status', '--porcelain'),
              'authority_sha256': {}, 'test_source_git_blobs': {}, 'dependency_sha256': {},
              'production_sha256': sha(root / gate['production_path'])}
    # Retain actual observations before checking expected identities.
    dump(destination, result)
    for path in gate['preserved_authority_sha256']:
        result['authority_sha256'][path] = sha(root / path)
        dump(destination, result)
    for path in gate['dependency_sha256']:
        result['dependency_sha256'][path] = sha(root / path)
        dump(destination, result)
    for bank in gate['banks']:
        path = bank['test_source']
        result['test_source_git_blobs'][path] = git(root, 'hash-object', path)
        dump(destination, result)
    assert (result['head'], result['tree']) == SOURCES[role]
    assert result['head'] == gate['sources'][role]['head']
    assert result['tree'] == gate['sources'][role]['tree']
    assert not result['status'], 'Source checkout must be completely clean'
    assert result['authority_sha256'] == gate['preserved_authority_sha256']
    assert result['dependency_sha256'] == gate['dependency_sha256']
    assert result['production_sha256'] == gate['sources'][role]['production_sha256']
    for bank in gate['banks']:
        assert result['test_source_git_blobs'][bank['test_source']] == bank['test_source_git_blob']
    return result

def observation_map(output, marker):
    matches = re.findall(r'^' + re.escape(marker) + r' (\{[^\r\n]+\})$', output, re.M)
    assert len(matches) == 1, 'Missing or repeated complete observation map: ' + marker
    result = {}
    for item in matches[0][1:-1].split(', '):
        pair = item.split('=')
        assert len(pair) == 2 and pair[0] not in result and pair[1] in ('true', 'false')
        result[pair[0]] = pair[1] == 'true'
    return result

def collect_xml(path, bank, started, finished):
    raw = path.read_bytes()
    suite = ET.fromstring(raw)
    cases = suite.findall('testcase')
    names = [case.attrib['name'] for case in cases]
    assert suite.tag == 'testsuite' and suite.attrib['name'] == bank['class']
    assert len(cases) == int(suite.attrib['tests']) == bank['expected_cases']
    assert len(names) == len(set(names)) and sorted(names) == sorted(bank['case_names'])
    assert all(case.attrib.get('classname') == bank['class'] for case in cases)
    assert not any(suite.findall('.//' + kind) for kind in ('error', 'skipped'))
    assert int(suite.attrib.get('errors', 0)) == int(suite.attrib.get('skipped', 0)) == 0
    actual_failures = []
    failures = []
    for case in cases:
        entries = case.findall('failure')
        assert len(entries) <= 1
        if entries:
            actual_failures.append(case.attrib['name'])
            failures.append({'case': case.attrib['name'], 'attributes': entries[0].attrib,
                             'text': entries[0].text or ''})
    assert sorted(actual_failures) == sorted(bank['expected_failure_names'])
    assert int(suite.attrib.get('failures', 0)) == len(suite.findall('.//failure')) == len(actual_failures)
    assert started - 2_000_000_000 <= path.stat().st_mtime_ns <= finished + 2_000_000_000
    observations = {}
    if bank['requires_observation_maps']:
        output = '\n'.join(node.text or '' for node in suite.findall('.//system-out'))
        observed = observation_map(output, 'IZZET_LEGACY_FACTORY_DIFFERENTIAL')
        fixed = bank['source_role'] == 'fixed'
        expected = {'explicitLegacy': True, 'explicitCompleted': False,
                    'renamedCompanion': False, 'renamedReusable': False,
                    'frozenCompanion': fixed, 'frozenReusable': fixed,
                    'equalCopyCompanion': fixed, 'equalCopyReusable': fixed}
        assert observed == expected, 'Same-input strategy differential was not demonstrated'
        same_id = observation_map(output, 'IZZET_LEGACY_FACTORY_SAME_ID_CONTROL')
        assert same_id == {'explicitLegacy': True, 'explicitCompleted': False,
                           'alteredCompanion': False, 'alteredReusable': False}
        observations = {'differential': observed, 'same_id_control': same_id}
    if actual_failures:
        assert bank['source_role'] == 'before' and len(failures) == 1
        failure = failures[0]
        diagnostic = failure['attributes'].get('message', '') + '\n' + failure['text']
        assert 'FROZEN_FACTORY_LEGACY_BINDING' in diagnostic
        assert failure['attributes'].get('type', '').endswith('AssertionFailedError')
        assert 'EXPLICIT_STRATEGY_DIFFERENTIAL' not in diagnostic
        assert 'STATE_UNCHANGED_AFTER_' not in diagnostic
    return {'class': bank['class'], 'actual_cases': len(cases), 'case_names': names,
            'passed': len(cases) - len(failures), 'failed': len(failures), 'errors': 0, 'skipped': 0,
            'declared_expected_failures': failures, 'observations': observations,
            'xml_sha256': hashlib.sha256(raw).hexdigest()}

def run_bank(gate, bank, index):
    root = ROOT / bank['source_role']
    limits = gate['resource_limits']
    folder = OUT / f"{index:02d}-{bank['stage']}"
    folder.mkdir()
    before = source_snapshot(gate, bank['source_role'], folder / 'source-before.json')
    xml_dir = root / bank['module'] / 'build/test-results/test'
    # Only generated reports inside these two newly created owned checkouts are removed.
    for path in xml_dir.glob('TEST-*.xml'):
        path.unlink()
    assert not list(xml_dir.glob('TEST-*.xml'))
    command = ['just', 'test-class', bank['class'].rsplit('.', 1)[1], '--rerun', '--no-build-cache',
               '--no-daemon', '-DupdateSnapshots=false', '--info', '--stacktrace', '--max-workers=1',
               '-PkotlinCompileParallelism=1', '-Pkotlin.compiler.execution.strategy=in-process',
               '-Dorg.gradle.jvmargs=-Xmx4g']
    row = {'stage': bank['stage'], 'source_role': bank['source_role'], 'class': bank['class'],
           'expected_cases': bank['expected_cases'], 'expected_failure_names': bank['expected_failure_names'],
           'command': command, 'status': 'INCOMPLETE', 'started_ns': time.time_ns()}
    dump(folder / 'command.json', row)
    try:
        row.update(run_capped(command, root, folder / 'command.log', xml_dir, OUT, limits))
        row['finished_ns'] = time.time_ns()
        (folder / 'exit-status.txt').write_text(str(row['exit_status']) + '\n')
        row['observed_report_bytes_after_exit'] = directory_bytes(xml_dir)
        if row['observed_report_bytes_after_exit'] > limits['test_result_bytes']:
            row['technical_limit'] = 'TEST_RESULT_BYTE_LIMIT'
            row['output_complete'] = False
        paths = sorted(xml_dir.glob('TEST-*.xml'))
        row['xml_retention'] = []
        for path in paths:
            size = path.stat().st_size
            allowed = max(0, min(limits['test_result_bytes'], limits['artifact_bytes'] - directory_bytes(OUT) - 4194304))
            with path.open('rb') as source:
                raw = source.read(min(size, allowed))
            complete = len(raw) == size
            (folder / (path.name if complete else path.name + '.partial')).write_bytes(raw)
            row['xml_retention'].append({'name': path.name, 'observed_bytes': size,
                'retained_bytes': len(raw), 'complete': complete, 'sha256': hashlib.sha256(raw).hexdigest()})
        if not all(item['complete'] for item in row['xml_retention']):
            row['technical_limit'] = 'INCOMPLETE_XML_BYTE_LIMIT'
            row['output_complete'] = False
        assert row['output_complete'], 'Technical resource stop; prefixes remain incomplete evidence'
        assert row['exit_status'] == (1 if bank['expected_failure_names'] else 0), 'Unexpected command exit'
        assert len(paths) == 1 and paths[0].name == 'TEST-' + bank['class'] + '.xml'
        row['actual'] = collect_xml(paths[0], bank, row['started_ns'], row['finished_ns'])
        task = ':' + bank['module'].replace('/', ':') + ':test'
        log = (folder / 'command.log').read_text()
        lines = log.splitlines()
        assert any(line.strip() == '> Task ' + task or line.strip() == '> Task ' + task + ' FAILED' for line in lines)
        assert not any(line.strip() == '> Task ' + task + ' ' + suffix
                       for line in lines for suffix in ('FROM-CACHE', 'UP-TO-DATE', 'NO-SOURCE', 'SKIPPED'))
        assert len(re.findall(r'^Gradle Test Executor \d+ started executing tests\.$', log, re.M)) == 1
        assert len(re.findall(r'^Gradle Test Executor \d+ finished executing tests\.$', log, re.M)) == 1
        assert before == source_snapshot(gate, bank['source_role'], folder / 'source-after.json')
        row['status'] = 'PASS_DECLARED_BEHAVIOR_RAW_FAILURES_RETAINED'
    except Exception as error:
        row['status'] = 'FAILED_PRESERVED_FOR_REVIEW'
        row['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        dump(folder / 'command.json', row)
    return row

def main():
    OUT.mkdir(exist_ok=False)
    audit = {'schema': 'izzet-factory-differential-audit/v1', 'status': 'INCOMPLETE',
             'control_files_sha256': {}, 'control_head': None, 'source_before': {}, 'source_after': {},
             'run_id': os.environ.get('GITHUB_RUN_ID'), 'attempt': os.environ.get('GITHUB_RUN_ATTEMPT'),
             'event': os.environ.get('GITHUB_EVENT_NAME'), 'stages': [], 'errors': [],
             'new_software_identities': 2, 'new_pilot_cases': 0, 'official_games': 0, 'official_seeds': 0,
             'gameplay_authorized': False, 'full_runtime_accepted': False}
    dump(OUT / 'audit.json', audit)
    try:
        for path in CONTROL_PATHS:
            target = OUT / 'control' / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(CONTROL / path, target)
            audit['control_files_sha256'][path] = sha(target)
            dump(OUT / 'audit.json', audit)
        gate = json.loads((CONTROL / 'gate.json').read_text())
        audit['control_head'] = git(CONTROL, 'rev-parse', 'HEAD')
        assert os.environ['GITHUB_REPOSITORY'] == 'GodaPupa/argentum-batshit-test'
        assert os.environ['GITHUB_RUN_ATTEMPT'] == '1' and os.environ['GITHUB_EVENT_NAME'] == 'push'
        assert audit['control_head'] == os.environ['GITHUB_SHA']
        assert not git(CONTROL, 'status', '--porcelain')
        assert sorted(git(CONTROL, 'ls-files').splitlines()) == sorted(CONTROL_PATHS)
        assert gate['ready_for_execution'] is True and gate['source_review']
        assert os.environ['GITHUB_REF'] == 'refs/heads/lab/izzet-legacy-factory-qualification-20260927'
        event = json.loads(Path(os.environ['GITHUB_EVENT_PATH']).read_text())
        assert event['before'] == '0' * 40 and event['created'] is True and event['after'] == audit['control_head']
        audit['activation_event'] = {key: event[key] for key in ['before', 'after', 'created']}
        assert shutil.disk_usage(ROOT).free >= gate['resource_limits']['minimum_free_bytes']
        ids = [(bank['class'], name) for bank in gate['banks'] for name in bank['case_names']]
        assert len(gate['banks']) == 3 and len(ids) == 11 and len(set(ids)) == 9
        assert [b['source_role'] for b in gate['banks']] == ['before', 'fixed', 'fixed']
        assert [len(b['expected_failure_names']) for b in gate['banks']] == [1, 0, 0]
        for role in SOURCES:
            audit['source_before'][role] = source_snapshot(gate, role, OUT / ('source-before-' + role + '.json'))
            dump(OUT / 'audit.json', audit)
        for index, bank in enumerate(gate['banks'], 1):
            audit['current_stage'] = bank['stage']
            dump(OUT / 'audit.json', audit)
            audit['stages'].append(run_bank(gate, bank, index))
            dump(OUT / 'audit.json', audit)
            if audit['stages'][-1]['status'] != 'PASS_DECLARED_BEHAVIOR_RAW_FAILURES_RETAINED':
                audit['unattempted_stages'] = [rest['stage'] for rest in gate['banks'][index:]]
                break
        for role in SOURCES:
            audit['source_after'][role] = source_snapshot(gate, role, OUT / ('source-after-' + role + '.json'))
            dump(OUT / 'audit.json', audit)
        assert audit['source_before'] == audit['source_after']
        assert audit['control_files_sha256'] == {p: sha(CONTROL / p) for p in CONTROL_PATHS}
        assert len(audit['stages']) == 3 and all(row['status'] == 'PASS_DECLARED_BEHAVIOR_RAW_FAILURES_RETAINED' for row in audit['stages'])
        audit['observed_software_results'] = {'case_executions': sum(r['actual']['actual_cases'] for r in audit['stages']),
            'passed': sum(r['actual']['passed'] for r in audit['stages']),
            'failed': sum(r['actual']['failed'] for r in audit['stages']),
            'errors': 0, 'skipped': 0, 'distinct_identities': 9}
        assert audit['observed_software_results'] == {'case_executions': 11, 'passed': 10, 'failed': 1, 'errors': 0, 'skipped': 0, 'distinct_identities': 9}
        audit['status'] = 'DECLARED_DIFFERENTIAL_OBSERVED_REQUIRES_INDEPENDENT_ARTIFACT_REVIEW'
    except Exception as error:
        audit['errors'].append(type(error).__name__ + ': ' + str(error))
        raise
    finally:
        dump(OUT / 'audit.json', audit)

# Inherited bounded-process helpers are appended verbatim before main() below.


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def directory_bytes(path):
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file()) if path.exists() else 0


def terminate_owned_group(process):
    # This Popen owns a new session; never signal another worker or runner process.
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    finally:
        # The wrapper may have exited while a child still owns its pipe/session.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)


def run_capped(command, root, log_path, reports, out, limits):
    start = time.monotonic()
    reason = None
    written = 0
    discarded_observed_bytes = 0
    process = subprocess.Popen(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)
    try:
        with log_path.open('wb') as log:
            while selector.get_map():
                if time.monotonic() - start > limits['command_timeout_seconds']:
                    reason = 'COMMAND_TIMEOUT'; break
                if directory_bytes(reports) > limits['test_result_bytes']:
                    reason = 'TEST_RESULT_BYTE_LIMIT'; break
                if directory_bytes(out) >= limits['artifact_bytes'] - 4194304:
                    reason = 'ARTIFACT_BYTE_LIMIT'; break
                for key, _ in selector.select(timeout=0.1):
                    chunk = os.read(key.fileobj.fileno(), 65536)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    remaining = min(limits['stdout_bytes'] - written, limits['artifact_bytes'] - directory_bytes(out) - 4194304)
                    keep = chunk[:max(0, remaining)]
                    log.write(keep); log.flush(); written += len(keep)
                    if len(keep) < len(chunk):
                        discarded_observed_bytes += len(chunk) - len(keep)
                        reason = 'STDOUT_OR_ARTIFACT_BYTE_LIMIT'; break
                if reason:
                    break
            if not reason:
                try:
                    process.wait(timeout=max(0.01, limits['command_timeout_seconds'] - (time.monotonic() - start)))
                except subprocess.TimeoutExpired:
                    reason = 'COMMAND_TIMEOUT'
    finally:
        if reason or process.poll() is None:
            terminate_owned_group(process)
        selector.close()
        process.stdout.close()
    return {'exit_status': process.returncode, 'technical_limit': reason, 'stdout_retained_bytes': written,
            'discarded_observed_pipe_bytes': discarded_observed_bytes, 'output_complete': reason is None,
            'elapsed_seconds': time.monotonic() - start}


if __name__ == "__main__":
    main()
