"""Synthetic parser guards only; no child process, JVM, fixture or experiment execution."""
from pathlib import Path
import copy, hashlib, json, os, runpy, tempfile, time
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
gate = json.loads((HERE / 'gate.json').read_bytes())
results = []
def suite(bank):
    node = ET.Element('testsuite', name=bank['class'], tests=str(bank['expected_cases']),
                      failures=str(len(bank['expected_failure_names'])), errors='0', skipped='0')
    for name in bank['case_names']:
        case = ET.SubElement(node, 'testcase', classname=bank['class'], name=name)
        if name in bank['expected_failure_names']:
            ET.SubElement(case, 'failure', type='io.kotest.assertions.AssertionFailedError',
                          message='FROZEN_FACTORY_LEGACY_BINDING').text = 'FROZEN_FACTORY_LEGACY_BINDING: expected true but was false'
    if bank['requires_observation_maps']:
        fixed = bank['source_role'] == 'fixed'
        values = {'explicitLegacy': True, 'explicitCompleted': False, 'renamedCompanion': False,
                  'renamedReusable': False, 'frozenCompanion': fixed, 'frozenReusable': fixed,
                  'equalCopyCompanion': fixed, 'equalCopyReusable': fixed}
        control = {'explicitLegacy': True, 'explicitCompleted': False, 'alteredCompanion': False, 'alteredReusable': False}
        def line(marker, m):return marker+' {'+', '.join(k+'='+str(v).lower() for k,v in m.items())+'}'
        ET.SubElement(node, 'system-out').text = line('IZZET_LEGACY_FACTORY_DIFFERENTIAL', values)+'\n'+line('IZZET_LEGACY_FACTORY_SAME_ID_CONTROL', control)+'\n'
    return node
with tempfile.TemporaryDirectory(prefix='izzet-factory-parser-only-') as td:
    os.environ['GITHUB_WORKSPACE'] = td
    loaded = runpy.run_path(str(HERE / 'qualify.py'), run_name='guard_import_only')
    def check(label, bank, edit=None, accepts=False, stale=False):
        root = suite(bank)
        if edit:edit(root)
        path=Path(td)/'fixture.xml';path.write_bytes(ET.tostring(root))
        now=time.time_ns()
        if stale:os.utime(path, ns=(1,1))
        rejected=None
        try:loaded['collect_xml'](path,bank,now-1_000_000_000,now+1_000_000_000)
        except Exception as e:rejected=type(e).__name__+': '+str(e)
        assert bool(rejected) != accepts,(label,rejected)
        results.append({'name':label,'expected':'accept' if accepts else 'reject','result':'accepted' if rejected is None else 'rejected','error':rejected})
    b,f,old=gate['banks']
    check('specific old-source failure with complete equivalent controls',b,accepts=True)
    check('fixed same-input complete maps and zero failures',f,accepts=True)
    check('seven original passing identities',old,accepts=True)
    check('generic failure is not the intended regression',b,lambda n:(n.find('.//failure').set('message','OTHER'),setattr(n.find('.//failure'),'text','OTHER')))
    check('compile-like failure type cannot count as a strategy differential',b,lambda n:n.find('.//failure').set('type','java.lang.IllegalStateException'))
    check('failed state preservation cannot count as expected regression',b,lambda n:n.find('.//failure').set('message','FROZEN_FACTORY_LEGACY_BINDING STATE_UNCHANGED_AFTER_control'))
    check('missing map cannot pass via failure message alone',b,lambda n:setattr(n.find('system-out'),'text',''))
    check('explicit legacy and completed must differ under equal inputs',b,lambda n:setattr(n.find('system-out'),'text',n.find('system-out').text.replace('explicitLegacy=true','explicitLegacy=false')))
    check('same-id altered configuration must retain completed behavior',f,lambda n:setattr(n.find('system-out'),'text',n.find('system-out').text.replace('alteredCompanion=false','alteredCompanion=true')))
    check('unexpected second failure rejects',b,lambda n:ET.SubElement(n.findall('testcase')[1],'failure',type='io.kotest.assertions.AssertionFailedError'))
    check('duplicate original case rejects',f,lambda n:n.findall('testcase')[1].set('name',n.findall('testcase')[0].attrib['name']))
    check('skipped case rejects',old,lambda n:ET.SubElement(n.find('testcase'),'skipped'))
    check('stale XML rejects',old,stale=True)
report={'scope':'13 synthetic parser guards only; no JVM, child process, actual test case, policy or game execution','collector_sha256':hashlib.sha256((HERE/'qualify.py').read_bytes()).hexdigest(),'gate_sha256':hashlib.sha256((HERE/'gate.json').read_bytes()).hexdigest(),'checks':results,'status':'PASS'}
(HERE/'local-parser-guard-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','synthetic_guards':len(results),'collector_sha256':report['collector_sha256']}))
