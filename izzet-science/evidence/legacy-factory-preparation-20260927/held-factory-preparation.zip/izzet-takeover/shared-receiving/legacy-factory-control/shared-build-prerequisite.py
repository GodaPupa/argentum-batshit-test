"""Exact reusable control helper; reviewed in its owning qualification control before reuse.
Requires ROOT, OUT, stdlib imports and gate.resource_limits/build_semaphore.
No engine or fixture logic. This local extraction is NOT a fourth tracked control path.
"""

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def directory_bytes(path):
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file()) if path.exists() else 0


def owned_group_members(group_id):
    """Linux observation only: match both process group and the new owned session."""
    result = []
    namespace = os.readlink('/proc/self/ns/pid')
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            # /proc can be mounted from an ancestor namespace (as in the local tools).
            # Only observe our own PID namespace, then use its innermost identifiers.
            if os.readlink(path / 'ns/pid') != namespace:
                continue
            status = dict(line.split(':', 1) for line in (path / 'status').read_text().splitlines() if ':' in line)
            pid = int(status['NSpid'].split()[-1])
            pgrp = int(status['NSpgid'].split()[-1])
            session = int(status['NSsid'].split()[-1])
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if pgrp == group_id and session == group_id:
                result.append({'pid': pid, 'proc_pid': int(path.name), 'state': fields[0], 'group': pgrp,
                               'session': session, 'start_ticks': int(fields[19]), 'pid_namespace': namespace})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return sorted(result, key=lambda row: row['pid'])


def terminate_owned_group(process):
    # Called on EVERY terminal path, even when the wrapper already exited and closed its pipe.
    # A group consisting solely of zombies is quiescent: none can continue writing a report.
    record = {'group': process.pid, 'before': owned_group_members(process.pid), 'signals': [], 'errors': []}
    def live(rows):return [row for row in rows if row['state'] not in ('Z', 'X')]
    for sig in (signal.SIGTERM, signal.SIGKILL):
        current = owned_group_members(process.pid)
        if not live(current):
            break
        try:
            os.killpg(process.pid, sig)
            record['signals'].append(signal.Signals(sig).name)
        except ProcessLookupError:
            pass
        except PermissionError as error:
            record['errors'].append(type(error).__name__ + ': ' + str(error))
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            process.poll()
            if not live(owned_group_members(process.pid)):
                break
            time.sleep(0.05)
    try:
        process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        record['errors'].append('Owned wrapper did not terminate after group cleanup')
    record['after'] = owned_group_members(process.pid)
    record['quiescent'] = not live(record['after']) and process.poll() is not None
    return record


def run_capped(command, root, log_path, reports, out, limits, semaphore_lock=None):
    start = time.monotonic()
    reason = None
    written = 0
    discarded_observed_bytes = 0
    owned_semaphore_observations = []
    process = subprocess.Popen(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)
    try:
        with log_path.open('wb') as log:
            while selector.get_map():
                if semaphore_lock:
                    try:
                        text = Path(semaphore_lock).read_text().strip()
                        if text.isdigit() and len(text) <= 16:
                            holder = int(text)
                            if os.getpgid(holder) == process.pid and holder not in [r['holder_pid'] for r in owned_semaphore_observations]:
                                owned_semaphore_observations.append({'holder_pid': holder, 'owned_process_group': process.pid, 'observed_ns': time.time_ns()})
                    except (FileNotFoundError, ProcessLookupError, PermissionError):
                        pass
                if time.monotonic() - start > limits['command_timeout_seconds']:
                    reason = 'COMMAND_TIMEOUT'; break
                if directory_bytes(reports) > limits['test_result_bytes']:
                    reason = 'TEST_RESULT_BYTE_LIMIT'; break
                if directory_bytes(out) >= limits['artifact_bytes'] - 4194304:
                    reason = 'ARTIFACT_BYTE_LIMIT'; break
                for key, _ in selector.select(timeout=0.1):
                    chunk = os.read(key.fileobj.fileno(), 65536)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    remaining = min(limits['stdout_bytes'] - written, limits['artifact_bytes'] - directory_bytes(out) - 4194304)
                    keep = chunk[:max(0, remaining)]
                    log.write(keep); log.flush(); written += len(keep)
                    if len(keep) < len(chunk):
                        discarded_observed_bytes += len(chunk) - len(keep)
                        reason = 'STDOUT_OR_ARTIFACT_BYTE_LIMIT'; break
                if reason:
                    break
            if not reason:
                try:
                    process.wait(timeout=max(0.01, limits['command_timeout_seconds'] - (time.monotonic() - start)))
                except subprocess.TimeoutExpired:
                    reason = 'COMMAND_TIMEOUT'
    finally:
        # Parent exit is insufficient: a child can close stdout yet keep writing XML.
        normal_wrapper_exit = reason is None and process.poll() is not None
        cleanup = terminate_owned_group(process)
        if normal_wrapper_exit and any(row['state'] not in ('Z', 'X') for row in cleanup['before']):
            reason = 'OWNED_DESCENDANTS_AFTER_WRAPPER_EXIT'
        if not cleanup['quiescent']:
            reason = 'OWNED_PROCESS_GROUP_NOT_QUIESCENT'
        selector.close()
        process.stdout.close()
    return {'exit_status': process.returncode, 'technical_limit': reason, 'stdout_retained_bytes': written,
            'discarded_observed_pipe_bytes': discarded_observed_bytes, 'output_complete': reason is None,
            'owned_semaphore_observations': owned_semaphore_observations,
            'process_group_cleanup': cleanup,
            'elapsed_seconds': time.monotonic() - start}


def prepare_build_semaphore(gate):
    """Use the packaged upstream shlock; never install services or replace locking semantics."""
    cfg = gate['build_semaphore']
    folder = OUT / 'build-semaphore'
    folder.mkdir()
    tool = ROOT / 'shlock-prerequisite'
    tool.mkdir(exist_ok=False)
    packages = folder / 'packages'
    packages.mkdir()
    reports = tool / 'no-test-results'
    lists = tool / 'apt-lists'
    (lists / 'partial').mkdir(parents=True)
    cache = tool / 'apt-cache'
    cache.mkdir()
    apt_options = ['-o', 'Dir::State::Lists=' + str(lists), '-o', 'Dir::Cache=' + str(cache),
                   '-o', 'APT::Sandbox::User=', '-o', 'Acquire::Retries=0']
    record = {'status': 'INCOMPLETE_BEFORE_ANY_JVM', 'commands': [], 'packages': [],
              'utility_checks': [], 'errors': [], 'official_games': 0}
    def save():dump(folder / 'prerequisite.json', record)
    def small(command):
        row = {'command': command, 'started_ns': time.time_ns()}
        record['commands'].append(row);save()
        log = folder / ('metadata-' + str(len(record['commands'])) + '.log')
        limits = dict(gate['resource_limits'], command_timeout_seconds=15, stdout_bytes=65536)
        row.update(run_capped(command, tool, log, reports, OUT, limits))
        row.update({'stdout': log.read_text(errors='replace'), 'finished_ns': time.time_ns()})
        save()
        assert row['output_complete'] and row['exit_status'] == 0, 'Prerequisite metadata command failed'
        return row['stdout']
    def capped(label, command, cwd):
        row = {'command': command, 'started_ns': time.time_ns()}
        record['commands'].append(row);save()
        limits = dict(gate['resource_limits'], command_timeout_seconds=cfg['setup_command_timeout_seconds'], stdout_bytes=4194304)
        row.update(run_capped(command, cwd, folder / (label + '.log'), reports, OUT, limits))
        row['finished_ns'] = time.time_ns();save()
        assert row['output_complete'] and row['exit_status'] == 0, 'Prerequisite setup failed; no JVM admitted'
    save()
    try:
        os_release = Path('/etc/os-release').read_text()
        (folder / 'os-release.txt').write_text(os_release)
        assert '\nID=ubuntu\n' in '\n' + os_release
        assert '\nVERSION_ID="24.04"\n' in '\n' + os_release
        assert small(['dpkg', '--print-architecture']).strip() == cfg['architecture'] == 'amd64'
        assert os.environ.get('GRADLE_LOCK_SLOTS') == str(cfg['lock_slots']) == '1'
        assert 'GRADLE_LOCK_FILE' not in os.environ, 'Preserve the existing machine-global default lock'
        # Authenticated APT metadata and package extraction remain entirely in owned directories.
        # No root process, package installation, maintainer script or service is started.
        capped('apt-update', ['apt-get', *apt_options, 'update'], tool)
        for package in cfg['packages']:
            spec = package + '=' + cfg['package_version']
            metadata = small(['apt-cache', *apt_options, 'show', spec])
            (folder / (package + '-apt-metadata.txt')).write_text(metadata)
            stanzas = [dict(line.split(': ', 1) for line in part.splitlines() if ': ' in line and not line.startswith(' '))
                       for part in metadata.strip().split('\n\n')]
            chosen = [s for s in stanzas if s.get('Package') == package and s.get('Version') == cfg['package_version']
                      and s.get('Architecture') == cfg['architecture']]
            assert len(chosen) == 1
            meta = chosen[0]
            assert meta['Filename'].startswith(cfg['package_filename_prefix'])
            assert int(meta['Size']) <= cfg['package_max_bytes']
            before = set(packages.glob('*.deb'))
            capped('download-' + package, ['apt-get', *apt_options, 'download', spec], packages)
            added = set(packages.glob('*.deb')) - before
            assert len(added) == 1
            deb = added.pop()
            actual = {'package': package, 'version': cfg['package_version'], 'file': deb.name,
                      'bytes': deb.stat().st_size, 'sha256': sha(deb), 'apt_metadata': meta}
            record['packages'].append(actual);save()
            assert actual['sha256'] == meta['SHA256'] and actual['bytes'] == int(meta['Size'])
            for field, expected in [('Package', package), ('Version', cfg['package_version']), ('Architecture', cfg['architecture'])]:
                assert small(['dpkg-deb', '--field', str(deb), field]).strip() == expected
            small(['dpkg-deb', '--extract', str(deb), str(tool / 'extracted')])
        binary = tool / 'extracted' / cfg['upstream_binary']
        libraries = tool / 'extracted' / cfg['upstream_library_directory']
        assert binary.is_file() and os.access(binary, os.X_OK)
        record['binary'] = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': sha(binary)}
        record['libraries'] = {str(p.relative_to(tool)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                               for p in sorted(libraries.glob('libinn*.so*')) if p.is_file()}
        assert record['libraries']
        owned_bin = tool / 'bin'
        owned_bin.mkdir()
        (owned_bin / 'shlock').symlink_to(binary)
        os.environ['PATH'] = str(owned_bin) + os.pathsep + os.environ['PATH']
        os.environ['LD_LIBRARY_PATH'] = str(libraries) + (os.pathsep + os.environ['LD_LIBRARY_PATH'] if os.environ.get('LD_LIBRARY_PATH') else '')
        assert Path(shutil.which('shlock')).resolve() == binary.resolve()
        record['resolved_command'] = shutil.which('shlock')
        record['default_lock'] = str(Path.home() / '.cache/argentum/gradle.lock')
        save()
        lock = tool / 'owned-prerequisite-test.lock'
        assert not lock.exists()
        def probe(label, expected):
            result = subprocess.run(['shlock', '-f', str(lock), '-p', str(os.getpid())], capture_output=True, timeout=10)
            row = {'label': label, 'exit_status': result.returncode, 'stdout': result.stdout.decode(errors='replace'),
                   'stderr': result.stderr.decode(errors='replace'), 'lock_content': lock.read_text() if lock.exists() else None}
            record['utility_checks'].append(row);save()
            assert len(result.stdout) + len(result.stderr) <= 65536
            assert (result.returncode == 0) == expected
            assert row['lock_content'].strip() == str(os.getpid())
        try:
            probe('acquire owned test lock', True)
            probe('reject already live holder without overwrite', False)
            assert lock.read_text().strip() == str(os.getpid());lock.unlink()
            probe('reacquire after explicit owned release', True)
        finally:
            if lock.exists():
                assert lock.read_text().strip() == str(os.getpid()), 'Never remove a foreign lock'
                lock.unlink()
        record['status'] = 'UPSTREAM_SHLOCK_PREREQUISITE_QUALIFIED_BEFORE_JVM'
        save()
        return {'binary_path': str(binary), 'binary_sha256': sha(binary), 'lock_path': record['default_lock']}
    except Exception as error:
        record['errors'].append(type(error).__name__ + ': ' + str(error));save()
        raise
