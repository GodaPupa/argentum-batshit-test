"""Only AST-selected observer functions, stub Git and synthetic temporary files."""
from pathlib import Path
import ast, hashlib, json, tempfile
HERE=Path(__file__).resolve().parent
raw=(HERE/'qualify.py').read_bytes()
selected=[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name in ['dump','sha','source_snapshot']]
ns={'Path':Path,'json':json,'hashlib':hashlib}
exec(compile(ast.Module(body=selected,type_ignores=[]),'observer-only','exec'),ns)
results=[]
with tempfile.TemporaryDirectory(prefix='izzet-source-retention-only-') as td:
    root=Path(td);source=root/'before';source.mkdir();ns['ROOT']=root;ns['SOURCES']={'before':('h','t')}
    for name in ['production.kt','authority.json','dependency.txt']:(source/name).write_text('synthetic exact content')
    digest=hashlib.sha256((source/'production.kt').read_bytes()).hexdigest()
    for case in ['missing-production','missing-authority','missing-dependency','failed-git-identity','dirty-source','bad-authority-hash']:
        gate={'production_path':'production.kt','preserved_authority_sha256':{'authority.json':digest},
              'dependency_sha256':{'dependency.txt':digest},'banks':[],
              'sources':{'before':{'head':'h','tree':'t','production_sha256':digest}}}
        def git_stub(root,*args):
            if case=='failed-git-identity':raise RuntimeError('synthetic Git identity failure')
            return {'HEAD':'h','HEAD^{tree}':'t','--porcelain':' M synthetic' if case=='dirty-source' else ''}[args[-1]]
        ns['git']=git_stub
        if case=='missing-production':gate['production_path']='missing.kt'
        if case=='missing-authority':gate['preserved_authority_sha256']={'missing.json':digest}
        if case=='missing-dependency':gate['dependency_sha256']={'missing.txt':digest}
        if case=='bad-authority-hash':gate['preserved_authority_sha256']['authority.json']='0'*64
        dest=root/(case+'.json');error=None
        try:ns['source_snapshot'](gate,'before',dest)
        except Exception as e:error=type(e).__name__+': '+str(e)
        assert error and dest.exists()
        observed=json.loads(dest.read_bytes());assert len(observed['errors'])==1
        assert observed['errors'][0]['error']==error
        if case!='failed-git-identity':assert observed['head']=='h' and observed['tree']=='t'
        if case in ['dirty-source','bad-authority-hash']:assert observed['errors'][0]['kind']=='validation_error'
        else:assert observed['errors'][0]['kind']=='read_error'
        results.append({'case':case,'preserved_observation':observed})
report={'scope':'6 synthetic observer error-retention checks only; no subprocess, JVM, software fixture or game','collector_sha256':hashlib.sha256(raw).hexdigest(),'checks':results,'status':'PASS'}
(HERE/'local-source-retention-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','synthetic_checks':len(results),'collector_sha256':report['collector_sha256']}))
