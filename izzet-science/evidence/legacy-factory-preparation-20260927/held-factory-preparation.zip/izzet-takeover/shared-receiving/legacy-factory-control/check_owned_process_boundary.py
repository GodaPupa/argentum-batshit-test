"""Four bounded Python-only process checks; no JVM, project fixture or game."""
from pathlib import Path
import hashlib, json, os, runpy, sys, tempfile, time
HERE=Path(__file__).resolve().parent
results=[]
with tempfile.TemporaryDirectory(prefix='izzet-owned-process-review-') as td:
    root=Path(td);out=root/'output';out.mkdir();reports=root/'reports';reports.mkdir()
    os.environ['GITHUB_WORKSPACE']=str(root)
    module=runpy.run_path(str(HERE/'qualify.py'),run_name='process_guard_only')
    limits={'stdout_bytes':65536,'test_result_bytes':65536,'artifact_bytes':8388608,'command_timeout_seconds':2}
    orphan="""import os,time,sys,json
child=os.fork()
if child:
 print(json.dumps({'leader':os.getpid(),'child':child}),flush=True)
 os._exit(0)
os.close(1);os.close(2)
with open(sys.argv[1],'wb',buffering=0) as f:
 for _ in range(40):
  f.write(b'x');time.sleep(.02)
os._exit(0)
"""
    specs=[('clean-exit','print("clean")',None),
           ('exited-wrapper-live-writer',orphan,'OWNED_DESCENDANTS_AFTER_WRAPPER_EXIT'),
           ('bounded-timeout','import time;time.sleep(2)','COMMAND_TIMEOUT'),
           ('bounded-output','print("x"*100000)','STDOUT_OR_ARTIFACT_BYTE_LIMIT')]
    for label,code,expected in specs:
        selected=dict(limits,command_timeout_seconds=.15 if label=='bounded-timeout' else 2)
        writer=reports/(label+'.writer')
        result=module['run_capped']([sys.executable,'-I','-B','-c',code,str(writer)],root,out/(label+'.log'),reports,out,selected)
        assert result['process_group_cleanup']['quiescent']
        assert result['technical_limit']==expected,(label,result)
        assert result['output_complete']==(expected is None)
        before=writer.stat().st_size if writer.exists() else 0
        time.sleep(.15)
        after=writer.stat().st_size if writer.exists() else 0
        assert before==after
        if label=='exited-wrapper-live-writer':
            assert result['exit_status']==0 and result['owned_semaphore_observations']==[]
            assert result['process_group_cleanup']['signals']
            assert any(x['state'] not in ('Z','X') for x in result['process_group_cleanup']['before'])
        results.append({'name':label,'result':result,'report_bytes_at_return':before,'report_bytes_after150ms':after})
report={'status':'PASS','scope':'Four Python-only owned-process/resource guards, including the independently identified exited-wrapper writer. No semaphore package download or JVM/project test.','collector_sha256':hashlib.sha256((HERE/'qualify.py').read_bytes()).hexdigest(),'checks':results}
(HERE/'local-owned-process-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','process_guards':len(results),'collector_sha256':report['collector_sha256']}))
