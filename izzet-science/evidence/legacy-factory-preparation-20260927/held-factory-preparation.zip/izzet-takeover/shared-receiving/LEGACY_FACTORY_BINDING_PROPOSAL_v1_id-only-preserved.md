# Proposed explicit factory selection for frozen v0

This is a review proposal only. `AIPlayer.kt`, `AiProfile.kt`, `DecisionResponder.kt` and all existing strategy selections remain unmodified.

The exact proposed insertion is one named argument at the existing DecisionResponder construction in AIPlayer.create:

```kotlin
yesNoStrategy = if (profile.id == AiProfile.LEGACY_V0.id) {
    YesNoDecisionStrategy.LEGACY_SIMULATE_BOTH_V1
} else {
    YesNoDecisionStrategy.COMPLETED_BRANCH_V1
},
```

The existing factory already receives the profile, and `AiProfile.LEGACY_V0.id` is the frozen `v0` identifier. This restores the intended previous Yes/No branch for that reference identity; it does not change the global responder default or profile data. The reviewer must approve the identity predicate and confirm that no intentionally distinct policy uses the frozen v0 identifier. Other named profiles and separately constructed responders retain their current explicit or default strategy. Industrial's owner confirmed that its official FullHorizonRunner and CapabilityRunner paths already explicitly select LEGACY_SIMULATE_BOTH_V1, so those paths must not be edited.

A meaningful prospective regression should reach the public factory and `respondToDecision`, rather than reflect or merely assert the enum field. Reuse the already-declared generic up-to-one optional-selection shape from DecisionResponderCompletedBranchTest: selecting its one card loses life, while selecting none is outcome-equivalent to declining. The original simulate-both tie rule accepts; the completed-branch strict-improvement rule declines. Verify that the actual factory-created v0 responds like the explicit legacy strategy, and that a factory-created production candidate retains the completed strategy. Require the responses to differ on the same unchanged state and verify that policy evaluation does not mutate the authoritative state. If that fixture does not distinguish the two paths on the exact source, do not bless it as a policy regression.

The existing seven completed-branch cases must remain unchanged and pass with the retained production strategy; bounded factory tests and relevant AI regressions require fresh qualification. This is software policy-version restoration, not permission to tune any experimental pilot or infer competent play. All six experimental programs still require their own exact pilot/actor and information-boundary admission.
