# Proposed structural factory selection for frozen v0

This is a revised review proposal only. `AIPlayer.kt`, `AiProfile.kt`, `DecisionResponder.kt` and existing strategy selections remain unmodified. The original id-only proposal is preserved separately; nonauthor review `fbd3705220c65cb4` identified that a public data class can retain id=v0 while changing other configuration.

The proposed insertion at the existing DecisionResponder construction in AIPlayer.compose is:

```kotlin
yesNoStrategy = if (profile == AiProfile.LEGACY_V0) {
    YesNoDecisionStrategy.LEGACY_SIMULATE_BOTH_V1
} else {
    YesNoDecisionStrategy.COMPLETED_BRANCH_V1
},
```

Use Kotlin data-class structural equality, not the identifier alone. The frozen object and an equal copy receive the original simulate-both strategy. A configuration that changes any profile constructor property, even while retaining id=v0, does not silently receive this restoration. The exact-source AiProfile constructor includes the id, advisor modules, evaluation-weight identifier, budget policy and all behavior flags/settings; its reference has empty advisor modules, the singleton legacy budget, null rollout settings and the frozen default values. This stronger identity guard needs independent review. It does not claim a complete inventory of all external callers or that every configuration mislabeled v0 is equivalent. A mutable or intentionally changed profile remains subject to its own pilot/source binding.

No global responder default or profile fields change. Industrial's explicit legacy choices in its official FullHorizonRunner and CapabilityRunner remain untouched. Other profiles and direct responder constructors retain current strategy selection. Manual's distinct historical unselected completed-branch boundary remains outside this repair.

## Behavioral regression requirements before source acceptance

The public factory and respondToDecision must be exercised. Reuse the existing harmful-singleton/empty-selection-tie optional shape from DecisionResponderCompletedBranchTest: taking its card loses life, while selecting no card ties declining. Do not infer a distinguishing result before actual execution.

Hold every evaluator and profile behavior input equal. A factory with the exact frozen profile and a factory with `AiProfile.LEGACY_V0.copy(id = "v0-completed-control")` differ only in their identity label and the proposed strategy selection; the current composition does not otherwise feed that label into evaluation. Explicit direct legacy/completed responder controls must be constructed with the same resolved evaluation vector, budget, intents, advisor configuration and simulator behavior as the factory. Production-candidate versus v0 alone is insufficient because their evaluator/profile settings differ.

Require actual evidence that the intended legacy assertion fails through the pre-fix factory and passes through the corrected factory on this same decision/state. The retained completed control must decline and remain unchanged. A structurally equal copy must behave like the frozen object; a deliberately altered behavior configuration retaining id=v0 must not pass the structural guard. Verify evaluation does not mutate the authoritative state. Keep the existing seven completed-branch cases byte-identical and require their fresh execution. Define the exact finite case/source/event plan after source review; this proposal itself authorizes no run, fixture count or experimental pilot-development expenditure.

## Inventory evidence and limits

The read-only `legacy-profile-partial-inventory.json` compares an already retained source archive to the exact current Git blob map: 23,760 of 24,628 Kotlin/Java/build-source files match current bytes; 868 are absent or different and remain unchecked in this partial scan. The 51 matching files containing AiProfile or AIPlayer.create are retained with their exact current blob identities. This is useful source material, explicitly not a complete caller/configuration inventory or proof of absence. The proposed structural guard is intended to avoid relying on that missing proof.

No implementation, compiler run, golden adoption, gameplay execution or policy qualification has occurred. All programs retain separate exact pilot/actor and information-boundary admission requirements.
