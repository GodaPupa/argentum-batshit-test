"""Independent AST-only checks. No child, /proc observation, or real signal."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
SOURCE = Path('izzet-takeover/shared-receiving/legacy-factory-visibility-successor/qualify.py')
EXPECTED = 'ed3c72a1fa5494598f212d0981e37eb0f6cf1c9116bf61938f2fa8dca9ad88e8'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
nodes = {n.name: n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef)}
checks = []


def scanner_check(mode):
    calls = []
    class P:
        def __init__(self, text): self.text = str(text); self.name = self.text.rsplit('/', 1)[-1]
        def __truediv__(self, value): return P(self.text + '/' + str(value))
        def iterdir(self): return iter([P('/proc/1234')])
        def read_text(self):
            calls.append(self.text)
            if self.text.endswith('/status'):
                if mode == 'denied_status': raise PermissionError('actual synthetic condition from9e7188')
                group = 99 if mode == 'proved_foreign_group' else 77
                return f'NSpgid: 800 {group}\nNSsid: 800 {group}\nNSpid: 900 88\n'
            if mode == 'malformed_stat': return 'not a stat record'
            return '1234 (multiple ) parens) S ' + ' '.join(['0'] * 18) + ' 12345'
    def link(path):
        text = path.text if isinstance(path, P) else path
        calls.append(text)
        if text != '/proc/self/ns/pid' and mode in ('denied_namespace', 'proved_foreign_group'):
            raise PermissionError('synthetic namespace denied')
        return 'pid:[scope]'
    env = {'Path': P, 'os': SimpleNamespace(readlink=link)}
    exec(compile(ast.Module(body=[nodes['owned_group_members']], type_ignores=[]), str(SOURCE), 'exec'), env)
    result = env['owned_group_members'](77)
    if mode in ('denied_status', 'denied_namespace', 'malformed_stat'):
        assert result['complete'] is False and result['errors'] and not result['members']
    elif mode == 'proved_foreign_group':
        assert result['complete'] is True and result['errors'] == [] and result['members'] == []
        assert '/proc/1234/ns/pid' not in calls
    else:
        assert result['complete'] is True and len(result['members']) == 1
        assert result['members'][0]['pid'] == 88 and result['members'][0]['start_ticks'] == 12345
    checks.append({'case': mode, 'passed': True, 'actual': result, 'fake_reads': calls})


for mode in ('denied_status', 'denied_namespace', 'malformed_stat', 'proved_foreign_group', 'valid_member'):
    scanner_check(mode)


def cleanup_check(mode):
    saved, signals, state = [], [], {'n': 0, 'live': mode == 'known_live_child'}
    def observation(group):
        assert saved, 'Initial durable record must precede first scan'
        state['n'] += 1
        error = mode == 'transient_visibility_error' and state['n'] == 1
        return {'members': [{'pid': 88, 'state': 'S'}] if state['live'] else [],
                'complete': not error,
                'errors': [{'operation': 'read candidate', 'error': 'PermissionError: synthetic'}] if error else [],
                'excluded': {}}
    class Wrapper:
        pid = 77
        def poll(self): return 0
        def wait(self, timeout=None): return 0
    def signal(group, sig):
        assert group == 77 and sig == 15
        signals.append(sig); state['live'] = False
    env = {'owned_group_members': observation, 'dump': lambda p, r: saved.append(copy.deepcopy(r)),
           'signal': SimpleNamespace(SIGTERM=15, SIGKILL=9, Signals=lambda n: SimpleNamespace(name='SIGTERM')),
           'os': SimpleNamespace(killpg=signal), 'time': SimpleNamespace(monotonic=lambda: 0, sleep=lambda _: None)}
    exec(compile(ast.Module(body=[nodes['terminate_owned_group']], type_ignores=[]), str(SOURCE), 'exec'), env)
    result = env['terminate_owned_group'](Wrapper(), 'memory-only')
    assert saved[0]['scans'] == 0 and saved[0]['quiescent'] is False
    assert saved[-1] == result
    if mode == 'transient_visibility_error':
        assert result['observation_complete'] is False and result['quiescent'] is False
        assert result['errors'] and signals == []
    else:
        assert result['observation_complete'] is True and result['quiescent'] is True
        assert result['before'] == [{'pid': 88, 'state': 'S'}] and result['after'] == []
        assert signals == [15]
    checks.append({'case': mode, 'passed': True, 'actual': result, 'in_memory_writes': len(saved)})


cleanup_check('transient_visibility_error')
cleanup_check('known_live_child')

old = Path('izzet-takeover/shared-receiving/legacy-factory-control/qualify.py')
old_nodes = {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(old.read_bytes()).body
             if isinstance(n, ast.FunctionDef)}
changed = sorted(k for k, n in nodes.items() if old_nodes.get(k) != ast.dump(n, include_attributes=False))
assert changed == ['owned_group_members', 'run_capped', 'terminate_owned_group']
result = {'schema': 'independent-pure-visibility-successor-checks/v1', 'source_sha256': EXPECTED,
          'reviewer': '/root/ferocity', 'scope': 'Only AST-extracted functions and in-memory fake interfaces. No subprocess, JVM, signal, /proc read, package, fixture or gameplay execution.',
          'changed_function_ASTs': changed, 'checks': checks, 'passed': len(checks)}
(HERE / 'independent-visibility-successor-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': len(checks), 'source_sha256': EXPECTED, 'changed_function_ASTs': changed}))
