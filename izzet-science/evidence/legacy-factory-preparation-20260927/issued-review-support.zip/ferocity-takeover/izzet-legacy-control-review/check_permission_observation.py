"""Pure in-memory reproduction of the 67ba process-observation finding.

This imports only two AST function bodies. It creates no process, reads no /proc
entry, sends no signal, and does not import or execute the qualification module.
"""
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

SOURCE = Path("izzet-takeover/shared-receiving/legacy-factory-control/qualify.py")
EXPECTED = "67ba5871d5c4dc64b1674096389be05118023596ed14d88261b7b78f4e67ffbc"
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
selected = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef)
            and node.name in ("owned_group_members", "terminate_owned_group")]


class FakePath:
    def __init__(self, value):
        self.value = str(value)
        self.name = self.value.rsplit("/", 1)[-1]

    def __truediv__(self, other):
        return FakePath(self.value + "/" + str(other))

    def iterdir(self):
        return iter([FakePath("/proc/12345")])

    def read_text(self):
        raise PermissionError("synthetic denied owned process observation")


class FakeOS:
    @staticmethod
    def readlink(path):
        return "pid:[review-synthetic]"

    @staticmethod
    def killpg(*args):
        raise AssertionError("No real signals permitted by this static review")


class ExitedWrapper:
    pid = 77

    def poll(self):
        return 0

    def wait(self, timeout=None):
        return 0


scope = {"Path": FakePath, "os": FakeOS,
         "signal": SimpleNamespace(SIGTERM=15, SIGKILL=9),
         "subprocess": SimpleNamespace(TimeoutExpired=TimeoutError),
         "time": SimpleNamespace()}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE), "exec"), scope)
result = scope["terminate_owned_group"](ExitedWrapper())
assert result["quiescent"] is True and result["errors"] == [] and result["signals"] == []
print(json.dumps({"source_sha256": EXPECTED, "actual": result}, indent=2))
