"""Read-only exact-source and original-trace checks for the baseline proposal."""
import base64,hashlib,json,pathlib,re,zipfile
import xml.etree.ElementTree as ET
HERE=pathlib.Path(__file__).resolve().parent; ROOT=HERE.parents[1]; P=ROOT/'izzet-takeover/shared-receiving'
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
inputs=json.loads((P/'baseline-proposal-inputs.json').read_text())
for n,h in inputs.items():assert sha((P/n).read_bytes())==h
independent=json.loads((HERE/'independent-priority-source.json').read_text())
raw={}
for r in independent:
 assert r['status']=='fulfilled';v=r['value'];raw[v['ref'],v['path']]=v['data']['structuredContent']['content'].encode()
old='50eca5fb955013d70ea26c3c6a09efabef4bcff4';cur='8b05f2cecee6e992f7eca6d77695040f32901f40';donor='994383d4a9495bcb34d5aae0e69181bcf4c04d45';recv='b6fc446543d3ce566bb12c60d1ab6b84e1c96d8c'
priority={}
for p,expected in [('rules-engine/src/main/kotlin/com/wingedsheep/engine/handlers/actions/combat/DeclareBlockersHandler.kt','92ec0a430c583371e3d37b15bec3520f7cff541e'),('rules-engine/src/main/kotlin/com/wingedsheep/engine/mechanics/combat/BlockDeclarationProcessor.kt','c5b84fc475e57b5d019606829725063c35dcd1e5'),('rules-engine/src/main/kotlin/com/wingedsheep/engine/mechanics/CastPriorityProcessor.kt','ae82f39ef1ebbd462d65c47ce4b0939d2338b7dc')]:
 assert raw[cur,p]==raw[donor,p]==raw[recv,p] and blob(raw[cur,p])==expected
 priority[p]={'git_blob':expected,'sha256':sha(raw[cur,p]),'equal_refs':[cur,donor,recv]}
trees=json.loads((ROOT/'pest-takeover/izzet-sequence-source-review/baseline-independent-ai-trees.json').read_text());maps={};main={}
for r in trees:
 assert r['commit']['tree']['sha']==r['root']['sha'] and not r['root']['truncated'] and not r['ai']['truncated']
 assert next(e['sha'] for e in r['root']['tree'] if e['path']=='ai')==r['ai']['sha']
 maps[r['sha']]={'ai/'+e['path']:e['sha'] for e in r['ai']['tree'] if e['type']=='blob'}
 main[r['sha']]={p:h for p,h in maps[r['sha']].items() if p.startswith('ai/src/main/')}
assert len(main[old])==227 and len(main[cur])==228
common=set(main[old])&set(main[cur]);same={p for p in common if main[old][p]==main[cur][p]}
changed=sorted(common-same);added=sorted(set(main[cur])-set(main[old]));removed=sorted(set(main[old])-set(main[cur]))
assert len(same)==225 and not removed and changed==['ai/src/main/kotlin/com/wingedsheep/ai/engine/DecisionResponder.kt','ai/src/main/kotlin/com/wingedsheep/ai/engine/GameSimulator.kt'] and added==['ai/src/main/kotlin/com/wingedsheep/ai/engine/YesNoDecisionStrategy.kt']
author_source={}
for f in ['baseline-source-deltas.json','baseline-profile-dispatch.json','baseline-factory-dispatch.json']:
 for r in json.loads((P/f).read_text()):
  assert r['status']=='fulfilled';v=r['value'];ref=v.get('ref',cur);p=v['path'];b=v['data']['content'].encode();author_source[ref,p]=b
  if p.startswith('ai/'):assert blob(b)==maps[ref][p]
  if (ref,p) in raw:assert raw[ref,p]==b
test='ai/src/test/kotlin/com/wingedsheep/ai/arena/FrozenBaselineTest.kt'
old_test=raw[old,test];new_test=author_source[cur,test]
assert blob(old_test)=='69006814d54b85a11673093a907f267172e238e2' and blob(new_test)=='bfeb52503c604549b7625fa02a486a0f85cfdbef'
for b in [old_test,new_test]:assert b'private const val GOLDEN_HASH = "47e993c61a57ebbd"' in b
assert re.search(rb'private val FROZEN_DECK = Deck\([\s\S]*?\n        \)',old_test).group()==re.search(rb'private val FROZEN_DECK = Deck\([\s\S]*?\n        \)',new_test).group()
assert re.search(rb'private const val FROZEN_SEED = .*',old_test).group()==re.search(rb'private const val FROZEN_SEED = .*',new_test).group()
responder=author_source[cur,'ai/src/main/kotlin/com/wingedsheep/ai/engine/DecisionResponder.kt'].decode()
factory=author_source[cur,'ai/src/main/kotlin/com/wingedsheep/ai/engine/AIPlayer.kt'].decode()
assert 'val yesNoStrategy: YesNoDecisionStrategy = YesNoDecisionStrategy.COMPLETED_BRANCH_V1' in responder
call=factory.split('val responder = DecisionResponder(',1)[1].split('\n            )',1)[0]
assert 'yesNoStrategy' not in call
assert 'ArenaAgent("v0", AiProfile.LEGACY_V0)' in raw[cur,'ai/src/test/kotlin/com/wingedsheep/ai/arena/ArenaAgent.kt'].decode()
original=ROOT/'attachments/686ca404-d1f9-4283-a475-8170306dbd39/izzet-c47e-base-diagnostic-10916376133.zip'
assert sha(original.read_bytes())=='28759ae2198dc4efc2a64ae069f4d74408e9667da85222f9c918417be6cc6b74'
with zipfile.ZipFile(original) as z:
 assert z.testzip() is None
 oldxml=ET.fromstring(z.read('FrozenBaselineTest/raw-test-results/TEST-com.wingedsheep.ai.arena.FrozenBaselineTest.xml'))
 assert len(oldxml.findall('testcase'))==1 and all(oldxml.attrib[k]=='0' for k in ['failures','errors','skipped'])
 stream=[]
 for node in oldxml.iter('system-out'):
  for line in (node.text or '').splitlines():
   if line.startswith('IZZET_DIAGNOSTIC_TRACE '):stream.append(base64.b64decode(line.split(' ',1)[1],validate=True))
 old_stream=b''.join(stream);assert old_stream==z.read('FrozenBaselineTest/baseline-hash-input.bin') and len(stream)==413
 assert z.read('original-source/'+test)==old_test
currentdir=P/'prospective-failure-diagnostic/publication/izzet-science/evidence/passive-failure-diagnostic-36282117960'
assert old_stream==(currentdir/'accepted-base-stream.txt').read_bytes()
new_stream=(currentdir/'candidate-stream.txt').read_bytes();old_lines=old_stream.splitlines();new_lines=new_stream.splitlines()
assert len(old_lines)==len(new_lines)==413
diff=[i for i,(a,b) in enumerate(zip(old_lines,new_lines)) if a!=b];assert len(diff)==14
derived=[]
for a,b in zip(diff[::2],diff[1::2]):
 assert b==a+1 and b'DeclareBlockers(' in new_lines[a-1]
 attack=next(x for x in reversed(new_lines[:a]) if b'|DECLARE_ATTACKERS|DeclareAttackers(' in x)
 assert attack.split(b'|')[1]==new_lines[a].split(b'|')[1] and new_lines[a-1].split(b'|')[1]==old_lines[a].split(b'|')[1]
 assert old_lines[a].split(b'|',1)[1]==new_lines[b].split(b'|',1)[1] and old_lines[b].split(b'|',1)[1]==new_lines[a].split(b'|',1)[1]
 derived.append({'entries':[a+1,b+1],'most_recent_attack_declaration':attack.decode(),'current_first_pass':new_lines[a].decode(),'attacking_player_gets_first_postblock_priority':True})
proposal_derive=json.loads((P/'baseline-current-priority-derivation.json').read_text());assert derived==proposal_derive['pairs']
assert new_lines[-1]==old_lines[-1]==b'END|turns=20|winner=1|life=-8/16'
report={'schema':'izzet-baseline-proposal-independent-checks-v1','proposal_inputs':inputs,'additional_priority_derivation_sha256':sha((P/'baseline-current-priority-derivation.json').read_bytes()),'priority_source_equal':priority,'ai_production':{'old_files':227,'current_files':228,'identical_existing_files':225,'changed':changed,'added':added,'removed':removed},'original_golden_retained':True,'literal_deck_seed_equal':True,'old_stream_sha256':sha(old_stream),'current_stream_sha256':sha(new_stream),'entries_per_stream':413,'bytes_per_stream':len(new_stream),'seven_attacker_first_pairs':derived,'effective_default_strategy_unresolved':True,'scope':'Source/governance proposal checks only; no source mutation or execution.'}
(HERE/'independent-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'check_sha256':sha((HERE/'independent-checks.json').read_bytes()),'ai_files':[227,228,225],'priority_pairs':len(derived),'source_mutations':0,'tests_executed':0}))
