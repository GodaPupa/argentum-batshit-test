# Route B operational backend candidates — LOCAL ONLY

Disposition: PARTIAL_OPERATIONAL_CANDIDATES_FROZEN__NOT_DEPLOYABLE__INDEPENDENT_REVIEW_PENDING.

This is substantive new candidate code, not an operational qualification or a claim that all requested backends are complete. It deliberately leaves the accepted five runtime barriers and all original artifacts unchanged. No live connection, unit creation, BPF load/attach, pidfd acquisition, cgroup write, helper execution, deployment, compiler or gameplay was performed. Live candidate constructors unconditionally refuse; no environment variable or JSON approval enables them. A future reviewed deployment must supply the remaining integrations and source-bound authority, not merely remove a barrier.

## Exact starting evidence

- Reconciliation ZIP: 4fd04abeaf7e9b9192d2ce25800c4630c72952500e8d14a1f35b5539ef0d5a8f.
- Original Decision B receipt: d02d3b7970de08ae902cb6aebd3384b71c3fcfd9b5d3033907a6bb2610b01c40.
- Original V6.3 archive: f572837b5008e1ffa7e0e83b8d2e7f386cd444bf37206646c8bb74def393b27a.
- Frozen source commit: de40fd2b79348c76b10d491b1df0e3aa36a88ed4.
- Unit contract: 6dddfa5f30311a76d19bebc5d7433ce3692e92e3324b0d42e7698d01f319c7d2.

## Implemented versus unresolved

| Lane | Implemented candidate | Not implemented or not demonstrated |
|---|---|---|
| Manager | Fixed system-bus dbus-next adapter, SASL EXTERNAL selection, SO_PEERCRED check, stable unique owner/PID1/boot checks, fixed unit introspection and readback, effective-property validation; descriptor-relative no-symlink D/S/C broker; mount/proc identity helpers; fixed StartTransientUnit serialization and one-attempt transaction coordinator | Actual connection and systemd ABI validation; audited dependency wheel/hash; version/readback integration; atomic binding of installed supervisor bytes to execution; creation of C and controller setup under a reviewed delegation transaction; upstream effect authority; end-to-end trusted control implementation |
| Observer | Concrete libbpf ring-buffer FFI consumer, bounded record decoding, per-CPU sequence and loss checks, descendant tracking, syscall pairing, durable raw-record journal; no record can confer kernel authentication or qualification | Kernel program and loader; BTF/hook selection; map identity verification; kernel image-FD hash, resolved inode, actual credential/seccomp proofs; producer-side losses, CPU hotplug protocol, complete inherited model-receipt adapter and qualified attach-to-drain evidence |
| Watchdog | Root-peer SCM_RIGHTS escrow receiver candidate; owned held-D descriptor and fixed cgroup.kill/events plumbing; one-attempt state machine, pre-C/pre-pidfd failure triggers, supervisor death/heartbeat/observer loss/deadline triggers, bounded drain checks and fsynced journal | External service launcher, actual pidfd/heartbeat event loop, sender side escrow, supervisor-independent survival qualification, race-safe manager revalidation callback and exact inactive-state evidence source |

Host-independent missing integrations are listed above rather than mislabeled as information that only a host can supply. The package is suitable for changed-source review and further implementation, not an acceptance request for complete deployment readiness. No BPF program was fabricated from guessed kernel offsets. The ring consumer's bounded JSON framing is a proposed producer ABI, not an existing kernel event format or evidence that a compatible producer exists.

## Validation

38 focused tests pass. Eight isolated mutations are detected: owner drift, bus peer, stale invocation, delegation, event binding, loss counters, cleanup deadline and inactive-state gating. Mutations run concurrently in isolated temporary copies. Tests use mocked transports/backends and ordinary temporary files/directories; no frozen qualification suite was rerun. Three-stage test logs are preserved; no failing test runs occurred. A code-inspection correction is recorded in CHANGE_NOTES.md. AST syntax checks passed. Fresh-extraction test and mutation verification is required by freeze.py and was performed for the delivered package.

Test injections (wire, filesystem identity, backend, clock) are not trust boundaries and confer no production authority. Hash chains are tamper-evident only against an independently retained tip; they are not signatures. No independently authenticated Reviewer B verdict is included.

## Reproduction

Use Python 3.12 in an isolated local directory. No external package installation is needed for the synthetic checks.

```
python3 -B -m unittest discover -s tests -v
python3 -B mutate.py
python3 -B freeze.py --check
```

Do not import this candidate into the published source or enable its live constructors. Optional future runtime dependency targets are dbus-next 0.2.3 and libbpf.so.1; they were not installed or invoked, their artifact hashes are not frozen, and these version names are not a sufficient deployment lock. No ELF is built by this package and no local Git commit is claimed. source.patch is a reproducible addition-only patch; reference/ contains immutable requirement sources for review.

The original Decision B observation must not be repeated. C4 remains INCOMPLETE, D2 BLOCKED; no gameplay authority is issued.
