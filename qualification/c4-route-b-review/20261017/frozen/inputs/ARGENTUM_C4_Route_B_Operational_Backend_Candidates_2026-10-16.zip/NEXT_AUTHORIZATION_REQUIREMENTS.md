# Next authorization requirements — no executable authorization yet

Present action allowed: independent changed-source assessment and completion of local backend integrations. Existing owner local-only authority need not be requested again.

Before requesting any host execution, freeze and review the complete operational package, dependencies, supervisor/helper and kernel provider; bind a named target/operator, exact unit and external watchdog, complete evidence protocol and all privilege/ancestor effects. Current source inventory hashes bind only these partial candidates and must not be reused to authorize unreviewed later changes.

Then request exactly one distinct noncompiler Route B enforcement original: authenticated systemd D/S/C setup, narrowly scoped kernel observer, prearmed external watchdog, fixed adversarial helper, original-only collection and bounded cleanup. Preserve every failed or uncertain outcome; no automatic retries or substitute originals. This is not a Decision B rerun. Any GitHub ref/workflow transport needs its own exact scope if used.

Protected R5/R6 compilation, D2, G11 and gameplay remain excluded. Qualification must precede separate C4 compile authority and D2 admission. No favorable acceptance JSON, runtime permit, target identity or run number is fabricated here.
