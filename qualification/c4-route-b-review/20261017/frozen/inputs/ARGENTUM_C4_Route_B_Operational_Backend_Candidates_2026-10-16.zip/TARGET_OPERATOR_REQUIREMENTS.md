# Required target and operator bindings

No target is selected and no host-side operation is authorized by this sheet.

1. Identify the controlling operator, named host, architecture/kernel build and BTF digest, immutable boot/run identity acquisition method and precise approval for one noncompiler enforcement original. Do not promote GitHub path hints to these bindings.
2. Bind systemd version and live D-Bus introspection. Confirm the exact fixed service's Delegate/DelegateControllers/DelegateSubgroup and property ABI; authenticate the bus peer and root PID1 unique owner in the same namespace. Freeze dependency artifacts and the reviewed private dbus-next socket access or replace it with an audited public interface.
3. Establish a normal host cgroup2 root with hierarchical events, exact mount/namespace/FD identity and ACL semantics. Reserve a non-root worker identity. Allow only authenticated D descendants. Specify whether upstream controller enabling occurs; absent explicit approval any such difference is a stop.
4. Select reviewed non-stopping hooks for fork/exec/exit/reparent/cgroup moves, syscall entry/return, kernel-resolved FD/inode, pinned executed image, credentials and seccomp. Supply actual BTF/LSM compatibility and attach rights. Freeze BPF/loader/map artifacts, record ABI, loss-map semantics and CPU hotplug behavior. A ring FD supplied by a caller is not kernel provenance.
5. Bind an independently controlled root watchdog outside D/S/C, persistent across supervisor death, with authenticated descriptor transfer and exact-invocation lifecycle controls. Specify lease/pre-C/pre-pidfd failure handling and bounded drain. No StopUnit-by-name or numeric-PID fallback.
6. Freeze the actual supervisor/helper binaries, source/run hashes and installation ownership. Complete same-FD image execution, privilege/seccomp and scratch-FD checks inherited from Route B before releasing any worker.
7. Specify evidence destination, independent journal-tip retention, complete original ID/attempt, immutable logs, final memory counters and cleanup receipts. Missing evidence remains INCOMPLETE; scoped positive OOM or escape remains FAIL.

The existing GitHub-hosted runner is not qualified by Decision B. No finding here proves it cannot meet these requirements. Host selection and remaining local implementation can proceed in parallel. Selection is not authorization to provision, deploy, trace or execute.
