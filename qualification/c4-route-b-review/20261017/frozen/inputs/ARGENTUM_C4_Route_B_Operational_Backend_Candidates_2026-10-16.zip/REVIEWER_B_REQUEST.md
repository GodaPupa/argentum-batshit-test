# Independent changed-source review request — acceptance not issued

Reviewer must disclose actual material involvement in architecture, implementation, repairs, tests, previous reviews or conductor decisions. A different chat or model name alone is not independence. Identify the attributable review channel and exact package/source hashes. Author and implementing assistant do not self-issue acceptance.

Scope: only new src/, tests/, mutate.py, freeze.py, configuration and documented integration assumptions. Reuse unchanged prior source assessments within their stated scope. Do not claim that previous source-only or importer acceptance covers these operational candidates.

Assess:

- Read and write endpoint restrictions; fixed command/unit serialization; dependency provenance; D-Bus connection, SASL, peer credentials and unique-owner/namespace/boot binding.
- Effective-property mapping against actual target ABI; absence of guessed ControlGroup or arbitrary command arguments; descriptor ownership, ACL, mount and lifetime checks.
- Source/installation/image identity TOCTOU and upstream effects. Distinguish an unimplemented control interface from an authenticated implementation.
- Observer's proposed producer ABI, libbpf FFI, bounded decoding, failure/loss handling, positive-signal retention and absence of a complete kernel producer. It must not be called a complete observer backend.
- Watchdog independence, escrow descriptor ownership, pre-release coverage, no retry after uncertain kill, disk failures, exact invocation revalidation, final drain and bounded termination. External event loop and deployment integrations are missing.
- Synthetic test validity and mutation detection. No fixture may become operational permission or kernel attestation. Inactive-manager boolean is currently an injected test interface, not authenticated proof.
- All five frozen runtime entry points remain unchanged. No hosted operation or compilation was performed.

Return a source-bound assessment separating acceptable components, defects and required implementation/host bindings. The requested review may accept individual components for continued local development; it cannot declare complete deployment or runtime qualification while listed gaps remain.
