#!/usr/bin/env python3
"""Run project-selected deterministic real-engine tests through the repository's just gate.

No gameplay is initialized and no experimental seeds are generated here. Existing
fixed scenario seeds remain fixture identities, never randomized development data.
Each test invocation preserves its XML before another invocation can replace it.
An absent prerequisite, empty XML, skipped test, compile error, or assertion failure
fails visibly. The first failure stops dependent validation; it is not rerolled.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
BASE = "d0c78bb4cca79b7402ba65bd62b5cb621230a054"
TESTS = {
    "RestrictedActivatedXScenarioTest": "rules-engine",
    "FerocityOfTheHuntScenarioTest": "rules-engine",
    "CryptRatsScenarioTest": "rules-engine",
    "ToxinAnalysisScenarioTest": "mtg-sets/2024/tests",
    "KrarkClanShamanScenarioTest": "mtg-sets/2003-2007/tests",
    "NotDeadAfterAllScenarioTest": "mtg-sets/2023/tests",
    "RefurbishedFamiliarScenarioTest": "mtg-sets/2024/tests",
    "MalevolentRumbleScenarioTest": "mtg-sets/2024/tests",
    "FanaticalOfferingScenarioTest": "mtg-sets/2023/tests",
    "IchorWellspringScenarioTest": "mtg-sets/2008-2016/tests",
    "ShamblingGhastScenarioTest": "mtg-sets/2017-2022/tests",
    "BloodFountainScenarioTest": "mtg-sets/2017-2022/tests",
    "MakeshiftMunitionsScenarioTest": "mtg-sets/2017-2022/tests",
    "GrixisAffinityAgentDecisionTest": "ai",
}
DEFAULT_TESTS = tuple(TESTS)
BUILD_FILES = (
    "gradle/libs.versions.toml", "gradle/wrapper/gradle-wrapper.properties",
    "gradle/wrapper/gradle-wrapper.jar", "build.gradle.kts", "settings.gradle.kts",
    "gradle.properties", "buildSrc/src/main/kotlin/kotlin-jvm.gradle.kts",
    "gradlew", "gradlew.bat", "justfile", "scripts/test-class", "scripts/gradle-locked",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stamp() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def output(command: list[str]) -> str:
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
    if result.returncode:
        raise RuntimeError(f"{command[0]} failed ({result.returncode}): {result.stderr.strip()}")
    return (result.stdout + result.stderr).strip()


def source_roots(classes: list[str] | tuple[str, ...]) -> list[Path]:
    roots = [ROOT / name / "src/main" for name in ("mtg-sdk", "rules-engine", "ai", "gym", "buildSrc")]
    roots.append(ROOT / "rules-engine/src/testFixtures")
    roots.extend((ROOT / "mtg-sets").glob("**/src/main"))
    roots.extend(ROOT / TESTS[name] / "src/test" for name in classes)
    return roots


def is_compiled_input(name: str, classes: list[str] | tuple[str, ...]) -> bool:
    """Use path membership, not existence: a deleted source must fail the dirty guard."""
    if name in BUILD_FILES or Path(name).name in {"build.gradle.kts", "settings.gradle.kts"}:
        return True
    if name.startswith("mtg-sets/") and "/src/main/" in name:
        return True
    return any(name.startswith(str(root.relative_to(ROOT)) + "/") for root in source_roots(classes))


def compiled_inputs(classes: list[str] | tuple[str, ...]) -> dict[str, str]:
    """Pin Kotlin/Java/KTS and classpath resources, including untracked fixtures."""
    paths = {ROOT / name for name in BUILD_FILES}
    paths.update(ROOT.glob("**/build.gradle.kts"))
    paths.update(ROOT.glob("**/settings.gradle.kts"))
    for base in source_roots(classes):
        if base.exists():
            paths.update(p for p in base.rglob("*") if p.is_file())
    return {
        str(path.relative_to(ROOT)): sha(path) for path in sorted(paths)
        if "/build/" not in str(path.relative_to(ROOT)) and "/.gradle/" not in str(path.relative_to(ROOT))
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--classes", nargs="+", choices=TESTS, default=DEFAULT_TESTS)
    parser.add_argument("--expected-head")
    args = parser.parse_args()
    report_dir = args.out.resolve()
    report_dir.mkdir(parents=True, exist_ok=False)
    receipt = {
        "schema": "ferocity-recycling-real-engine-qualification-v1",
        "started_at_utc": stamp(),
        "scope": "DETERMINISTIC_BUILD_CARD_AND_FIXED_POLICY_FIXTURES_ONLY",
        "interactive_development_games": 0, "evaluation_games": 0,
        "confirmation_games": 0, "randomized_experimental_seeds": 0,
        "status": "RUNNING", "stages": [],
    }
    receipt_path = report_dir / "receipt.json"

    def write() -> None:
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")

    write()
    try:
        receipt["source_head"] = output(["git", "rev-parse", "HEAD"])
        receipt["source_tree"] = output(["git", "rev-parse", "HEAD^{tree}"])
        input_hashes = compiled_inputs(args.classes)
        tracked_changes = output(["git", "diff", "--name-only", "HEAD"]).splitlines()
        untracked = output(["git", "ls-files", "--others", "--exclude-standard"]).splitlines()
        receipt["tracked_compiled_input_changes"] = [p for p in tracked_changes if is_compiled_input(p, args.classes)]
        receipt["untracked_compiled_inputs_sha256"] = {p: input_hashes[p] for p in untracked if p in input_hashes}
        receipt["source_is_dirty"] = bool(receipt["tracked_compiled_input_changes"] or receipt["untracked_compiled_inputs_sha256"])
        inputs_path = report_dir / "compiled-inputs-before.json"
        inputs_path.write_text(json.dumps(input_hashes, indent=2) + "\n")
        receipt["compiled_inputs_before_sha256"] = sha(inputs_path)
        receipt["base_commit"] = BASE
        output(["git", "merge-base", "--is-ancestor", BASE, receipt["source_head"]])
        if args.expected_head and args.expected_head != receipt["source_head"]:
            raise RuntimeError("Checked-out source does not match expected head")
        if args.expected_head and receipt["source_is_dirty"]:
            raise RuntimeError("CI runtime/test compile inputs differ from committed expected head")
        if not shutil.which("just"):
            raise RuntimeError("Required just executable absent; raw Gradle bypass is forbidden")
        receipt["java_version"] = output(["java", "-version"])
        receipt["just_version"] = output(["just", "--version"])
        receipt["build_file_sha256"] = {name: sha(ROOT / name) for name in BUILD_FILES}
        receipt["runner_sha256"] = sha(Path(__file__))
        write()
        for name in args.classes:
            module = TESTS[name]
            sources = list((ROOT / module / "src/test/kotlin").rglob(f"{name}.kt"))
            if len(sources) != 1:
                raise RuntimeError(f"Expected exactly one source file for {name}; found {len(sources)}")
            stage_dir = report_dir / name
            stage_dir.mkdir()
            # Archive then remove only this class's old XML. A cached prior success
            # must not masquerade as a test executed by this invocation.
            old_xml = sorted((ROOT / module / "build/test-results/test").glob(f"TEST-*{name}.xml"))
            if old_xml:
                archive = stage_dir / "preexisting-xml"
                archive.mkdir()
                for path in old_xml:
                    shutil.copyfile(path, archive / path.name)
                    path.unlink()
            command = [
                "just", "test-class", name, "--rerun", "--console=plain", "--stacktrace",
                "--no-build-cache",
                "--max-workers=2", "-PkotlinCompileParallelism=1",
            ]
            stage = {
                "test_class": name, "module": module, "started_at_utc": stamp(),
                "command": command, "source_path": str(sources[0].relative_to(ROOT)),
                "source_sha256": sha(sources[0]), "status": "RUNNING",
            }
            receipt["stages"].append(stage)
            write()
            print(f"Running {name}", flush=True)
            with (stage_dir / "build.log").open("w") as stream:
                result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            stage["exit_status"] = result.returncode
            stage["finished_at_utc"] = stamp()
            xml_files = sorted((ROOT / module / "build/test-results/test").glob(f"TEST-*{name}.xml"))
            copied = []
            totals = {key: 0 for key in ("tests", "failures", "errors", "skipped")}
            for source in xml_files:
                dest = stage_dir / source.name
                shutil.copyfile(source, dest)
                root = ET.parse(dest).getroot()
                for key in totals:
                    totals[key] += int(root.attrib.get(key, "0"))
                copied.append({"name": dest.name, "sha256": sha(dest)})
            stage["test_xml"] = copied
            stage["totals"] = totals
            stage["log_sha256"] = sha(stage_dir / "build.log")
            task = ":" + module.replace("/", ":") + ":test"
            task_statuses = re.findall(
                r"^> Task " + re.escape(task) + r"(?: ([^\r\n]*))?$",
                (stage_dir / "build.log").read_text(), re.MULTILINE,
            )
            stage["observed_test_task_statuses"] = task_statuses
            stage["test_task_executed"] = bool(task_statuses) and all(
                status in {"", "FAILED"} for status in task_statuses
            )
            passed = result.returncode == 0 and stage["test_task_executed"] and totals["tests"] > 0 and not any(
                totals[key] for key in ("failures", "errors", "skipped")
            )
            stage["status"] = "PASS" if passed else "FAIL"
            write()
            if not passed:
                raise RuntimeError(f"{name} did not qualify; preserve logs and diagnose before any successor")
        receipt["status"] = "PASS"
        receipt["qualification_limit"] = (
            "Only the recorded deterministic assertions passed. This is not production card "
            "admission, complete selected-pool coverage, pilot totality, or matchup evidence."
        )
    except Exception as exc:
        receipt["status"] = "FAIL"
        receipt["failure"] = {"type": type(exc).__name__, "message": str(exc)}
        print(str(exc), file=sys.stderr)
    finally:
        if "compiled_inputs_before_sha256" in receipt:
            try:
                after = compiled_inputs(args.classes)
                after_path = report_dir / "compiled-inputs-after.json"
                after_path.write_text(json.dumps(after, indent=2) + "\n")
                receipt["compiled_inputs_after_sha256"] = sha(after_path)
                receipt["compiled_inputs_unchanged"] = receipt["compiled_inputs_before_sha256"] == receipt["compiled_inputs_after_sha256"]
                if not receipt["compiled_inputs_unchanged"]:
                    receipt["status"] = "FAIL"
                    receipt["source_change_failure"] = "Compiled inputs changed during validation; no assertions admitted"
            except Exception as exc:
                receipt["status"] = "FAIL"
                receipt["compiled_inputs_unchanged"] = False
                receipt["source_change_failure"] = f"Final source capture failed: {type(exc).__name__}: {exc}"
        receipt["finished_at_utc"] = stamp()
        write()
    print(json.dumps({"status": receipt["status"], "receipt": str(receipt_path)}), flush=True)
    return 0 if receipt["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
