# Red Madness pilot v0.1

Status: authored, not yet compiled or qualified. Development, evaluation and confirmation randomized games: **0**. The 24 fixed cases are policy and mechanics checks, not matchup samples. No case has executed on this initial pilot source.

## Exact role and evidence boundary

This pilot represents the archived MisterTwin Mono Red Madness list from the 2026-09-24 Pauper Challenge 32. The complete source 60/15 remains unchanged; this policy version covers its preboard 60 against the declared first-cell A3-F4/A3-N0 public pool. `card-identity.json` binds the exact source lists and the twelve main-deck card records. The event payload is the audited MTGGoldfish mirror, with the original provenance limitations retained in the benchmark JSON.

The executable interface is `choose(ActorInput): ActorProposal`. The policy receives only a detached actor observation, the actor's pending typed question, complete legal action templates and the bound policy RNG state. It has no `GameState`, registry, environment, full journal, opponent hand, library contents or simulator callback. It does not consume a random value. Choices use public facts and explicit deterministic priorities. Numerical combat priorities choose an action; they never replace a game outcome or evaluate a deck's strength.

The shared `ActorPublicCards` resolves only visible entities. `ActorChoiceSupport` validates explicit targets, mode selections and additional-cost selections against the complete supplied domain, then copies the actual action template. It never chooses consent, targets or costs by itself. Unsupported payment channels, question shapes, hidden or absent entities, and unexplained pending Shaman source identities throw visibly. A rejected action is not repaired, retried or converted into a pass.

## Tactical choices fixed before outcomes

The mulligan policy rejects zero-land or severely flooded hands, preserves a two- or three-land development plan, and evaluates whether the retained hand has immediate pressure or Looting. London bottoming removes surplus lands and redundant expensive/support cards before the only spell-damage creature. At three mulligans the policy accepts any hand with a land; this is a bounded practical rule, not a claim that every such hand is optimal.

On a clear board it develops Flamebreather or Guttersnipe before nonurgent spells. These cards require their actual two or three mana and receive no imaginary damage from a future unknown spell. The pilot acts on direct available lethal, timely removal and explicit combat opportunities before routine development. It preserves mana for Fiery Temper when discarding it, accepts the actual madness cast opportunity only when it can pay, and still chooses legal targets and submits the spell through the engine.

Snacker planning reads the actual cards-drawn-this-turn public counter. A draw-two spell is sufficient only if it will include the third draw while Snacker is already in the graveyard. Discarding Snacker after Looting's two draws does not retroactively trigger it. A returned Snacker stays tapped and has no haste. The policy cannot ordinarily hard-cast it from the exact nineteen-Mountain mana base.

Fireblast pays two distinct Mountains, and Dart flashback pays one. Artifact bridges without the Mountain subtype cannot pay those costs. Sacrificed lands are charged even when the spell is countered. The policy reserves these costly lines for lethal, necessary removal or a declared late-race condition. A one-damage removal attempt on a larger creature requires an actual second burn spell with sufficient combined available mana.

Highway Robbery makes its real optional discard-or-sacrifice choice during resolution, after both players have had the casting response window. No cast-time modes are announced. Plot spends mana and exiles the card without casting it; the subsequent free cast still requires its actual legal timing and resolution choice. Sazacap's Brew uses the repaired genuine Gift template: recipient and complete targets are fixed during casting, one actual card is discarded, and the opposing tapped Fish is real material. This initial policy gifts only when the friendly boost enables immediate unblocked combat lethal. It does not use a legacy resolution-time recipient shortcut.

Shaman activation costs only sacrificing an artifact. A tapped, summoning-sick or returned Shaman may activate; no extra red mana is charged. The pilot does not assume killing a Shaman cancels a queued activation. For a pending ability, it distinguishes a live original source from a departed source and the returned creature's new object identity using the reviewed public source projection. If that information is unavailable, it fails visibly instead of treating the ability as cancelled.

Combat uses the shared public-board `ActorCombatPlanner`: legal attackers and blockers, actual flying/deathtouch/lifelink/indestructible handling within the declared pool, same-event life gain, and complete owned damage edges. No hidden opponent response or future draw is inspected. Spell-damage engines have explicit preservation priorities (Guttersnipe 10, Flamebreather 8); these are tactical policy constants fixed before the bank runs. They are not card-advantage counts or win probabilities.

## Fixed bank, versioning and admission

`FIRST_CELL_POLICY_PLAN.md` is copied byte-for-byte from the parent plan. `RedMadnessPilotScenarioTest` contains exactly its twenty-four Red cases, from London decisions through discard/madness, draw-three timing, Plot, true Gift, physical Mountain payments, countered flashback and combat. Each actor proposal and the bound actor input are printed into the preserved test output. Each selected action is submitted once. Opposing passes or the named Counterspell are fixed disruption behavior, not a matchup pilot.

The fixture explicitly registers the canonical selected card corpus after `ScenarioTestBase`, whose test-only card definitions otherwise override some familiar names. It calls the runtime journal's existing `fullMenu` for London setup and complete legal enumeration. There is one legal-action surface, not a canned pilot-specific menu.

Initial v0.1 and at most two documented tactical revisions (v0.2/v0.3) are allowed by the parent plan. These authoring decisions precede all policy outcomes. Later engine or serialization repairs must preserve failed evidence and describe their effect on fixture or gameplay validity; they do not silently create additional tactical revision opportunities. No randomized pilot training, D2 run, or outcome selection is authorized by this file itself.

The first execution requires the exact combined engine and card source: qualified LKI/priority/optional-trigger ordering, paid flashback stack exits, genuine instant Gift, Highway Robbery resolution choice and madness-aware drawing, current combat-damage assignment, and the v3.1 public observer. The v3.1 copy in this worktree is an authoring dependency, not a claim of acceptance; it depends on engine LKI fields not present in this worktree's original base. Compilation and tests are dispatched only by the shared build owner after integration and source capture. Passing the fixed bank will qualify the tested behavior and decision surface; it will not prove this benchmark pilot is optimal or that either deck wins a matchup.
