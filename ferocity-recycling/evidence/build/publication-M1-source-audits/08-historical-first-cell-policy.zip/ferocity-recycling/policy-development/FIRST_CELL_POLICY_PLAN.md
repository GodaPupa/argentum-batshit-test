# First development-cell pilots — pre-outcome plan

Status: authoring, no gameplay or policy-training result. Lists remain frozen at v0.1.

## Scope and opportunity

Implement actor-only pilots for family A, first instantiated on A3-F4 and its complete A3-N0 comparator, and for the exact MisterTwin Red Madness benchmark. This is preparation for the already allocated first D2 cell. It adds no opponent, candidate, seed or game allocation. The same artifact pilot code handles Ferocity, Toxin and efficient return spells according to their actual functions; it does not force Ferocity casts or reward a card for originality.

Each pilot receives at most two documented D1 revisions, using at most 24 fixed policy scenarios per revision under the existing contract. The 24-case banks below are declared before policy outcomes. Replays of a case are fixed training/debugging work, not new matchup samples. The initial authored policy is v0.1; policy changes after inspecting these cases become v0.2 and at most v0.3, with exact changed behavior recorded. Required engine/serialization repairs do not silently become an extra tactical training budget.

The pilot receives only `ActorInput` and returns `ActorProposal`. It has no GameState, mutable registry, omniscient journal, opponent hand, hidden library order, authoritative RNG, evaluator callback or engine lookahead. Its deterministic action priorities are implementation choices, not deck scores or experimental outcomes. Equal opportunity means separate competent strategic policies with the same revision/work limits.

## Artifact control policy bank (24)

1. Mulligan a seven with no lands.
2. Keep a two-source hand with a castable early plan and follow-up draw/threat.
3. Mulligan a seven with six lands and no productive draw.
4. London bottom redundant support before the only castable threat or required color.
5. Play untapped red artifact mana before a bridge when current interaction is needed.
6. Develop a missing blue/black source when immediate interaction is not needed.
7. Cast an affinity-discounted Familiar without assuming future sacrificed artifacts still count.
8. Cast a free Enforcer while retaining actual mana for interaction.
9. Cash in Wellspring before sacrificing a needed artifact land.
10. Use Bargain in response to lethal burn when its actual life gain saves the player.
11. Do not count token mana value as invented Bargain life gain.
12. Use metalcraft Blast to remove a relevant four-toughness threat.
13. Take directly available lethal burn when legal.
14. Preserve a flying threat through a Shaman sweep where it survives legally.
15. Avoid an ordinary Shaman activation that kills important friendly creatures without sufficient benefit.
16. Pay Ferocity plus the actual Shaman fodder when its deathtouch sweep is worthwhile.
17. Prefer a saving Toxin lifelink sweep when life pressure makes Ferocity insufficient.
18. Use Not Dead After All to protect a useful creature when its cheaper role is appropriate.
19. Recognize target removal in response to Ferocity; do not assume its Aura resolved.
20. Treat a returned creature as tapped/new, without the departed Aura or imaginary haste.
21. Queue only the Shaman activations supported by actual remaining fodder and source identity.
22. Respond to an opposing graveyard return with Spellbomb when useful; select the correct player.
23. Attack with a credible evasive clock while retaining necessary defense.
24. Block a lethal attack using actual public attackers/flight/deathtouch and legal assignments.

## Red Madness policy bank (24)

1. Mulligan a zero-land seven.
2. Keep an ordinary two-Mountain hand with pressure and follow-up spells.
3. Mulligan a six-land seven without a viable draw plan.
4. London bottom excess land/support without discarding the only pressure spell.
5. Develop Flamebreather before a nonurgent spell when it creates real future damage.
6. Develop Guttersnipe when mana and survival permit its actual three-mana cost.
7. Cast lethal burn directly at the opponent when legal.
8. Remove a Shaman that otherwise produces a decisive sweep when removal can matter.
9. Avoid wasting a single damage spell on a larger creature without a supported follow-up.
10. Discard Fiery Temper to a legal outlet while retaining actual madness mana.
11. Accept and pay the resulting madness opportunity correctly.
12. Decline an unaffordable optional payment without inventing mana.
13. Discard Sneaky Snacker when the actual draw plan supports its return.
14. Count cards drawn this turn correctly for Snacker; two draws alone are not three.
15. Treat Snacker's return as tapped; do not attack with it immediately.
16. Choose Highway Robbery's exile option only when that is the intended real action.
17. Pay Sazacap's Brew discard once and choose its legal player target.
18. Consider Brew's gift cost and conditional friendly target; no free gifted card.
19. Save Fireblast's Mountain sacrifice for a justified lethal/race line.
20. Do not sacrifice the same Mountain twice or treat artifact bridges as Mountains.
21. Use Lava Dart's flashback with a real Mountain and charge the lost land.
22. Preserve paid costs when a flashback spell is countered; no imaginary draw/damage.
23. Attack profitably and account for Strix/deathtouch and flying blockers.
24. Block or burn to survive an actual lethal attack when racing fails.

## Admission and boundaries

All cases use qualified engine observations and actual legal-action domains. Assertions must evaluate the declared scenario's behavior rather than a canned role score. Unknown cards, mandatory decision schemas, or unsupported legal-action parameters fail visibly. An invalid action is retained as a failed attempt; there is no repaired fallback submission or silent pass.

Observer v2 is a reviewed dependency with 27 authored tests; its runtime qualification is pending. Public exact-source LKI projection, complete same-controller trigger ordering, selected cards, durable journal/replay, and applicable engine gates remain prerequisites. A board wipe or creature return is never treated as a game result. No D2 trial may be initialized until the actual combined-source admission record passes.
