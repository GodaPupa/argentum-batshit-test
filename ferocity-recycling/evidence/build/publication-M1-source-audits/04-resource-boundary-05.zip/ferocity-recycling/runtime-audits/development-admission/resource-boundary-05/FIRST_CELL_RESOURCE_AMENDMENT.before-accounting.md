# First-cell resource boundary — prospective amendment 05

This amendment governs the existing first sixteen D2 allocations only. Zero research games and zero production seed allocations have occurred. It changes no deck, pilot, matchup, sample allocation, game-action cap, turn cap, or statistical criterion. Evaluation and confirmation remain inaccessible. Previous source and failed attempts remain preserved.

## Exact added stops

The real watchdog must impose RLIMIT_FSIZE soft and hard limits of 134217728 bytes (128 MiB) before Java exec. The D2 handshake verifies the actual inherited OS limit before claim/initialization. This is a per-file limit: journal, stdout, and stderr can each reach it. The production child remains -Xmx2048m, 300 seconds external wall time and five seconds TERM grace; internal caps remain 6000 actions, 150 completed player turns, and 300000 ms. No JVM process or RSS bound beyond the heap limit is claimed.

Before launching the child the supervisor requires at least 805306368 bytes (768 MiB) available to the current user on every filesystem containing its evidence directory or proposed journal. The budget comprises three 128 MiB child files plus 384 MiB operating reserve. The check uses current OS free-space facts and is not a reservation against other writers. Insufficient space is durably recorded as a supervisor failure where the remaining storage permits, and no child is launched. A supervisor claim already made remains consumed; no retry or alternate-root interface is added.

File-limit, out-of-memory, write/fsync, space and timeout failures are unresolved attempts, never wins or draws and never fresh replacement samples. Original complete or partial bytes stay intact. A terminal engine marker is insufficient without successful supervision, unchanged sources, strict fresh replay and protocol acceptance. The parent inspection stays bounded and cannot certify a journal by observing an END marker.

## Small memory correction

FreshReplay will retain one authoritative strict journal read/replay. Its two additional full parses are replaced by streaming SHA-256 snapshots of the exact claim, allocation reservation and journal before/after replay. Paths and raw bytes must remain identical; no recovery edits or permissive decoding are introduced. The writer's full record retention and the strict reader's full-text parse remain unchanged.

## Admission and qualification

The added stop is prospective and applies only to the first sixteen allocations of D2. The existing journal, admission, bundle, inline-token and watchdog assertions remain acceptance requirements, together with the fixed resource cases and exact-source qualification. The original ACTIVE_CONTRACT and research/search inputs are unchanged; this additional resource amendment is explicitly bound in the first-cell admission's protocol map.

No success percentage is assigned to an unresolved attempt. A resource cap does not authorize a replacement seed or another run under a new name/root. Investigative replays remain diagnostic replays. If the resource boundary prevents useful precision or coverage, that limitation must be reported rather than changing the limit after seeing the deck outcomes.
