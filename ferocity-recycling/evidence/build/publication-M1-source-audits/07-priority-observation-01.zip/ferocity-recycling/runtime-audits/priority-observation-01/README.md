# Actual priority in gym player observations

This isolated successor changes one shared projection expression: `PlayerView.hasPriority` calls
`GameState.hasPriority(playerId)`. It keeps the raw `priorityPlayerId` and `agentToAct` routing fields.
The existing engine declaration actor can therefore receive its legal declaration input while every
player reports false for actual priority. Shared-team priority reports true for both teammates.
No new engine rules, SDK fields, serialization properties, policy priorities or actor permissions are
introduced. The trusted adapter continues to use the shared builder's player views.

The four prospective fixtures in PRE_EXECUTION_PLAN.json are separate fixed initializations: ordinary
priority/pass, actual attack-to-block declaration and completion, serialized actual block-tax payment,
and a seeded four-player shared-team priority transfer. They compare direct builder and actor views
only for the adapter's valid current actor. The original 61/502 selection and every existing bank stay
intact. This source has zero executed new cases; the build owner must qualify the four and the required
unchanged consumers on an explicitly imported successor.

## Other public consumers

The server's legal menus already use the engine mana-payment window and common `canDeclareBlockers`
query. They retain the actor routing baton without allowing ordinary priority actions during an
unfinished declaration. This successor changes no server behavior.

The legacy client DTO has a nonnullable `priorityPlayerId`, with the transformer substituting the
active player when the engine has no raw holder. Browser helpers use it as an interaction routing
hint. That older client contract does not contain the gym's `PlayerView.hasPriority` boolean and is
not corrected here. Clearing the raw baton would break declaration routing; this patch does not do
that. No claim of complete client priority-label qualification follows from these gym tests.

The observed source ZIP preserves the exact engine/server/client/gym versions read for this audit.
All other programs' lists, policies, protocols, fixtures and seed ledgers remain unchanged. A common
source version and its fresh verification are necessary before any research-game admission.
