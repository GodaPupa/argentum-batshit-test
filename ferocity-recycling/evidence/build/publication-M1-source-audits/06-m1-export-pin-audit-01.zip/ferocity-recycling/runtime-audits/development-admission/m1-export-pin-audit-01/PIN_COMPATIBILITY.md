# M1 export and admission compatibility inventory

This is a read-only source audit and a non-executable inventory. It is not an export plan, a production admission, an allocation ledger or authorization to consume entropy. No exporter/assembler/JVM/game was invoked. Source version and evidence pins must come from the final accepted common-source runtime.

## Exact changes before final material

| Boundary | Required final identity or action | Why |
|---|---|---|
| Red policy | `red-madness-v0.2`; RedMadnessPilot.kt `6ddd9d1daa60e777775b9f66de777b87bb84034b8973c92589d0f5c2ed40cef5` | First post-outcome D1 revision admits the exact qualified Fish Token. Tactical helpers are unchanged; at most v0.3 remains. |
| Red qualification | RedMadnessPilotScenarioTest.kt `fd712e765d3f9b670c2397db4c40c95a1daa9230deaf7e33e3460648796d9089`, all24 fresh cases | Preserved earlier failures cannot become accepted through relabeling. Case10 fixes declared land-drop state; case18 proves actual token and both pilot continuations. |
| Artifact policy | `artifact-control-v0.1`; ArtifactControlPilot.kt `3f92f97465ae3c39ce4d31b57a8f4215a802412510f251857059d4101c377251` | No Artifact tactical/source revision was needed for the Fish. Use the final unchanged runtime source and actual current24 fixture source, not an obsolete initial fixture hash. |
| Export watchdog | trial_watchdog.py `803a03aae3f63ffb114d9a8b56d4bf108b2f5f71f051057e204220f5f52adb37` after actual13 qualification | The prior9-case source3c48 is not the newly admitted supervisor. |
| Export wrapper | export_first_cell.py proposed `29d753603a7b25a6410d834060872146c799ec0c4008b6ab978007aa55b57b69` | Binds new watchdog and actual resource fields. Export remains heap2048m/wall120s/TERM5s; no research command. |
| Assembly helper | assemble_export_plan.py proposed `e0e29897920dcd6043a3ea86511466046dfbd6b313db564f2c987370ab8b60f3` | Its EXPORTER_SHA must equal the new wrapper bytes. |
| Resource protocol | FIRST_CELL_RESOURCE_AMENDMENT.md `356f4c06c9c944334f59856e0f336de8510b7b88c29bda9cdbd3c2d9851ba765` | Import it with source; old five files stay unchanged. |
| Admission source | resource06 FerocityDevelopmentAdmission.kt `ed75e5d32a9eccf90a0379d62716a0a7b695b7196a82f32972df88a03b8b881f`, pending root delta review | Adds exact FerocityPriorityObservationTest=4 to resource05. No existing14 case bodies change. |
| Priority observation | FerocityPriorityObservationTest, exactly4 separately predeclared cases | It must be explicitly required; an aggregate182 or an older observer46 total does not establish this proof. |
| Resource runtime | FerocityResourceBoundaryTest2 and unchanged Admission14/Journal20 plus replay compatibility | New file/space enforcement and single-read replay must pass on the exact combined source. |

The two helper successor is independently peer clear under receipt981659340d4f3bc6cfb01340c06fdbefa17cc48a98ee382266459b8ac070fd73, bound to author fbc8e1f70eff0b578b73211e69d254ce4b3cc50925894b0a738613893fe2da83. Actual exports still wait for source and process gates.

## Six-file protocol digest

The material object must contain the exact path-to-SHA map from `requiredProtocolHashes`; it must not use the raw pretty-printed material-file digest as the protocol identity. The canonical sorted compact JSON map has SHA-256:

`b23496e6c183078a148cdd6c07bd57000670b15f074ffadd110fd5ef41879f2b`

The builder's pretty material file has raw SHA `3d1af913e1e03cc9c87b2aad07f9adce290520344d6de2d90d8ad72b055d30ca`; the different values are intentional. All six bytes were independently checked in the D2 source. The resource file was absent from the active checkout when this audit ran and is part of the authorized import, not an already-installed file.

## Source, policies and runtime pins

1. Publish the final reviewed compiled source version M. Capture the complete compiled-input path-to-SHA map for that version; `sourceTreeSha256` is the canonical map digest. Do not reuse Q3's source digest after Red/resource/projection changes. Every file of each qualification gate's compiled map must occur with identical hash in this final map.
2. Bind final ordered classpath paths, each JAR hash or complete directory-file map, and actual Java executable path/hash. Source-only equality is insufficient to infer bytecode identity. The serializer pin is the actual final compiled FerocityJournalCodec.kt digest. No template, guessed hash or old worktree executable substitutes for the actual runtime.
3. Supply the two complete reviewed policy objects with exactly `{version,files}`. All source/helper entries must be present in the final compiled map. Use Redv0.2 and Artifactv0.1 above. Recompute each `policySha256` from the canonical entire object; changing the version or any included source/fixture changes this digest. Do not edit just a display label while retaining the old policy hash. Shared helper files and the two final fixture sources must be bound by the actual source/gate maps; policy-map membership should match the reviewed intended source closure.
4. The unchanged Java exporter reads only the supplied policy digests and protocol digest, and the assembly helper derives them without hardcoded version strings. No Java/getter source change is needed for Redv0.2 or the sixth protocol.
5. The unchanged36 getter closure remains the33 exact deck names plus Blood, Clue and Wicked Role. Fish Token stays an exact inline recipe/provenance admission, never a fabricated canonical definition. The three frozen deck JSON and main-list hashes remain unchanged.
6. Re-export the raw bundle from the final compiled source once those pins are concrete. Bundle metadata binds source commit/tree/serializer; a prior bundle from a different logical source tree is not interchangeable merely because visible card text is the same. Preserve actual generated card/ability identities in the archive. Load the raw archive for trials/replay, without independently rebuilding a catalog.
7. Preserve all exact generated dependency identities: bundle SHA, ordered-classpath digest, actual Java SHA, each `ferocity/card-source/<sourcePath>`, all four `ferocity/inline-source/` keys, and `ferocity/inline-tokens/gift-fish/v1`. The exporter adds generated keys through a conflict-rejecting putExact; do not prefill them with an old guessed artifact hash. M1 dependencyFiles must cover every non-bundle/non-classpath/non-Java dependency with exact immutable source/artifact references.
8. The offline `artifact-validation-pins.json` binds an export-plan digest and explicit NO_LEDGER marker. It is not M1 or a production seed allocation. M1 must be reviewed and verified separately; only then may an exclusive immutable ledger be reserved. Trial pins replace those offline fields with the actual admission and durable ledger hashes.
9. After sourceM, later evidence-only publication is allowed only through the admission ancestry check, which inspects each intervening commit, including merge-parent diffs, and rejects compiled/build edits even if subsequently reverted. Keep logical M, record actual verification HEAD separately, and preserve the exact canonical repository and evidence paths.

## Gate and supervisor evidence

`verifyDevelopmentGates` requires top-level receipt PASS, sourceguard true, the exact archived validator, matching before/after compiled-map digests, actual fresh task markers, original named XML/log hashes, explicit in-window XML timestamps, exact class counts and zero failures/errors/skips/unaccepted XML. A passing class lifted out of a FAIL receipt is insufficient. Use the new full gym PASS receipt once it exists and actual compatible independently PASS receipts for other required classes; do not manufacture a new PASS summary from Q3 failures.

The prospective combined selection is63 classes/508 fixed cases, including182 gym cases. This does not change Q3's historical selection or a gameplay budget. The final admission required table includes observer28, source12, trigger-order6, priority4, journal20, bundle16, inline12, Artifact24, Red24, Admission14 and resource2; selected card/mechanic coverage additionally references the exact classes that establish each declared behavior. Aggregate totals do not replace that semantic mapping.

M1 watchdog fields must bind exact source803a plus the actual new13-case run receipt, acceptance, tested author/source boundary and one preserved qualified process claim. The tested author reference must contain the `owned_files` entry expected by the verifier (resource SOURCE_FREEZE168a has it; AUTHOR_REVIEW05 does not). The real process claim supplies the actual Python executable/hash; neither the export process's receipt nor a static peer replaces these13 fixed cases. All new resource cases must have executed and passed, with old9 preserved.

Actual D2 supervisor specs must include exact per-file soft/hard134217728 bytes and minimum available805306368 bytes, fixed300s/TERM5s, heap2048m and the strict expected argv/cwd/root/source/pin fields. The child verifies actual inherited limits and the existing strict OS parent/process identity. The JSON file/space fields are part of the spec hash. No override stage, cap, seed, deck, initializer, root alias or replacement interface is added.

The 128MiB calibration is separate observed resource evidence, not gameplay or a universal memory guarantee. Cap/OOM/write/space attempts stay unresolved in planned/attempted counts and diagnostics; no favorable removal from denominators or automatic replacement is authorized.

## Activity of this audit

No exporter, assembler, Java/game initializer, policy proposal or entropy provider was invoked. Python parsing/hashing and source comparisons were read-only. Only this audit and the independently requested peer receipt were written. Actual final source/bytecode/gate material remains to be supplied by the builder/root.
