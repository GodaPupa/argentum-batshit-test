#!/usr/bin/env python3
"""Guard the bounded SDK-only Assay consumer commands; never run gameplay."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time
import urllib.parse
import zipfile


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'out', 'toolchain', 'gradle-home', 'assay-home'):
        ap.add_argument('--' + name, type=Path, required=True)
    args = ap.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    home = args.assay_home.resolve()
    home.mkdir(parents=True, exist_ok=True)
    source_bases = ['mtg-sdk/src/main', 'oracle-assay/src/main', 'buildSrc/src/main',
                    'mtg-sets/src/test/resources/snapshots/cards']
    fixed = ['build.gradle.kts', 'settings.gradle.kts', 'gradle.properties', 'justfile',
             'scripts/gradle-locked', 'gradlew', 'gradlew.bat', 'gradle/libs.versions.toml',
             'gradle/wrapper/gradle-wrapper.properties', 'gradle/wrapper/gradle-wrapper.jar']

    def inputs():
        paths = {root / p for p in fixed}
        paths.update(root.glob('**/build.gradle.kts'))
        paths.update(root.glob('**/settings.gradle.kts'))
        for rel in source_bases:
            paths.update(p for p in (root / rel).rglob('*') if p.is_file())
        return {str(p.relative_to(root)): digest(p) for p in sorted(paths)}

    def installed():
        base = root / 'oracle-assay/build/install/oracle-assay'
        return {str(p.relative_to(base)): digest(p) for p in sorted(base.rglob('*')) if p.is_file()}

    def write(name, value):
        (out / name).write_text(json.dumps(value, indent=2) + '\n')

    commands = [('touchstone-2000', ['just', 'assay-gate', '--limit', '2000'], 600),
                *[(f'differential-{code}', ['just', 'assay-differential', '--set', code, '--top', '1000'], 300)
                  for code in ('BLB', 'OTJ', 'SPM')]]
    receipt = {'schema': 'ferocity-assay-consumer-qualification-v1', 'started_utc': stamp(),
               'status': 'RUNNING', 'scope': 'SDK_PARSER_AND_GOLDEN_DIFFERENTIAL_ONLY',
               'research_games': 0, 'engine_fixed_cases': 0, 'stages': [],
               'commands_declared_before_outcomes': commands,
               'limits': ['Parser/card counts are not game outcomes or engine scenario counts.',
                          'A zero differential exit code only establishes decodable goldens; every divergence still requires classification.',
                          'The first2000 corpus cards are a finite touchstone, not complete parser coverage.',
                          'The raw public bulk remains in the isolated input cache; replay requires exactly its recorded hash.']}
    before = None
    env = os.environ.copy()
    env['JAVA_HOME'] = str(args.toolchain.resolve() / 'jdk-21.0.12.1+1')
    env['PATH'] = str(args.toolchain.resolve()) + ':' + env['JAVA_HOME'] + '/bin:' + env['PATH']
    env['GRADLE_USER_HOME'] = str(args.gradle_home.resolve())
    proxy = urllib.parse.urlparse(env['HTTPS_PROXY'])
    assert not proxy.username and re.fullmatch(r'[A-Za-z0-9.-]+', proxy.hostname or '') and proxy.port
    proxy_flags = (f'-Dhttps.proxyHost={proxy.hostname} -Dhttps.proxyPort={proxy.port} '
                   f'-Dhttp.proxyHost={proxy.hostname} -Dhttp.proxyPort={proxy.port} '
                   '-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts')
    env['GRADLE_OPTS'] = proxy_flags + ' -Dorg.gradle.caching=false -DupdateSnapshots=false'
    env['JAVA_OPTS'] = proxy_flags + ' -Duser.home=' + str(home)
    env['UPDATE_SNAPSHOTS'] = '0'
    corpus = home / '.cache/scryfall/_bulk-oracle-cards.jsonl.gz'

    def run(label, command, timeout):
        stage = {'name': label, 'command': command, 'started_utc': stamp(), 'timeout_seconds': timeout}
        receipt['stages'].append(stage)
        write('receipt.json', receipt)
        log = out / (label + '.log')
        started = time.monotonic()
        with log.open('wb') as stream:
            proc = subprocess.Popen(command, cwd=root, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, start_new_session=True)
            while True:
                try:
                    code = proc.wait(timeout=min(30, max(1, timeout - (time.monotonic() - started))))
                    break
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic() - started
                    print(json.dumps({'stage': label, 'elapsed_seconds': round(elapsed), 'status': 'RUNNING'}), flush=True)
                    if elapsed >= timeout:
                        os.killpg(proc.pid, signal.SIGTERM)
                        try:
                            proc.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(proc.pid, signal.SIGKILL)
                            proc.wait()
                        stage['timed_out'] = True
                        code = 124
                        break
        stage.update(finished_utc=stamp(), exit_status=code, log_sha256=digest(log))
        stage['source_inputs_unchanged'] = inputs() == before
        write('receipt.json', receipt)
        if not stage['source_inputs_unchanged']:
            raise RuntimeError('SDK/build/golden input changed during Assay command')
        return code

    write('receipt.json', receipt)
    try:
        before = inputs()
        write('source-inputs-before.json', before)
        receipt['source_inputs_before_sha256'] = digest(out / 'source-inputs-before.json')
        receipt['source_head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
        receipt['source_roots'] = source_bases
        receipt['runner_sha256'] = digest(Path(__file__))
        shutil.copyfile(Path(__file__), out / 'validator-attempt.py')
        changed = set(subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=root, text=True).splitlines())
        changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines())
        def in_scope(rel):
            return rel in fixed or Path(rel).name in {'build.gradle.kts', 'settings.gradle.kts'} or any(rel.startswith(base + '/') for base in source_bases)
        deleted = sorted(rel for rel in changed if in_scope(rel) and not (root / rel).is_file())
        receipt['deleted_source_inputs'] = deleted
        if deleted:
            raise RuntimeError('This bounded consumer wrapper requires no initially deleted input; preserve and review a deletion-aware successor')
        changed = sorted(changed.intersection(before))
        with zipfile.ZipFile(out / 'source-changes.zip', 'w', zipfile.ZIP_DEFLATED) as z:
            for rel in changed:
                data = (root / rel).read_bytes()
                assert hashlib.sha256(data).hexdigest() == before[rel]
                z.writestr(rel, data)
        receipt['source_changes_sha256'] = digest(out / 'source-changes.zip')
        write('receipt.json', receipt)
        if run('provision-cli-and-corpus', ['just', 'assay', 'corpus'], 600) != 0:
            receipt['status'] = 'BLOCKED_DURING_PROVISIONING'
            return 1
        if not corpus.is_file() or corpus.stat().st_size == 0:
            raise RuntimeError('Corpus command produced no nonempty pinned input')
        binary = installed()
        if not binary or not any(name.endswith('.jar') for name in binary):
            raise RuntimeError('No installed CLI binary dependency closure')
        data_pin = {'path': str(corpus), 'sha256': digest(corpus), 'bytes': corpus.stat().st_size,
                    'retrieved_or_observed_utc': stamp(),
                    'provider_index': 'https://api.scryfall.com/bulk-data',
                    'downloader_source_sha256': before['oracle-assay/src/main/kotlin/com/wingedsheep/assay/corpus/OracleCorpus.kt']}
        freeze = {'schema': 'ferocity-assay-frozen-evaluation-inputs-v1', 'frozen_utc': stamp(),
                  'source_input_sha256': receipt['source_inputs_before_sha256'], 'corpus': data_pin,
                  'installed_cli_files_sha256': binary, 'commands': commands, 'research_games': 0}
        write('FROZEN_CONSUMER_INPUTS.json', freeze)
        receipt['consumer_freeze_sha256'] = digest(out / 'FROZEN_CONSUMER_INPUTS.json')
        print(json.dumps({'consumer_freeze_sha256': receipt['consumer_freeze_sha256'], 'scope': 'first2000_and_three_frozen_golden_sets'}), flush=True)
        codes = []
        for label, command, timeout in commands:
            if digest(corpus) != data_pin['sha256'] or installed() != binary:
                raise RuntimeError('Corpus or installed CLI changed before command')
            codes.append(run(label, command, timeout))
            receipt['stages'][-1]['corpus_and_cli_unchanged'] = digest(corpus) == data_pin['sha256'] and installed() == binary
            write('receipt.json', receipt)
            if not receipt['stages'][-1]['corpus_and_cli_unchanged']:
                raise RuntimeError('Corpus or installed CLI changed during command')
        receipt['status'] = 'EXECUTED_AWAITING_DIVERGENCE_CLASSIFICATION' if all(code == 0 for code in codes) else 'COMMAND_FAILURES_RETAINED'
    except Exception as exc:
        receipt['status'] = 'FAIL_VISIBLE'
        receipt['error'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            after = inputs()
            write('source-inputs-after.json', after)
            receipt['source_inputs_unchanged'] = before is not None and after == before
            if not receipt['source_inputs_unchanged']:
                receipt['status'] = 'INVALID_SOURCE_DRIFT'
        except Exception as exc:
            receipt['status'] = 'FAIL_FINAL_SOURCE_CAPTURE'
            receipt['postcheck_error'] = {'type': type(exc).__name__, 'message': str(exc)}
        receipt['finished_utc'] = stamp()
        write('receipt.json', receipt)
        print(json.dumps({'status': receipt['status'], 'receipt': str(out / 'receipt.json')}), flush=True)
    return 0 if receipt['status'] == 'EXECUTED_AWAITING_DIVERGENCE_CLASSIFICATION' else 1


if __name__ == '__main__':
    raise SystemExit(main())
