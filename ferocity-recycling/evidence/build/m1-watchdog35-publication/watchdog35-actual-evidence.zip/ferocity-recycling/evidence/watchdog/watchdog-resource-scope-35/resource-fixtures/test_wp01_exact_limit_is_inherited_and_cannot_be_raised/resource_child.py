import json, os, pathlib, resource, sys
mode, counter, journal = sys.argv[1:]
limit = 128 * 1024 * 1024
assert resource.getrlimit(resource.RLIMIT_FSIZE) == (limit, limit)
with open(counter, "xb", buffering=0) as out:
    out.write(b"one-launch\n")
    os.fsync(out.fileno())
try:
    resource.setrlimit(resource.RLIMIT_FSIZE, (limit + 1, limit + 1))
except (ValueError, OSError):
    pass
else:
    raise AssertionError("Child raised its hard file limit")
print(json.dumps({"soft": limit, "hard": limit, "gameplay": 0}), flush=True)
if mode == "cap":
    with open(journal, "xb", buffering=0) as out:
        out.write(b'fixed-resource-prefix; not a game journal\n')
        # A sparse extent exercises the actual OS byte-offset limit without wasting 128 MiB
        # of physical storage. The original prefix and entire sparse file are retained.
        out.seek(limit - 1)
        out.write(b"!")
        os.fsync(out.fileno())
        out.write(b"must-fail")
    raise AssertionError("File grew beyond the hard limit")
