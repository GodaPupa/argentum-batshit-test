import json, os, pathlib, signal, subprocess, sys, time
mode, claim_name, counter_name, journal_name, pid_name = sys.argv[1:]
claim = pathlib.Path(claim_name)
assert claim.is_file(), "Supervisor claim was not durable before child initialization"
assert json.loads(claim.read_text())["scope"] == "PROCESS_SUPERVISION_ONLY"
with open(counter_name, "ab", buffering=0) as out:
    out.write(b"one-launch\n")
    os.fsync(out.fileno())
print("fixed dummy child", mode, flush=True)
if mode == "normal":
    sys.exit(0)
if mode == "nonzero":
    sys.exit(17)
if mode == "ignore":
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
if mode == "intent":
    raw = b'{"index":0,"previousSha256":"dummy-fixture-only","record":{"type":"INTENT","submission":1},"sha256":"unverified-dummy-prefix"}\n'
    with open(journal_name, "xb", buffering=0) as out:
        out.write(raw)
        os.fsync(out.fileno())
if mode == "descendant":
    ready = pid_name + ".ready"
    code = "import pathlib,signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); pathlib.Path(" + repr(ready) + ").write_text('ready'); time.sleep(600)"
    child = subprocess.Popen([sys.executable, "-c", code])
    pathlib.Path(pid_name).write_text(str(child.pid))
    deadline = time.monotonic() + 4
    while not pathlib.Path(ready).exists():
        if time.monotonic() >= deadline:
            raise RuntimeError("Fixed child did not initialize")
        time.sleep(0.005)
    sys.exit(0)
while True:
    time.sleep(0.05)
