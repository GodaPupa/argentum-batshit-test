# Watchdog v1.1: usage and fixed results

The first guarded run executed all eight fixed process cases and passed all eight, with no
failures, errors or skips. Seven directly supervised children launched; one fixture deliberately
spawned one additional child in its owned process group. All dummy sources, commands, process
records, logs and the interrupted dummy prefix remain in
`ferocity-recycling/evidence/watchdog/watchdog-first-01/`.

The source was unchanged across the run. The author receipt is
`031d67b252b40cd8e62ebdc1e990bd68d8f55b0ca52ec592e9edf653d578aae5`;
the complete unittest log hash is
`289a42b160529a05e5c531e4e1dbde9d20d5ed7a2d259823ccff389256ff64b0`.
Independent static review identified a spawn-boundary cancellation gap after that run. Its exact
bytes and results remain preserved. Version v1.1 defers soft cancellation during process creation
until the owned handle is assigned, then performs the existing process-group cleanup.

The first nine-case successor executed eight passes and one fixture failure: its broad Popen
injection intercepted an unrelated platform-information subprocess before reaching the tested
launch. This complete failed attempt remains under `watchdog-spawn-cancellation-02`. The fixture
was narrowed to the exact declared dummy argv, with the watchdog runtime bytes unchanged. The
next guarded run, `watchdog-injection-scope-03`, executed and passed all nine cases, with zero
errors or skips and unchanged source hashes. All eight original test bodies remain identical.

The accepted successor runtime SHA is
`3c48f16ac3db1921fe572a9d10c30c22b5665fe0a5fcf66a0bae66d4d6cc233e`;
the nine-case run receipt is
`662bc090d634a0055596a4298fe4606d8d55c55b48a3735ada4df1299d316357`;
the evidence acceptance manifest is
`e7e5bb1b1a4034a613187eb25ca9f6f7239940a0db735614e7f829162d92d1c5`.
Independent source review of the exact successor is bound by
`fb420ebf9347425260e5d1ca53f79e8d8d9c428bb644bcd8458f9ef154face4e`.
The source archives preserve both predecessors. These results qualify the recorded process
fixtures on the captured Python/POSIX environment; they do not qualify the engine, pilots,
fresh-process game replay, or research admission. All gameplay counts remain zero.

## Structured invocation

The trusted trial launcher writes a complete `WatchdogSpec` JSON with all fields present:
`schema_version`, `run_id`, `argv`, `cwd`, `wall_seconds`, `term_grace_seconds`, `journal_path`,
`pinned_files`, `supervisor_sha256`, and `inspection_limit_bytes`. `argv` is an array, its first
entry is an absolute executable path, and its resolved executable plus every declared runtime
input must match the supplied SHA-256 pins. The source SHA must match `trial_watchdog.py`.
Neither file pins nor a successful launch are substitutes for reviewed research admission.

Run:

```bash
python ferocity-recycling/tools/trial_watchdog.py --spec /absolute/path/to/spec.json --output-root /absolute/path/to/supervision
```

The output directory for a run ID is exclusively created and never reopened. A durable claim and
`LAUNCH_INTENT` precede the single `Popen` call. The command uses no shell and inherits the
trusted launcher's environment without logging its contents. Runtime stdout/stderr remain exact
files under that run. Every supervisor event is durably appended with a predecessor hash.

At timeout, the supervisor sends TERM to the child process group and waits the declared grace;
it then sends KILL when the group remains. Child reap and post-KILL observation are bounded.
A normally exited leader with a surviving group also causes cleanup and an unresolved status.
Soft cancellation of the supervisor triggers the same cleanup. The original run identity,
input files, trial journal and allocation ledger are never reset or edited.

## Classification and acceptance

`EXIT_ZERO_REQUIRES_ENGINE_REPLAY` records a process exit only. Nonzero exit, timeout, changed
inputs and surviving descendants are explicitly unresolved. The supervisor sets `game_outcome`
to null for every result. The trusted first-cell wrapper must then run the strict engine journal
reader/replay under the exact pinned source and CardDefinitions before admitting any game.

The `journal` field is a bounded, read-only diagnostic. It records file bytes/hash when within
the inspection limit, identifies truncation and an observed unmatched `INTENT` marker, and always
sets `engine_verified` to false. Even an observed `END` requires the authoritative reader/replay.
The dummy prefix fixture intentionally carries no valid GameState or engine chain; it proves
that process termination does not rewrite the prefix, not that the prefix is gameplay evidence.

## Remaining real integration requirements

The admitted child must remain in its owned process group. A reviewed trial entry point must not
detach new sessions. This supervisor is not an OS sandbox. SIGKILL of the supervisor itself
cannot run Python cleanup, so the outer CI/job owner must clean up the entire job when it kills
the supervisor. The fixed descendant fixture also allows the container's init to retain a dead
zombie briefly; the process cannot execute, and group-disappearance uncertainty is recorded.

Fresh-process replay additionally requires archived exact serialized CardDefinitions, including
their generated AbilityIds. Reloading card source in a different initialization order may change
those IDs. Do not normalize them away in runtime pins, state, actions or replay comparisons.
Source-only normalized card comparisons remain separate metadata checks.
