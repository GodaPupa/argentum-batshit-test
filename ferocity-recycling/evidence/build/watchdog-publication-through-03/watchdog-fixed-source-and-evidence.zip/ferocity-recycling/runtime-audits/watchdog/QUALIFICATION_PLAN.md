# Process watchdog qualification plan v1.1

Frozen before any watchdog fixture execution on 2026-09-26. This is a project-private process
supervisor, not a game engine, pilot, result analyzer, or trial-allocation generator.

The supervisor must reserve its run identity durably before launching exactly one child without
a shell. The claim records its own source/version, interpreter and child executable identities,
the exact command and working directory, input-file pins, inspected journal path, and finite
wall-time and termination-grace limits. No environment credentials are logged. A failed launch,
nonzero exit, timeout, signal, malformed prefix or interrupted action remains visible; no retry
or substitute process is allowed under the same run identity.

The child gets a fresh process group. At timeout, send TERM to that group, then KILL if its
leader does not exit within the fixed grace. Record actual signals, return code and elapsed
times. External cancellation must also terminate the owned child group. The supervisor never
edits trial claims, allocation ledgers, journal bytes or game-result files.

All supervisor outcomes require the independent strict engine journal reader/replay before any
game outcome can be admitted. A zero process exit is not a win, draw, valid game, or successful
experimental sample. Prefix inspection is explicitly structural and unverified: it can identify
an observed unmatched `INTENT` marker or truncation, but cannot certify GameState, event semantics
or the engine hash chain. Every process-level game outcome field remains null.

## Bounded fixture budget

Eight fixed Python child-process tests, authored before execution:

Before the first execution, source review expanded the original seven-case draft to eight by
adding the owned-group descendant case. No earlier watchdog outcomes existed at that revision.

1. Normal child exit 0; exact source/input pins, command, logs and durable claim are recorded.
2. Child exit 17; one launch, nonzero classification, no winner and no retry.
3. Hanging child accepts TERM after a 1.0 second wall cap; TERM is recorded.
4. Hanging child ignores TERM; after 1.0 second wall cap and 0.3 second grace, KILL is recorded.
5. Child writes and fsyncs an explicit dummy `INTENT` prefix then hangs; timeout preserves those
   exact bytes and classifies the observed unmatched prefix as unresolved/unverified.
6. Reusing the supervisor run ID is rejected before a second child launch; files stay intact.
7. A changed declared executable/input hash or unsupported spec schema rejects before launch.
8. A normally exited leader leaves an owned-group child that ignores TERM; the supervisor cleans
   up the remaining group and records unresolved descendant cleanup rather than accepting exit 0.

Normal fixtures have a 5 second wall cap. Termination fixtures have the limits above; after KILL,
direct-child reap and group-disappearance checks each have at most one additional grace bound.
An adopted zombie may leave the group observable after execution has stopped; the supervisor
records that uncertainty and gives no gameplay outcome. There is no
random seed, deck, policy, simulation or gameplay outcome in these fixtures. Dummy prefix bytes
are labeled as process-accounting fixtures and do not pretend to contain a valid engine state.
Finite file inspection limits prevent a large output from turning the supervisor into an
unbounded evidence parser; oversized evidence remains untouched for the strict reader.

The first fixture run will preserve a source manifest, complete unittest log and actual outcome
counts. Failures require a versioned source boundary; do not silently rerun them as fresh proof.
External-watchdog qualification and exact serialized CardDefinition bundles with AbilityIds are
separate admission requirements from the current synchronous journal tests.

## Bounded correction after independent static review

Version v1 executed eight fixed cases with eight passes. Its exact source, receipt and results
remain preserved. Independent review then identified a cancellation window: a signal handler
could raise after the operating system created the child, before `Popen` returned its owned
Python handle. Version v1.1 defers SIGTERM/SIGINT only during creation and assignment, then
consumes the cancellation through the existing group cleanup path. It does not mask signals
in the child process. The eight predecessor test bodies are unchanged.

Before successor outcomes, add exactly one fixed case (nine total): an injected Popen wrapper
starts a real child, waits up to three seconds for its exact dummy intent bytes, signals the
supervisor before returning the real child handle, then returns that handle. Assert cancellation
raises, the owned group is terminated, one durable launch remains, the unmatched intent bytes
remain exact, and no process result or game outcome is created. This injection deliberately
targets the ownership seam; it does not claim probabilistic scheduling coverage. Run one fresh
guarded nine-case successor. Any new failure requires its own preserved diagnostic boundary.
