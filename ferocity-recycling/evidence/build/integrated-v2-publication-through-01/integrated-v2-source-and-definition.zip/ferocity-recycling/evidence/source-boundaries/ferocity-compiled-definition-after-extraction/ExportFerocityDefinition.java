import java.nio.file.Files;
import java.nio.file.Path;
import com.wingedsheep.sdk.model.CardDefinition;
import com.wingedsheep.sdk.serialization.CardSerialization;
import kotlinx.serialization.json.JsonKt;
import kotlin.Unit;

/** Metadata only: load the compiled top-level card value, never create a game or test instance. */
class ExportFerocityDefinition {
    public static void main(String[] arguments) throws Exception {
        CardDefinition card = (CardDefinition) Class.forName(
            "com.wingedsheep.engine.research.ferocity.FerocityOfTheHuntPrereleaseKt"
        ).getMethod("getFerocityOfTheHuntPrerelease").invoke(null);
        var json = JsonKt.Json(CardSerialization.INSTANCE.getJson(), builder -> {
            builder.setEncodeDefaults(true);
            builder.setPrettyPrint(true);
            return Unit.INSTANCE;
        });
        Files.writeString(Path.of(arguments[0]), json.encodeToString(CardDefinition.Companion.serializer(), card));
    }
}
