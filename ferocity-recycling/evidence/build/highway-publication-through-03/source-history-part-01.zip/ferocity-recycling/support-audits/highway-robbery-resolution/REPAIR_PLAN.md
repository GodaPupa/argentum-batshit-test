# Highway Robbery: resolution-time optional payment

Isolated worktree: `ferocity-highway`, branch `engine/ferocity-highway-robbery`, base `2e7e78653ed1c7e56fc609b993a79b68ecca33c6`. Root assigned this selected-card repair; this plan and its eight-case limit precede source changes and all outcomes. Combat and Brew remain frozen in their own worktrees.

## Verified meaning and defect

Current OTJ #129 Oracle text says the controller may discard a card or sacrifice a land and draws two if they do. Plot remains `{1}{R}`. The official release note and current Scryfall ruling exclude a discard choice with no card in hand and a sacrifice choice with no controlled land. CR 608.2d places these choices during resolution. CR 118.12 treats the optional action as a resolution cost: choosing to pay it matters even if a replacement changes the resulting events.

The current canonical card instead exposes a top-level `ModalEffect(countsAsModalSpell=false)`. `CastSpellHandler` detects its type directly and asks while casting. Wrapping that modal would move its prompt, but its executor does not filter impossible payment choices. The existing `IfYouDo` branches also use `SuccessCriterion.Auto`, whose zone-size test can lose the draw when madness redirects a discard to exile.

## Composition-only repair

Replace that top-level modal with existing `Effects.ChooseAction` and three existing `EffectChoice` values:

1. **Discard a card, then draw two cards**: available when `FeasibilityCheck.HasCardsInZone(Zone.HAND)` succeeds; execute the existing real discard pipeline followed by `Effects.DrawCards(2)`.
2. **Sacrifice a land, then draw two cards**: available when `FeasibilityCheck.ControlsPermanentMatching(GameObjectFilter.Land)` succeeds; choose exactly one controlled land, perform its real sacrifice, then draw two.
3. **Decline**: always available; execute an empty composite.

The feasible optional choice commits to paying the selected action; the draw therefore follows the payment regardless of whether a replacement sends the discarded or sacrificed object to a different destination. No priority occurs between that choice, the exact card/land selection, and the draw. Illegal selection responses still reject before resumption. No new SDK type, engine executor, action, decision, or client DTO is required.

At casting, the spell has no chosen modes or additional discard/sacrifice cost and permits ordinary opponent responses. At resolution, the existing `ChooseActionEffectExecutor` issues `ChooseOptionDecision` with `DecisionPhase.RESOLUTION`, the source ID/name, and the available labels above. It may omit either unavailable payment label. With no payable option, the sole decline automatically resolves and no choice is needed. The subsequent real discard/land selection uses existing card-selection decisions. The Red pilot must consume these actual options, without submitting an early cast choice or relying on an option index.

Only the canonical Highway Robbery file, its individual scenario file, and this audit/source archive are owned here. Preserve canonical mechanical/printing metadata; use the fresh source's exact image URL and archive that metadata update. Keep the Plot keyword intact. Do not modify other cards, generic engines, pilots, frozen decks, or other projects.

## Eight fixed deterministic cases

The three existing cases receive explicit timing-correct successors, with their original bytes archived. Five cases are added. No parameterized expansion or random game is authorized.

1. Discard choice occurs at resolution after response priority; selecting one actual card discards it and draws exactly two. Casting consumes no discard and supplies no mode.
2. Sacrifice choice occurs at resolution; selecting one actual controlled land sacrifices that land and draws exactly two.
3. Explicit decline at resolution performs no discard, sacrifice, or draw and finishes once.
4. Empty hand removes the discard option while a controlled land leaves sacrifice and decline available.
5. Empty hand and no controlled lands resolve without a payment prompt or draw.
6. An opponent counters the spell before resolution, with no payment choice, discard, sacrifice, or draw.
7. Discarding Fiery Temper pays through madness exile, still draws two before the madness trigger can resolve, and permits the real madness continuation afterward.
8. Actual Plot special action cannot cast on the same turn; a later-turn plotted cast has no early choice and makes its optional payment during resolution.

All fixtures use fixed scenario state/RNG and sufficient libraries. Assert returned errors and relevant unchanged state/events on invalid selections, exact pending decision phases and options, actual zone transitions, draw counts, and completed-stack state. No gameplay samples, builds, or commits by this author. Required compilation, eight-case execution, and relevant regression gates belong to the coordinated build owner.

## Source receipts and qualification boundary

`SOURCE_BEFORE.json` binds the exact prior canonical card and three-case fixture. `sources/` contains fresh set-qualified Oracle data, all printings, official rulings, a bounded official release-note excerpt, and current CR 118.12/608.2d/702.170 extracts with source hashes. The final source/test bank is to be hashed before any outcome. A build failure must retain its logs and source boundary; an additional case or primitive requires explicit scope review rather than an outcome-driven silent expansion.
