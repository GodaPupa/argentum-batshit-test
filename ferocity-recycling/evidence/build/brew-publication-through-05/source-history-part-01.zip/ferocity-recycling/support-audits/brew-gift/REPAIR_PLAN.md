# Sazacap's Brew: real cast-time Gift

Declared 2026-09-26 before source edits or test outcomes. Isolated base:
`2e7e78653ed1c7e56fc609b993a79b68ecca33c6`, branch `engine/ferocity-brew-gift`.
Root approved this bounded design before implementation. No gameplay allocation is used.

## Evidence and defect

Current BLB #151 and canonical Scryfall records, all two printings, and rulings are
archived under `sources/`, including request dates and response hashes. The exact
current official rules are the 2026-09-25 Comprehensive Rules; the source receipt
binds the full downloaded archive and extracts 601.2b/c/f/h, 608.2b, 702.35,
702.174, and 707.10. Official Bloomburrow release notes corroborate Gift timing.

The baseline Brew is a `countsAsModalSpell=false` modal composition. Exact source
inspection corrected the initial diagnosis: `CastSpellHandler` already chooses
top-level modal branches and their targets during casting, including this shape.
Its `ChooseOpponentForSourceEffect` still chooses the gift recipient on resolution.
The real Gift keyword is restricted to permanents by the DSL and validator, and
its menu postprocessor assumes a promise cannot change targets. Those assumptions
cannot expose Brew's conditional own-creature target through the real Gift menu or
lock the recipient into the actual cast-time Gift declaration.

## Bounded implementation

The contract is a real Gift cast choice and its paid spell shape; the selected card
continues to compose ordinary discard, draw, token creation, and temporary stats.

1. Add defaulted, serializable `giftTargetRequirements` and `giftSpellEffect` to
   `CardScript`, with named `giftTarget` bindings and `giftEffect` in `SpellBuilder`.
   They specify the complete alternate target/effect shape when promised, exactly
   as existing kicker/cleave shapes do. They are not modes or a second cost flag.
2. Let `gift(kind)` add the keyword to any spell; derive an enters trigger only
   for a permanent. Admit instant/sorcery Gift in the validator. Preserve all
   permanent Gift behavior and tests. Update target/dataflow linting and SDK docs.
3. `CastSpellHandler` selects the promised target/effect shape while validating
   and constructing the spell, before any discard cost is paid. It retains exact
   `TargetsComponent` requirements for ordinary 608.2b partial-fizzle handling.
4. `CastSpellEnumerator` recomputes the promised target domain for every existing
   affordable Gift cast path. No own creature suppresses the promised branch only;
   nongift remains legal. Preserve all additional-cost and payment metadata.
5. `StackResolver` selects the promised main effect and prefixes existing
   `giftEffect(kind)` before every main effect, then emits `GiftGiven` in the
   existing spell finalizer after all main and spliced text (702.174c concerns
   the whole promised spell resolving). Seed the existing
   resolution chosen-opponent pipeline entry from `SpellOnStackComponent`.
   Countered/all-illegal spells never reach that prefix. Copies retain the original
   promise and recipient through the existing spell-component copy path. A copied
   spell does not repromise, retarget the recipient, or pay another discard cost.
6. Replace only Brew's canonical body; keep the exact current Oracle metadata and
   existing discard cost. Nongift: player target/draw two. Promised: player and
   own-creature targets/draw two/+2/+0 until end of turn. No new engine effect,
   action, decision DTO, event type, or GameState field is needed.
7. Trace existing public `giftPromised`, target-selection, discard selection,
   and `CastWithGift` client paths. The Red pilot consumes their actual menu data.
   Existing unselected legacy modal Gift cards are unchanged and remain outside
   this repair's admission claim. Mark the old helper as a legacy approximation.

Primary edit paths are `mtg-sdk/.../{model/CardScript.kt,dsl/CardBuilder.kt,
dsl/mechanics/GiftDsl.kt,serialization/CardValidator.kt,serialization/CardLinter.kt}`,
`rules-engine/.../{handlers/actions/spell/CastSpellHandler.kt,
legalactions/enumerators/CastSpellEnumerator.kt,mechanics/stack/StackResolver.kt}`,
the canonical BLB Brew, and corresponding SDK/reference documentation. Supporting
comments in keyword, choice-slot, stack/action/view files may be corrected without
changing their serialized shape. Assay remains a required compile/gate consumer;
no new parser approximation is permitted.

## Finite deterministic qualification budget

Maximum **33 new or revised deterministic cases** before the first test outcomes:
up to **20 dedicated Brew cases**, **8 generic Gift engine cases**, and **5 SDK
cases**. Existing permanent Gift cases are retained as regressions and are not new
development evidence. Parameterized expansions count as separate cases. No random
games, mulligan samples, or pilot training occurs in this batch.

The matrix covers: legal promised/nongift menu and exact conditional domains;
no own creature; forged missing, enemy, extra, or illegal recipient targets;
required discard and unchanged returned failure state; locked choices and discard
before priority; promise/recipient/action/state serialization; tapped Fish before
draw/buff and exactly one give-gift event; no gift if countered or all targets
illegal; remaining player or creature target still works if the other becomes
illegal; end-of-turn removal; copied paid promise without extra cost; madness cost
exile/trigger and its spell resolving before Brew; free-cast additional cost and
promised target requirements; multiplayer recipient remains chosen, not retargeted.

Builds run only in the root-coordinated `just` gate. Authored fixtures are not passes.
Preserve failed XML/logs and source hashes; assess any new failure before repair.
No existing unrelated frozen tests, lists, policies, or evidence are rewritten.
Stop optional testing when this selected Gift scope and required regression gates
are sufficiently qualified. An uncovered concrete case may require a declared
pre-outcome budget revision, never a silent skip or favorable reroll.

## Limits and compatibility

This is an additive serialized SDK version boundary; absent new fields mean the
old base shape. Old Brew bytes and relevant old tests are archived before editing.
Changing Brew's canonical body invalidates any prior Brew gameplay source version;
there are no accepted Ferocity gameplay samples using it. No untested joint
Gift/kicker/cleave/modal/face composition is claimed by this card qualification.
Target/effect precedence is explicit; ambiguous simultaneous alternate shapes
must fail visibly rather than silently select an incompatible shape.

Pre-outcome implementation bound: the promised shape retains the exact base
target prefix and may append conditional targets. This is sufficient for Brew and
guarantees a satisfiable promised shape has an enumerable base cast. A generic
replacement target shape that could be legal while the base has no targets would
require another cast-enumeration path; the SDK validator and runtime explicitly
reject it, along with combined modal/kicker/cleave/face shapes. This limitation is
not presented as support for every Gift card.

Read-only peer review found that a marker in the main composite precedes the
existing splice continuation. Before any outcomes, the marker moved to the
existing whole-spell finalizer, and `CastWithSplice` became an expandable Gift
payment path. `pre-finalizer-amendment/` retains the preceding source bytes and
test bank. One redundant generic nongift-only case was replaced by an actual
Gift plus splice draw case; the maximum and authored total remain 33. Invalid
cast fixtures also require no emitted cost or trigger events.

The finalizer deliberately follows the captured resolving stack ObjectRef.
Authored effects that move their own resolving source before completion require
separate qualification of the completion marker; they are outside this repair's
admitted source pool. Brew and the generic fixtures do not do this. Ordinary
graveyard/exile destinations applied *after* resolution and copied-spell cleanup
still pass through the finalizer.
