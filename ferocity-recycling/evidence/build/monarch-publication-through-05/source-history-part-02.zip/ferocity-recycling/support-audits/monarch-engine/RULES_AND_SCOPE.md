# Monarch and shared inherent-trigger scope

Source: current official Comprehensive Rules2026-09-25, locally verified by the independent rules audit at the root project's recorded Wizards URL. The retained excerpt and original source digest bind CR725–726; CR603.3b/d,603.5 and608.2h govern ordering, target placement, optional choices and last-known information. Thorn/Commodore canonical text, earliest printing eligibility and rulings have separate sourced crown-card records.

The core implements the unique designation, genuine source-free end-step/combat triggered stack abilities, ordinary responses/counter/copy behavior, independent ability controller and drawing player, exact original-creature controller lookup, disappearance/token/return LKI, player departure, public DTO/JSON/badges, and generic same-controller placement ordering. It depends on the separately versioned LKI repair and the independently reviewed bare optional-target timing correction. It does not claim to implement arbitrary monarch-dependent static abilities or future prohibition/replacement effects absent from the bounded card pool. New such card text requires new support and qualification.

Damage events retain a shared monotonic combat batch identity and both designation holders before damage. The creature snapshot describes the simultaneous pre-damage original object. Monarch checks one trigger per creature; initiative uses one per player group. These must not be conflated. Monarch's singular 'its controller' follows current original-object information at resolution or departure LKI. Initiative's supplied Avenging Hunter ruling binds the player whose creatures dealt the damage.

Tests are deterministic fixtures and source/serialization/visibility checks. No randomized development, evaluation, confirmation, postboard or match results are produced by these tests. All source is unqualified until the guarded real build and required gates complete. Existing test failures and root optional-target baseline are retained; no past gameplay allocation is borrowed.

Public interface: ClientPlayer.isMonarch and hasInitiative, server-driven holder badges, sourceId=null on source-free ability stack events. Existing ChooseOptionDecision renders ordered trigger choices; no client rules or library/hand access is introduced.

## Target-selection source identity amendment

Static integration review found that `TriggeredAbilityContinuation` previously omitted the departing source snapshot even when the originating `PendingTrigger` retained it. The added pass-through carries both the ability source and the separately referenced triggering object through target selection and damage distribution, and chooses source snapshots only when their exact object reference matches the trigger origin. It never falls back to a returned creature's new projection.

`SourceSnapshotContinuationScenarioTest` is one separately identified authored fixture: destroy a token with a targeted dies ability, verify the token has ceased to exist before answering the target decision, round-trip the suspended state and stacked ability through engine serialization, then require one deathtouch damage to kill a 6/4 and produce exactly one lifelink life. It has not executed at this source boundary.

## Shared designation succession

`DesignationSuccession` implements the common surviving-active-player / next-surviving-seat rule of CR 725.4 and 726.4. Monarch departure emits a designation change. Initiative departure invokes the real initiative service and propagates its take event so the inherent venture trigger can be detected normally. No dungeon progress is granted directly by the monarch code.

The engine still has pre-existing documented limits in multiplayer mass-removal trigger handling inside `PlayerLeavesGameProcessor`. This project does not claim universal multiplayer support from the two ordinary three-player concession fixtures. The research gauntlet is two-player.

## Authored counts after integration review

At this boundary the source contains 18 monarch cases (including a lethal-combat holder-capture case), 6 generic trigger-order cases, 1 source-snapshot target-continuation case, the separately authored 8 crown-card cases, and the separately reviewed 7 optional-trigger cases. Those 40 cases are authored, not executed in this combined worktree. All gameplay-development, frozen-evaluation and confirmation counts remain zero here. Both multiplayer initializer fixtures have explicit `GameConfig.seed = 0xFE000080`; no entropy-seeded fixture is presented as seed-free evidence.

## Generic ordering concession preservation

A controller's new ordering question can occur after a stack object has resolved. The existing departure handler preserved automatic pending-trigger queues only during a post-cast boundary and discarded them during a post-resolution boundary. The narrowly scoped integration repair now collects those existing automatic queues in their ordinary top-first continuation order, preserves each exact trigger object, and resumes the existing priority processor for surviving controllers. The eventual priority recipient remains the active player after resolution, redirected to a surviving seat when required.

`TriggerOrderingConcessionScenarioTest` adds one separately identified three-player fixed fixture, bringing this source's authored count to 41. It proves only generic trigger queue preservation; it contains no initiative. Initiative remains bounded to its author's two-player admission rule. No ordinary multiplayer initiative-concession routing was added. The pre-fix source bytes are retained in `evidence/source-boundaries/before-ordering-concession-preservation/`.
