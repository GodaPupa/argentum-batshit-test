import { EntityId } from './entities'
import { DayNight } from './enums'

/**
 * Client-facing game events.
 * Matches backend ClientEvent.kt
 *
 * These are simplified versions of internal GameActionEvents for
 * driving animations and displaying game log.
 */
export type ClientEvent =
  | LifeChangedEvent
  | SpeedChangedEvent
  | DayNightChangedEvent
  | InitiativeTakenEvent
  | DungeonRoomEnteredEvent
  | DungeonCompletedEvent
  | DamageDealtEvent
  | StatsModifiedEvent
  | CardDrawnEvent
  | CardDiscardedEvent
  | PermanentEnteredEvent
  | PermanentLeftEvent
  | CreatureAttackedEvent
  | CreatureBlockedEvent
  | CreatureDiedEvent
  | SpellCastEvent
  | SpellResolvedEvent
  | SpellCounteredEvent
  | AbilityTriggeredEvent
  | AbilityActivatedEvent
  | AbilityAutoAnsweredEvent
  | PermanentTappedEvent
  | PermanentUntappedEvent
  | CounterAddedEvent
  | CounterRemovedEvent
  | ManaAddedEvent
  | PlayerLostEvent
  | GameEndedEvent
  | HandLookedAtEvent
  | HandRevealedEvent
  | CardsRevealedEvent
  | TurnedFaceUpEvent
  | TransformedEvent
  | CoinFlippedEvent
  | TurnChangedEvent
  | ControlChangedEvent
  | CardCycledEvent
  | LibraryShuffledEvent
  | AbilityFizzledEvent
  | PermanentsSacrificedEvent
  | TargetReselectedEvent
  | DecisionMadeEvent

// ============================================================================
// Life/Damage Events
// ============================================================================

export interface LifeChangedEvent {
  readonly type: 'lifeChanged'
  readonly playerId: EntityId
  readonly oldLife: number
  readonly newLife: number
  readonly change: number
  readonly description: string
}

/**
 * A player's speed went up (Aetherdrift, CR 702.179) — "Start your engines!" starting it at 1
 * (`oldSpeed` 0) or the inherent speed trigger raising it. `reachedMaxSpeed` fires at most once per
 * player per game, since speed only rises and stops at 4.
 */
export interface SpeedChangedEvent {
  readonly type: 'speedChanged'
  readonly playerId: EntityId
  readonly oldSpeed: number
  readonly newSpeed: number
  readonly isYours?: boolean
  readonly reachedMaxSpeed: boolean
  readonly description: string
}

/**
 * The game's day/night designation changed (Innistrad, CR 731). `oldDesignation` is null when the game
 * leaves the neither state it starts in; a non-null → non-null change is a day↔night flip (CR 731.1a).
 */
export interface DayNightChangedEvent {
  readonly type: 'dayNightChanged'
  readonly oldDesignation: DayNight | null
  readonly newDesignation: DayNight
  readonly sourceName: string
  readonly description: string
}

export interface InitiativeTakenEvent {
  readonly type: 'initiativeTaken'
  readonly playerId: EntityId
  readonly previousHolderId: EntityId | null
  readonly description: string
}

export interface DungeonRoomEnteredEvent {
  readonly type: 'dungeonRoomEntered'
  readonly playerId: EntityId
  readonly dungeonId: EntityId
  readonly roomId: string
  readonly roomName: string
  readonly description: string
}

export interface DungeonCompletedEvent {
  readonly type: 'dungeonCompleted'
  readonly playerId: EntityId
  readonly dungeonId: EntityId
  readonly description: string
}

export interface DamageDealtEvent {
  readonly type: 'damageDealt'
  readonly sourceId: EntityId | null
  readonly sourceName: string | null
  readonly targetId: EntityId
  readonly targetName: string
  readonly amount: number
  readonly targetIsPlayer: boolean
  readonly isCombatDamage: boolean
  readonly description: string
}

export interface StatsModifiedEvent {
  readonly type: 'statsModified'
  readonly targetId: EntityId
  readonly targetName: string
  readonly powerChange: number
  readonly toughnessChange: number
  readonly sourceName: string
  readonly description: string
}

// ============================================================================
// Card Movement Events
// ============================================================================

export interface CardDrawnEvent {
  readonly type: 'cardDrawn'
  readonly playerId: EntityId
  readonly cardId: EntityId
  readonly cardName: string | null // Null if hidden from viewing player
  readonly description: string
}

export interface CardDiscardedEvent {
  readonly type: 'cardDiscarded'
  readonly playerId: EntityId
  readonly cardId: EntityId
  readonly cardName: string
  readonly description: string
}

export interface PermanentEnteredEvent {
  readonly type: 'permanentEntered'
  readonly cardId: EntityId
  readonly cardName: string
  readonly controllerId: EntityId
  readonly enteredTapped: boolean
  readonly copyOf?: string
  readonly description: string
}

export interface PermanentLeftEvent {
  readonly type: 'permanentLeft'
  readonly cardId: EntityId
  readonly cardName: string
  readonly destination: 'graveyard' | 'exile' | 'hand' | 'library'
  readonly description: string
}

// ============================================================================
// Combat Events
// ============================================================================

export interface CreatureAttackedEvent {
  readonly type: 'creatureAttacked'
  readonly creatureId: EntityId
  readonly creatureName: string
  readonly attackingPlayerId: EntityId
  readonly defendingPlayerId: EntityId
  readonly description: string
}

export interface CreatureBlockedEvent {
  readonly type: 'creatureBlocked'
  readonly blockerId: EntityId
  readonly blockerName: string
  readonly attackerId: EntityId
  readonly attackerName: string
  readonly description: string
}

export interface CreatureDiedEvent {
  readonly type: 'creatureDied'
  readonly creatureId: EntityId
  readonly creatureName: string
  readonly description: string
}

// ============================================================================
// Spell/Ability Events
// ============================================================================

export interface SpellCastEvent {
  readonly type: 'spellCast'
  readonly spellId: EntityId
  readonly spellName: string
  readonly casterId: EntityId
  /**
   * How the spell was cast — "disturb, from graveyard", "from command zone" — or absent for an
   * ordinary cast from hand. Already folded into {@link description}; present separately so the
   * log could style it without re-deriving it.
   */
  readonly castProvenance?: string
  readonly description: string
}

export interface SpellResolvedEvent {
  readonly type: 'spellResolved'
  readonly spellId: EntityId
  readonly spellName: string
  readonly description: string
}

export interface SpellCounteredEvent {
  readonly type: 'spellCountered'
  readonly spellId: EntityId
  readonly spellName: string
  readonly description: string
}

export interface AbilityTriggeredEvent {
  readonly type: 'abilityTriggered'
  readonly sourceId: EntityId
  readonly sourceName: string
  readonly abilityDescription: string
  readonly description: string
}

export interface AbilityActivatedEvent {
  readonly type: 'abilityActivated'
  readonly sourceId: EntityId
  readonly sourceName: string
  readonly abilityDescription: string
  readonly description: string
}

/** A "you may" may-question was auto-resolved from the viewer's persistent yield (backlog §C). */
export interface AbilityAutoAnsweredEvent {
  readonly type: 'abilityAutoAnswered'
  readonly sourceId: EntityId
  readonly sourceName: string
  readonly answer: boolean
  readonly description: string
}

// ============================================================================
// State Change Events
// ============================================================================

export interface PermanentTappedEvent {
  readonly type: 'permanentTapped'
  readonly permanentId: EntityId
  readonly permanentName: string
  readonly description: string
}

export interface PermanentUntappedEvent {
  readonly type: 'permanentUntapped'
  readonly permanentId: EntityId
  readonly permanentName: string
  readonly description: string
}

export interface CounterAddedEvent {
  readonly type: 'counterAdded'
  readonly permanentId: EntityId
  readonly permanentName: string
  readonly counterType: string
  readonly count: number
  readonly description: string
}

export interface CounterRemovedEvent {
  readonly type: 'counterRemoved'
  readonly permanentId: EntityId
  readonly permanentName: string
  readonly counterType: string
  readonly count: number
  readonly description: string
}

// ============================================================================
// Mana Events
// ============================================================================

export interface ManaAddedEvent {
  readonly type: 'manaAdded'
  readonly playerId: EntityId
  readonly manaString: string // e.g., "{G}{G}" or "{R}"
  readonly description: string
}

// ============================================================================
// Game State Events
// ============================================================================

export interface PlayerLostEvent {
  readonly type: 'playerLost'
  readonly playerId: EntityId
  readonly reason: string
  readonly description: string
}

export interface GameEndedEvent {
  readonly type: 'gameEnded'
  readonly winnerId: EntityId | null
  readonly description: string
}

// ============================================================================
// Information Events
// ============================================================================

export interface HandLookedAtEvent {
  readonly type: 'handLookedAt'
  readonly viewingPlayerId: EntityId
  readonly targetPlayerId: EntityId
  readonly cardIds: readonly EntityId[]
  readonly description: string
}

export interface HandRevealedEvent {
  readonly type: 'handRevealed'
  readonly revealingPlayerId: EntityId
  readonly cardIds: readonly EntityId[]
  readonly description: string
}

export interface CardsRevealedEvent {
  readonly type: 'cardsRevealed'
  readonly revealingPlayerId: EntityId
  readonly cardIds: readonly EntityId[]
  readonly cardNames: readonly string[]
  readonly imageUris: readonly (string | null)[]
  readonly source: string | null
  /** Owner of each revealed card (parallel to cardIds); set for multi-player reveals. */
  readonly cardOwnerIds?: readonly EntityId[]
  /** Set when the reveal represents a zone transition (e.g., GRAVEYARD → HAND). */
  readonly fromZone?: string | null
  readonly toZone?: string | null
  readonly description: string
}

// ============================================================================
// Transform Events
// ============================================================================

export interface TransformedEvent {
  readonly type: 'transformed'
  readonly cardId: EntityId
  readonly newFaceName: string
  readonly intoBackFace: boolean
  readonly controllerId: EntityId
  readonly isYours: boolean | null
  readonly description: string
}

// ============================================================================
// Coin Flip Events
// ============================================================================

export interface CoinFlippedEvent {
  readonly type: 'coinFlipped'
  readonly playerId: EntityId
  readonly won: boolean
  readonly sourceId: EntityId
  readonly sourceName: string
  /**
   * True when a "flip N coins and ignore all but one" replacement (Krark's Thumb) discarded this
   * flip. The coin really was flipped, so it is still shown, but its result decided nothing.
   */
  readonly ignored?: boolean
  readonly description: string
}

// ============================================================================
// Morph Events
// ============================================================================

export interface TurnedFaceUpEvent {
  readonly type: 'turnedFaceUp'
  readonly cardId: EntityId
  readonly cardName: string
  readonly controllerId: EntityId
  readonly description: string
}

// ============================================================================
// Turn Events
// ============================================================================

export interface TurnChangedEvent {
  readonly type: 'turnChanged'
  readonly turnNumber: number
  readonly activePlayerId: EntityId
  readonly isYourTurn: boolean | null
  readonly description: string
}

// ============================================================================
// Control Events
// ============================================================================

export interface ControlChangedEvent {
  readonly type: 'controlChanged'
  readonly permanentName: string
  readonly newControllerId: EntityId
  readonly isYours: boolean | null
  readonly description: string
}

// ============================================================================
// Cycling Events
// ============================================================================

export interface CardCycledEvent {
  readonly type: 'cardCycled'
  readonly playerId: EntityId
  readonly cardName: string
  readonly isYours: boolean | null
  readonly description: string
}

// ============================================================================
// Library Events
// ============================================================================

export interface LibraryShuffledEvent {
  readonly type: 'libraryShuffled'
  readonly playerId: EntityId
  readonly isYours: boolean | null
  readonly description: string
}

// ============================================================================
// Fizzle Events
// ============================================================================

export interface AbilityFizzledEvent {
  readonly type: 'abilityFizzled'
  readonly abilityDescription: string
  readonly reason: string
  readonly description: string
}

// ============================================================================
// Sacrifice Events
// ============================================================================

export interface PermanentsSacrificedEvent {
  readonly type: 'permanentsSacrificed'
  readonly playerId: EntityId
  readonly permanentNames: readonly string[]
  readonly isYours: boolean | null
  readonly description: string
}

// ============================================================================
// Target Reselection Events
// ============================================================================

export interface TargetReselectedEvent {
  readonly type: 'targetReselected'
  readonly spellOrAbilityName: string
  readonly oldTargetName: string
  readonly newTargetName: string
  readonly sourceName: string
  readonly description: string
}

// ============================================================================
// Decision Events
// ============================================================================

export interface DecisionMadeEvent {
  readonly type: 'decisionMade'
  readonly playerId: EntityId
  readonly isYours: boolean | null
  readonly description: string
}

// ============================================================================
// Type Guards
// ============================================================================

export function isLifeChangedEvent(event: ClientEvent): event is LifeChangedEvent {
  return event.type === 'lifeChanged'
}

export function isSpeedChangedEvent(event: ClientEvent): event is SpeedChangedEvent {
  return event.type === 'speedChanged'
}

export function isDamageDealtEvent(event: ClientEvent): event is DamageDealtEvent {
  return event.type === 'damageDealt'
}

export function isStatsModifiedEvent(event: ClientEvent): event is StatsModifiedEvent {
  return event.type === 'statsModified'
}

export function isCardDrawnEvent(event: ClientEvent): event is CardDrawnEvent {
  return event.type === 'cardDrawn'
}

export function isPermanentEnteredEvent(event: ClientEvent): event is PermanentEnteredEvent {
  return event.type === 'permanentEntered'
}

export function isCreatureDiedEvent(event: ClientEvent): event is CreatureDiedEvent {
  return event.type === 'creatureDied'
}

export function isSpellCastEvent(event: ClientEvent): event is SpellCastEvent {
  return event.type === 'spellCast'
}

export function isPermanentTappedEvent(event: ClientEvent): event is PermanentTappedEvent {
  return event.type === 'permanentTapped'
}

export function isPermanentUntappedEvent(event: ClientEvent): event is PermanentUntappedEvent {
  return event.type === 'permanentUntapped'
}

export function isHandLookedAtEvent(event: ClientEvent): event is HandLookedAtEvent {
  return event.type === 'handLookedAt'
}
